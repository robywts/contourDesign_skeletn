// require('dotenv').config();
// require('./app/config/database'); //DB Connection

var CronJob = require('cron').CronJob;
var playerGameStats = require('../app/modules/crons/playerGameStatsCron');

var winston = require('winston');
var logger = new(winston.Logger)({
  transports: [
    new(winston.transports.Console)(),
    new(winston.transports.File)({
      filename: './app/modules/crons/logs/cronError.log'
    })
  ]
});

const timeZone = 'America/Los_Angeles';

module.exports = {
  playerGames: function () {
    /**
     * MLB player games data taken from the stats (annual stats and all games) - Time interval (runs once every day)
     */
    try {

      /**
       * Runs Everyday at 1:10 AM
       */
      new CronJob('0 10 1 * * *', function () {
        try {
          // logger.info('1' + '-' + 'annualStats');
          playerGameStats.playerGameByGameStats('annualStats', '1');
        } catch (ex) {
          logger.info(ex);
        }
      }, null, true, timeZone);

      /**
       * Runs Everyday at 1:40 AM
       */
      new CronJob('0 40 1 * * *', function () {
        try {
          // logger.info('1' + '-' + 'allGames');
          playerGameStats.playerGameByGameStats('allGames', '1');
        } catch (ex) {
          logger.info(ex);
        }
      }, null, true, timeZone);

      /**
       * Runs Everyday at 2:10 AM
       */
      new CronJob('0 10 2 * * *', function () {
        try {
          // logger.info('2' + '-' + 'annualStats');
          playerGameStats.playerGameByGameStats('annualStats', '2');
        } catch (ex) {
          logger.info(ex);
        }
      }, null, true, timeZone);

      /**
       * Runs Everyday at 2:40 AM
       */
      new CronJob('0 40 2 * * *', function () {
        try {
          // logger.info('2' + '-' + 'allGames');
          playerGameStats.playerGameByGameStats('allGames', '2');
        } catch (ex) {
          logger.info(ex);
        }
      }, null, true, timeZone);

      /**
       * Runs Everyday at 3:10 AM
       */
      new CronJob('0 10 3 * * *', function () {
        try {
          // logger.info('3' + '-' + 'annualStats');
          playerGameStats.playerGameByGameStats('annualStats', '3');
        } catch (ex) {
          logger.info(ex);
        }
      }, null, true, timeZone);

      /**
       * Runs Everyday at 3:40 AM
       */
      new CronJob('0 40 3 * * *', function () {
        try {
          // logger.info('3' + '-' + 'allGames');
          playerGameStats.playerGameByGameStats('allGames', '3');
        } catch (ex) {
          logger.info(ex);
        }
      }, null, true, timeZone);

      /**
       * Runs Everyday at 4:10 AM
       */
      new CronJob('0 10 4 * * *', function () {
        try {
          // logger.info('4' + '-' + 'annualStats');
          playerGameStats.playerGameByGameStats('annualStats', '4');
        } catch (ex) {
          logger.info(ex);
        }
      }, null, true, timeZone);

      /**
       * Runs Everyday at 4:40 AM
       */
      new CronJob('0 40 4 * * *', function () {
        try {
          // logger.info('4' + '-' + 'allGames');
          playerGameStats.playerGameByGameStats('allGames', '4');
        } catch (ex) {
          logger.info(ex);
        }
      }, null, true, timeZone);

      /**
       * Runs Everyday at 5:10 AM
       */
      new CronJob('0 10 5 * * *', function () {
        try {
          // logger.info('5' + '-' + 'annualStats');
          playerGameStats.playerGameByGameStats('annualStats', '5');
        } catch (ex) {
          logger.info(ex);
        }
      }, null, true, timeZone);

      /**
       * Runs Everyday at 5:40 AM
       */
      new CronJob('0 40 5 * * *', function () {
        try {
          // logger.info('5' + '-' + 'allGames');
          playerGameStats.playerGameByGameStats('allGames', '5');
        } catch (ex) {
          logger.info(ex);
        }
      }, null, true, timeZone);

    } catch (ex) {
      logger.info(ex);
    }
  }
}