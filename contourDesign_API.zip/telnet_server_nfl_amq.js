/**
 * Telnet
 * @exports Telnet/Stats
 */
var Telnet = require('telnet-client');
var fs = require('fs');
var winston = require('winston');
//var Stomp = require('stomp-client');
var logger = new(winston.Logger)({
  transports: [
    new(winston.transports.Console)(),
    new(winston.transports.File)({
      filename: './app/modules/crons/logs/nfl_socket.log'
    })
  ]
});

var connection = new Telnet();

var params = {
  host: 'socket1.stats.com',
  port: 32102,
  //shellPrompt: '/ # ',
  shellPrompt: 'Logon Successful',
  timeout: 30000,
  // removeEcho: 4
  debug: true,
  execTimeout: 30000,
  sendTimeout: 30000,
  echoLines: 500,
  username: 'contour',
  password: 'football1999',
  loginPrompt: 'Login Username:',
  passwordPrompt: 'Password:'
};

// var destinationQueue = '/queue/NflQueue';

// var qparams = {
//   address: '35.162.54.12',
//   //address: '127.0.0.1',
//   port: 61613,
//   //user: 'vijaykaimal',
//   //pass: 'user123'
// };

var event = Date.now();

/**
 * When the connection is ready
 */
connection.on('ready', function (prompt) {
  logger.info('Ready: ' + prompt);
});

/**
 * When the data keep coming from the server
 */
connection.on('data', function (message) {
  var msg = message.toString();

  while (msg.indexOf("Ping ") >= 0) {
    var pingIndex = msg.indexOf("Ping ");
    var sliced = msg.slice(pingIndex, (pingIndex + 27));
    msg = msg.replace(sliced, '');
  }

  if (msg.indexOf("</nfl-event>") >= 0) {
    var msgArr = msg.toString().split("</nfl-event>");

    for (var i = 0; i < msgArr.length; i++) {
      if ((i + 1) != msgArr.length) { // not the last item
        appendToFile(msgArr[i] + "</nfl-event>", 'incre');
      } else { // last item
        appendToFile(msgArr[i], '');
      }
    }
  } else { // no closing tag in the data
    appendToFile(msg, '');
  }
});

function appendToFile(msg, eventCounter) {
  fs.appendFileSync('./temp/nfl/unprocessed/telnet_nfl_' + event + '.txt', msg);
  if (eventCounter == 'incre') {
    if (Date.now() != event) {
    //   var telnetNflFile = 'telnet_nfl_' + event + '.txt';
    //   sendFileNameToQueue(telnetNflFile);
      event = Date.now();
    } else {
      while (fs.existsSync('./temp/nfl/unprocessed/telnet_nfl_' + event + '.txt')) {
        event += 'a';
      }
    }
  }
}

// function sendFileNameToQueue(telnetNflFile) {
//   try{
//     var client = new Stomp(qparams);
//     client.connect(function(sessionId) {
//       client.publish(destinationQueue, telnetNflFile);
//     });
//   } catch(e){
//     logger.info(e);
//   }
// }

/**
 * When timeout happened
 */
connection.on('timeout', function () {
  logger.info('socket timeout!');
  connection.end();
});

/**
 * When the other end of the socked ended
 */
connection.on('end', function () {
  logger.info('Connection ended');
});

/**
 * When the connection fully closed
 */
connection.on('close', function () {
  logger.info('Connection closed');
});

/**
 * When an error happends
 */
connection.on('error', function () {
  logger.info('An error occured');
});

/**
 * When the login credential is wrong
 */
connection.on('failedlogin', function () {
  logger.info('Login Mismatch');
});

connection.connect(params);