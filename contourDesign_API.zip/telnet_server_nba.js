/**
 * Telnet
 * @exports Telnet/Stats
 */
var Telnet = require('telnet-client');
var fs = require('fs');
var connection = new Telnet();

var params = {
  host: 'socket1.stats.com',
  port: 32104,
  //shellPrompt: '/ # ',
  shellPrompt: 'Logon Successful',
  timeout: 30000,
  // removeEcho: 4
  debug: true,
  execTimeout: 30000,
  sendTimeout: 30000,
  echoLines: 500,
  username: 'Contour_NBA',
  password: 'b@skets94',
  loginPrompt: 'Login Username:',
  passwordPrompt: 'Password:'
};

/**
 * When the connection is ready
 */
connection.on('ready', function(prompt) {
  console.log(prompt);
  // connection.exec(cmd, function(err, response) {
  //   console.log(response);
  // })
});

/**
 * When the data keep coming from the server
 */
connection.on('data', function(message) {
  //console.log(message);
  fs.appendFile('./temp/telnet_nba.txt', message.toString(), (err) => {
        // throws an error, you could also catch it here
        if (err) throw err;

        // success case, the file was saved
        console.log('Lyric saved!'); 
      });
});

/**
 * When timeout happened
 */
connection.on('timeout', function() {
  console.log('socket timeout!');
  connection.end();
});

/**
 * When the other end of the socked ended
 */
connection.on('end', function() {
  console.log('Connection ended');
});

/**
 * When the connection fully closed
 */
connection.on('close', function() {
  console.log('Connection closed');
});
 
/**
 * When an error happends
 */
connection.on('error', function() {
  console.log('An error occured');
});

/**
 * When the login credential is wrong
 */
connection.on('failedlogin', function() {
  console.log('Login Mismatch');
});
 

connection.connect(params);

