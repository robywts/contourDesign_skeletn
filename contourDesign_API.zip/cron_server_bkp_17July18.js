require('dotenv').config();
require('./app/config/database'); //DB Connection

var CronJob = require('cron').CronJob;
//NFL
var playerCron = require('./app/modules/crons/playerCron');
//var teamCron = require('./app/crons/teamCron');
var depthChartCron = require('./app/modules/crons/depthChartCron');
var playerFantasyCron = require('./app/modules/crons/playerFantasy');
var eventScheduleCron = require('./app/modules/crons/eventScheduleCron');
var draftGroupCron = require('./app/modules/crons/draftGroupCron');
//NBA
var eventNBAScheduleCron = require('./app/modules/crons/eventNBAScheduleCron');
var draftGroupCronNBA = require('./app/modules/crons/draftGroupCronNBA');
var nbaMValueUpdateCron = require('./app/modules/crons/nbaMValueUpdateCron');
//MLB
var eventMLBScheduleCron = require('./app/modules/crons/eventMLBScheduleCron');
var draftGroupCronMLB = require('./app/modules/crons/draftGroupCronMLB');
var mlbMValueUpdateCron = require('./app/modules/crons/mlbMValueUpdateCron');
var scoreCronMLB = require('./app/modules/crons/scoreCronMLB.js');

//General
var generalSchemaUpdateCron = require('./app/modules/crons/generalSchemaUpdateCron');

var playerGames = require('./cron_server/cron_playerGames');
var rewardPointsMLB = require('./app/modules/crons/rewardPointsMLB');

//var scoreCronMLB = require('./app/modules/crons/scoreCronMLB');

var winston = require('winston');
var logger = new (winston.Logger)({
  transports: [
    new (winston.transports.Console)(),
    new (winston.transports.File)({
      filename: './app/modules/crons/logs/cronError.log'
    })
  ]
});

const timeZone = 'America/Los_Angeles';

try {

  ///////////////////////////////////////////NFL////////////////////////////////////////////////
  /**
   * Player Cron to get basic details related to player - for players schema
   * 
   * @param {String} - Time interval (runs the cron daily at 1 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 0 1 * * *', function () {
    try {
      playerCron.getPlayerDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player Fantasy Cron to get average salary and points related to player - for players schema 
   * 
   * @param {String} - Time interval (runs the cron daily at 1:10 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 10 1 * * *', function () {
    try {
      playerFantasyCron.getPlayerFantasyDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  //team cron
  //new CronJob('0 0 0 * * *', function () {
  //  teamCronData = teamCron.getTeamDetails();
  //}, null, true, timeZone);

  /**
   * Depth Chart Cron to get player position details related to player - for players schema 
   * 
   * @param {String} - Time interval (runs the cron daily at 1:15 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 15 1 * * *', function () {
    try {
      depthChartCron.getDepthChartDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Event Cron to get scheduled NFL game details by week - for events schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:20 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 20 1 * * *', function () {
    try {
      eventScheduleCron.getEventScheduleDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to get event's weather - for events schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:30 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 30 1 * * *', function () {
    try {
      eventScheduleCron.getEventWeatherDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * NFL DraftGroup Cron to create draftgroup based on time slots - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:35 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 35 1 * * *', function () {
    try {
      draftGroupCron.getDraftGroupDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Player news Cron to save player news details - for playernews schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 4:30 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 30 4 * * *', function () {
    try {
      playerCron.getNewsDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Player Injury Cron to save player injury details - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:45 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 45 1 * * *', function () {
    try {
      playerCron.getInjuryDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  ///////////////////////////////////////////NBA////////////////////////////////////////////////

  /**
   * Event Cron to get scheduled NBA game details by day - for events schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 11:51 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 51 11 * * *', function () {
    try {
      eventNBAScheduleCron.getEventScheduleDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Player Cron to get basic details related to NBA player - for players schema
   * 
   * @param {String} - Time interval (runs the cron daily at 1:55 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 55 1 * * *', function () {
    try {
      eventNBAScheduleCron.getPlayerDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player Fantasy Cron to get average salary and points related to NBA player - for players schema 
   * 
   * @param {String} - Time interval (runs the cron daily at 2 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 0 2 * * *', function () {
    try {
      eventNBAScheduleCron.getPlayerFantasyDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player Injury Cron to save NBA player injury details - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 2:15 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 15 2 * * *', function () {
    try {
      eventNBAScheduleCron.getInjuryDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Depth Chart Cron to get player position details related to NBA player - for players schema 
   * 
   * @param {String} - Time interval (runs the cron daily at 2:20 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 20 2 * * *', function () {
    try {
      eventNBAScheduleCron.getDepthChartDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player news Cron to save NBA player news details - for playernews schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 2:25 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 25 2 * * *', function () {
    try {
      eventNBAScheduleCron.getNewsDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * NBA DraftGroup Cron to create draftgroup based on time slots - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 2:45 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 45 2 * * *', function () {
    try {
      draftGroupCronNBA.getDraftGroupDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);



  /**
   * Cron to update mValue value for players(NBA) - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 4:15 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 15 4 * * *', function () {
    try {
      nbaMValueUpdateCron.updateDraftMValue();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  ///////////////////////////////////////////MLB////////////////////////////////////////////////

  /**
   * Event Cron to get scheduled MLB game details by day - for events schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 12:52 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 52 0 * * *', function () {
    try {
      eventMLBScheduleCron.getEventScheduleDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player Cron to get basic details related to MLB player - for players schema
   * 
   * @param {String} - Time interval (runs the cron daily at 12:57 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 57 0 * * *', function () {
    try {
      eventMLBScheduleCron.getPlayerDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player Fantasy Cron to get average salary and points related to MLB player - for players schema 
   * 
   * @param {String} - Time interval (runs the cron daily at 1:02 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 2 1 * * *', function () {
    try {
      eventMLBScheduleCron.getPlayerFantasyDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player Injury Cron to save MLB player injury details - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:07 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 7 1 * * *', function () {
    try {
      eventMLBScheduleCron.getInjuryDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Depth Chart Cron to get player position details related to MLB player - for players schema 
   * 
   * @param {String} - Time interval (runs the cron daily at 1:12 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 12 1 * * *', function () {
    try {
      eventMLBScheduleCron.getDepthChartDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player news Cron to save MLB player news details - for playernews schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:17 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 17 1 * * *', function () {
    try {
      eventMLBScheduleCron.getNewsDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * MLB DraftGroup Cron to create draftgroup based on time slots - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:22 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 22 1 * * *', function () {
    try {
      draftGroupCronMLB.getDraftGroupDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Cron to get MLB event's weather - for events schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:40 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 40 1 * * *', function () {
    try {
      eventMLBScheduleCron.getEventWeatherDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to update mValue value for players(MLB) - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:50 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 50 1 * * *', function () {
    try {
      mlbMValueUpdateCron.updateDraftMValue();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  ///////////////////////////////////////////General////////////////////////////////////////////

  /**
   * Cron to update gameStatus value for players - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 3 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 0 3 * * *', function () {
    try {
      generalSchemaUpdateCron.updateDraftPlayers();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to update mValue value for players(NFL,MLB,Golf) - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 4:55 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 55 4 * * *', function () {
    try {
      generalSchemaUpdateCron.updateDraftMValue();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to update draftgroup startTimeUTC - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 2 25 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 25 2 * * *', function () {
    try {
      generalSchemaUpdateCron.draftGroupTime();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Cron to update draftgroup startTimeUTC - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 4:05 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 5 4 * * *', function () {
    try {
      generalSchemaUpdateCron.updateDraftGroupStatus();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Cron to update liunup score based on player scores - for lineup schema  
   * 
   * @param {String} - Time interval (runs the cron every 10 seconds)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('*/10 * * * * *', function () {
    try {
      scoreCronMLB.updateScoreMLB();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to update liunup positions - for lineup schema  
   * 
   * @param {String} - Time interval (runs the cron every 14 seconds)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('*/14 * * * * *', function () {
    try {
      scoreCronMLB.updateLineupPositionMLB();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /*new CronJob('0 0 3 * * *', function () {
    try {
      scoreCronMLB.autoCreateContest();
    }
    catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);*/

  //playerGames.playerGames(); // Calling all 10 crons of player games

  /**
   * Cron to abort contest which are not guaranteed or min entry limit not reached 
   * 
   * @param {String} - Time interval (runs cron every 5 sec)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('*/5 * * * * *', function () {
    try {
      generalSchemaUpdateCron.abortContest();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to delete player news which is older than a month 
   * 
   * @param {String} - Time interval (runs cron once in a day at 6 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 0 6 * * *', function () {
    try {
      generalSchemaUpdateCron.removePlayerNews();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to delete user lineups which is not used in any completed or live contest 
   * 
   * @param {String} - Time interval (runs cron every 13th minute of hour)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 13 * * * *', function () {
    try {
      generalSchemaUpdateCron.removeUnusedLineups();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to set prizepool values for live multiplayer contest 
   * 
   * @param {String} - Time interval (runs cron every 20 seconds)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('*/5 * * * * *', function () {
    try {
      generalSchemaUpdateCron.setContestPayout();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron(back up) to reset player score from lineups if no entry found in playerScore collection  
   * 
   * @param {String} - Time interval (runs cron every 4 seconds)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('*/4 * * * * *', function () {
    try {
      scoreCronMLB.removeUnsetPlayerScore();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to distribute the winning amount to users  
   * 
   * @param {String} - Time interval (runs cron daily at 5 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 0 5 * * *', function () {
    try {
      scoreCronMLB.winningDistribution();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to add rewards  
   * 
   * @param {String} - Time interval (runs cron every 30 seconds)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('*/30 * * * * *', function () {
    try {
      rewardPointsMLB.updateUserRewards();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

} catch (ex) {
  logger.info(ex);
}