/**
 * Telnet
 * @exports Telnet/Stats
 */
var Telnet = require('telnet-client');
var connection = new Telnet();
var fs = require('fs');
xml2js = require('xml2js');
var x = 'qw';

var parser = new xml2js.Parser();
var async = require('async');
var params = {
  host: 'socket1.stats.com',
  port: 32102,
  //shellPrompt: '/ # ',
  shellPrompt: 'Logon Successful',
  timeout: 30000,
  // removeEcho: 4
  debug: true,
  execTimeout: 30000,
  sendTimeout: 30000,
  echoLines: 500,
  username: 'contour',
  password: 'football1999',
  loginPrompt: 'Login Username:',
  passwordPrompt: 'Password:'
};

/**
 * When the connection is ready
 */
connection.on('ready', function (prompt) {
  console.log(prompt);
  // connection.exec(cmd, function(err, response) {
  //   console.log(response);
  // })
});

/**
 * When the data keep coming from the server
 */
connection.on('data', function (message) {
  //console.log(message.toString()); process.exit();
// x = message += x
  async.series({

    res1: function (callback) {

      fs.appendFile('websocket_response2.txt', message.toString(), (err) => {
        // throws an error, you could also catch it here
        if (err) throw err;

        // success case, the file was saved
        console.log('Lyric saved!'); 
      });


    },


    res2: function (callback) {

      fs.readFile("./" + '2pac.txt', function (err, data) {
        //  console.log(err);
        parser.parseString(data, function (err, result) {
          // console.dir(result);
          callback(null, result);
        });
      });
    }
  },
    //stats api call to get player position details from depth chart api
    function (err, result) {
      if (typeof result.res != 'undefined' && result.res) {
        // console.log(result.res['nfl-event'].gamecode); process.exit();
      }
    });

});
/**
 * When timeout happened
 */
connection.on('timeout', function () {
  console.log('socket timeout!');
  connection.end();
});

/**
 * When the other end of the socked ended
 */
connection.on('end', function () {console.log('dsadsdad');
//console.log(x);process.exit();
  console.log('Connection ended');
});

/**
 * When the connection fully closed
 */
connection.on('close', function () {
  console.log('Connection closed');
});

/**
 * When an error happends
 */
connection.on('error', function () {
  console.log('An error occured');
});

/**
 * When the login credential is wrong
 */
connection.on('failedlogin', function () {
  console.log('Login Mismatch');
});


connection.connect(params);

