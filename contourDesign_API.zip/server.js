var express = require('express');
var bodyParser = require('body-parser');

var app = express();

// app.use(function (req, res, next) {
//   console.log(req.headers);

//   next();
// });
require('dotenv').config({
  path: './.env'
});

app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Headers', Content-Length, API-KEY, SESSION-KEY, GEO-TOKEN");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  if ('OPTIONS' === req.method) { //intercepts OPTIONS method
    res.send(200);
  } else {
    next();
  }
});

/**Swagger Config BEGIN**/
if (process.env.SWAGGER == 'yes') {
  var swaggerSpec = require('./app/config/swagger');
  app.get('/api-docs.json', function (req, res) {
    res.setHeader('Content-Type', 'application/json');
    res.header('Access-Control-Allow-Origin', '*');
    res.send(swaggerSpec.swaggerSpecWS);
  });

  app.get('/admin-api-docs.json', function (req, res) {
    res.setHeader('Content-Type', 'application/json');
    res.header('Access-Control-Allow-Origin', '*');
    res.send(swaggerSpec.swaggerSpecAdmin);
  });
}
/**Swagger Config END**/

//var morgan    = require('morgan');
//app.use(morgan('dev')); // log requests to the console

// configure body parser
app.use(bodyParser.urlencoded({
  extended: true
})); // parse application/x-www-form-urlencoded

app.use(bodyParser.json()); // parse application/json
app.use(express.static('public')) // serve static folder

require('./app/config/database'); //DB Connection

var router = require('./app/modules/mobile/apiRoute'); //ws routes
var adminRouter = require('./app/modules/admin/adminRoute'); //admin routes
app.use('/api', router); // ws register routes
app.use('/admin/api', adminRouter); // admin register routes

/**
 * Run the code on port
 */
var server = app.listen(process.env.APP_PORT, function () {
  var port = server.address().port;
  console.log(new Date());
  console.log("App now running on port", port);
});