nodemon server.js

npm run devstart
npm run start

Swagger Url: http://localhost:8080/api-docs


npm install <pkg-name> --save
npm install <pkg-name> --save-dev
npm install <pkg-name> -g

npm uninstall <pkg-name> -g



jsdoc <input-folder> -r -d <destination-folder>
jsdoc app -r -d docs