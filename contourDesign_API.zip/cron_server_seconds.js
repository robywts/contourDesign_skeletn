require('dotenv').config();
require('./app/config/database'); //DB Connection

var CronJob = require('cron').CronJob;
//MLB
var scoreCronMLB = require('./app/modules/crons/scoreCronMLB.js');
var rewardPointsMLB = require('./app/modules/crons/rewardPointsMLB');
var eventMLBScheduleCron = require('./app/modules/crons/eventMLBScheduleCron');
//General
var generalSchemaUpdateCron = require('./app/modules/crons/generalSchemaUpdateCron');
var remTimeLineupAllGame = require('./app/modules/crons/remTimeLineupAllGame');
var remTimeLineupCompletedMLB = require('./app/modules/crons/remTimeLineupCompletedMLB');
//NFL
var scoreCronNFL = require('./app/modules/crons/scoreCronNFL.js');

var winston = require('winston');
var logger = new (winston.Logger)({
  transports: [
    new (winston.transports.Console)(),
    new (winston.transports.File)({
      filename: './app/modules/crons/logs/cronError.log'
    })
  ]
});

const timeZone = 'America/Los_Angeles';

try {


  ///////////////////////////////////////////General////////////////////////////////////////////

  /**
   * Cron to update liunup score based on player scores - for lineup schema  
   * 
   * @param {String} - Time interval (runs the cron every 10 seconds)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('*/40 * * * * *', function () {
    try {
      scoreCronMLB.updateScoreMLB();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to update liunup positions - for lineup schema  
   * 
   * @param {String} - Time interval (runs the cron every 14 seconds)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('*/40 * * * * *', function () {
    try {
      scoreCronMLB.updateLineupPositionMLB();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to abort contest which are not guaranteed or min entry limit not reached 
   * 
   * @param {String} - Time interval (runs cron every 5 sec)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('*/15 * * * * *', function () {
    try {
      generalSchemaUpdateCron.abortContest();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to set prizepool values for live multiplayer contest 
   * 
   * @param {String} - Time interval (runs cron every 20 seconds)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('*/5 * * * * *', function () {
    try {
     // generalSchemaUpdateCron.setContestPayout();  //added prizepool calculation for multiplayer contest in add/update web service --- 06 Aug 18
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron(back up) to reset player score from lineups if no entry found in playerScore collection  
   * 
   * @param {String} - Time interval (runs cron every 4 seconds)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('*/4 * * * * *', function () {
    try {
      //scoreCronMLB.removeUnsetPlayerScore();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to add rewards  
   * 
   * @param {String} - Time interval (runs cron every minute)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 */1 * * * *', function () {
    try {
      rewardPointsMLB.updateUserRewards();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to update the remaining lineup time - for lineups schema  
   * 
   * @param {String} - Time interval (runs the cron every 11 seconds)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 */1 * * * *', function () {
    try {
      remTimeLineupAllGame.lineupRemainingTime();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to update the completed MLB lineup time - for lineups schema  
   * 
   * @param {String} - Time interval (runs the cron every minute)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 */1 * * * *', function () {
    try {
      remTimeLineupCompletedMLB.lineupRemainingTimeMLB();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to update starting lineup
   * 
   * @param {String} - Time interval (runs the cron every 15 minitues)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 */15 * * * *', function () {
    try {
      eventMLBScheduleCron.getStartingLineupDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

    /**
   * Cron to update pitching probables.
   * 
   * @param {String} - Time interval (runs the cron daily at 12.10 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 10 0 * * *', function () {
    try {
      eventMLBScheduleCron.getPitchingProbables();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

   /**
   * Cron to update liunup score based on player scores NFL- for lineup schema  
   * 
   * @param {String} - Time interval (runs the cron every 10 seconds)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  /*new CronJob('* * * * * *', function () {
    try {
      scoreCronNFL.updateScoreNFL();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);*/

  /**
   * Cron to update liunup positions NFL - for lineup schema  
   * 
   * @param {String} - Time interval (runs the cron every 14 seconds)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  /*new CronJob('* * * * * *', function () {
    try {
      scoreCronNFL.updateLineupPositionNFL();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);*/



} catch (ex) {
  logger.info(ex);
}