/**
 * Telnet
 * @exports Telnet/Stats
 */
var Telnet = require('telnet-client');
var fs = require('fs');
var winston = require('winston');
var logger = new(winston.Logger)({
  transports: [
    new(winston.transports.Console)(),
    new(winston.transports.File)({
      filename: './app/modules/crons/logs/mlb_socket.log'
    })
  ]
});

var connection = new Telnet();

var params = {
  host: 'socket1.stats.com',
  port: 32100,
  //shellPrompt: '/ # ',
  shellPrompt: 'Logon Successful',
  timeout: 30000,
  // removeEcho: 4
  debug: true,
  execTimeout: 30000,
  sendTimeout: 30000,
  echoLines: 500,
  username: 'contour',
  password: 'baseball99',
  loginPrompt: 'Login Username:',
  passwordPrompt: 'Password:'
};

var event = Date.now();

/**
 * When the connection is ready
 */
connection.on('ready', function (prompt) {
  logger.info('Ready: ' + prompt);
});

/**
 * When the data keep coming from the server
 */
connection.on('data', function (message) {
  var msg = message.toString();

  while (msg.indexOf("Ping ") >= 0) {
    var pingIndex = msg.indexOf("Ping ");
    var sliced = msg.slice(pingIndex, (pingIndex + 27));
    msg = msg.replace(sliced, '');
  }

  if (msg.indexOf("</MLB-event>") >= 0) {
    var msgArr = msg.split("</MLB-event>");

    for (var i = 0; i < msgArr.length; i++) {
      if ((i + 1) != msgArr.length) { // not the last item
        appendToFile(msgArr[i] + "</MLB-event>", 'incre');
      } else { // last item
        appendToFile(msgArr[i], '');
      }
    }
  } else { // no closing tag in the data
    appendToFile(msg, '');
  }
});

function appendToFile(msg, eventCounter) {
  fs.appendFileSync('./temp/mlb/unprocessed/telnet_mlb_' + event + '.txt', msg);
  if (eventCounter == 'incre') {
    if (Date.now() != event) {
      event = Date.now();
    } else {
      while (fs.existsSync('./temp/mlb/unprocessed/telnet_mlb_' + event + '.txt')) {
        event += 'a';
      }
    }
  }
}

/**
 * When timeout happened
 */
connection.on('timeout', function () {
  logger.info('socket timeout!');
  connection.end();
});

/**
 * When the other end of the socked ended
 */
connection.on('end', function () {
  logger.info('Connection ended');
});

/**
 * When the connection fully closed
 */
connection.on('close', function () {
  logger.info('Connection closed');
});

/**
 * When an error happends
 */
connection.on('error', function () {
  logger.info('An error occured');
});

/**
 * When the login credential is wrong
 */
connection.on('failedlogin', function () {
  logger.info('Login Mismatch');
});

connection.connect(params);