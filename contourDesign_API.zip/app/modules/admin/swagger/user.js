 /**
  * @swagger
  * definitions:
  *   editUserStatus:
  *     type: object
  *     required:
  *       - status      
  *     properties:
  *       status:
  *         type: integer
  */

 /**
  * @swagger
  * /admin/api/users/{id}:
  *   get:
  *     tags:
  *       - User
  *     description: Returns a User's profile
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: id
  *         description: User's id
  *         in: path      
  *         type: integer
  *         required: true
  *     responses:
  *       200:
  *         description: Returns a User's profile
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  */

 /**
  * @swagger
  * /admin/api/users:
  *   get:
  *     tags:
  *       - User
  *     description: Returns all Users
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: page_number
  *         description: Page Number
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 0
  *       - name: page_limit
  *         description: Number of records in a page
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 5   
  *       - name: search_text
  *         description: Search String
  *         in: query      
  *         type: string
  *       - name: status
  *         description: user status
  *         in: query      
  *         type: string
  *       - name: sort_field
  *         description: Field to sort
  *         in: query      
  *         type: string
  *       - name: sort_order
  *         description: Sort Order (asc or desc)
  *         in: query      
  *         type: string
  *     responses:
  *       200:
  *         description: All records retrieved successfully.
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  */

 /**
  * @swagger
  * /admin/api/users/status/{id}:
  *   put:
  *     tags:
  *       - User
  *     description: Update user status, Activate- 1, InActive/Blocked- 2
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: id
  *         description: User's id
  *         in: path      
  *         type: integer
  *         required: true
  *       - name: user
  *         description: User object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/editUserStatus'
  *     responses:
  *       200:
  *         description: User Update Successfull
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  */

 /**
  * @swagger
  * /admin/api/users/htohcontest/{id}:
  *   get:
  *     tags:
  *       - User
  *     description: Returns all H to H contests by userId
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: page_number
  *         description: Page Number
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 0
  *       - name: page_limit
  *         description: Number of records in a page
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 5
  *       - name: league_type
  *         description: 1-NFL, 2-MLB, 3-NHL, 4-NBA, 5-GOLF
  *         in: query
  *         required: false
  *         type: integer
  *         format: int64
  *       - name: id
  *         description: User's id
  *         in: path
  *         required: true
  *         type: integer
  *       - name: contest_status
  *         description: contest status (1 - Completed, 2 - Live, 3 - Upcoming)
  *         in: query      
  *         type: string
  *       - name: from_date
  *         description: from date
  *         in: query      
  *         type: string  
  *       - name: to_date
  *         description: to date
  *         in: query      
  *         type: string
  *       - name: sort_field
  *         description: Field to sort
  *         in: query      
  *         type: string
  *       - name: sort_order
  *         description: Sort Order (asc or desc)
  *         in: query      
  *         type: string
  *     responses:
  *       200:
  *         description: Returns all H2H contest by UserId
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  */

 /**
  * @swagger
  * /admin/api/users/multicontest/{id}:
  *   get:
  *     tags:
  *       - User
  *     description: Returns all multi player contests by userId
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: page_number
  *         description: Page Number
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 0
  *       - name: page_limit
  *         description: Number of records in a page
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 5
  *       - name: league_type
  *         description: 1-NFL, 2-MLB, 3-NHL, 4-NBA 5-GOLF
  *         in: query
  *         required: false
  *         type: integer
  *         format: int64
  *       - name: id
  *         description: User's id
  *         in: path
  *         required: true
  *         type: integer
  *       - name: contest_status
  *         description: contest status (1 - Completed, 2 - Live, 3 - Upcoming)
  *         in: query      
  *         type: string
  *       - name: from_date
  *         description: from date
  *         in: query      
  *         type: string  
  *       - name: to_date
  *         description: to date
  *         in: query      
  *         type: string   
  *       - name: sort_field
  *         description: Field to sort
  *         in: query      
  *         type: string
  *       - name: sort_order
  *         description: Sort Order (asc or desc)
  *         in: query      
  *         type: string
  *     responses:
  *       200:
  *         description: Returns all multi player contest by UserId
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  */