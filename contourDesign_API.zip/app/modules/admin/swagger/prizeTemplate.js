/**
 * @swagger
 * definitions:
 *   addPrizeTemplate:
 *     type: object
 *     required:
 *       - prizeTemplate
 *       - gameTypeId
 *       - leagueTypeId
 *       - entryFees
 *       - maxMultiEntries
 *       - minMembers
 *       - maxMembers
 *       - prizeMode
 *       - prizePool
 *       - prizeTickets
 *       - gameTypeId
 *       - prizes
 *     properties:
 *       parentPrizeTemplateId:
 *         type: number
 *       prizeTemplate:
 *         type: string
 *       gameTypeId:
 *         type: string
 *       leagueTypeId:
 *         type: number
 *       entryFees:
 *         type: number
 *       maxMultiEntries:
 *         type: number
 *       minMembers:
 *         type: number
 *       maxMembers:
 *         type: number
 *       prizeMode:
 *         type: string
 *       prizePool:
 *         type: number
 *       prizeTickets:
 *         type: number
 *       prizes:
 *         type: array
 *         items:
 *           $ref: '#/definitions/prizes'
 */

/**
 * @swagger
 * definitions:
 *   editPrizeTemplate:
 *     type: object
 *     required:
 *       - prizeTemplate
 *       - gameTypeId
 *       - leagueTypeId
 *       - entryFees
 *       - maxMultiEntries
 *       - minMembers
 *       - maxMembers
 *       - prizeMode
 *       - prizePool
 *       - prizeTickets
 *       - gameTypeId
 *       - prizes
 *     properties:
 *       parentPrizeTemplateId:
 *         type: number
 *       prizeTemplate:
 *         type: string
 *       gameTypeId:
 *         type: string
 *       leagueTypeId:
 *         type: number
 *       entryFees:
 *         type: number
 *       maxMultiEntries:
 *         type: number
 *       minMembers:
 *         type: number
 *       maxMembers:
 *         type: number
 *       prizeMode:
 *         type: string
 *       prizePool:
 *         type: number
 *       prizeTickets:
 *         type: number
 *       prizes:
 *         type: array
 *         items:
 *           $ref: '#/definitions/prizes'
 */

/**
 * @swagger
 * definitions:
 *   editStatus:
 *     type: object
 *     required:
 *       - status
 *     properties:
 *       status:
 *         type: number
 */

/**
 * @swagger
 * definitions:
 *   prizes:
 *     type: object
 *     required:
 *       - prizePosition
 *       - amount
 *       - fromRange
 *       - toRange
 *     properties:
 *       prizePosition:
 *         type: number
 *       amount:
 *         type: number
 *       fromRange:
 *         type: number
 *       toRange:
 *         type: number
 */

/**
 * @swagger
 * /admin/api/prizetemplates/dd:
 *   get:
 *     tags:
 *       - PrizeTemplate
 *     description: Returns all active prize templates for dropdown
 *     produces:
 *       - application/json
 *     responses:
 *       200:
 *         description: All records retrieved
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/prizetemplates:
 *   get:
 *     tags:
 *       - PrizeTemplate
 *     description: Returns all prize templates
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5   
 *       - name: search_text
 *         description: Search String
 *         in: query      
 *         type: string
 *       - name: game_type
 *         description: Game Type (SC or M)
 *         in: query      
 *         type: string
 *       - name: prize_mode
 *         description: Game Type (C or T or CT)
 *         in: query      
 *         type: string
 *       - name: sort_field
 *         description: Field to sort
 *         in: query      
 *         type: string
 *       - name: sort_order
 *         description: Sort Order (asc or desc)
 *         in: query      
 *         type: string
 *     responses:
 *       200:
 *         description: All records retrieved
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

 /**
 * @swagger
 * /admin/api/prizetemplates/{id}:
 *   get:
 *     tags:
 *       - PrizeTemplate
 *     description: Returns all prize templates
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: prizetemplate's id
 *         in: path      
 *         type: integer
 *         required: true
 *     responses:
 *       200:
 *         description: Record retrieved.
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/prizetemplates:
 *   post:
 *     tags:
 *       - PrizeTemplate
 *     description: Adding prize templates
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: prizeTemplate
 *         description: prizeTemplate object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/addPrizeTemplate'
 *     responses:
 *       200:
 *         description: Record added
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/prizetemplates/{id}:
 *   put:
 *     tags:
 *       - PrizeTemplate
 *     description: Edit prize template
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: prizetemplate's id
 *         in: path      
 *         type: integer
 *         required: true
 *       - name: prizeTemplate
 *         description: prizeTemplate object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/editPrizeTemplate'
 *     responses:
 *       200:
 *         description: Record updated
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/prizetemplates/status/{id}:
 *   put:
 *     tags:
 *       - PrizeTemplate
 *     description: Update prize template status, Activate- 1, InActive/Blocked- 2
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: Prize template's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *       - name: prizeTemplate
 *         description: Prize template status
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/editStatus'
 *     responses:
 *       200:
 *         description: Status updated
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/prizetemplates/{id}:
 *   delete:
 *     tags:
 *       - PrizeTemplate
 *     description: Deletes a single record
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: prizeTemplate's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Successfully deleted
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */