/**
 * @swagger
 * tags:
 *   - name: Dashboard
 *     description: Web services of dashboard related functionalities
 *   - name: General
 *     description: General web services
 *   - name: UserAuth
 *     description: Web services of users authentication
 *   - name: User
 *     description: Web services of users related functionalities
 *   - name: PrizeTemplate
 *     description: Web services of prize template related functionalities
 *   - name: Contest
 *     description: Web services of contests
 *   - name: DraftGroup
 *     description: Web services of draft group related functionalities
 *   - name: StaticContent
 *     description: Web services of content related functionalities
 *   - name: Admin
 *     description: Web services of admin related functionalities
 *   - name: Setting
 *     description: Web services of setting related functionalities
 *   - name: Withdrawal
 *     description: Web services of withdrawal related functionalities
 *   - name: Transaction
 *     description: Web services of transaction related functionalities
 * securityDefinitions:
 *   ApiKey:
 *     type: apiKey
 *     in: header
 *     name: API-KEY
 *   SessionKey:
 *     type: apiKey
 *     in: header
 *     name: SESSION-KEY
 * definitions:
 *   ApiResponse:
 *     type: object
 *     properties:
 *       code:
 *         type: integer
 *         format: int32
 *       message:
 *         type: string
 */

 /**
 * @swagger
 * definitions:
 *   GeneralResult:
 *     type: object
 *     properties:
 *       message:
 *         type: string
 *       errorCode:
 *         type: integer
 *         format: int32
 *       data:
 *         type: object
 *       info:
 *         type: object
 */