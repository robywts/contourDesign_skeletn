 /**
  * @swagger
  * definitions:
  *   Log:
  *     type: object
  */

 /**
  * @swagger
  * /admin/api/general/ping:
  *   get:
  *     tags:
  *       - General
  *     description: Ping the server to check availability, api key and session key
  *     produces:
  *       - application/json
  *     responses:
  *       200:
  *         description: Returns a message
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  */

 /**
  * @swagger
  * /admin/api/general/log:
  *   post:
  *     tags:
  *       - General
  *     description: Log the error from the client side
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: log
  *         description: Log object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/Log'
  *     responses:
  *       200:
  *         description: Returns a error
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  */