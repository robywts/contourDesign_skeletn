/**
 * @swagger
 * /admin/api/dashboard:
 *   get:
 *     tags:
 *       - Dashboard
 *     description: Returns all dashboard contents
 *     produces:
 *       - application/json
 *     responses:
 *       200:
 *         description: All content retrieved
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */
