/**
 * @swagger
 * definitions:
 *   addAdminUser:
 *     type: object
 *     required:
 *       - userName
 *       - email
 *       - password
 *     properties:
 *       userName:
 *         type: string
 *       email:
 *         type: string
 *       password:
 *         type: string
 *       permission:
 *         type: array
 */

/**
 * @swagger
 * definitions:
 *   editAdminUser:
 *     type: object
 *     required:
 *       - userName
 *       - email
 *       - password
 *     properties:
 *       password:
 *         type: string
 *       permission:
 *         type: array
 */

/**
 * @swagger
 * definitions:
 *   editAdminStatus:
 *     type: object
 *     required:
 *       - status      
 *     properties:
 *       status:
 *         type: integer
 */




/**
 * @swagger
 * /admin/api/admins:
 *   get:
 *     tags:
 *       - Admin
 *     description: Returns all Admin Users
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5   
 *       - name: search_text
 *         description: Search String
 *         in: query      
 *         type: string
 *       - name: status
 *         description: Status value (1 or 2)
 *         in: query      
 *         type: string
 *       - name: sort_field
 *         description: Field to sort
 *         in: query      
 *         type: string
 *       - name: sort_order
 *         description: Sort Order (asc or desc)
 *         in: query      
 *         type: string
 *     responses:
 *       200:
 *         description: All records retrieved successfully.
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/admins/{id}:
 *   get:
 *     tags:
 *       - Admin
 *     description: Returns One Admin User
 *     produces:
 *       - application/json
 *     parameters:    
 *       - name: id
 *         description: Admin's id
 *         in: path      
 *         type: integer
 *         required: true
 *     responses:
 *       200:
 *         description: Record retrieved successfully.
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

 /**
 * @swagger
 * /admin/api/admins:
 *   post:
 *     tags:
 *       - Admin
 *     description: Add admin user
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/addAdminUser'
 *     responses:
 *       200:
 *         description: Registration Successfull
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */
 /**
 * @swagger
 * /admin/api/admins/{id}:
 *   put:
 *     tags:
 *       - Admin
 *     description: Edit admin user
 *     produces:
 *       - application/json
 *     parameters:
*       - name: id
 *         description: Admin's id
 *         in: path      
 *         type: integer
 *         required: true
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/editAdminUser'
 *     responses:
 *       200:
 *         description: User Update Successfull
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

 /**
 * @swagger
 * /admin/api/admins/status/{id}:
 *   put:
 *     tags:
 *       - Admin
 *     description: Update user status, Activate- 1, InActive/Blocked- 2
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: Admin's id
 *         in: path      
 *         type: integer
 *         required: true
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/editAdminStatus'
 *     responses:
 *       200:
 *         description: User Status Update Successfull
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/admins/{id}:
 *   delete:
 *     tags:
 *       - Admin
 *     description: Delete Admin User
 *     produces:
 *       - application/json
 *     parameters:    
 *       - name: id
 *         description: Admin's id
 *         in: path      
 *         type: integer
 *         required: true
 *     responses:
 *       200:
 *         description: Record deleted retrieved successfully.
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

 