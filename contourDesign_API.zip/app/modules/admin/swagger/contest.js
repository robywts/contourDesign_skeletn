/**
 * @swagger
 * definitions:
 *   addContest:
 *     type: object
 *     required:
 *       - contestName
 *       - draftgroupId
 *       - visibility
 *       - guaranteed
 *       - video
 *       - summary
 *       - tplId
 *       - currentStatus
 *       - gameTypeId
 *       - leagueTypeId
 *       - entryFees
 *       - maxMultiEntries
 *       - minMembers
 *       - maxMembers
 *       - prizeMode
 *       - prizePool
 *       - prizeTickets
 *       - gameTypeId
 *       - rake
 *       - prizes
 *     properties:
 *       contestName:
 *         type: string
 *       draftgroupId:
 *         type: number
 *       visibility:
 *         type: string
 *       guaranteed:
 *         type: boolean
 *       video:
 *         type: boolean
 *       summary:
 *         type: string
 *       tplId:
 *         type: number
 *       currentStatus:
 *         type: number
 *       gameTypeId:
 *         type: string
 *       leagueTypeId:
 *         type: number
 *       entryFees:
 *         type: number
 *       maxMultiEntries:
 *         type: number
 *       minMembers:
 *         type: number
 *       maxMembers:
 *         type: number
 *       prizeMode:
 *         type: string
 *       prizePool:
 *         type: number
 *       prizeTickets:
 *         type: number
 *       rake:
 *         type: number
 *       prizes:
 *         type: array
 *         items:
 *           $ref: '#/definitions/prizes'
 */

/**
 * @swagger
 * definitions:
 *   editContest:
 *     type: object
 *     required:
 *       - contestName
 *       - draftgroupId
 *       - visibility
 *       - guaranteed
 *       - video
 *       - summary
 *       - tplId
 *       - currentStatus
 *       - gameTypeId
 *       - leagueTypeId
 *       - entryFees
 *       - maxMultiEntries
 *       - minMembers
 *       - maxMembers
 *       - prizeMode
 *       - prizePool
 *       - prizeTickets
 *       - gameTypeId
 *       - rake
 *       - prizes
 *     properties:
 *       contestName:
 *         type: string
 *       draftgroupId:
 *         type: number
 *       visibility:
 *         type: string
 *       guaranteed:
 *         type: boolean
 *       video:
 *         type: boolean
 *       summary:
 *         type: string
 *       tplId:
 *         type: number
 *       currentStatus:
 *         type: number
 *       gameTypeId:
 *         type: string
 *       leagueTypeId:
 *         type: number
 *       entryFees:
 *         type: number
 *       maxMultiEntries:
 *         type: number
 *       minMembers:
 *         type: number
 *       maxMembers:
 *         type: number
 *       prizeMode:
 *         type: string
 *       prizePool:
 *         type: number
 *       prizeTickets:
 *         type: number
 *       rake:
 *         type: number
 *       prizes:
 *         type: array
 *         items:
 *           $ref: '#/definitions/prizes'
 */

/**
 * @swagger
 * definitions:
 *   prizes:
 *     type: object
 *     required:
 *       - prizePosition
 *       - amount
 *       - fromRange
 *       - toRange
 *     properties:
 *       prizePosition:
 *         type: number
 *       amount:
 *         type: number
 *       fromRange:
 *         type: number
 *       toRange:
 *         type: number
 */

/**
 * @swagger
 * /admin/api/contests:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns all contests
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5
 *       - name: sort_order
 *         description: Sort Order (asc or desc)
 *         in: query
 *         required: true
 *         type: string
 *         default: asc
 *       - name: sort_field
 *         description: Sort field name
 *         in: query
 *         required: false
 *         type: string
 *       - name: search_text
 *         description: Search String
 *         in: query
 *         required: false
 *         type: string
 *     responses:
 *       200:
 *         description: Get all records
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */


/**
 * @swagger
 * /admin/api/contests/form/{id}:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns a single contest (for form)
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: contest's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Get single record for form
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/contests/h2h/{id}:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns a single HtoH contest
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: contest's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Get single record
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/contests/multiplayer/{id}:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns a single multiplayer contest
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: contest's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Get single record
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/contests:
 *   post:
 *     tags:
 *       - Contest
 *     description: Creates a new contest
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: contest
 *         description: Contest object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/addContest'
 *     responses:
 *       200:
 *         description: Successfully created
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */



/**
 * @swagger
 * /admin/api/contests/{id}:
 *   put:
 *     tags: 
 *       - Contest
 *     description: Updates a single contest
 *     produces: 
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: contest's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *       - name: contest
 *         description: Fields for the contest resource
 *         in: body
 *         schema:
 *           $ref: '#/definitions/editContest'
 *     responses:
 *       200:
 *         description: Successfully updated
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */


/**
 * @swagger
 * /admin/api/contests/{id}:
 *   delete:
 *     tags:
 *       - Contest
 *     description: Deletes a single contest
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: Contest's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Successfully deleted
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/contests/gethtohcontest:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns all H to H contests
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5
 *       - name: sportId
 *         description: 1-NFL, 2-MLB, 3-NHL, 4-NBA, 5-GOLF
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64     
 *       - name: contest_status
 *         description: contest status
 *         in: query      
 *         type: string
 *       - name: from_date
 *         description: from date
 *         in: query      
 *         type: string  
 *       - name: to_date
 *         description: to date
 *         in: query      
 *         type: string
 *       - name: sort_field
 *         description: Field to sort
 *         in: query      
 *         type: string
 *       - name: sort_order
 *         description: Sort Order (asc or desc)
 *         in: query      
 *         type: string
 *     responses:
 *       200:
 *         description: Returns all contest by UserId
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/contests/multicontest:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns all multi player contests
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5
 *       - name: sportId
 *         description: 1-NFL, 2-MLB, 3-NHL, 4-NBA, 5-GOLF
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *       - name: contest_status
 *         description: contest status
 *         in: query      
 *         type: string
 *       - name: from_date
 *         description: from date
 *         in: query      
 *         type: string  
 *       - name: to_date
 *         description: to date
 *         in: query
 *         type: string
 *       - name: sort_field
 *         description: Field to sort
 *         in: query      
 *         type: string
 *       - name: sort_order
 *         description: Sort Order (asc or desc)
 *         in: query      
 *         type: string
 *     responses:
 *       200:
 *         description: Returns all contest by UserId
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/contests/lineUp/{id}:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns all lineups in a contest
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: Contest's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns lineups in Contest
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 *  /admin/api/contests/getmultiGames/{id}:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns a single contest's games
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5
 *       - name: id
 *         description: contest's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Get single record
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 *  /admin/api/contests/getStandings/{id}:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns all standings in a contest
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5
 *       - name: sort_order
 *         description: Position Sort Order (asc or desc)
 *         in: query
 *         required: true
 *         type: string
 *         default: asc
 *       - name: id
 *         description: contest's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns all standings in a contest
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/contests/lineUp/{id}:
 *   get:
 *     tags:
 *       - Contest
 *     description: Get a multiplayer contest Lineup by lineup id
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: Lineup's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns all contest by by lineup id
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */