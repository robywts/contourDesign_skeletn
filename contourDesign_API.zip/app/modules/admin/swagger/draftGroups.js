/**
 * @swagger
 * definitions:
 *   DraftGroupDetails:
 *     type: object
 *     properties:
 *       _id:
 *         type: string
 *       email:
 *         type: string
 */

/**
 * @swagger
 * definitions:
 *   DraftGroupContestList:
 *     type: object
 *     properties:
 *       _id:
 *         type: string
 *       email:
 *         type: string
 */

/**
 * @swagger
 * definitions:
 *   DraftGroupPlayerList:
 *     type: object
 *     properties:
 *       _id:
 *         type: string
 */

 /**
 * @swagger
 * definitions:
 *   DraftGroup:
 *     type: object
 *     required:
 *       - draftGroupName
 *       - sortOrder
 *       - weekId
 *       - leagueType
 *       - games   
 *     properties:
 *       draftGroupName:
 *         type: string
 *       sortOrder:
 *         type: integer
 *         format: int64     
 *       weekId:
 *         type: integer
 *         format: int64
 *       leagueType:
 *         type: integer
 *         format: int64   
 *       games:
 *         type: array
 */

  /**
 * @swagger
 * definitions:
 *   DraftGroupUpdate:
 *     type: object
 *     required:
 *       - draftGroupName
 *       - sortOrder
 *       - weekId
 *       - leagueType
 *       - games   
 *     properties:
 *       draftGroupName:
 *         type: string
 *       sortOrder:
 *         type: integer
 *         format: int64     
 *       weekId:
 *         type: integer
 *         format: int64
 *       leagueType:
 *        type: integer
 *        format: int64   
 *       games:
 *         type: array
 */

 
/**
 * @swagger
 * /admin/api/draftgroups/dd/{id}:
 *   get:
 *     tags:
 *       - DraftGroup
 *     description: Returns all active draftgroups for dropdown by sports id
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: sport's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 1
 *     responses:
 *       200:
 *         description: All records retrieved
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

 /**
 * @swagger
 * /admin/api/draftgroups:
 *   get:
 *     tags:
 *       - DraftGroup
 *     description: Returns Live and Upcoming draftgroup list based on week and sportId
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sportId
 *         description: sportId
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: week
 *         description: week
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 1 
 *     responses:
 *       200:
 *         description: Returns Live and Upcoming draftgroup list based on week and sportId
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

 /**
 * @swagger
 * /admin/api/draftgroups/{id}:
 *   get:
 *     tags:
 *       - DraftGroup
 *     description: Returns a single draftgroup
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: draftgroup's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Get single record
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */
  /**
 * @swagger
 * /admin/api/draftgroups/weeks/{id}:
 *   get:
 *     tags:
 *       - DraftGroup
 *     description: Returns all weeks in a draftgroup
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: sport id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns weeks in draftgroups
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

 /**
 * @swagger
 * /admin/api/draftgroups/games:
 *   get:
 *     tags:
 *       - DraftGroup
 *     description: Returns Live and Upcoming games list based on week and sportId
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sportId
 *         description: sportId
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: week
 *         description: week
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 1 
 *     responses:
 *       200:
 *         description: Returns Live and Upcoming games list based on week and sportId
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

 /**
 * @swagger
 * /admin/api/draftgroups:
 *   post:
 *     tags:
 *       - DraftGroup
 *     description: Creates a new DraftGroup
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: contest
 *         description: Contest object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/DraftGroup'
 *     responses:
 *       200:
 *         description: Successfully created
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

 /**
 * @swagger
 * /admin/api/draftgroups/{id}:
 *   put:
 *     tags:
 *       - DraftGroup
 *     description: Update a Draft Group
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: Draft Group's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *       - name: contest
 *         description: Contest object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/DraftGroupUpdate'
 *     responses:
 *       200:
 *         description: Successfully created
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

  /**
 * @swagger
 *  /admin/api/draftgroups/{id}:
 *   delete:
 *     tags:
 *       - DraftGroup
 *     description: Deletes a Draft Group
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: Draft Group's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Successfully deleted
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

