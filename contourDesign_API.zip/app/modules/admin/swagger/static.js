 /**
 * @swagger
 * definitions:
 *   Static:
 *     type: object
 *     required:
 *       - content
 *     properties:
 *       content:
 *         type: string
 */

 /**
 * @swagger
 *  /admin/api/static/{id}:
 *   put:
 *     tags:
 *       - StaticContent
 *     description: Static data update
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: id
 *         in: path      
 *         type: integer
 *         required: true
 *       - name: user
 *         description: Static object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Static'
 *     responses:
 *       200:
 *         description:Update successfully completed.
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */
/**
 * @swagger
 * /admin/api/static:
 *   get:
 *     tags:
 *       - StaticContent
 *     description: Returns all Static data
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5 
 *     responses:
 *       200:
 *         description: All records retrieved successfully.
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */
 /**
 * @swagger
 * /admin/api/static/{id}:
 *   get:
 *     tags:
 *       - StaticContent
 *     description: Returns one static data
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: id
 *         in: path      
 *         type: integer
 *         required: true
 *     responses:
 *       200:
 *         description: Returns static data
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */
