 /**
 * @swagger
 * definitions:
 *   Setting:
 *     type: object
 *     required:
 *       - rewardToDollar
 *       - ticketToDollar
 *       - rewardToTicket
 *     properties:
 *       rewardToDollar:
 *         type: number
 *       ticketToDollar:
 *         type: number
 *       rewardToTicket:
 *         type: number
 */

 /**
 * @swagger
 *  /admin/api/setting:
 *   put:
 *     tags:
 *       - Setting
 *     description: Setting data update
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: setting
 *         description: Setting object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Setting'
 *     responses:
 *       200:
 *         description: Update successfully completed.
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

 /**
 * @swagger
 * /admin/api/setting:
 *   get:
 *     tags:
 *       - Setting
 *     description: Returns setting data
 *     produces:
 *       - application/json
 *     responses:
 *       200:
 *         description: Returns setting data
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */
