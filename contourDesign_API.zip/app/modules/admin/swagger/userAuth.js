 /**
 * @swagger
 * definitions:
 *   UserLogin:
 *     type: object
 *     required:
 *       - email
 *       - pwd
 *     properties:
 *       email:
 *         type: string
 *       pwd:
 *         type: string
 */

 
 /**
 * @swagger
 * definitions:
 *   UserForgot:
 *     type: object
 *     required:
 *       - email
 *     properties:
 *       email:
 *         type: string
 */

 
 /**
 * @swagger
 * definitions:
 *   UserReset:
 *     type: object
 *     required:
 *       - email
 *       - resetCode
 *       - pwd
 *     properties:
 *       email:
 *         type: string
 *       resetCode:
 *         type: string
 *       pwd:
 *         type: string
 */
 
 /**
 * @swagger
 * definitions:
 *   UserChangePassword:
 *     type: object
 *     required:
 *       - oldPwd
 *       - pwd
 *       - confirmPwd
 *     properties:
 *       oldPwd:
 *         type: string
 *       pwd:
 *         type: string
 *       confirmPwd:
 *         type: string
 */




 /**
 * @swagger
 * /admin/api/user/auth/login:
 *   post:
 *     tags:
 *       - UserAuth
 *     description: User Login
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/UserLogin'
 *     responses:
 *       200:
 *         description: Login Successfull/Failed
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 */


 /**
 * @swagger
 * /admin/api/user/auth/forgot:
 *   put:
 *     tags:
 *       - UserAuth
 *     description: User Forgot Password
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/UserForgot'
 *     responses:
 *       200:
 *         description: Reset code sent to email
 *     security:
 *       - ApiKey: []
 */

 
 /**
 * @swagger
 * /admin/api/user/auth/reset:
 *   put:
 *     tags:
 *       - UserAuth
 *     description: User Reset Password
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/UserReset'
 *     responses:
 *       200:
 *         description: Password Reset Successfully
 *     security:
 *       - ApiKey: []
 */
 
 /**
 * @swagger
 * /admin/api/user/auth/changePassword:
 *   put:
 *     tags:
 *       - UserAuth
 *     description: User Change Password
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/UserChangePassword'
 *     responses:
 *       200:
 *         description: Password Changed Successfully
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */


 /**
 * @swagger
 * /admin/api/user/auth/logout:
 *   delete:
 *     tags:
 *       - UserAuth
 *     description: Logout a user
 *     produces:
 *       - application/json
 *     responses:
 *       200:
 *         description: Logout Successfully
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

