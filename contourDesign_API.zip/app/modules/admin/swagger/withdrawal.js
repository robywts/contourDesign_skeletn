/**
 * @swagger
 * definitions:
 *   editwithdrawalStatus:
 *     type: object
 *     required:
 *       - status      
 *       - paymentType      
 *     properties:
 *       status:
 *         type: string
 *       paymentType:
 *         type: string
 */

/**
 * @swagger
 * /admin/api/withdrawals/getwithdrawalrequests/{id}:
 *   get:
 *     tags:
 *       - Withdrawal
 *     description: Returns all withdrawal requests
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: User id
 *         in: path
 *         required: false
 *         type: integer
 *         format: int64
 *         default: ''
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5
 *       - name: search_text
 *         description: Search String
 *         in: query      
 *         type: string   
 *       - name: request_status
 *         description: Request status (P - Pending, I - In Progress, C - Closed, R - Rejected)
 *         in: query      
 *         type: string
 *       - name: from_date
 *         description: from date
 *         in: query      
 *         type: string  
 *       - name: to_date
 *         description: to date
 *         in: query      
 *         type: string
 *       - name: sort_field
 *         description: Field to sort
 *         in: query      
 *         type: string
 *       - name: sort_order
 *         description: Sort Order (asc or desc)
 *         in: query      
 *         type: string
 *     responses:
 *       200:
 *         description: All records retrieved successfully.
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /admin/api/withdrawals/updatewithdrawalstatus/{id}:
 *   put:
 *     tags:
 *       - Withdrawal
 *     description: Update withdrawal status. (P - Pending, C - Closed, R - Rejected, I - In progress)
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: Withdrawal Id
 *         in: path      
 *         type: string
 *         required: true
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/editwithdrawalStatus'
 *     responses:
 *       200:
 *         description: Withdrawal Status Update Successfull
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */