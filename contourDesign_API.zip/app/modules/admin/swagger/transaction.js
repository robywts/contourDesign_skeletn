/**
 * @swagger
 * /admin/api/transactions/common/{id}:
 *   get:
 *     tags:
 *       - Transaction
 *     description: Returns all common transactions
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: User Id
 *         in: path
 *         required: false
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5   
 *       - name: transaction_type
 *         description: Transaction Type (D or W or TM)
 *         in: query
 *         type: string
 *       - name: from_date
 *         description: From Date
 *         in: query      
 *         type: string
 *       - name: to_date
 *         description: To Date
 *         in: query      
 *         type: string
 *       - name: sort_field
 *         description: Field to sort
 *         in: query      
 *         type: string
 *       - name: sort_order
 *         description: Sort Order (asc or desc)
 *         in: query      
 *         type: string
 *     responses:
 *       200:
 *         description: All records retrieved
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */
/**
 * @swagger
 * /admin/api/transactions/contests/{id}:
 *   get:
 *     tags:
 *       - Transaction
 *     description: Returns all contest transactions
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: User Id
 *         in: path
 *         required: false
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: league_type
 *         description: League Id (1 - NFL, 2 - MLB, 3 - NHL, 4 - NBA, 5 - GOLF)
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 1
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5   
 *       - name: search_text
 *         description: Search text
 *         in: query
 *         type: string
 *       - name: from_date
 *         description: From Date
 *         in: query      
 *         type: string
 *       - name: to_date
 *         description: To Date
 *         in: query      
 *         type: string
 *       - name: sort_field
 *         description: Field to sort
 *         in: query      
 *         type: string
 *       - name: sort_order
 *         description: Sort Order (asc or desc)
 *         in: query      
 *         type: string
 *     responses:
 *       200:
 *         description: All records retrieved
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */
