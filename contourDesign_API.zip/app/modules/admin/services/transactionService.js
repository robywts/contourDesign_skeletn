/**
 * Transaction Service
 * @exports Transaction/Service
 */
var TransactionModel = require('../../../models/transaction');
var ContestModel = require('../../../models/contest');

module.exports = {

    /**
     * Get Transactions 
     * @param {object} search - search object
     * @param {number} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getTransactionsCommon: async function (search, userId) {
        try {
            let searchConditions = [{
                'userName': new RegExp('', 'i')
            }];
            // let searchConditions = [{
            //     $or: [{
            //             'userName': new RegExp(search.search_text, 'i')
            //         },
            //         {
            //             'transactionType': new RegExp(search.search_text, 'i')
            //         }
            //     ]
            // }];
            if (userId != '' && userId != 0) {
                searchConditions.push({
                    'userId': userId
                });
            }
            if (search.transaction_type != '') {
                searchConditions.push({
                    'tranType': search.transaction_type
                });
            }
            if (search.from_date != '') {
                var dt = search.from_date.split('/');
                searchConditions.push({
                    'entryDate': {
                        $gte: new Date(dt[2] + '-' + dt[0] + '-' + dt[1])
                        // $gte: new Date("2018-03")
                    }
                });
            }
            if (search.to_date != '') {
                var dt = search.to_date.split('/');
                var dtObj = new Date(dt[2] + '-' + dt[0] + '-' + dt[1]);
                dtObj.setDate(dtObj.getDate() + 1);
                searchConditions.push({
                    'entryDate': {
                        $lte: dtObj
                        // $gte: new Date("2018-03")
                    }
                });
            }

            return await TransactionModel.find({
                    $and: searchConditions
                })
                .select('userName fName lName tranType tranStatus entryDate amount')
                .limit(search.limit)
                .skip(search.limit * search.page)
                .collation({
                    locale: "en"
                })
                .sort({
                    [search.sort_field]: search.sort_order
                })
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get Transactions  count
     * @param {object} search - search object
     * @param {number} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getTransactionsCountCommon: async function (search, userId) {
        try {
            let searchConditions = [{
                'userName': new RegExp('', 'i')
            }];
            // let searchConditions = [{
            //     $or: [
            //         {
            //             'userName': new RegExp(search.search_text, 'i')
            //         },
            //         {
            //             'transactionType': new RegExp(search.search_text, 'i')
            //         }
            //     ]
            // }];
            if (userId != '' && userId != 0) {
                searchConditions.push({
                    'userId': userId
                });
            }
            if (search.transaction_type != '') {
                searchConditions.push({
                    'tranType': search.transaction_type
                });
            }
            if (search.from_date != '') {
                var dt = search.from_date.split('/');
                searchConditions.push({
                    'entryDate': {
                        $gte: new Date(dt[2] + '-' + dt[0] + '-' + dt[1])
                        // $gte: new Date("2018-03")
                    }
                });
            }
            if (search.to_date != '') {
                var dt = search.to_date.split('/');
                var dtObj = new Date(dt[2] + '-' + dt[0] + '-' + dt[1]);
                dtObj.setDate(dtObj.getDate() + 1);
                searchConditions.push({
                    'entryDate': {
                        $lte: dtObj
                        // $gte: new Date("2018-03")
                    }
                });
            }

            return await TransactionModel.count({
                $and: searchConditions
            }).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get all contests transactions from DB
     * @param {object} search - Data required for search
     * @param {number} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getContestTransactions: async function (search, userId) {
        try {
            let searchConditions = [{
                'contestName': new RegExp(search.search_text, 'i')
            }];

            if (userId != '' && userId != 0) {
                searchConditions.push({
                    'entrants.userId': userId
                });
            }

            searchConditions.push({
                'sportId': search.league_type
            });

            if (search.from_date != '') {
                var dt = search.from_date.split('/');
                searchConditions.push({
                    'contestStartTime': {
                        $gte: new Date(dt[2] + '-' + dt[0] + '-' + dt[1])
                        // $gte: new Date("2018-03")
                    }
                });
            }
            if (search.to_date != '') {
                var dt = search.to_date.split('/');
                var dtObj = new Date(dt[2] + '-' + dt[0] + '-' + dt[1]);
                dtObj.setDate(dtObj.getDate() + 1);
                searchConditions.push({
                    'contestStartTime': {
                        $lte: dtObj
                        // $gte: new Date("2018-03")
                    }
                });
            }
            return await ContestModel.find({
                    $and: searchConditions
                })
                .select('_id contestId contestName entryFees contestStartTime entrants rakePerc prizePool prizes') // no. of players, total entry fees, total prize, totalrake
                .limit(parseInt(search.limit))
                .skip(search.limit * search.page)
                .collation({
                    locale: "en"
                })
                .sort({
                    [search.sort_field]: search.sort
                })
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get total count of content transactionss
     * @param {object} search - Data required for search
     * @param {number} userId - user id
     * @returns {Number} Total count of records
     * @throws {object} e - Error
     */
    getContestTransactionsCount: async function (search, userId) {
        try {
            let searchConditions = [{
                'contestName': new RegExp(search.search_text, 'i')
            }];

            if (userId != '' && userId != 0) {
                searchConditions.push({
                    'entrants.userId': userId
                });
            }

            searchConditions.push({
                'sportId': search.league_type
            });

            if (search.from_date != '') {
                var dt = search.from_date.split('/');
                searchConditions.push({
                    'contestStartTime': {
                        $gte: new Date(dt[2] + '-' + dt[0] + '-' + dt[1])
                        // $gte: new Date("2018-03")
                    }
                });
            }
            if (search.to_date != '') {
                var dt = search.to_date.split('/');
                var dtObj = new Date(dt[2] + '-' + dt[0] + '-' + dt[1]);
                dtObj.setDate(dtObj.getDate() + 1);
                searchConditions.push({
                    'contestStartTime': {
                        $lte: dtObj
                        // $gte: new Date("2018-03")
                    }
                });
            }
            return await ContestModel.count({
                $and: searchConditions
            }).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get transaction amount (deposit and withdrawal)
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    transactionAmount: async function () {
        try {
            return await TransactionModel.aggregate([{
                $group: {
                    _id: {
                        tranType: "$tranType"
                    },
                    amt: {
                        $sum: "$amount"
                    }
                }
            }]).exec();
        } catch (e) {
            throw e;
        }
    },
};