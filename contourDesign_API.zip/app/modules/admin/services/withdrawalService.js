/**
 * Withdrawal Service
 * @exports Admin/Withdrawal/Service
 */
var UserModel = require('../../../models/user');
var WithdrawalModel = require('../../../models/withdrawal');

module.exports = {

    /**
     * Get users balance from DB
     * @param {object} userDB - user Object
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getUsersBalance: async function (userDB) {
        try {
            return await UserModel.find({
                'userId': {
                    $in: userDB
                }
            }, 'userId balance');
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get Withdrawal Requests 
     * @param {object} search - search object
     * @param {number} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    withdrawalRequests: async function (search, userId) {
        try {
            let searchConditions = [{
                $or: [{
                        'userName': new RegExp(search.search_text, 'i')
                    },
                    {
                        'userEmail': new RegExp(search.search_text, 'i')
                    }
                ]
            }];
            if (userId != '') {
                searchConditions.push({
                    'userId': userId
                });
            }
            if (search.request_status != '') {
                searchConditions.push({
                    'requestStatus': search.request_status
                });
            }
            if (search.from_date != '') {
                var dt = search.from_date.split('/');
                searchConditions.push({
                    'createdAt': {
                        $gte: new Date(dt[2] + '-' + dt[0] + '-' + dt[1])
                        // $gte: new Date("2018-03")
                    }
                });
            }
            if (search.to_date != '') {
                var dt = search.to_date.split('/');
                var dtObj = new Date(dt[2] + '-' + dt[0] + '-' + dt[1]);
                dtObj.setDate(dtObj.getDate() + 1);
                searchConditions.push({
                    'createdAt': {
                        $lte: dtObj
                        // $gte: new Date("2018-03")
                    }
                });
            }

            return await WithdrawalModel.find({
                    $and: searchConditions
                    // $or: [{
                    //     'userEmail': new RegExp(search.search_text, 'i'),
                    // }, {
                    //     'userName': new RegExp(search.search_text, 'i'),
                    // }],
                    // "requestStatus": {
                    //     $in: search.status
                    // },
                    // "createdAt": {
                    //     $gte: search.from_date,
                    //     $lte: search.to_date
                    // },
                })
                .select('_id userId requestStatus amount paymentType createdAt updatedAt userName userEmail')
                .limit(search.limit)
                .skip(search.limit * search.page)
                .collation({
                    locale: "en"
                })
                .sort({
                    [search.sort_field]: search.sort_order
                })
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get Withdrawal Requests count
     * @param {object} search - search object   
     * @param {number} userId - user id 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    withdrawalRequestsCount: async function (search, userId) {
        try {
            let searchConditions = [{
                $or: [{
                        'userName': new RegExp(search.search_text, 'i')
                    },
                    {
                        'userEmail': new RegExp(search.search_text, 'i')
                    }
                ]
            }];
            if (userId != '') {
                searchConditions.push({
                    'userId': userId
                });
            }
            if (search.request_status != '') {
                searchConditions.push({
                    'requestStatus': search.request_status
                });
            }
            if (search.from_date != '') {
                var dt = search.from_date.split('/');
                searchConditions.push({
                    'createdAt': {
                        $gte: new Date(dt[2] + '-' + dt[0] + '-' + dt[1])
                        // $gte: new Date("2018-03")
                    }
                });
            }
            if (search.to_date != '') {
                var dt = search.to_date.split('/');
                var dtObj = new Date(dt[2] + '-' + dt[0] + '-' + dt[1]);
                dtObj.setDate(dtObj.getDate() + 1);
                searchConditions.push({
                    'createdAt': {
                        $lte: dtObj
                        // $gte: new Date("2018-03")
                    }
                });
            }

            return await WithdrawalModel.count({
                $and: searchConditions
                // $or: [{
                //     'userEmail': new RegExp(search.search_text, 'i'),
                // }, {
                //     'userName': new RegExp(search.search_text, 'i'),
                // }],
                // "requestStatus": {
                //     $in: search.status
                // },
                // "createdAt": {
                //     $gte: search.from_date,
                //     $lte: search.to_date
                // },
            }).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get users Withdrawal Requests 
     * @param {object} search - search object     
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    // userWithdrawalRequests: async function (search) {
    //     try {
    //         return await WithdrawalModel.find({
    //                 $or: [{
    //                     'userEmail': new RegExp(search.search_text, 'i'),
    //                 }, {
    //                     'userName': new RegExp(search.search_text, 'i'),
    //                 }],
    //                 "requestStatus": {
    //                     $in: search.status
    //                 },
    //                 "createdAt": {
    //                     $gte: search.from_date,
    //                     $lte: search.to_date
    //                 },
    //                 "userId": search.userId
    //             })
    //             .select('_id userId requestStatus amount createdAt updatedAt userName userEmail')
    //             .limit(search.limit)
    //             .skip(search.limit * search.page)
    //             .exec();
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     *  Get users Withdrawal Requests count
     * @param {object} search - search object    
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    // userWithdrawalRequestsCount: async function (search) {
    //     try {
    //         return await WithdrawalModel.count({

    //             $or: [{
    //                 'userEmail': new RegExp(search.search_text, 'i'),
    //             }, {
    //                 'userName': new RegExp(search.search_text, 'i'),
    //             }],
    //             "requestStatus": {
    //                 $in: search.status
    //             },
    //             "createdAt": {
    //                 $gte: search.from_date,
    //                 $lte: search.to_date
    //             },
    //             "userId": search.userId
    //         }).exec();
    //     } catch (e) {
    //         throw e;
    //     }
    // },


    /**
     * Get withdrawal status
     * @param {String} withdrawalId - withdrawal id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    withdrawalRequestStatus: async function (withdrawalId) {
        try {
            return await WithdrawalModel.findOne({
                '_id': withdrawalId
            }, 'requestStatus userId');
        } catch (e) {
            throw e;
        }
    },

    /**
     * Update Withdrawal Status
     * @param {object} withdrawal - Data required for withdrawal status  
     * @returns {Number} Total count of records
     * @throws {object} e - Error
     */
    updateWithdrawalStatus: async function (withdrawal) {
        try {
            return await WithdrawalModel.findOneAndUpdate({
                '_id': withdrawal.withdrawalId
            }, {
                $set: {
                    "requestStatus": withdrawal.status,
                    "paymentType": withdrawal.paymentType
                }
            }, {
                new: true,
                fields: 'userId userEmail userName requestStatus paymentType amount',
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get user userId
     * @param {integer} id - id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    // getUser: async function (id) {
    //     try {
    //         return await WithdrawalModel.findOne({
    //             '_id': id
    //         }, 'userId');
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     * Update User Withdrawal Status    
     * @param {object} withdrawal - Data required for withdrawal status
     * @throws {object} e - Error
     */
    updateWithdrawalStatusUser: async function (withdrawal) { //userId, amount
        try {
            if (withdrawal.requestStatus == 'C') { // if completed (update the amount)
                return await UserModel.findOneAndUpdate({
                    'userId': withdrawal.userId
                }, {
                    $set: {
                        "withdrawalStatus": withdrawal.requestStatus
                    },
                    $inc: {
                        "balance": -withdrawal.amount
                    }
                }, {
                    new: true,
                    fields: 'userId userName fName lName email imageName balance',
                });
            } else {
                return await UserModel.findOneAndUpdate({
                    'userId': withdrawal.userId
                }, {
                    $set: {
                        "withdrawalStatus": withdrawal.requestStatus
                    }
                }, {
                    new: true,
                    fields: 'userId userName fName lName email imageName balance',
                });
            }

        } catch (e) {
            throw e;
        }
    },

    /**
     * Add a transaction (withdrawal)
     * @param {object} transactionModel - Transaction model object 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    transactionEntry: async function (transactionModel) {
        try {
            return await transactionModel.save();
        } catch (e) {
            throw e;
        }
    },

};