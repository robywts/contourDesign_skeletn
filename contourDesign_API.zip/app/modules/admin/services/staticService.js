/**
 * User Service
 * @exports Admin/User/Service
 */
var UserModel = require('../../../models/user');
var StaticModel = require('../../../models/static');
module.exports = {

    /**
     *  Get user profile from DB
     * @param {integer} id -  id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getStaticOne: async function (id) {
        try {
            return await StaticModel.findOne({
                '_id': id
            }, 'id name content createdAt updatedAt');
        } catch (e) {
            throw e;
        }
    },

    /**
     * Update Static data
     * @param {object} staticData - Data required for update data
     * @param {integer} id - id    
     * @throws {object} e - Error
     */
    updateStaticData: async function (staticData, id) {
        try {
            return await StaticModel.findOneAndUpdate({
                '_id': id
            }, staticData, {
                new: true,
                safe: true,
                upsert: true
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get Static Data 
     * @param {object} search - search object    
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    listStaticData: async function (search) {
        try {
            let searchConditions = [{
                'name': new RegExp(search.search_text, 'i')
            }, {
                'content': new RegExp(search.search_text, 'i')
            }];
            return await StaticModel.find({
                    $or: searchConditions
                })
                .select('_id name userName createdAt updatedAt')
                .limit(search.limit)
                .skip(search.limit * search.page)
                .collation({
					locale: "en"
				})
                .sort({
                    [search.sort_field]: search.sort_order
                })
                .exec();

        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get Static Data count   
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    StaticDataCount: async function () {
        try {
            return await StaticModel.count().exec();
        } catch (e) {
            throw e;
        }
    },


};