/**
 * Lineup Service
 * @exports Lineup/Service
 */
var LineUpModel = require('../../../models/lineup');

module.exports = {

	/**
	 * Add a contest lineup to db
	 * @param {object} LineUpModel - Model object mapped to the data to be added
	 * @returns {object} Modal object
	 * @throws {object} e - Error
	 */
	addLineup: async function (lineUpModel) {
		try {
			return await lineUpModel.save();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get lineups in a draftgroup from DB
	 * @param {Number} draftgroupId - draftgroup id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getDraftGroupLineups: async function (draftgroupId) {
		try {
			return await LineUpModel.find({
				'draftgroupId': draftgroupId,
				'userId': global.userId,
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get lineups in a contest from DB
	 * @param {Number} contestId - contest id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getContestLineups: async function (contestId) {
		try {
			return await LineUpModel.find({
				'contestId': contestId
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Update a contest lineup to db
	 * @param {object} LineUpModel - Model object mapped to the data to be added
	 * @returns {object} Modal object
	 * @throws {object} e - Error
	 */
	updateLineup: async function (lineUpModel, lineupData, lineupID) {
		try {
			return await lineUpModel.findOneAndUpdate({
				lineupId: lineupID
			}, lineupData)

		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get contest standings details from DB
	 * @param {object} contestId - contest id
	 * @param {object} search - Data required for search
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getUserContestStandings: async function (contestId, search) {
		try {
			 
			let searchConditions = [{
                'userName': new RegExp(search.search_text, 'i')
			}];
			
			if (contestId != '') {
                searchConditions.push({
                    'contestId': contestId
                });            }

			return await LineUpModel.find({					
					$and: searchConditions
				}).select('userId userName userImgName position points lineupId winning')
				.limit(parseInt(search.limit))
				.skip(search.limit * search.page)
				.collation({
					locale: "en"
				})
				.sort({
                    [search.sort_field]: search.sort_order
				}).exec();
				
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get total count of contests by id
	 * @param {object} contestId - contest id
	 * @returns {Number} Total count of records
	 * @throws {object} e - Error
	 */
	getAllCountContUser: async function (contestId, search) {
		try {

			let searchConditions = [{
                'userName': new RegExp(search.search_text, 'i')
			}];
			
			if (contestId != '') {
                searchConditions.push({
                    'contestId': contestId
                });            }

			return await LineUpModel.count({
				$and: searchConditions
			}).exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get lineUp by id
	 * @param {object} LineUpId - lineup id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getLineup: async function (lineupId) {
		try {
			return await LineUpModel.findOne({
				"lineupId": lineupId
			}, 'lineupId players' ).exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get lineUp  Details by contestId and  userId
	 * @param {object} contestId - contest id
	 * @param {object} userId - user id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getLineupDetails: async function (contestId, userId, userId1) {
		try {
			return await LineUpModel.find({
				$and: [{
					"contestId": contestId
				}, {
					$or: [{
						"userId": userId
					}, {
						"userId": userId1
					}]
				}]
			}).exec();
		} catch (e) {
			throw e;
		}
	},

};