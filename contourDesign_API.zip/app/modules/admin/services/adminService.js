/**
 * Admin Service
 * @exports Admin/User/Service
 */
var UserModel = require('../../../models/user');
// var FriendrequestModel = require('../../../models/friendrequest');
// var NotificationsModel = require('../../../models/notification');

module.exports = {

    /**
     * Get admin users 
     * @param {object} search - search object 
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    listUsers: async function (search, userId) {
        try {
            let searchConditions = [{
                $or: [{
                    'email': new RegExp(search.search_text, 'i')
                }, {
                    'userName': new RegExp(search.search_text, 'i')
                }]
            }, {
                "userId": {
                    $nin: ['1', userId]
                }
            }, {
                "isAdmin": true
            }];

            if (search.status != '') {
                searchConditions.push({
                    'userStatus': search.status
                });
            } else {
                searchConditions.push({
                    'userStatus': {
                        $ne: 3
                    }
                });
            }

            return await UserModel.find({
                    $and: searchConditions
                })
                .select('userId userName email imageName userStatus isAdmin createdAt')
                .limit(search.limit)
                .skip(search.limit * search.page)
                .collation({
                    locale: "en"
                })
                .sort({
                    [search.sort_field]: search.sort_order
                })
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get admin users count
     * @param {object} search - search object 
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    listUsersCount: async function (search, userId) {
        try {
            let searchConditions = [{
                $or: [{
                    'email': new RegExp(search.search_text, 'i')
                }, {
                    'userName': new RegExp(search.search_text, 'i')
                }]
            }, {
                "userId": {
                    $nin: ['1', userId]
                }
            }, {
                "isAdmin": true
            }];

            if (search.status != '') {
                searchConditions.push({
                    'userStatus': search.status
                });
            } else {
                searchConditions.push({
                    'userStatus': {
                        $ne: 3
                    }
                });
            }

            return await UserModel.count({
                $and: searchConditions
            }).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get admin user by userId
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getProfile: async function (userId = '') {
        try {
            var userId = userId ? userId : global.userId;
            return await UserModel.findOne({
                'userId': userId
            }, 'userId email userName permissions userStatus createdAt');
        } catch (e) {
            throw e;
        }
    },

    /**
     * Find User
     * @param {object} userAuth - User object
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    findUser: async function (userAuth) {
        try {
            return await UserModel.findOne({
                    $or: [{
                        'email': userAuth.email
                    }, {
                        'userName': userAuth.userName
                    }]
                },
                '_id userId email userName currentLoginType userStatus');
        } catch (e) {
            throw e;
        }
    },

    /**
     * User Addition
     * @param {object} userAuthDBNew - Model object
     * @returns {object} Response model
     * @throws {object} e - Error
     */
    addUser: async function (userAuthDBNew) {
        try {
            return await userAuthDBNew.save();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Update User
     * @param {object} userProfile - Data required for update profile
     * @param {integer} userId - user id
     * @returns {Number} Total count of records
     * @throws {object} e - Error
     */
    updateProfile: async function (userProfile, userId) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userId
            }, {
                $set: userProfile
            }, {
                new: false
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Update User Status
     * @param {object} status - Data required for update status
     * @param {integer} userId - user id
     * @returns {Number} Total count of records
     * @throws {object} e - Error
     */
    updateStatus: async function (status, userId) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userId
            }, {
                $set: {
                    "userStatus": status
                }
            }, {
                new: false
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Delete User Status
     * @param {integer} userId - user id
     * @returns {Number} Total count of records
     * @throws {object} e - Error
     */
    deleteUser: async function (userId) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userId
            }, {
                $set: {
                    "userStatus": 3
                }
            }, {
                new: false
            });
        } catch (e) {
            throw e;
        }
    },

};