/**
 * User Authentication Service
 * @exports Admin/UserAuth/Service
 */
var UserModel = require('../../../models/user');

module.exports = {
	/**
	 * Find User
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	// findUser: async function (userAuth) {
	// 	try {
	// 		return await UserModel.findOne({
	// 				$and: [{
	// 						$or: [{
	// 							'email': userAuth.email
	// 						}, {
	// 							'userName': userAuth.userName
	// 						}]
	// 					},
	// 					{
	// 						'isAdmin': true
	// 					}
	// 				]
	// 			},
	// 			'_id userId email userName currentLoginType userStatus');
	// 	} catch (e) {
	// 		throw e;
	// 	}
	// },



	/**
	 * Find active user by Id
	 * @param {Number} userId - User id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	findActiveUserById: async function (userId) {
		try {
			return await UserModel.findOne({ //find the account
				'userId': userId,
				'isAdmin': true,
				'userStatus': 1
			}, '_id userId pwd');
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Find user by email
	 * @param {object} userAuth - User object
	 * @param {Number} status - User status
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	findUserByEmail: async function (userAuth, status = '') {
		try {
			var conditions = {
				'email': userAuth.email,
				'isAdmin': true,
			};
			if (status != '') {
				conditions.userStatus = status;
			}
			return await UserModel.findOne(conditions, '_id userId email pwd userStatus');
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Find active user by email and reset code
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	findActiveUserByResetCode: async function (userAuth) {
		try {
			return await UserModel.findOne({ //find the account
				'email': userAuth.email,
				'resetCode': userAuth.resetCode,
				'isAdmin': true,
				'userStatus': 1
			}, '_id userId');
		} catch (e) {
			throw e;
		}
	},

	/**
	 * User Login - Update session
	 * @param {number} userId - User id
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	updateUserSession: async function (userId, userAuth) {
		try {
			return await UserModel.findOneAndUpdate({ //update and get the session token
				'userId': userId,
				'isAdmin': true,
			}, {
				$push: {
					'sessions': userAuth.sessions
				}
			}, {
				new: true,
				fields: 'userId email userName sessions.sessionToken fName lName permissions',
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * User Forgot - Update reset code
	 * @param {number} userId - User id
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	updateResetCode: async function (userId, userAuth) {
		try {
			return await UserModel.findOneAndUpdate({ // update and get the reset password code
				'userId': userId,
				'isAdmin': true,
			}, {
				$set: {
					'resetCode': userAuth.resetCode
				}
			}, {
				new: true,
				fields: 'userId email userName resetCode',
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * User Reset Password
	 * @param {number} userId - User id
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	resetPassword: async function (userId, userAuth) {
		try {
			return await UserModel.findOneAndUpdate({ //update and get the reset session token
				'userId': userId,
				'isAdmin': true,
			}, {
				$set: {
					'resetCode': '',
					'pwd': userAuth.pwd
					// 'sessions': {
					// 	$elemMatch: {
					// 		'sessionToken': userAuth.sessions.sessionToken
					// 	}
					// }
				},
				$push: {
					'sessions': userAuth.sessions
				}
			}, {
				new: true,
				fields: 'userId email userName sessions.sessionToken fName lName',
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * User Change Password
	 * @param {number} userId - User id
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	changePassword: async function (userId, userAuth) {
		try {
			return await UserModel.findOneAndUpdate({ // update and get the data
				'userId': userId,
				'isAdmin': true,
			}, {
				$set: {
					'pwd': userAuth.pwd
				}
			}, {
				new: true,
				fields: 'userId email userName fName lName',
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * User Logout
	 * @param {number} userId - User id
	 * @param {string} sessionToken - Session Token
	 * @returns {object}  Modal object
	 * @throws {object} e - Error
	 */
	logout: async function (userId, sessionToken) {
		try {
			return await UserModel.findOneAndUpdate({
				'userId': userId
			}, {
				$pull: {
					'sessions': { 'sessionToken': sessionToken }
				}
			}, {
				new: true, // to get the updated record
				fields: 'sessions.sessionToken',
			});
		} catch (e) {
			throw e;
		}
	},

};