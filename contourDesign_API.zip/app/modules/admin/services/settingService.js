/**
 * Setting Service
 * @exports Admin/Setting/Service
 */
var SettingModel = require('../../../models/setting');

module.exports = {

    /**
     * Get all settings from DB
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getSettings: async function () {
        try {
            return await SettingModel.findOne({
                'settingId': 1
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Update Setting data
     * @param {object} settingData - Data required for update data
     * @throws {object} e - Error
     */
    updateSettingData: async function (settingData) {
        try {
            return await SettingModel.findOneAndUpdate({
                'settingId': 1
            }, settingData, {
                new: true,
                upsert: true
            });
        } catch (e) {
            throw e;
        }
    },

};