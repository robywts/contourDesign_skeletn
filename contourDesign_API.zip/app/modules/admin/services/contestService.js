/**
 * Contest Service
 * @exports Admin/Contest/Service
 */
var ContestModel = require('../../../models/contest');
var UserModel = require('../../../models/user');

module.exports = {

	/**
	 * Get all contests from DB
	 * @param {object} search - Data required for search
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getAll: async function (search) {
		try {
			return await ContestModel.find({
					'contestName': new RegExp(search.search_text, 'i')
				})
				.select('_id contestId contestName contestStartTime entryFees userName description visibility')
				.limit(parseInt(search.limit))
				.skip(search.limit * search.page)
				.collation({
					locale: "en"
				})
				.sort({
					[search.sort_field]: search.sort
				})
				.exec();
			// return await ContestModel.aggregate([{
			// 			$match: {
			// 				'contestName': new RegExp(search.search_text, 'i')
			// 			}
			// 		},
			// 		{
			// 			$unwind: "$entrants"
			// 		},
			// 		{
			// 			$group: {
			// 				// _id: "$contestId",
			// 				_id: {
			// 					_id: "$_id",
			// 					contestId: "$contestId",
			// 					contestName: "$contestName",
			// 					entryFees: "$entryFees",
			// 					contestStartTime: "$contestStartTime",
			// 					userName: "$userName"
			// 					// isAdmin: "$isAdmin"
			// 				},
			// 				entrantsCount: {
			// 					$sum: 1
			// 				}
			// 			}
			// 		},
			// 		{
			// 			$sort: {
			// 				entrantsCount: -1
			// 			}
			// 		}
			// 	])
			// 	.limit(parseInt(search.limit))
			// 	.skip(search.limit * search.page)
			// 	.exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get total count of contents
	 * @param {object} search - Data required for search
	 * @returns {Number} Total count of records
	 * @throws {object} e - Error
	 */
	getAllCount: async function (search, contestsDB) {
		try {
			return await ContestModel.count({
				'contestName': new RegExp(search.search_text, 'i')
			}).exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get one record from DB
	 * @param {Number} id - Id of the record
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	// getOne: async function (contestGamesMapData) {
	// 	try {
	// 		return await ContestModel.findOne({

	// 			$and: [{
	// 				"contestId": contestGamesMapData.contestId
	// 			}, {
	// 				$or: [{
	// 					"entrants.userId": contestGamesMapData.userId
	// 				}, {
	// 					"createdBy": contestGamesMapData.userId
	// 				}]
	// 			}]
	// 		});
	// 	} catch (e) {
	// 		throw e;
	// 	}
	// },

	/**
	 * Get one contest by id (for Form)
	 * @param {Number} id - Id of the record
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getOneFormContest: async function (id = '') {
		try {
			return await ContestModel.findOne({
					'contestId': id
				},
				'contestId contestName contestStartTime visibility isGuaranteed isVideoAvailable summary labels sportId sName contestTypeId contestType prizeTmpId gameTypeId gameType prizeMode prizeTickets prizePool entryFees entrants rakePerc minLimit maxLimit maxEntriesPerUser prizes draftgroupId contestStatus');
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get one contest by id
	 * @param {Number} id - Id of the record
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getOneContest: async function (id) {
		try {
			return await ContestModel.findOne({
				'contestId': id
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Find duplicate record
	 * @param {object} modalObj - Modal object
	 * @param {number} id - Id of the record which is to be ignored
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	findContest: async function (modalObj, id = '') {
		try {
			if (id != '') { // for update
				return await ContestModel.findOne({
						$and: [{
							'contestName': modalObj.contestName
						}, {
							"contestId": {
								$ne: id
							}
						}]
					},
					'_id contestId contestName');
			} else { // for add
				return await ContestModel.findOne({
						'contestName': modalObj.contestName
					},
					'_id contestId contestName');
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Record Addition
	 * @param {object} modalObj - Model object
	 * @returns {object} Response model
	 * @throws {object} e - Error
	 */
	addContest: async function (modalObj) {
		try {
			// console.log(modalObj);
			return await modalObj.save();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Update Record
	 * @param {object} modalObj - Data required for update
	 * @param {integer} id - record id
	 * @returns {object} Response model
	 * @throws {object} e - Error
	 */
	updateContest: async function (modalObj, id) {
		try {
			return await ContestModel.findOneAndUpdate({
				'contestId': id,
				'contestStatus': 3
			}, {
				$set: modalObj
			}, {
				new: true
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Add a contest to db
	 * @param {object} contestModel - Model object mapped to the data to be added
	 * @returns {object} Modal object
	 * @throws {object} e - Error
	 */
	// add: async function (contestModel) {
	// 	try {
	// 		return await contestModel.save();
	// 	} catch (e) {
	// 		throw e;
	// 	}
	// },


	/**
	 * Update a contest to db
	 * @param {Number} id - Request object (id of the record)
	 * @param {object} contest - Oject mapped to the data to be added
	 * @returns {object} Response object
	 * @throws {object} e - Error
	 */
	// update: async function (id, contest) {
	// 	try {
	// 		return await ContestModel.update({
	// 			contestId: id
	// 		}, contest);
	// 	} catch (e) {
	// 		throw e;
	// 	}
	// },

	/**
	 * Delete a contest
	 * @param {Number} id Request id of the record
	 * @returns {object} Delete Object
	 * @throws {object} e - Error
	 */
	delete: async function (id) {
		try {
			return await ContestModel.remove({
				contestId: id
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get HtoH contest list details
	 * @param {object}  search - search object 
	 * @param {integer} sportId -sport Id
	 * @param {integer} userId - user id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getUserHtoHContest: async function (search, sportId) {
		try {
			let searchConditions = [{
				'contestName': new RegExp(search.search_text, 'i')
			}];

			searchConditions.push({
				'contestTypeId': 2
			});

			if (sportId != '') {
				searchConditions.push({
					'sportId': parseInt(sportId)
				});
			}

			return await ContestModel.find({
					$and: searchConditions
				})
				.limit(parseInt(search.limit))
				.skip(search.limit * search.page)
				.collation({
					locale: "en"
				})
				.sort({
					[search.sort_field]: search.sort_order
				})
				.exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get HtoH contest count
	 * @param {integer} sportId -sport Id
	 * @param {integer} userId - user id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getUserHtoHContestAll: async function (search, sportId) {
		try {
			let searchConditions = [{
				'contestName': new RegExp(search.search_text, 'i')
			}];

			searchConditions.push({
				'contestTypeId': 2
			});

			if (sportId != '') {
				searchConditions.push({
					'sportId': parseInt(sportId)
				});
			}

			return await ContestModel.count({
				$and: searchConditions
			}).exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get multi contest list details
	 * @param {object}  search - search object 
	 * @param {integer} sportId -sport Id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getUserMultiContest: async function (search, sportId) {
		try {
			let searchConditions = [{
				'contestName': new RegExp(search.search_text, 'i')
			}];

			searchConditions.push({
				'contestTypeId': 1
			});

			if (sportId != '') {
				searchConditions.push({
					'sportId': parseInt(sportId)
				});
			}

			return await ContestModel.find({
					$and: searchConditions
				})
				.limit(parseInt(search.limit))
				.skip(search.limit * search.page)
				.collation({
					locale: "en"
				})
				.sort({
					[search.sort_field]: search.sort_order
				})
				.exec();

			// let skip = parseInt(search.limit) * parseInt(search.page);
			// let limit = parseInt(search.limit);
			// return await ContestModel.aggregate([{
			// 			$match: {
			// 				$and: searchConditions
			// 			}
			// 		},
			// 		{
			// 			$unwind: "$entrants"
			// 		},
			// 		{
			// 			$group: {
			// 				_id: {
			// 					_id: "$_id",
			// 					contestId: "$contestId",
			// 					contestName: "$contestName",
			// 					entryFees: "$entryFees",
			// 					contestStartTime: "$contestStartTime",
			// 					userName: "$userName",
			// 					visibility: "$visibility",
			// 					contentStatus: "$contentStatus",
			// 					gameType: "$gameType",
			// 					createdBy: "$createdBy",
			// 					createdAt: "$createdAt",
			// 					updatedAt: "$updatedAt",
			// 					isAdminRow: "$isAdminRow"
			// 				},
			// 				entrantsCount: {
			// 					$sum: 1
			// 				}
			// 			}
			// 		}, {
			// 			$sort: {
			// 				[search.sort_field]: search.sort_order
			// 			}
			// 		},
			// 		{
			// 			$limit: limit
			// 		},
			// 		{
			// 			$skip: skip
			// 		}
			// 	])
			// 	.exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get multi contest count
	 * @param {object} search - Search Object
	 * @param {integer} sportId -sport Id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getUserMultiContestCount: async function (search, sportId) {
		try {
			let searchConditions = [{
				'contestName': new RegExp(search.search_text, 'i')
				// }, {
				// 	'entrants': {
				// 		$elemMatch: {
				// 			"_id": {
				// 				"$exists": true
				// 			}
				// 		}
				// 	}
			}];

			searchConditions.push({
				'contestTypeId': 1
			});

			if (sportId != '') {
				searchConditions.push({
					'sportId': parseInt(sportId)
				});
			}

			return await ContestModel.count({
				$and: searchConditions
			}).exec();
		} catch (e) {
			throw e;
		}
	},


	/**
	 * Get contests list to be refunded
	 * @param {object}  search - search object 
	 * @param {integer} sportId -sport Id
	 * @param {integer} userId - user id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getAllContestToBeRefunded: async function (search, sportId) {
		try {
			let searchConditions = [{
				'contestName': new RegExp(search.search_text, 'i')
			}];

			searchConditions.push({
				'contestStatus': 4				
			});	
			
			searchConditions.push({				
				'entryFees': {$ne: 0}				
			});
						
			if (sportId != '') {
				searchConditions.push({
					'sportId': parseInt(sportId)
				});
			}

			return await ContestModel.find({
					$and: searchConditions
				})
				.limit(parseInt(search.limit))
				.skip(search.limit * search.page)
				.collation({
					locale: "en"
				})
				.sort({
					[search.sort_field]: search.sort_order
				})
				.exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get total count of contests to be refunded
	 * @param {integer} sportId -sport Id
	 * @param {integer} userId - user id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getRefundedContestsCount: async function (search, sportId) {
		try {
			let searchConditions = [{
				'contestName': new RegExp(search.search_text, 'i')
			}];

			searchConditions.push({
				'contestStatus': 4				
			});	
			
			searchConditions.push({				
					'entryFees': {$ne: 0}				
			});
				
			if (sportId != '') {
				searchConditions.push({
					'sportId': parseInt(sportId)
				});
			}

			return await ContestModel.count({
				$and: searchConditions
			}).exec();
		} catch (e) {
			throw e;
		}
	},

	/**
     * Get refund contest by contest id.
     * @param {Number} contestId - Contest id to be refunded    	
     * @returns {object} Contest
     * @throws {object} e - Error
     */
    getRefundContest: async function (contestId) {
        try {
			let searchConditions = [{
				'contestId': contestId
			},{
				'contestStatus': 4				
			},{
				'refundIssued': {$ne: 'Y'}				
			},{
				'entryFees': {$ne: 0}				
			}];
	
            return await ContestModel.findOne({
                $and: searchConditions
            },'_id userId contestId contestName entryFees contestStatus refundIssued entrants');
        } catch (e) {
            throw e;
        }
	},
	
	/**
     * Update contest refunded status
     * @param {Number} contestId - Contest id to be refunded	
     * @returns {object} Status
     * @throws {object} e - Error
     */
    updateContestStatus: async function (contestId) {
        try {
            return await ContestModel.findOneAndUpdate({
                'contestId': contestId
            }, {
				$set: {
                    "refundIssued": 'Y'
                }				
			},{
                new: false
            });
        } catch (e) {
            throw e;
        }
    },

	/**
     * Refund user contest amount
     * @param {Number} contestId - User id   
	 * @param {Number} totalAmount - Amount to be refunded    
     * @returns {object} Status
     * @throws {object} e - Error
     */
    refundAmount: async function (userId, totalAmount) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userId
            }, {
				$inc: {
					"balance": totalAmount
				}
			},{
                new: false
            });
        } catch (e) {
            throw e;
        }
    },


};