/**
 * PrizeTemplate Service
 * @exports PrizeTemplate/Service
 */
var PrizeTemplateModel = require('../../../models/prizeTemplate');

module.exports = {

    /**
     * Get PrizeTemplates for dropdown
     * @param {number} sportsId League id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getPrizeTemplatesDD: async function (sportsId) {
        try {
            return await PrizeTemplateModel.find({
                    $and: [{
                            "status": 1
                        },
                        {
                            $or: [{
                                "gameTypeId": parseInt(sportsId)
                            }, {
                                "gameTypeId": parseInt(sportsId) + 5
                            }]
                        }
                    ]
                })
                .select('prizeTmpId tmpName')
                .collation({
                    locale: "en"
                })
                .sort({
                    "tmpName": "asc"
                })
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get PrizeTemplates 
     * @param {object} search - search object
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getPrizeTemplates: async function (search) {
        try {
            let searchConditions = [{
                'tmpName': new RegExp(search.search_text, 'i')
            }];
            if (search.game_type != '') {
                searchConditions.push({
                    'gameType': search.game_type
                });
            }
            if (search.prize_mode != '') {
                searchConditions.push({
                    'prizeMode': search.prize_mode
                });
            }

            return await PrizeTemplateModel.find({
                    $and: searchConditions
                })
                .select('prizeTmpId tmpName gameTypeId gameType prizeMode prizeTickets prizePool minLimit maxLimit maxEntriesPerUser status updatedAt')
                .limit(search.limit)
                .skip(search.limit * search.page)
                .collation({
                    locale: "en"
                })
                .sort({
                    [search.sort_field]: search.sort_order
                })
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get PrizeTemplates  count
     * @param {object} search - search object
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getPrizeTemplatesCount: async function (search) {
        try {
            let searchConditions = [{
                'tmpName': new RegExp(search.search_text, 'i')
            }];
            if (search.game_type != '') {
                searchConditions.push({
                    'gameType': search.game_type
                });
            }
            if (search.prize_mode != '') {
                searchConditions.push({
                    'prizeMode': search.prize_mode
                });
            }
            return await PrizeTemplateModel.count({
                $and: searchConditions
            }).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get prize template by id
     * @param {integer} id - record id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getOnePrizeTemplate: async function (id = '') {
        try {
            return await PrizeTemplateModel.findOne({
                'prizeTmpId': id
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Find duplicate record
     * @param {object} modalObj - Modal object
     * @param {number} id - Id of the record which is to be ignored
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    findPrizeTemplate: async function (modalObj, id = '') {
        try {
            if (id != '') { // for update
                return await PrizeTemplateModel.findOne({
                        $and: [{
                            'tmpName': modalObj.tmpName
                        }, {
                            "prizeTmpId": {
                                $ne: id
                            }
                        }]
                    },
                    '_id tmpName');
            } else { // for add
                return await PrizeTemplateModel.findOne({
                        'tmpName': modalObj.tmpName
                    },
                    '_id tmpName');
            }
        } catch (e) {
            throw e;
        }
    },

    /**
     * Record Addition
     * @param {object} modalObj - Model object
     * @returns {object} Response model
     * @throws {object} e - Error
     */
    addPrizeTemplate: async function (modalObj) {
        try {
            return await modalObj.save();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Update Record
     * @param {object} modalObj - Data required for update
     * @param {integer} id - record id
     * @returns {object} Response model
     * @throws {object} e - Error
     */
    updatePrizeTemplate: async function (modalObj, id) {
        try {
            return await PrizeTemplateModel.findOneAndUpdate({
                'prizeTmpId': id
            }, {
                $set: modalObj
            }, {
                new: true
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Update record Status
     * @param {object} status - Data required for update status
     * @param {integer} id - id
     * @returns {object} Response model 
     * @throws {object} e - Error
     */
    updateStatus: async function (status, id) {
        try {
            return await PrizeTemplateModel.findOneAndUpdate({
                'prizeTmpId': id
            }, {
                $set: {
                    "status": status
                }
            }, {
                new: false
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Delete a record
     * @param {Number} id Request id of the record
     * @returns {object} Delete Object
     * @throws {object} e - Error
     */
    delete: async function (id) {
        try {
            return await PrizeTemplateModel.remove({
                prizeTmpId: id
            });
        } catch (e) {
            throw e;
        }
    },

};