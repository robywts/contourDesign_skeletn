/**
 * DraftGroup Service
 * @exports User/Service
 */
var DraftGroupModel = require('../../../models/draftgroup');
var PlayerModel = require('../../../models/player');
var GameModel = require('../../../models/event');
var async = require('async');
var moment = require('moment');

var self = module.exports = {

    /**
     * Get DraftGroups for dropdown
     * @param {number} sportsId League id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getDraftGroupsDD: async function (sportsId) {
        try {
            // return await DraftGroupModel.find({
            //         $and: [{
            //                 "sportId": sportsId
            //             },
            //             {
            //                 "dgState": 'Upcoming'
            //                 // },
            //                 // {
            //                 //     $or: [{
            //                 //         "dgState": 'Upcoming'
            //                 //     }, {
            //                 //         "dgState": 'Live'
            //                 //     }]
            //             }
            //         ]
            //     })
            //     .select('draftgroupId dgName startTimeUTC gameList')
            //     .collation({
            //         locale: "en"
            //     })
            //     .sort({
            //         "dgName": "asc"
            //     })
            //     .exec();
            return await DraftGroupModel.aggregate([{
                        $match: {
                            $and: [{
                                    sportId: parseInt(sportsId)
                                },
                                {
                                    dgState: 'Upcoming'
                                }
                            ]
                        }
                    },
                    {
                        $unwind: "$gameList"
                    },
                    {
                        $group: {
                            _id: {
                                _id: "$_id",
                                draftgroupId: "$draftgroupId",
                                dgName: "$dgName",
                                startTimeUTC: "$startTimeUTC"
                            },
                            gamesCount: {
                                $sum: 1
                            }
                        }
                    }, {
                        $sort: {
                            dgName: 1
                        }
                    }
                ])
                // .collation({
                //     locale: "en"
                // })
                .exec();

            // , {
            //     collation: {
            //         locale: "en",
            //         strength: 1
            //     }
            // }

        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get draftgroup from DB
     * @param {object} week - Data required for getting draftgroups
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getDraftGroup: async function (draftGroupMapData) {
        try {
            return await DraftGroupModel.find({
                /*$or: [{
                    "dgState": 'Upcoming'
                }, {
                    "dgState": 'Live'
                }],*/
                "sportId": draftGroupMapData.sportId,
                "week": draftGroupMapData.dgWeek
            }, 'draftgroupId dgName gameList dgState sportId week sortOrder');
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get draftgroup from DB
     * @param {object} id - draftgroup id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getDraftGroupDetails: async function (draftgroupId) {
        try {
            return await DraftGroupModel.findOne({
                'draftgroupId': draftgroupId,
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get draftgroup's contest list from DB
     * @param {object} id - draftgroup id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getDraftGroupContest: async function (draftgroupId) {
        try {
            return await DraftGroupModel.findOne({
                'draftgroupId': draftgroupId,
            }, 'contestList');
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get draftgroup's contest list details from DB
     * @param {object} array - contest ids
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getDraftgroupGames: async function (draftgroupId) {
        try {
            return await DraftGroupModel.find({
                'draftgroupId': draftgroupId
            }, 'gameList');
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get draftgroup's players list from DB
     * @param {object} id - draftgroup id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getDraftGroupPlayers: async function (draftgroupId) {
        try {
            return await DraftGroupModel.findOne({
                'draftgroupId': draftgroupId,
            }, 'gameList');
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get player details from DB
     * @param {object} array - contest ids
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getPlayerDataFromDraftgroup: async function (lineupData, playerIndex) {
        try {
            return await DraftGroupModel.aggregate([{
                    "$match": {
                        draftgroupId: lineupData.draftgroupId
                    }
                },
                {
                    "$unwind": "$gameList"
                },
                {
                    "$match": {
                        "gameList.eventId": lineupData.players[playerIndex].eventId
                    }
                },
                {
                    "$unwind": "$gameList.players"
                },
                {
                    "$match": {
                        "gameList.players.playerId": lineupData.players[playerIndex].playerId
                    }
                },
                // Tidy up the output
                {
                    "$project": {
                        _id: 0,
                        players: "$gameList.players"
                    }
                }
            ])
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get draftgroup weeks from DB
     * @param {object} week - Data required for getting draftgroups
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getDraftGroupWeek: async function (draftGroupWeekMapData) {
        try {
            /* return await DraftGroupModel.find({
                 "sportId": draftGroupWeekMapData.sportId
             }, 'week');*/
            /* return await GameModel.distinct("week", {
                 "sportId": draftGroupWeekMapData.sportId
             })*/
             var season = moment().tz("EST").format('YYYY');
            return await GameModel.aggregate([{
                $match: {
                    "sportId": draftGroupWeekMapData.sportId,"season":parseInt(season)
                }
            }, {
                $group: {
                    _id: '$week'
                }
            }, {
                $sort: {
                    "_id": 1
                }
            }, {
                $project: {
                    _id: 0,
                    week: "$_id"
                }
            }])
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get draftgroup days from DB
     * @param {object} week - Data required for getting draftgroups
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getDraftGroupDayNBA: async function (draftGroupWeekMapData) {
        try {
            /* return await GameModel.distinct("week", {
                 "sportId": draftGroupWeekMapData.sportId
             })*/
            var curdate = moment().tz("EST").format('YYYYMMDD');
            return await GameModel.aggregate([{
                $match: {
                    $and: [{
                            "sportId": draftGroupWeekMapData.sportId
                        },
                        {
                            "week": {
                                $gte: parseInt(curdate)
                            }
                        }
                    ]
                }
            }, {
                $group: {
                    _id: '$week'
                }
            }, {
                $sort: {
                    "_id": 1
                }
            }, {
                $project: {
                    _id: 0,
                    week: "$_id"
                }
            }])

        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get Games from DB
     * @param {object} week - Data required for getting draftgroups
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getGamesList: async function (draftGroupMapData) {
        try {
            return await GameModel.find({
                /*"isActive": 1,
                  $or: [{
                      "dgState": 'Upcoming'
                  }, {
                      "dgState": 'Live'
                  }],*/
                "sportId": draftGroupMapData.sportId,
                "week": draftGroupMapData.dgWeek
                // }, 'draftgroupId dgName gameList dgState sportId week');
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Add a darftGroup to db
     * @param {object} contestModel - Model object mapped to the data to be added
     * @returns {object} Modal object
     * @throws {object} e - Error
     */
    add: async function (darftGroupModel) {
        try {
            return await darftGroupModel.save();
        } catch (e) {
            throw e;
        }
    },

    /**
     * update a darftGroup
     * @param {object} contestModel - Model object mapped to the data to be added
     * @returns {object} Modal object
     * @throws {object} e - Error
     */
    update: async function (darftGroupModel, draftgroupId) {
        try {
            return await DraftGroupModel.findOneAndUpdate({
                'draftgroupId': draftgroupId
            }, {
                $set: darftGroupModel
            }, {
                new: false
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get events from DB
     * @param {object} gameIds - Data required for getting games
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getEventsList: async function (eventId) {
        try {
            var GameModel = require('../../../models/event');
            return await GameModel.find({
                "eventId": {
                    $in: eventId
                }
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get All events from DB
     * @param {object} gameIds - Data required for getting games
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getAllEventsList: async function (eventDB) {
        try {
            gameList = [];

            //return await eventDB.forEach(async function(event, index, arr) {                  
            return await async.eachSeries(eventDB, async function (event, outCb) {

                daraftgroups = [];
                game = {};
                game['eventId'] = event.eventId;
                game['startTimeUTC'] = event.startTimeUTC;
                game['gameStatus'] = '';
                //game player details
                players = [];
                //home team details
                homeTeamId = event.homeTeam.teamId;
                awayTeamId = event.awayTeam.teamId;
                playersDatas = [];
                var playersDatasHome = await self.getHomePlayers(homeTeamId);
                var playersDatasAway = await self.getAwayPlayers(awayTeamId);
                playersDatas = playersDatasHome.concat(playersDatasAway);

                if (playersDatas) {
                    playersDatas.forEach(async function (playersData) {
                        var teamPlayers = {};
                        teamPlayers.fName = playersData.fName;
                        teamPlayers.lName = playersData.lName;
                        teamPlayers.playerId = playersData.playerId;
                        teamPlayers.posId = playersData.positions[0].posId;
                        teamPlayers.posAbbr = playersData.positions[0].posAbbr;
                        teamPlayers.CapValue = playersData.fanProjSalary;
                        teamPlayers.isInjured = playersData.isInjured;
                        competitionPlayer = {};
                        competitionPlayer.compId = event.eventId;
                        competitionPlayer.nameDisplay = [{
                            htName: event.homeTeam.tAbbr,
                            htScore: '',
                            value: '',
                            atName: event.awayTeam.tAbbr,
                            atScore: ''
                        }];

                        teamPlayers.competition = competitionPlayer;
                        teamPlayers.teamId = playersData.team.teamId;
                        teamPlayers.teamAbbr = playersData.team.tAbbr;
                        teamPlayers.fanProjSalary = playersData.fanProjSalary;
                        teamPlayers.fanProjScore = playersData.fanProjPoints;
                        players.push(teamPlayers);
                    });
                }
                game['players'] = players;

                //away team details
                //awayTeamId = event.awayTeam.teamId
                League = {};
                League.leagueId = event.league.leagueId;
                League.name = event.league.name;
                League.abbr = event.league.abbr;
                leagues = [];
                leagues.push(League);
                gameList.push(game);
                outCb(null);
            });

        } catch (e) {
            throw e;
        }
    },
    /**
     *  Get events from DB
     * @param {object} gameIds - Data required for getting games
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getHomePlayers: async function (homeTeamId) {
        try {
            return await PlayerModel.find({
                'team.teamId': homeTeamId
            });
        } catch (e) {
            throw e;
        }
    },

    getAwayPlayers: async function (awayTeamId) {
        try {
            return await PlayerModel.find({
                'team.teamId': awayTeamId
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Delete a draftgroup
     * @param {Number} id Request id of the record
     * @returns {object} Delete Object
     * @throws {object} e - Error
     */
    delete: async function (draftgroupId) {
        try {
            return await DraftGroupModel.remove({
                'draftgroupId': draftgroupId
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get Week duration
     * @param {object} week - Data required for getting draftgroups
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getWeekDuration: async function (draftGroupMapData, week) {
        try {
            return await GameModel.aggregate(
                [{
                        "$match": {
                            'week': week,
                            'sportId': draftGroupMapData.sportId
                            /*'isActive': '1'*/
                        }
                    },
                    {
                        $group: {
                            _id: null,
                            min: {
                                $min: "$startTimeUTC"
                            },
                            max: {
                                $max: "$startTimeUTC"
                            }
                        }
                    }
                ]
            );

        } catch (e) {
            throw e;
        }
    },

     /**
     *  /To get max and min fantasy player positions NBA
     * @param {object} draftgroupId -draftgroupId
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getMinMaxNBA: async function (draftgroupId) {
        try {
            return await DraftGroupModel.aggregate(
                [
                    { "$match": { draftgroupId: draftgroupId } },
                    { $unwind: "$gameList" },
                    { $unwind: "$gameList.players" },
                    { "$match": { "gameList.players.fanProjSalary": { "$gte": 1 } } },
                    {
                        $group:
                        {
                            _id: "$gameList.players.posGen",
                            min: { $min: "$gameList.players.fanProjSalary" },
                            max: { $max: "$gameList.players.fanProjSalary" }
                        }
                    }
                ]
            );

        } catch (e) {
            throw e;
        }
    },

         /**
     *  /To get max and min fantasy player positions NFL
     * @param {object} draftgroupId -draftgroupId
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getMinMaxNFL: async function (draftgroupId) {
        try {
            return await DraftGroupModel.aggregate(
                [
                    { "$match": { draftgroupId: draftgroupId } },
                    { $unwind: "$gameList" },
                    { $unwind: "$gameList.players" },
                    { "$match": { "gameList.players.fanProjSalary": { "$gte": 1 } } },
                    {
                        $group:
                        {
                            _id: "$gameList.players.posAbbr",
                            min: { $min: "$gameList.players.fanProjSalary" },
                            max: { $max: "$gameList.players.fanProjSalary" }
                        }
                    }
                ]
            );

        } catch (e) {
            throw e;
        }
    },


    
     /**
     *  updating mValue draftgroup schema
     * @param {object} draftgroupId -draftgroupId
     * @param {object} playerId -playerId
     * @param {object} field -field
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    updateMvalue: async function (draftgroupId, playerId, field) {
        try {
            return await DraftGroupModel.findOneAndUpdate(
                { "draftgroupId": draftgroupId, "gameList.players.playerId": playerId },

                field,
                {
                    new: false
                });

        } catch (e) {
            throw e;
        }
    },
};