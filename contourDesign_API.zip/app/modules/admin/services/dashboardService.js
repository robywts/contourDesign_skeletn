/**
 * Dashboard Service
 * @exports Dashboard/Service
 */
var UserModel = require('../../../models/user');
var ClanModel = require('../../../models/clan');
var ContestModel = require('../../../models/contest');
var WithdrawalModel = require('../../../models/withdrawal');
var TransactionModel = require('../../../models/transaction');

module.exports = {

    /**
     * Get user count
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    userCount: async function () {
        try {
            return await UserModel.aggregate([{
                $group: {
                    _id: {
                        userStatus: "$userStatus",
                        isAdmin: "$isAdmin"
                    },
                    cnt: {
                        $sum: 1
                    }
                }
            }]).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get clan count
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    clanCount: async function () {
        try {
            return await ClanModel.aggregate([{
                $group: {
                    _id: {
                        clanStatus: "$clanStatus"
                    },
                    cnt: {
                        $sum: 1
                    }
                }
            }]).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get contest count
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    contestCount: async function () {
        try {
            return await ContestModel.aggregate([{
                $group: {
                    _id: {
                        contestStatus: "$contestStatus",
                        contestType: "$contestTypeId"
                    },
                    cnt: {
                        $sum: 1
                    }
                }
            }]).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get withdrawal count
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    withdrawalCount: async function () {
        try {
            return await WithdrawalModel.aggregate([{
                $group: {
                    _id: {
                        withdrawalStatus: "$requestStatus"
                    },
                    cnt: {
                        $sum: 1
                    }
                }
            }]).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get transaction
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    transactionAmount: async function () {
        try {
            return await TransactionModel.aggregate([{
                $group: {
                    _id: {
                        tranType: "$tranType"
                    },
                    amt: {
                        $sum: "$amount"
                    }
                }
            }]).exec();
        } catch (e) {
            throw e;
        }
    },
};