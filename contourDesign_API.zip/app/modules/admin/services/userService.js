/**
 * User Service
 * @exports Admin/User/Service
 */
var UserModel = require('../../../models/user');
var ContestModel = require('../../../models/contest');
var LineupModel = require('../../../models/lineup');

module.exports = {

    /**
     * Get user profile from DB
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getProfile: async function (userId = '') {
        try {
            var userId = userId ? userId : global.userId;
            return await UserModel.findOne({
                    $and: [{
                        'userId': userId
                        // }, {
                        //     'isAdmin': false
                    }]
                },
                'userId email userName fName lName imageName balance totalDeposited h2hCnt multiplayerCnt wins totalAmountWon avgAmountPerContest userStatus currentLoginType loginTypes');
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get users by the array of ids
     * @param {array} userId - user ids
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getUsersByIds: async function (userIds) {
        try {
            return await UserModel.find({
                    "userId": {
                        $in: userIds
                    }
                })
                .select('userId userName fName lName email btId imageName userStatus loginTypes currentLoginType')
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get users 
     * @param {object} search - search object 
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    listUsers: async function (search, userId) {
        try {
            let searchConditions = [{
                    "userId": {
                        $ne: userId
                    }
                },
                {
                    "isAdmin": false
                },
                {
                    $or: [{
                            'userName': new RegExp(search.search_text, 'i')
                        },
                        {
                            'email': new RegExp(search.search_text, 'i')
                        }
                    ]
                }
            ];

            if (search.status != '') {
                searchConditions.push({
                    'userStatus': search.status
                });
            }

            return await UserModel.find({
                    $and: searchConditions
                })
                .select('userId userName fName lName email h2hCnt multiplayerCnt wins userStatus')
                .limit(search.limit)
                .skip(search.limit * search.page)
                .collation({
                    locale: "en"
                })
                .sort({
                    [search.sort_field]: search.sort_order
                })
                .exec();

        } catch (e) {
            throw e;
        }
    },

    /**
     * Get users count
     * @param {object} search - search object 
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    listUsersCount: async function (search, userId) {
        try {
            let searchConditions = [{
                    "userId": {
                        $ne: userId
                    }
                },
                {
                    "isAdmin": false
                },
                {
                    $or: [{
                            'userName': new RegExp(search.search_text, 'i')
                        },
                        {
                            'email': new RegExp(search.search_text, 'i')
                        }
                    ]
                }
            ];

            if (search.status != '') {
                searchConditions.push({
                    'userStatus': search.status
                });
            }

            return await UserModel.count({
                $and: searchConditions
            }).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Update User Status
     * @param {object} userProfile - Data required for update profile    
     * @returns {Number} Total count of records
     * @throws {object} e - Error
     */
    updateStatus: async function (userProfile) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userProfile.userId
            }, {
                $set: {
                    "userStatus": userProfile.status
                }
            }, {
                new: false
            });
        } catch (e) {
            throw e;
        }
    },



    /**
     * Get search conditions
     * @param {object}  search - search object
     * @param {integer} userId - user id
     * @param {integer} contestType - Contest Type (1 or 2)
     * @returns {object} Search Object
     * @throws {object} e - Error
     */
    getSearchConditions: function (search, userId, contestType) {
        try {
            let searchConditions = [{
                "contestTypeId": contestType
            }, {
                $or: [{
                    "entrants.userId": userId
                }, {
                    "createdBy": userId
                }]
            }];
            if (search.contest_status != '') {
                searchConditions.push({
                    'contestStatus': search.contest_status
                });
            }
            if (search.league_type != '') {
                searchConditions.push({
                    'sportId': search.league_type
                });
            }
            if (search.from_date != '') {
                var dt = search.from_date.split('/');
                searchConditions.push({
                    'createdAt': {
                        $gte: new Date(dt[2] + '-' + dt[0] + '-' + dt[1])
                        // $gte: new Date("2018-03")
                    }
                });
            }
            if (search.to_date != '') {
                var dt = search.to_date.split('/');
                var dtObj = new Date(dt[2] + '-' + dt[0] + '-' + dt[1]);
                dtObj.setDate(dtObj.getDate() + 1);
                searchConditions.push({
                    'createdAt': {
                        $lte: dtObj
                        // $gte: new Date("2018-03")
                    }
                });
            }
            return searchConditions;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get user's HtoH contest list details
     * @param {object}  search - search object
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getUserHtoHContest: async function (search, userId) {
        try {
            var searchConditions = this.getSearchConditions(search, userId, 2);
            return await ContestModel.find({
                    $and: searchConditions
                })
                .select('contestId createdBy contestStartTime entryFees entrants rakePerc')
                .limit(parseInt(search.limit))
                .skip(search.limit * search.page)
                .collation({
                    locale: "en"
                })
                .sort({
                    [search.sort_field]: search.sort_order
                })
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get user's HtoH contest count
     * @param {object} search - search object
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getUserHtoHContestCount: async function (search, userId) {
        try {
            var searchConditions = this.getSearchConditions(search, userId, 2);
            return await ContestModel.count({
                $and: searchConditions
            }).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get user's multi contest points
     * @param {object}  userContestDB - getUserMultiContest's result object
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getUserMultiContestPoints: async function (userContestDB, userId) {
        try {
            var contestIds = [];
            for (var i in userContestDB) {
                contestIds.push(userContestDB[i].contestId);
            }
            return await LineupModel.find({
                    $and: [{
                            'contestId': {
                                $in: contestIds
                            }
                        },
                        {
                            'userId': userId
                        }
                    ]
                })
                .select('contestId lineupId position points')
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get user's multi contest list details
     * @param {object}  search - search object
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getUserMultiContest: async function (search, userId) {
        try {
            var searchConditions = this.getSearchConditions(search, userId, 1);
            return await ContestModel.find({
                    $and: searchConditions
                })
                .select('contestId contestName contestStartTime entryFees entrants rakePerc')
                .limit(parseInt(search.limit))
                .skip(search.limit * search.page)
                .collation({
                    locale: "en"
                })
                .sort({
                    [search.sort_field]: search.sort_order
                })
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get user's multi contest count
     * @param {object}  search - search object
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getUserMultiContestCount: async function (search, userId) {
        try {
            var searchConditions = this.getSearchConditions(search, userId, 1);
            return await ContestModel.count({
                $and: searchConditions
            }).exec();
        } catch (e) {
            throw e;
        }
    },

};