/**
 * LineupTemplate Service
 * @exports LineupTemplate/Service
 */
var LineUpTemplateModel = require('../../../models/lineupTemplate');

module.exports = {

	/**
	 * Get lineup template
	 * @param {object} lineupTemplate - Data required for fetching lineup template
	 * @returns {Number} Result set object
	 * @throws {object} e - Error
	 */
	getLineUpTemplate: async function (lineupTemplate) {
		try {
			return await LineUpTemplateModel.findOne({
				'sportId': lineupTemplate.sportId,
			}, { 'gameTypes': { $elemMatch: { gameTypeId: lineupTemplate.gameTypeId } } }).select('sportId sName isAvailable sortOrder').exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get All lineup template
	 * @returns {Number} Result set object
	 * @throws {object} e - Error
	 */
	getAllLineUpTemplate: async function () {
		try {
			return await LineUpTemplateModel.find({
			});
		} catch (e) {
			throw e;
		}
	},

};