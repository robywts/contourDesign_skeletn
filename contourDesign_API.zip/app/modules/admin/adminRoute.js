/**
 * Admin Route
 * @exports Admin/General/Route
 */
var express = require('express');
var router = express.Router();

var generalHelper = require('./helpers/generalHelper');
var _t = require('./translations/' + process.env.LANGUAGE + '/generalTrans.json');

process.setMaxListeners(Infinity);
/**
 * Middleware
 */
var middleware = require('./adminMiddleware');
router.use(middleware.authentication);


/**
 * General Routes
 */
router.use('/general', function (req, res, next) {
	var generalController = require('./controllers/generalController');
	router.route('/general/ping').get(generalController.ping); // ping
	router.route('/general/log').post(generalController.log); // log

	router.route('/general/dummy-save').post(generalController.dummySave) // dummy add
	router.route('/general/dummy-save/:id').put(generalController.dummySave) // dummy update
		.delete(generalController.dummySave); // dummy delete
	next();
});

/**
 * Dashboard Routes
 */
router.use('/dashboard', function (req, res, next) {
	var dashboardController = require('./controllers/dashboardController');
	router.route('/dashboard').get(dashboardController.getDashboard);
	next();
});

/**
 * Setting Routes
 */
router.use('/setting', function (req, res, next) {
	if (global.permissions.includes('S')) { // if module id is found in the user permissions list
		var settingController = require('./controllers/settingController');
		router.route('/setting').get(settingController.getSettings) // Get all settings data
			.put(settingController.updateSettings); // Update settings data
		next();
	} else {
		generalHelper.handleError(req, res, 'Access Denied', _t.accessDenied, 1003);
	}
});

/**
 * UserAuth Routes
 */
router.use('/user/auth', function (req, res, next) {
	var userAuthController = require('./controllers/userAuthController');
	// router.route('/user/auth/register').post(userAuthController.register);
	router.route('/user/auth/login').post(userAuthController.login);
	router.route('/user/auth/forgot').put(userAuthController.forgot);
	router.route('/user/auth/reset').put(userAuthController.reset);
	router.route('/user/auth/changePassword').put(userAuthController.changePassword);
	router.route('/user/auth/logout').delete(userAuthController.logout);
	next();
});

/**
 * User Routes
 */
router.use('/users', function (req, res, next) {
	if (global.permissions.includes("U") === true) { // if module id is found in the user permissions list
		var userController = require('./controllers/userController');
		router.route('/users').get(userController.listUsers); //list users
		router.route('/users/status/:id').put(userController.updateStatus); //Update status
		router.route('/users/htohcontest/:id').get(userController.getHtHContest); //Update status
		router.route('/users/multicontest/:id').get(userController.getMultiPlayerContest); //Update status
		router.route('/users/:id').get(userController.getProfile) //get profile	
		next();
	} else {
		generalHelper.handleError(req, res, 'Access Denied', _t.accessDenied, 1003);
	}
});

/**
 * Prize Templates Routes
 */
router.use('/prizetemplates', function (req, res, next) {
	if (global.permissions.includes("PLT") === true) { // if module id is found in the user permissions list	
		var prizeTemplateController = require('./controllers/prizeTemplateController');
		router.route('/prizetemplates/dd').get(prizeTemplateController.getPrizeTemplatesDD); // get prizetemplates for dropdown
		router.route('/prizetemplates').get(prizeTemplateController.getPrizeTemplates); // get prizetemplates
		router.route('/prizetemplates').post(prizeTemplateController.addPrizeTemplates); // add prizetemplates
		router.route('/prizetemplates/:id').get(prizeTemplateController.getOnePrizeTemplate) // get one prizetemplates
			.put(prizeTemplateController.updatePrizeTemplate) // update
			.delete(prizeTemplateController.deletePrizeTemplate); // delete
		router.route('/prizetemplates/status/:id').put(prizeTemplateController.updateStatus) // Update status
		next();
	} else {
		generalHelper.handleError(req, res, 'Access Denied', _t.accessDenied, 1003);
	}
});

/**
 * H2H Contest Routes
 */
router.use('/contests/h2h', function (req, res, next) {
	var contestController = require('./controllers/contestController');
	// var prizeTemplateController = require('./controllers/prizeTemplateController');
	// var draftGroupController = require('./controllers/draftGroupController');

	if (global.permissions.includes("HC") === true) {
		router.route('/contests/h2h/lineUp/:id').get(contestController.getLineUpById); //get Lineup details by lineup id
		router.route('/contests/h2h/getmultiGames/:id').get(contestController.getMultiGames); //get contest's games by id

		router.route('/contests/h2h').get(contestController.getHtHContest); //get HtoH contets
		router.route('/contests/h2h/:id').get(contestController.getOneH2H) //getone
		next();
	} else {
		generalHelper.handleError(req, res, 'Access Denied', _t.accessDenied, 1003);
	}
});

/**
 * Multiplayer Contest Routes
 */
router.use('/contests/multicontest', function (req, res, next) {
	var contestController = require('./controllers/contestController');
	var prizeTemplateController = require('./controllers/prizeTemplateController');
	var draftGroupController = require('./controllers/draftGroupController');

	if (global.permissions.includes("MPC") === true) {
		router.route('/contests/multicontest/lineUp/:id').get(contestController.getLineUpById); //get Lineup details by lineup id
		router.route('/contests/multicontest/getmultiGames/:id').get(contestController.getMultiGames); //get contest's games by id

		router.route('/contests/multicontest/prizetemplates/dd/:id?').get(prizeTemplateController.getPrizeTemplatesDD); // get prizetemplates for dropdown
		router.route('/contests/multicontest/prizetemplates/:id').get(prizeTemplateController.getOnePrizeTemplate) // get one prizetemplates

		router.route('/contests/multicontest/draftgroups/dd/:id?').get(draftGroupController.getDraftGroupsDD); // get draft groups for dropdown
		router.route('/contests/multicontest/draftgroups/:id').get(draftGroupController.getDraftGroupDetails); //get draftgroup details by id

		// router.route('/contests').get(contestController.getAll); //getall
		router.route('/contests/multicontest').get(contestController.getMultiPlayerContest) //get multi contest
			.post(contestController.addContest) //add
		router.route('/contests/multicontest/:id')
			.get(contestController.getOnemultiplayer) //getone
			.put(contestController.updateContest) //update
			.delete(contestController.delete); //delete

		//router.route('/contests/getLineUps').get(contestController.getLineUp); //get lineups in a contest
		router.route('/contests/multicontest/getStandings/:id').get(contestController.getContestStandings); //get multi contest's participants standings by i
		router.route('/contests/multicontest/form/:id').get(contestController.getOneFormContest); //getone(form)

		next();
	} else {
		generalHelper.handleError(req, res, 'Access Denied', _t.accessDenied, 1003);
	}
});


/**
 * Refund Contest Routes
 */
router.use('/contests/refund', function (req, res, next) {
	var contestController = require('./controllers/contestController');
	if (global.permissions.includes("TH") === true) {
		router.route('/contests/refund').get(contestController.getContestToBeRefunded); //get contests tobe refunded.
		router.route('/contests/refund/:id').get(contestController.refundContest) //getone
		next();
	} else {
		generalHelper.handleError(req, res, 'Access Denied', _t.accessDenied, 1003);
	}
});

/**
 * DraftGroup Routes
 */
router.use('/draftgroups', function (req, res, next) {
	var draftGroupController = require('./controllers/draftGroupController');

	if (global.permissions.includes("DG") === true) {
		router.route('/draftgroups/dd/:id?').get(draftGroupController.getDraftGroupsDD); // get draft groups for dropdown

		router.route('/draftgroups/weeks/:id').get(draftGroupController.getDraftGroupWeeks); //get draftGroup weeks
		router.route('/draftgroups/games').get(draftGroupController.getGameslist); //get Games list    
		router.route('/draftgroups').get(draftGroupController.getDraftGroupList); //get draftGroups for dropdown
		router.route('/draftgroups/:id').get(draftGroupController.getDraftGroupDetails); //get draftgroup details by id
		//router.route('/draftgroups/getcontests/:id').get(draftGroupController.getDraftGroupContestDetails); //get draftgroup's contest list by id
		//router.route('/draftgroups/getplayers/:id').get(draftGroupController.getAllPlayer); //get all players in a draftgroup by id
		//router.route('/draftgroups/getlineUps/:id').get(draftGroupController.getLineUp); //get all lineups in a draftgroup by id
		router.route('/draftgroups').post(draftGroupController.cretae); //Create a draftgroup
		router.route('/draftgroups/:id').put(draftGroupController.update); //Update a draftgroup
		router.route('/draftgroups/:id').delete(draftGroupController.delete); //delete
		next();
	} else {
		generalHelper.handleError(req, res, 'Access Denied', _t.accessDenied, 1003);
	}
});

/**
 * Static Contents Routes
 */
router.use('/static', function (req, res, next) {
	if (global.permissions.includes("MC") === true) { // if module id is found in the user permissions list
		var staticController = require('./controllers/staticController');
		router.route('/static').get(staticController.getStaticDataList); // List data
		router.route('/static/:id').put(staticController.updateStaticData) // update static data
			.get(staticController.getStaticData); //Get one 
		next();
	} else {
		generalHelper.handleError(req, res, 'Access Denied', _t.accessDenied, 1003);
	}
});

/**
 * Admin Routes
 */
router.use('/admins', function (req, res, next) {
	if (global.permissions.includes("AM") === true) { // if module id is found in the user permissions list
		var adminController = require('./controllers/adminController');
		router.route('/admins').get(adminController.getUsers); //list users
		router.route('/admins').post(adminController.addUser); //Add user
		router.route('/admins/:id').put(adminController.updateUser); //Edit user
		router.route('/admins/:id').get(adminController.getUser); //Get profile
		router.route('/admins/:id').delete(adminController.deleteUser); //Delete user
		router.route('/admins/status/:id').put(adminController.updateStatus); //Update status
		next();
	} else {
		generalHelper.handleError(req, res, 'Access Denied', _t.accessDenied, 1003);
	}
});

/**
 * Withdrawals Routes
 */
router.use('/withdrawals', function (req, res, next) {
	if (global.permissions.includes("WR") === true) { // if module id is found in the user permissions list
		var withdrawalController = require('./controllers/withdrawalController');
		router.route('/withdrawals/getwithdrawalrequests/:id?').get(withdrawalController.getWithdrawalRequests); //Get Withdrawal Requests by user id
		router.route('/withdrawals/updatewithdrawalstatus/:id').put(withdrawalController.updateWithdrawalStatus); //Update Withdrawal status
		// router.route('/withdrawals/getuserwithdrawalrequests').get(withdrawalController.getUserWithdrawalRequests); //Get User's Withdrawal Requests
		next();
	} else {
		generalHelper.handleError(req, res, 'Access Denied', _t.accessDenied, 1003);
	}

});

/**
 * Transactions Routes
 */
router.use('/transactions', function (req, res, next) {
	if (global.permissions.includes("TH") === true) { // if module id is found in the user permissions list
		var staticController = require('./controllers/transactionController');
		router.route('/transactions/contests/:id?').get(staticController.getContestTransactions); // contest transactions
		router.route('/transactions/common/:id?').get(staticController.getCommonTransactions); // common transactions
		next();
	} else {
		generalHelper.handleError(req, res, 'Access Denied', _t.accessDenied, 1003);
	}
});


module.exports = router;