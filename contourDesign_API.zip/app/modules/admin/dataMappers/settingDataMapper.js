/**
 * Setting Data Mapper
 * @exports Admin/Setting/DataMapper
 */
// var moment = require('moment');
module.exports = {

    /**
     * Data Mapping for get setting data
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getSettingData: function (resultSet) {
        try {
            var row = {};
            row.rewardToDollar = resultSet.rewardToDollar;
            row.ticketToDollar = resultSet.ticketToDollar;
            row.rewardToTicket = resultSet.rewardToTicket;
            row.rewardToDollarDescri = resultSet.rewardToDollarDescri;
            row.ticketToDollarDescri = resultSet.ticketToDollarDescri;
            row.rewardToTicketDescri = resultSet.rewardToTicketDescri;
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for update setting data functionality
     * @param {Object} settingData - Setting Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} setting data object
     */
    updateSettingData: function (settingData, requestData, userDB) {
        try {
            settingData.rewardToDollar = requestData.rewardToDollar;
            settingData.ticketToDollar = requestData.ticketToDollar;
            settingData.rewardToTicket = requestData.rewardToTicket;
            settingData.updatedById = userDB.userId;
            settingData.updatedByName = userDB.userName;
            settingData.updatedByEmail = userDB.email;
            settingData.updatedAt = Date.now();
            return settingData;
        } catch (e) {
            throw e;
        }
    },

};