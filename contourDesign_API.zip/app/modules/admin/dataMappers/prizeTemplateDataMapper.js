/**
 * PrizeTemplate Data Mapper
 * @exports PrizeTemplate/DataMapper
 */
var moment = require('moment');

module.exports = {

    /**
     * Data Mapping for notification pagination
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    paginationData: function (requestData) {
        try {
            var pagination = {};
            pagination.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            pagination.page = (!requestData.page_number) ? 0 : requestData.page_number;
            return pagination;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Search
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.game_type = (!requestData.game_type) ? '' : requestData.game_type;
            search.prize_mode = (!requestData.prize_mode) ? '' : requestData.prize_mode;

            search.sort_field = (!requestData.sort_field) ? 'tplName' : requestData.sort_field;
            search.sort_order = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            switch (search.sort_field){
                case 'tplName': search.sort_field = 'tmpName'; break;
                case 'gameTypeId': search.sort_field = 'gameType'; break;
                case 'minMembers': search.sort_field = 'minLimit'; break;
                case 'prizeMode': search.sort_field = 'prizeMode'; break;
                case 'prizePool': search.sort_field = 'prizePool'; break;
                default: search.sort_field = 'tmpName'; break;
            }
            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for getting PrizeTemplates for drop down
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getPrizeTemplatesDDData: function (resultSet) {
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                row.tplId = resultSet[i].prizeTmpId;
                row.tplName = resultSet[i].tmpName;
                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for getting PrizeTemplates
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getPrizeTemplatesData: function (resultSet) {
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                row.tplId = resultSet[i].prizeTmpId;
                row.tplName = resultSet[i].tmpName;
                row.parentTpl = resultSet[i].parentPrizeTmpId;
                row.leagueTypeId = (resultSet[i].gameType == 'SC') ? (parseInt(resultSet[i].gameTypeId) - 5) : (resultSet[i].gameTypeId); // SC 6-10 and M 1-5 for the league types
                row.gameTypeId = resultSet[i].gameType; // (resultSet[i].gameType == 'Salary Cap') ? 'SC' : 'M';
                row.prizeMode = resultSet[i].prizeMode;
                row.prizeTickets = resultSet[i].prizeTickets;
                row.prizePool = resultSet[i].prizePool;
                // row.entryFees = resultSet[i].entryFee;
                // row.rake = resultSet[i].rakePerc;
                row.minMembers = resultSet[i].minLimit;
                row.maxMembers = resultSet[i].maxLimit;
                row.maxMultiEntries = resultSet[i].maxEntriesPerUser;
                row.status = resultSet[i].status;
                row.updatedAt = moment(resultSet[i].updatedAt).format('MM/DD/YYYY');
                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for getting one PrizeTemplates
     * @param {Object} resultSet - Resultset
     * @return {Object} Result object
     */
    getOnePrizeTemplateData: function (resultSet) {
        try {
            var row = {};
            row.tplId = resultSet.prizeTmpId;
            row.tplName = resultSet.tmpName;
            row.parentTpl = resultSet.parentPrizeTmpId;
            row.leagueTypeId = (resultSet.gameType == 'SC') ? (parseInt(resultSet.gameTypeId) - 5) : (resultSet.gameTypeId); // SC 6-10 and M 1-5 for the league types
            row.gameTypeId = resultSet.gameType; // (resultSet.gameType == 'Salary Cap') ? 'SC' : 'M';
            row.prizeMode = resultSet.prizeMode;
            row.prizeTickets = resultSet.prizeTickets;
            row.prizePool = resultSet.prizePool;
            row.entryFees = resultSet.entryFee;
            // row.rake = resultSet.rakePerc;
            row.minMembers = resultSet.minLimit;
            row.maxMembers = resultSet.maxLimit;
            row.maxMultiEntries = resultSet.maxEntriesPerUser;
            row.prizes = [];
            for (const i in resultSet.prizes) {
                if (resultSet.prizes[i].prizePosition) {
                    const nthPrize = {
                        'prizePosition': resultSet.prizes[i].prizePosition,
                        'amount': resultSet.prizes[i].amount,
                        'fromRange': resultSet.prizes[i].fromRange,
                        'toRange': resultSet.prizes[i].toRange
                    };
                    row.prizes.push(nthPrize);
                }
            }
            row.status = resultSet.status;
            row.updatedBy = resultSet.updatedBy;
            row.updatedAt = moment(resultSet.updatedAt).format('MM/DD/YYYY');
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for add functionality
     * @param {Object} modalObj - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated object
     */
    addData: function (modalObj, requestData) {
        try {
            modalObj.entryFee = requestData.entryFees;
            modalObj.gameTypeId = (requestData.gameTypeId == 'SC') ? (parseInt(requestData.leagueTypeId) + 5) : (requestData.leagueTypeId); // SC 6-10 and M 1-5 for the league types
            modalObj.gameType = requestData.gameTypeId; // (requestData.gameTypeId == 'SC') ? 'Salary Cap' : 'Multiplier';
            modalObj.maxLimit = requestData.maxMembers;
            modalObj.minLimit = requestData.minMembers;
            modalObj.maxEntriesPerUser = requestData.maxMultiEntries;
            modalObj.parentPrizeTmpId = requestData.parentPrizeTemplateId;
            modalObj.prizeMode = requestData.prizeMode;
            modalObj.prizeTickets = requestData.prizeTickets;
            modalObj.prizePool = requestData.prizePool;
            modalObj.tmpName = requestData.prizeTemplate;
            // modalObj.rakePerc = requestData.rake;
            modalObj.createdBy = global.userId;
            modalObj.createdAt = Date.now();
            modalObj.status = 1;
            modalObj.prizes = [];
            if (requestData.prizes && requestData.prizes.length > 0) {
                for (var i in requestData.prizes) {
                    const nthPrize = {
                        'prizePosition': requestData.prizes[i].prizePosition,
                        'amount': requestData.prizes[i].amount,
                        'fromRange': requestData.prizes[i].fromRange,
                        'toRange': requestData.prizes[i].toRange
                    };
                    modalObj.prizes.push(nthPrize);
                }
            }
            return modalObj;
        } catch (e) {
            throw e;
        }
    },
    
    /**
     * Data Mapping for update functionality
     * @param {Object} modalObj - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated object
     */
    updateData: function (modalObj, requestData) {
        try {
            this.addData(modalObj, requestData);
            delete modalObj.createdBy;
            delete modalObj.createdAt;
            delete modalObj.status;
            modalObj.updatedBy = global.userId;
            modalObj.updatedAt = Date.now();
            return modalObj;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Register functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    // getOneUserData: function (resultSet) {
    //     try {
    //         var row = {};
    //         row.userId = resultSet.userId;
    //         row.email = resultSet.email;
    //         row.Name = resultSet.fName;
    //         return row;
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     * Data Mapping for update status functionality
     * @param {Object} dataObj - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated object
     */
    updateStatusData: function (dataObj, requestData) {
        try {
            dataObj.status = requestData.status;
            return dataObj;
        } catch (e) {
            throw e;
        }
    },

};