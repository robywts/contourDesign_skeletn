/**
 * user Auth Data Mapper
 * @exports Admin/UserAuth/DataMapper
 */
var crypto = require('crypto');
var timeStamp = Math.round((new Date()).getTime() / 1000);

module.exports = {

    /**
     * Data Mapping for Login functionality
     * @param {Object} userAuth - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    loginData: function (userAuth, requestData) {
        try {
            userAuth.email = requestData.email;
            userAuth.pwd = requestData.pwd;
            userAuth.sessions = {
                'sessionToken': crypto.randomBytes(8).toString('hex') + timeStamp
            };
            // userAuth.sessions.sessionToken = crypto.randomBytes(8).toString('hex') + timeStamp;
            userAuth.currentLoginType = 'Normal';
            return userAuth;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Forgot functionality
     * @param {Object} userAuth - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    forgotData: function (userAuth, requestData) {
        try {
            userAuth.email = requestData.email;
            userAuth.resetCode = crypto.randomBytes(3).toString('hex').toUpperCase();
            return userAuth;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for reset functionality
     * @param {Object} userAuth - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    resetData: function (userAuth, requestData) {
        try {
            userAuth.email = requestData.email;
            userAuth.pwd = requestData.pwd;
            userAuth.resetCode = requestData.resetCode;
            userAuth.sessions = {
                'sessionToken': crypto.randomBytes(8).toString('hex') + timeStamp
            };
            // userAuth.sessions.sessionToken = crypto.randomBytes(8).toString('hex') + timeStamp;
            return userAuth;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for change password functionality
     * @param {Object} userAuth - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    changePasswordData: function (userAuth, requestData) {
        try {
            userAuth.pwd = requestData.pwd;
            userAuth.oldPwd = requestData.oldPwd;
            return userAuth;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Register/Login functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getOneUserData: function (resultSet) {
        try {
            var row = {};
            row.userId = resultSet.userId;
            row.email = resultSet.email;
            row.userName = resultSet.userName;
            row.fName = resultSet.fName;
            row.lName = resultSet.lName;
            row.permissions = resultSet.permissions;
            if (resultSet.sessions != null) {
                row.sessionToken = resultSet.sessions.sessionToken;
            }
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for forgot functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getUserForgotData: function (resultSet) {
        try {
            var row = {};
            row.resetCode = resultSet.resetCode;
            return row;
        } catch (e) {
            throw e;
        }
    },
};