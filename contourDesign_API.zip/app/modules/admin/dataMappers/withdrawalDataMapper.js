/**
 * Withdrawal Data Mapper
 * @exports Admin/Withdrawal/DataMapper
 */
var moment = require('moment');

module.exports = {

    /**
     * Data Mapping for Get Withdrawal requests functionality
     * @param {Object} resultSet - Resultset
     * @param {Array} usersBalance - usersBalance Array
     * @return {Object} Updated result object
     */
    getWithdrawalData: function (resultSet, usersBalance) {
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                row.requestId = resultSet[i]._id;
                row.userId = resultSet[i].userId;
                row.userName = resultSet[i].userName;
                row.email = resultSet[i].userEmail;
                row.status = (resultSet[i].requestStatus == 'R') ? 'Rejected' : (resultSet[i].requestStatus == 'C') ? 'Closed' : (resultSet[i].requestStatus == 'I') ? 'In Progress' : 'Pending';
                row.amount = resultSet[i].amount;
                row.balance = usersBalance[row.userId];
                row.paymentType = resultSet[i].paymentType;
                row.requestDate = moment(resultSet[i].createdAt).format('MM/DD/YYYY');
                // row.updatedAt = moment(resultSet[i].updatedAt).format('MM/DD/YYYY');
                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for update Withdrawal status functionality    
     * @param {Object} empty - Empty object
     * @param {Object} requestData - Request Body Object
     * @param {String} withdrawalId - Withdrawal Id
     * @return {Object} Updated user object
     */
    updateWithdrawalStatusData: function ({}, requestData, withdrawalId) {
        try {
            var result = [];
            result.withdrawalId = withdrawalId;
            result.paymentType = requestData.paymentType;
            result.status = requestData.status;
            return result;
        } catch (e) {
            throw e;
        }
    },
    
    /**
     * Data Mapping for transaction functionality
     * @param {Object} transaction - Data Schema Object
     * @param {Object} userData - User Object
     * @param {String} transactionType - Transaction Type
     * @return {Object} Updated object
     */
    transactionData: function (transaction, userData, amount, transactionType) {
        try {
            transaction.amount = amount;
            transaction.tranStatus = 1;
            transaction.tranType = transactionType;
            transaction.userId = userData.userId;
            transaction.userName = userData.userName;
            transaction.userImg = userData.imageName;
            transaction.fName = userData.fName;
            transaction.lName = userData.lName;
            return transaction;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for withdrawal
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    withdrawalData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.request_status = (!requestData.request_status) ? '' : requestData.request_status;
            search.from_date = (!requestData.from_date) ? '' : requestData.from_date; // moment(requestData.from_date).format('YYYY-MM-DD');
            search.to_date = (!requestData.to_date) ? '' : requestData.to_date; // moment(requestData.to_date).format('YYYY-MM-DD');
            
            search.sort_field = (!requestData.sort_field) ? 'userName' : requestData.sort_field;
            search.sort_order = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            switch (search.sort_field){
                case 'userName': search.sort_field = 'userName'; break;
                case 'requestDate': search.sort_field = 'createdAt'; break;
                case 'email': search.sort_field = 'userEmail'; break;
                case 'amount': search.sort_field = 'amount'; break;
                case 'paymentType': search.sort_field = 'paymentType'; break;
                case 'status': search.sort_field = 'requestStatus'; break;
                default: search.sort_field = 'userName'; break;
            }
            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for user withdrawal
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    // userWithdrawalData: function (requestData) {
    //     try {
    //         var search = {};
    //         search.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
    //         search.page = (!requestData.page_number) ? 0 : requestData.page_number;
    //         search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
    //         search.status = (!requestData.status) ? '' : requestData.status;
    //         search.from_date = (!requestData.from_date) ? '' : moment(requestData.from_date).format('YYYY-MM-DD');
    //         search.to_date = (!requestData.to_date) ? '' : moment(requestData.to_date).format('YYYY-MM-DD');
    //         search.userId = requestData.userId;
    //         return search;
    //     } catch (e) {
    //         throw e;
    //     }
    // },

};