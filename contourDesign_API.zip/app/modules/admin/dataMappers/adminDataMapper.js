/**
 * Admin Data Mapper
 * @exports Admin/User/DataMapper
 */
var moment = require('moment');

module.exports = {

    /**
     * Data Mapping for pagination
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    paginationData: function (requestData) {
        try {
            var pagination = {};
            pagination.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            pagination.page = (!requestData.page_number) ? 0 : requestData.page_number;
            return pagination;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Search
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.status = (!requestData.status) ? '' : requestData.status;

            search.sort_field = (!requestData.sort_field) ? 'userName' : requestData.sort_field;
            search.sort_order = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            switch (search.sort_field){
                case 'email': search.sort_field = 'email'; break;
                case 'userName': search.sort_field = 'userName'; break;
                case 'createdOn': search.sort_field = 'createdAt'; break;
                default: search.sort_field = 'userName'; break;
            }

            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get users functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getUsersData: function (resultSet) {
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                row.userId = resultSet[i].userId;
                row.userName = resultSet[i].userName;
                row.email = resultSet[i].email;
                row.status = (resultSet[i].userStatus == 1) ? 'Active' : 'Blocked';
                row.isAdmin = resultSet[i].isAdmin;
                row.createdOn = moment(resultSet[i].createdAt).format('MM-DD-YYYY');
                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get user functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getProfileData: function (resultSet) {
        try {
            var row = {};
            row.userId = resultSet.userId;
            row.userName = resultSet.userName;
            row.email = resultSet.email;
            row.password = '';
            // row.fName = resultSet.fName;
            row.permission = resultSet.permissions;
            row.status = (resultSet.userStatus == 1) ? 'Active' : 'Blocked';
            row.createdOn = moment(resultSet.createdAt).format('MM-DD-YYYY');
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping to get one user
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getOneUserData: function (resultSet) {
        try {
            var row = {};
            row.userId = resultSet.userId;
            row.email = resultSet.email;
            row.userName = resultSet.userName;
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for add functionality
     * @param {Object} userAuth - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    registerData: function (userAuth, requestData) {
        try {
            userAuth.userName = requestData.userName;
            userAuth.email = requestData.email;
            userAuth.pwd = requestData.password;
            userAuth.userStatus = 1;
            userAuth.isAdmin = true;
            userAuth.permissions = requestData.permission;
            return userAuth;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for update user functionality
     * @param {Object} userProfile - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    updateProfileData: function (userProfile, requestData) {
        try {
            if (requestData.password != '') {
                userProfile.pwd = requestData.password;
            }
            userProfile.permissions = requestData.permission;
            return userProfile;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for update status functionality
     * @param {Object} userProfile - Data Schema Object
     * @param {Number} userId - User Id
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    updateStatusData: function (userProfile, requestData, userId) {
        try {
            userProfile.userId = userId;
            userProfile.status = requestData.status;
            return userProfile;
        } catch (e) {
            throw e;
        }
    },


};