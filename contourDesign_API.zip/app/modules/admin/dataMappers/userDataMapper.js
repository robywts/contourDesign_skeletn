/**
 * User Data Mapper
 * @exports Admin/User/DataMapper
 */
var moment = require('moment');

module.exports = {

    /**
     * Data Mapping for get Profile functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getProfileData: function (resultSet) {
        try {
            var row = {};
            row.userId = resultSet.userId;
            row.userName = resultSet.userName;
            row.email = resultSet.email;
            row.fName = resultSet.fName;
            row.lName = resultSet.lName;
            row.hContests = resultSet.h2hCnt;
            row.mContests = resultSet.multiplayerCnt;
            row.wins = resultSet.wins;
            row.accountBalance = resultSet.balance;
            row.totalAmountDeposited = (resultSet.totalDeposited != null) ? resultSet.totalDeposited : 0;
            row.avgAmountPerContest = (resultSet.avgAmountPerContest != null) ? resultSet.avgAmountPerContest : 0;
            row.totalAmountWon = (resultSet.totalAmountWon != null) ? resultSet.totalAmountWon : 0;
            row.status = (resultSet.userStatus == 1) ? 'Active' : 'InActive';
            if (resultSet.currentLoginType == 'Normal') {
                row.imgUrl = resultSet.imageName ? process.env.PROFILE_IMAGE_URL + resultSet.imageName : '';
            } else if (resultSet.currentLoginType == 'FB') {
                row.imgUrl = process.env.FB_IMAGE_URL.replace(new RegExp('{fbId}', "g"), resultSet.loginTypes.FB.fbId);
            }
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Search
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    // searchData: function (requestData) {
    //     try {
    //         var search = {};
    //         search.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
    //         search.page = (!requestData.page_number) ? 0 : requestData.page_number;
    //         search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
    //         //search.sort = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
    //         //search.sort_field = (!requestData.sort_field) ? 'name' : requestData.sort_field;
    //         return search;
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     * Data Mapping for User list
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchUserData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.status = (!requestData.status) ? '' : requestData.status;

            search.sort_field = (!requestData.sort_field) ? 'userName' : requestData.sort_field;
            search.sort_order = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            switch (search.sort_field) {
                case 'userName':
                    search.sort_field = 'userName';
                    break;
                case 'email':
                    search.sort_field = 'email';
                    break;
                case 'hContests':
                    search.sort_field = 'h2hCnt';
                    break;
                case 'mContests':
                    search.sort_field = 'multiplayerCnt';
                    break;
                case 'wins':
                    search.sort_field = 'wins';
                    break;
                case 'status':
                    search.sort_field = 'userStatus';
                    break;
                default:
                    search.sort_field = 'userName';
                    break;
            }

            return search;
        } catch (e) {
            throw e;
        }
    },
    /**
     * Data Mapping for Search
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchContestData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.league_type = (!requestData.league_type) ? '' : requestData.league_type;
            search.contest_status = (!requestData.contest_status) ? '' : requestData.contest_status;
            search.from_date = (!requestData.from_date) ? '' : requestData.from_date;
            search.to_date = (!requestData.to_date) ? '' : requestData.to_date;

            search.sort_field = (!requestData.sort_field) ? 'entryFees' : requestData.sort_field;
            search.sort_order = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            switch (search.sort_field) {
                case 'contestName':
                    search.sort_field = 'contestName';
                    break;
                case 'position':
                    search.sort_field = 'position';
                    break;
                case 'entryFees':
                    search.sort_field = 'entryFees';
                    break;
                case 'winningAmount':
                    search.sort_field = 'winningAmount';
                    break;
                case 'entryCount':
                    search.sort_field = 'entryCount';
                    break;
                case 'opponentName':
                    search.sort_field = 'opponentName';
                    break;
                case 'userName':
                    search.sort_field = 'userName';
                    break;
                default:
                    search.sort_field = 'entryFees';
                    break;
            }

            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for pagination 
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    // paginationData: function (requestData) {
    //     try {
    //         var pagination = {};
    //         pagination.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
    //         pagination.page = (!requestData.page_number) ? 0 : requestData.page_number;
    //         return pagination;
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     * Data Mapping for Get users functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getUsersData: function (resultSet) {
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                row.userId = resultSet[i].userId;
                row.userName = resultSet[i].userName;
                row.email = resultSet[i].email;
                row.fName = resultSet[i].fName;
                row.lName = resultSet[i].lName;
                row.hContests = resultSet[i].h2hCnt;
                row.mContests = resultSet[i].multiplayerCnt;
                row.wins = resultSet[i].wins;
                row.status = (resultSet[i].userStatus == 1) ? 'Active' : 'InActive';

                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get userId
     * @param {Object} userId - userid
     * @return {Object} Updated user object
     */
    // getUserId: function ({}, userId) {
    //     try {
    //         var result = {};
    //         result.userid = userId;
    //         return result.userid;
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     * Data Mapping for update status functionality
     * @param {Object} userProfile - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @param {Number} userId - User Id
     * @return {Object} Updated user object
     */
    updateStatusData: function (userProfile, requestData, userId) {
        try {
            userProfile.userId = userId;
            userProfile.status = requestData.status;
            return userProfile;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get contest list as response
     * @param {Object} resultSet - Resultset
     * @param {Object} resultSetPoints - Resultset of Points
     * @return {Object} Updated result object
     */
    getUserContestsData: function (resultSet, resultSetPoints) {
        try {
            var contests = [];
            var lineups = {};
            for (var i in resultSetPoints) {
                lineups[resultSetPoints[i].contestId] = resultSetPoints[i].position;
            }
            for (var i in resultSet) {
                var row = {};
                row.contestId = resultSet[i].contestId;
                row.contestName = resultSet[i].contestName;
                row.entryFees = (resultSet[i].entryFees != null) ? resultSet[i].entryFees : 0;
                row.totalParticipants = (resultSet[i].entrants) ? resultSet[i].entrants.length : 0;
                row.entryCount = 0;
                for (entry of resultSet[i].entrants) {
                    row.entryCount += (entry.totalentry != null) ? entry.totalentry : 0;
                }
                row.rakePerc = (resultSet[i].rakePerc != null) ? resultSet[i].rakePerc : 0;
                row.position = (lineups[row.contestId]) ? lineups[row.contestId] : 0;
                var totalAmount = row.entryFees * row.entryCount;
                row.winningAmount = (row.rakePerc == 0) ? totalAmount : (totalAmount - (totalAmount / row.rakePerc));
                // console.log(totalAmount);
                // console.log(row);
                // row.visibility = resultSet[i].visibility;
                // row.sportId = resultSet[i].sportId;
                // row.contentStatus = resultSet[i].contentStatus;
                // row.gameTypeId = resultSet[i].gameTypeId;
                // row.gameType = resultSet[i].gameType;
                // row.isInvolved = (resultSet[i].createdBy == global.userId) ? 1 : 0;
                // row.createdAt = moment(resultSet[i].createdAt).format('MM/DD/YYYY');
                // row.updatedAt = moment(resultSet[i].updatedAt).format('MM/DD/YYYY');
                contests.push(row);
            }
            return contests;
        } catch (e) {
            throw e;
        }
    },

};