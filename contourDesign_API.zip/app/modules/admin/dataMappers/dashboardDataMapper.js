/**
 * Dashboard Data Mapper
 * @exports Dashboard/DataMapper
 */

module.exports = {

    /**
     * Data Mapping for Dashboard Contents (user)
     * @param {Object} dbData
     * @return {Object} Result object
     */
    getUserData: function (dbData) {
        try {
            var rowObj = {
                active: 0,
                blocked: 0,
                totalCnt: 0
            };
            for (row of dbData) {
                if (row._id.isAdmin === false) {
                    if (row._id.userStatus === 1) {
                        rowObj.active = row.cnt;
                    } else if (row._id.userStatus === 2) {
                        rowObj.blocked = row.cnt;
                    }
                }
            }
            rowObj.totalCnt = rowObj.active + rowObj.blocked;
            return rowObj;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Dashboard Contents (Clans)
     * @param {Object} dbData
     * @return {Object} Result object
     */
    getClanData: function (dbData) {
        try {
            var rowObj = {
                active: 0,
                blocked: 0,
                totalCnt: 0
            };
            for (row of dbData) {
                if (row._id.clanStatus === 1) {
                    rowObj.active = row.cnt;
                } else if (row._id.clanStatus === 2) {
                    rowObj.blocked = row.cnt;
                }
            }
            rowObj.totalCnt = rowObj.active + rowObj.blocked;
            return rowObj;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Dashboard Contents (Contests)
     * @param {Object} dbData
     * @return {Object} Result object
     */
    getContestData: function (dbData) {
        try {
            var rowObj = {
                h2h: {
                    active: 0,
                    completed: 0,
                    totalCnt: 0
                },
                multi: {
                    active: 0,
                    completed: 0,
                    totalCnt: 0
                }
            };
            for (row of dbData) {
                if (row._id.contestType === 1) { // Multiplayer
                    if (row._id.contestStatus === 1) {
                        rowObj.multi.completed = row.cnt;
                    } else if (row._id.contestStatus === 2) {
                        rowObj.multi.active += row.cnt;
                    } else if (row._id.contestStatus === 3) {
                        rowObj.multi.active += row.cnt;
                    }
                } else if (row._id.contestType === 2) { // H2H
                    if (row._id.contestStatus === 1) {
                        rowObj.h2h.completed = row.cnt;
                    } else if (row._id.contestStatus === 2) {
                        rowObj.h2h.active += row.cnt;
                    } else if (row._id.contestStatus === 3) {
                        rowObj.h2h.active += row.cnt;
                    }
                }
            }
            rowObj.multi.totalCnt = rowObj.multi.active + rowObj.multi.completed;
            rowObj.h2h.totalCnt = rowObj.h2h.active + rowObj.h2h.completed;
            return rowObj;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Dashboard Contents (Withdrawal)
     * @param {Object} dbData
     * @return {Object} Result object
     */
    getWithdrawalData: function (dbData) {
        try {
            var rowObj = {
                pending: 0,
                inProgress: 0,
                rejected: 0,
                completed: 0,
                totalCnt: 0
            };
            for (row of dbData) {
                if (row._id.withdrawalStatus === 'P') {
                    rowObj.pending = row.cnt;
                } else if (row._id.withdrawalStatus === 'C') {
                    rowObj.completed = row.cnt;
                } else if (row._id.withdrawalStatus === 'R') {
                    rowObj.rejected = row.cnt;
                } else if (row._id.withdrawalStatus === 'I') {
                    rowObj.inProgress = row.cnt;
                }
            }
            rowObj.totalCnt = rowObj.pending + rowObj.completed + rowObj.rejected + rowObj.inProgress;
            return rowObj;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Dashboard Contents (Transaction)
     * @param {Object} dbData
     * @return {Object} Result object
     */
    getTransactionData: function (dbData) {
        try {
            var rowObj = {
                deposit: 0,
                withdrawal: 0,
                totalCnt: 0
            };
            for (row of dbData) {
                if (row._id.tranType === 'D') {
                    rowObj.deposit = row.amt;
                } else if (row._id.tranType === 'W') {
                    rowObj.withdrawal = row.amt;
                }
            }
            rowObj.totalCnt = rowObj.deposit - rowObj.withdrawal;
            return rowObj;
        } catch (e) {
            throw e;
        }
    },

};