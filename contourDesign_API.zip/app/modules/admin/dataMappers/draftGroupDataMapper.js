/**
 * DraftGroup  Data Mapper
 * @exports DraftGroup/DataMapper
 */
var moment = require('moment-timezone');
module.exports = {

    /**
     * Data Mapping for getting DraftGroups for drop down
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getDraftGroupsDDData: function (resultSet) {
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                row.draftGroupId = resultSet[i]._id.draftgroupId;
                row.draftGroupName = resultSet[i]._id.dgName + ' ' + moment.utc(resultSet[i]._id.startTimeUTC).tz(process.env.dest_zone).format('MM/DD/YYYY h:mm a') + ' (' + resultSet[i].gamesCount + ')'; // gameList.length
                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get DraftGroups
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftListData: function ({}, requestData) {
        try {
            var draftgroup = {};
            draftgroup.dgWeek = parseInt(requestData.week);
            draftgroup.sportId = parseInt(requestData.sportId);
            // draftgroup.dgSeason = parseInt(requestData.season);
            return draftgroup;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get DraftGroups as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftGroupResultMap: function (resultSetDraft, resultSetLineup) {
        try {
            //draftgroups
            var drafts = {};
            var draftGroups = [];
            for (var i in resultSetDraft) {
                var row = {};
                row.eventIds = [];
                row.draftgroupId = resultSetDraft[i].draftgroupId;
                row.name = resultSetDraft[i].dgName;
                row.gamesCount = (resultSetDraft[i].gameList).length;
                row.status = resultSetDraft[i].dgState;
                row.sportId = resultSetDraft[i].sportId;
                row.st = resultSetDraft[i].startTimeUTC;
                row.draftGroupState = resultSetDraft[i].dgState;
                row.sortOrder = resultSetDraft[i].sortOrder;
                League = [];
                rowLeague = {};
                rowLeague.leagueId = resultSetDraft[i].league[0].leagueId;
                rowLeague.leagueAbbreviation = resultSetDraft[i].league[0].abbr;
                rowLeague.leagueName = resultSetDraft[i].league[0].name;
                League.push(rowLeague);
                row.leagues = League;

                for (var j = 0, len = resultSetDraft[i].gameList.length; j < len; j++) {
                    row.eventIds.push(resultSetDraft[i].gameList[j].eventId);
                }
                draftGroups.push(row);
            }
            drafts.draftGroups = draftGroups;
            //lineuptemplates
            lineuptemp = [];
            for (var j in resultSetLineup) {
                var lineuptemplate = {};
                lineuptemplate.sportId = resultSetLineup[j].sportId;
                lineuptemplate.name = resultSetLineup[j].sName;
                lineuptemplate.sortOrder = resultSetLineup[j].sortOrder;
                lineuptemplate.available = resultSetLineup[j].isAvailable;
                Game = [];
                rowGame = {};
                if (resultSetLineup[j].gameTypes.length != 0) {
                    gameType = [];
                    var len = resultSetLineup[j].gameTypes.length;
                    for (var k = 0; k < len; k++) {
                        rowGame.lptemplateId = resultSetLineup[j].gameTypes[k].lptemplateid;
                        rowGame.type = resultSetLineup[j].gameTypes[k].gameType;
                        rowGame.gameTypeId = resultSetLineup[j].gameTypes[k].gameTypeId;
                        rowGame.cap = resultSetLineup[j].gameTypes[k].capLimit;
                        Template = [];
                        templates = resultSetLineup[j].gameTypes[k].template;
                        for (var l = 0; l < templates.length; l++) {
                            rowTemp = {};
                            rowTemp.id = templates[l].id;
                            rowTemp.PositionID = templates[l].posId;
                            rowTemp.Position = templates[l].posAbbr;
                            rowTemp.PositionName = templates[l].posName;
                            rowTemp.playerId = '';
                            rowTemp.playerName = '';
                            Template.push(rowTemp);
                        }
                        rowGame.template = Template;
                        gameType.push(rowGame);
                    }
                }
                lineuptemplate.gameTypes = gameType;
                lineuptemp.push(lineuptemplate);
            }
            drafts.sports = lineuptemp;
            return drafts;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get DraftGroups Lst
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftGroupResultList: function (resultSetDraft, resultSetLineup) {
        try {
            //draftgroups
            var drafts = {};
            var draftGroups = [];
            for (var i in resultSetDraft) {
                var row = {};
                row.games = [];
                row.draftGroupId = resultSetDraft[i].draftgroupId;
                row.draftGroupName = resultSetDraft[i].dgName;
                row.gamesCount = (resultSetDraft[i].gameList).length;
                row.status = resultSetDraft[i].dgState;
                row.sportId = resultSetDraft[i].sportId;
                row.sortOrder = resultSetDraft[i].sortOrder;
                //games = [];
                for (var j = 0, len = resultSetDraft[i].gameList.length; j < len; j++) {
                    var game = {};
                    game.eventId = resultSetDraft[i].gameList[j].eventId;
                    if (resultSetDraft[i].gameList[j].players.length > 0) {
                        game.team1 = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].htName;
                        game.team2 = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].atName;
                    }
                    row.games.push(resultSetDraft[i].gameList[j].eventId);
                    // games.push(game);
                }
                // row.games = games;
                draftGroups.push(row);
            }
            drafts.draftGroups = draftGroups;
            return drafts;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get DraftGroups as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftGroupGameListMap: function (resultSetDraft, resultSetLineup) {
        try {
            // var drafts = {};
            //var draftGroups = [];
            games = [];
            for (var i in resultSetDraft) {

                var game = {};
                // game.draftGroupId = resultSetDraft[i].draftgroupId;
                game.gameId = resultSetDraft[i].eventId;
                game.team1 = resultSetDraft[i].homeTeam.tName;
                game.team1W = 1;
                game.team1L = 2;
                game.team2 = resultSetDraft[i].awayTeam.tName;
                game.team2W = 5;
                game.team2L = 6; //console.log(((resultSetDraft[i].startTimeUTC.toISOString())));process.exit();
                game.matchTime = (resultSetDraft[i].startTimeUTC) ? moment(resultSetDraft[i].startTimeUTC, 'UTC').tz(process.env.dest_zone).format('ddd h:mm a') : '';
                games.push(game);

                // row.games = games;
                // draftGroups.push(row);
            }
            //   drafts.draftGroups = draftGroups;
            //   return drafts;
            return games;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get DraftGroup Details
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftDetailsData: function (darftGroupId) {
        try {
            draftgroupId = parseInt(darftGroupId);
            return draftgroupId;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get DraftGroup details as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftGroupDetailsResultMap: function (resultSet) {
        try {
            var draftGroup = {};
            draftGroup.draftgroupId = resultSet.draftgroupId;
            draftGroup.dgName = resultSet.dgName;
            draftGroup.dgState = resultSet.dgState ? resultSet.dgState : '';
            draftGroup.dgWeek = resultSet.week;
            draftGroup.dgSeason = resultSet.season;
            draftGroup.startTimeSuffix = resultSet.startTimeSuffix ? resultSet.startTimeSuffix : '';
            draftGroup.sportId = resultSet.sportId;
            draftGroup.sName = resultSet.sName;
            draftGroup.contestList = resultSet.contestList;
            draftGroup.sortOrder = resultSet.sortOrder ? resultSet.sortOrder : '';

            draftGroup.gameList = [];

            games = resultSet.gameList;
            for (var i in games) {
                if (games[i].eventId) {
                    var rowGame = {};
                    rowGame.eventId = games[i].eventId;
                    rowGame.startTimeUTC = games[i].startTimeUTC;
                    rowGame.gameStatus = games[i].gameStatus ? games[i].gameStatus : '';
                    playersList = [];
                    players = resultSet.gameList[i].players;
                    for (var j in players) {
                        if (players[j].competition) {
                            rowPlayer = {};
                            rowPlayer.fName = players[j].fName;
                            rowPlayer.lName = players[j].lName;
                            rowPlayer.playerId = players[j].playerId;
                            rowPlayer.posId = players[j].posId;
                            rowPlayer.posAbbr = players[j].posAbbr;
                            rowPlayer.CapValue = players[j].CapValue;
                            rowPlayer.isInjured = players[j].isInjured;
                            competitionObj = {};
                            competitionObj.compId = (players[j].competition.compId) ? (players[j].competition.compId) : '';
                            nameDisplayList = [];
                            nameDisplayObj = {};
                            nameDisplayObj.htName = players[j].competition.nameDisplay[0].htName;
                            nameDisplayObj.htScore = (players[j].competition.nameDisplay[0].htScore) ? players[j].competition.nameDisplay[0].htScore : '';
                            nameDisplayObj.value = (players[j].competition.nameDisplay[0].value) ? players[j].competition.nameDisplay[0].value : '';
                            nameDisplayObj.atName = (players[j].competition.nameDisplay[0].atName) ? players[j].competition.nameDisplay[0].atName : '';
                            nameDisplayObj.atScore = (players[j].competition.nameDisplay[0].atScore) ? players[j].competition.nameDisplay[0].atScore : '';
                            nameDisplayList.push(nameDisplayObj);
                            competitionObj.nameDisplay = nameDisplayList;
                            rowPlayer.competition = competitionObj;
                            rowPlayer.teamId = players[j].teamId;
                            rowPlayer.teamAbbr = players[j].teamAbbr;
                            rowPlayer.fanProjScore = players[j].fanProjScore;
                            playersList.push(rowPlayer);
                        }
                    }
                    rowGame.players = playersList;
                    draftGroup.gameList.push(rowGame);
                }
            }
            //draftGroup.gameList = gameList;
            return draftGroup;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get DraftGroup's contest as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftGroupContestResultMap: function (resultSet) {
        try {
            var contests = [];
            for (var i in resultSet) {
                var row = {};
                row.id = resultSet[i].contestId;
                row.name = resultSet[i].contestName;
                row.entryFee = resultSet[i].entryFees;
                row.contestTypeId = resultSet[i].contestTypeId;
                row.contestType = resultSet[i].contestType;
                row.gameTypeId = resultSet[i].gameTypeId;
                row.gameType = resultSet[i].gameType;
                contests.push(row);
            }
            return contests;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get DraftGroup's players as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftGroupPlayersResultMap: function (resultSet) {
        try {
            games = resultSet.gameList;
            playersList = [];
            for (var i in games) {
                if (games[i].eventId) {
                    players = games[i].players;
                    for (var j in players) {
                        // if (players[j].isDisabled == 0) {
                        if (players[j].competition) {
                            rowPlayer = {};
                            pId = players[j].playerId
                            rowPlayer.eventId = games[i].eventId;
                            rowPlayer.startTimeUTC = games[i].startTimeUTC;
                            rowPlayer.fName = players[j].fName;
                            rowPlayer.lName = players[j].lName;
                            rowPlayer.playerId = pId;
                            rowPlayer.canDraft = players[j].canDraft;
                            rowPlayer.posAbbr = players[j].posAbbr;
                            rowPlayer.isInjured = players[j].isInjured;
                            rowPlayer.htName = players[j].competition.nameDisplay[0].htName ? players[j].competition.nameDisplay[0].htName : '';
                            rowPlayer.atName = (players[j].competition.nameDisplay[0].atName) ? players[j].competition.nameDisplay[0].atName : '';
                            rowPlayer.fanProjSalary = players[j].fanProjSalary;
                            rowPlayer.multiplier = players[j].mValue;
                            found = this.checkAndAdd(pId, playersList);
                            if (!found) {
                                playersList.push(rowPlayer);
                            }
                        }
                        // }
                    }
                }
            }
            return playersList;
        } catch (e) {
            throw e;
        }
    },
    /**
     * Data Mapping for Search
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : requestData.page_limit;
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.sort = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            search.sort_field = (!requestData.sort_field) ? 'name' : requestData.sort_field;
            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Function to check player exist
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    checkAndAdd: function (pId, playersList) {
        playersList.some(function (el) {
            return el.playerId === pId;
        });
    },

    /**
     * Data Mapping for get DraftGroup lineups as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftGroupLineUpsResultMap: function (resultSet) {
        try {
            var lineups = [];
            for (var i in resultSet) {
                var rowLineup = {};
                rowLineup.lineupId = resultSet[i].lineupId;
                rowLineup.contestId = resultSet[i].contestId;
                rowLineup.userId = resultSet[i].userId;
                rowLineup.draftgroupId = resultSet[i].draftgroupId;
                rowLineup.sportId = resultSet[i].sportId;
                playersList = [];
                players = resultSet[i].players;
                for (var j = 0; j < players.length; j++) {
                    rowPlayer = {};
                    rowPlayer.eventId = players[j].eventId;
                    rowPlayer.tmpPosId = players[j].tmpPosId;
                    rowPlayer.tmpPosAbbr = players[j].tmpPosAbbr;
                    rowPlayer.tmpPosName = players[j].tmpPosName;
                    rowPlayer.tmpId = players[j].tmpId;
                    rowPlayer.playerId = players[j].playerId;
                    rowPlayer.fName = players[j].fName;
                    rowPlayer.lName = players[j].lName;
                    rowPlayer.playerName = players[j].playerName;
                    rowPlayer.playerName = players[j].imgUrl;
                    competitionObj = {};
                    competitionObj.compId = (players[j].competition.compId) ? (players[j].competition.compId) : '';
                    nameDisplayList = [];
                    nameDisplayObj = {};
                    nameDisplayObj.htName = players[j].competition.nameDisplay[0].htName;
                    // nameDisplayObj.htScore = (players[j].competition.nameDisplay[0].htScore) ? players[j].competition.nameDisplay[0].htScore : '';
                    // nameDisplayObj.value = (players[j].competition.nameDisplay[0].value) ? players[j].competition.nameDisplay[0].value : '';
                    nameDisplayObj.atName = (players[j].competition.nameDisplay[0].atName) ? players[j].competition.nameDisplay[0].atName : '';
                    // nameDisplayObj.atScore = (players[j].competition.nameDisplay[0].atScore) ? players[j].competition.nameDisplay[0].atScore : '';
                    nameDisplayList.push(nameDisplayObj);
                    competitionObj.nameDisplay = nameDisplayList;
                    rowPlayer.competition = competitionObj;
                    rowPlayer.teamId = players[j].teamId;
                    rowPlayer.teamAbbr = players[j].teamAbbr;
                    rowPlayer.fanProjScore = players[j].fanProjScore;
                    playersList.push(rowPlayer);
                }
                rowLineup.players = playersList;
                lineups.push(rowLineup);
            }
            //console.log(lineups);process.exit();
            return lineups;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get DraftGroups
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftGroupWeekMapData: function ({}, requestData) {
        try {
            var draftgroup = {};
            var lg = ["NFL", "MLB", "NHL", "NBA", "GOLF"];
            draftgroup.sportId = parseInt(requestData.id);
            draftgroup.leauge = lg[draftgroup.sportId - 1];
            return draftgroup;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get DraftGroup weeeks response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftGroupWeekResultMap: function (resultSet, {}) {
        try {
            var weeks = [];
            for (var i in resultSet) {
                var row = {};
                row.weekId = resultSet[i];
                row.weekName = "WEEK " + resultSet[i];
                row.weekDuration = "";
                row.draftGroupCount = 1;
                weeks.push(row);
            }
            return weeks;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Add functionality
     * @param {Object} contest - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated contest object
     */
    addData: function (draftgroup, requestData, game, leagues, minDate) {
        try {
            /* var leagueType = 0;
             if (requestData.leagueType == "NBA") {
                 leagueType = 1;
             }
             if (requestData.leagueType == "MLB") {
                 leagueType = 2;
             }
             if (requestData.leagueType == "NHL") {
                 leagueType = 3;
             }
             if (requestData.leagueType == "NFL") {
                 leagueType = 4;
             }
             if (requestData.leagueType == "GOLF") {
                 leagueType = 5;
             }*/

            draftgroup.dgName = requestData.draftGroupName;
            draftgroup.startTimeUTC = minDate;
            draftgroup.sortOrder = requestData.sortOrder;
            draftgroup.week = requestData.weekId;
            draftgroup.sportId = requestData.leagueType;
            draftgroup.dgState = "Upcoming";
            draftgroup.gameList = game;
            draftgroup.league = leagues;
            return draftgroup;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Add functionality
     * @param {Object} contest - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated contest object
     */
    updateData: function (requestData, game, leagues, minDate) {
        try {

            /*  var leagueType = 0;           
              if (requestData.leagueType == "NBA") {
                  leagueType = 1;
              }
              if (requestData.leagueType == "MLB") {
                  leagueType = 2;
              }
              if (requestData.leagueType == "NHL") {
                  leagueType = 3;
              }
              if (requestData.leagueType == "NFL") {
                  leagueType = 4;
              }
              if (requestData.leagueType == "GOLF") {
                  leagueType = 5;
              }*/

            var draftgroup = {};
            draftgroup.dgName = requestData.draftGroupName;
            draftgroup.startTimeUTC = minDate;
            draftgroup.sortOrder = requestData.sortOrder;
            draftgroup.week = requestData.weekId;
            draftgroup.sportId = requestData.leagueType;
            draftgroup.dgState = "Upcoming";
            draftgroup.gameList = game;
            draftgroup.league = leagues;
            return draftgroup;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for event ids
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    eventIds: function ({}, requestData) {
        try {
            var eventIds;
            eventIds = requestData.games;
            return eventIds;
        } catch (e) {
            throw e;
        }
    },
};