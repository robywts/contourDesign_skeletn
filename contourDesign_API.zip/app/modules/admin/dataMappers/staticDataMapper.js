/**
 * User Data Mapper
 * @exports Admin/User/DataMapper
 */
var moment = require('moment');
module.exports = {
    /**
     * Data Mapping for get one static data
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getStaticDataOne: function (resultSet) {
        try {
            var row = {};
            row.contentId = resultSet.id;
            row.contentName = resultSet.name;
            row.content = resultSet.content;
            row.lastUpdatedBy = resultSet.userId;
            // row.createdAt = moment(resultSet.createdAt).format('MM-DD-YYYY');
            row.lastUpdated = moment(resultSet.updatedAt).format('MM-DD-YYYY');
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for update static data functionality
     * @param {Object} staticData - Static Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} static data object
     */
    updateStaticData: function (staticData, requestData, userDB) {
        try {
            // staticData.name = requestData.name;
            staticData.content = requestData.content;
            staticData.userId = global.userId;
            staticData.userName = userDB.userName;
            staticData.userEmail = userDB.email;
            return staticData;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for notification pagination
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    // paginationData: function (requestData) {
    //     try {
    //         var pagination = {};
    //         pagination.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
    //         pagination.page = (!requestData.page_number) ? 0 : requestData.page_number;
    //         return pagination;
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     * Data Mapping for Search
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.sort_field = (!requestData.sort_field) ? 'name' : requestData.sort_field;
            search.sort_order = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            switch (search.sort_field){
                case 'contentName': search.sort_field = 'name'; break;
                case 'lastUpdated': search.sort_field = 'updatedAt'; break;
                case 'lastUpdatedBy': search.sort_field = 'userName'; break;
                default: search.sort_field = 'name'; break;
            }
            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for pagination 
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    paginationData: function (requestData) {
        try {
            var pagination = {};
            pagination.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            pagination.page = (!requestData.page_number) ? 0 : requestData.page_number;
            return pagination;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get static data functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getStaticData: function (resultSet) {
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                row.contentId = resultSet[i].id;
                row.contentName = resultSet[i].name;
                // row.content = resultSet[i].content;
                row.lastUpdatedBy = resultSet[i].userName;
                // row.createdAt = moment(resultSet[i].createdAt).format('MM-DD-YYYY');
                row.lastUpdated = moment(resultSet[i].updatedAt).format('MM/DD/YYYY h:mm a');
                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

};