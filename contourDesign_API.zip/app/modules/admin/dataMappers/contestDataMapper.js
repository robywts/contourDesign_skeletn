/**
 * Contest Data Mapper
 * @exports Admin/Contest/DataMapper
 */
var moment = require('moment-timezone');
var fbHelper = require('../helpers/fbHelper');

module.exports = {
    /**
     * Data Mapping for Search
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : requestData.page_limit;
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.sort = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            search.sort_field = (!requestData.sort_field) ? 'name' : requestData.sort_field;
            return search;
        } catch (e) {
            throw e;
        }
    },


    /**
     * Data Mapping for Standings Search
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    standingsSearchData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : requestData.page_limit;
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;

            search.sort_field = (!requestData.sort_field) ? 'userName' : requestData.sort_field;
            search.sort_order = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            switch (search.sort_field) {
                case 'participantName':
                    search.sort_field = 'userName';
                    break;
                case 'position':
                    search.sort_field = 'position';
                    break;
                case 'points':
                    search.sort_field = 'points';
                    break;
                default:
                    search.sort_field = 'userName';
                    break;
            }


            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for multi contest Search
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    getMultiSearchData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : requestData.page_limit;
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.sportId = (!requestData.sportId) ? '1' : requestData.sportId;

            search.sort_field = (!requestData.sort_field) ? 'contestName' : requestData.sort_field;
            search.sort_order = (!requestData.sort_order) ? 1 : ((requestData.sort_order == 'desc') ? -1 : 1);

            switch (search.sort_field) {
                case 'contestName':
                    search.sort_field = 'contestName';
                    break;
                case 'entryFees':
                    search.sort_field = 'entryFees';
                    break;
                case 'startTime':
                    search.sort_field = 'contestStartTime';
                    break;
                case 'players':
                    search.sort_field = 'entrantsCount';
                    break;
                case 'createdBy':
                    search.sort_field = 'userName';
                    break;
                case 'refundIssued':
                    search.sort_field = 'refundIssued';
                    break;                    
                default:
                    search.sort_field = 'contestName';
                    break;
            }
            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for getting one Contests (for Form)
     * @param {Object} resultSet - Resultset
     * @return {Object} Result object
     */
    getOneFormContestData: function (resultSet) {
        try {
            var row = {};
            row.contestId = resultSet.contestId;
            row.contestName = resultSet.contestName;
            row.draftgroupId = resultSet.draftgroupId;
            row.visibility = resultSet.visibility;
            row.guaranteed = resultSet.isGuaranteed;
            row.video = resultSet.isVideoAvailable;
            row.summary = resultSet.summary;
            row.tags = resultSet.labels;
            row.currentStatus = resultSet.contestStatus;
            row.prizeTemplate = resultSet.prizeTmpId;
            row.leagueTypeId = (resultSet.gameType == 'SC') ? (parseInt(resultSet.gameTypeId) - 5) : (resultSet.gameTypeId); // SC 6-10 and M 1-5 for the league types
            row.gameTypeId = resultSet.gameType; // (resultSet.gameType == 'Salary Cap') ? 'SC' : 'M';
            row.prizeMode = resultSet.prizeMode;
            row.prizeTickets = resultSet.prizeTickets;
            row.prizePool = resultSet.prizePool;
            row.entryFees = resultSet.entryFees;
            let totalEntrantsCnt = 0;
            for (const i in resultSet.entrants) {
                if (resultSet.entrants[i].userId) {
                    totalEntrantsCnt += resultSet.entrants[i].totalentry;
                }
            }
            row.rake = 1 - (resultSet.prizePool / (totalEntrantsCnt * row.entryFees));
            row.entrantsCnt = totalEntrantsCnt;

            row.minMembers = resultSet.minLimit;
            row.maxMembers = resultSet.maxLimit;
            row.maxMultiEntries = resultSet.maxEntriesPerUser;
            row.prizes = [];
            for (const i in resultSet.prizes) {
                if (resultSet.prizes[i].prizePosition) {
                    const nthPrize = {
                        'prizePosition': resultSet.prizes[i].prizePosition,
                        'amount': resultSet.prizes[i].amount,
                        'fromRange': resultSet.prizes[i].fromRange,
                        'toRange': resultSet.prizes[i].toRange
                    };
                    row.prizes.push(nthPrize);
                }
            }
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Add functionality
     * @param {Object} modalObj - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @param {Object} profile - User profile Object
     * @return {Object} Updated contest object
     */
    addData: function (modalObj, requestData, profile, startTimeUTC) {
        try {
            // contest.contestName = requestData.contestName;
            // contest.entryFees = requestData.entryFees;
            // contest.description = requestData.description;
            // contest.visibility = requestData.visibility;
            // contest.author = requestData.author;
            // if (requestData.users && requestData.users.length > 0) {
            //     for (var i in requestData.users) {
            //         contest.users.push(requestData.users[i]);
            //     }
            // }
            // return contest;
            modalObj.contestName = requestData.contestName;
            modalObj.draftgroupId = requestData.draftgroupId;
            modalObj.visibility = requestData.visibility;
            modalObj.isGuaranteed = (!requestData.guaranteed) ? false : true;
            modalObj.isVideoAvailable = (!requestData.video) ? false : true;
            modalObj.summary = requestData.summary;
            modalObj.labels = requestData.tags;
            modalObj.prizeTmpId = requestData.prizeTemplate;
            modalObj.contestStatus = 3; // upcomming // requestData.currentStatus;
            modalObj.contestStartTime = startTimeUTC;

            modalObj.isAdminRow = true;
            modalObj.sportId = requestData.leagueTypeId;
            modalObj.contestTypeId = 1;
            modalObj.contestType = 'Multiplayer';

            modalObj.entryFees = requestData.entryFees;
            modalObj.gameTypeId = (requestData.gameTypeId == 'SC') ? (parseInt(requestData.leagueTypeId) + 5) : (requestData.leagueTypeId); // SC 6-10 and M 1-5 for the league types
            modalObj.gameType = requestData.gameTypeId; // (requestData.gameTypeId == 'SC') ? 'Salary Cap' : 'Multiplier';
            modalObj.maxLimit = requestData.maxMembers;
            modalObj.minLimit = requestData.minMembers;
            modalObj.maxEntriesPerUser = requestData.maxMultiEntries;
            modalObj.prizeMode = requestData.prizeMode;
            modalObj.prizeTickets = requestData.prizeTickets;
            modalObj.prizePool = requestData.prizePool;
            // modalObj.rakePerc = requestData.rake;
            modalObj.createdBy = global.userId;
            modalObj.userName = (profile != null) ? profile.userName : '';
            modalObj.userEmail = (profile != null) ? profile.email : '';
            modalObj.isAdminRow = 1;
            modalObj.prizes = [];
            if (requestData.prizes && requestData.prizes.length > 0) {
                for (var i in requestData.prizes) {
                    const nthPrize = {
                        'prizePosition': requestData.prizes[i].prizePosition,
                        'amount': requestData.prizes[i].amount,
                        'fromRange': requestData.prizes[i].fromRange,
                        'toRange': requestData.prizes[i].toRange
                    };
                    modalObj.prizes.push(nthPrize);
                }
            }
            return modalObj;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for update functionality
     * @param {Object} modalObj - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated object
     */
    updateData: function (modalObj, requestData, startTimeUTC) {
        try {
            this.addData(modalObj, requestData);
            modalObj.contestStartTime = startTimeUTC;
            delete modalObj.contestStatus;
            delete modalObj.createdBy;
            delete modalObj.userName;
            delete modalObj.userEmail;
            return modalObj;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Edit functionality
     * @param {Object} contest - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated contest object
     */
    // editData: function (contest, requestData) {
    //     try {
    //         contest.contestName = requestData.contestName;
    //         contest.entryFees = requestData.entryFees;
    //         contest.description = requestData.description;
    //         contest.visibility = requestData.visibility;

    //         //sub document object
    //         if (contest.author) {
    //             contest.author._id = requestData.author._id;
    //             contest.author.email = requestData.author.email;
    //         }

    //         //sub document array
    //         var subSetMode = 'edit';
    //         if (subSetMode == 'add') {
    //             contest.users = []; //emptying the whole array
    //             if (requestData.users && requestData.users.length > 0) { //add it fresh
    //                 for (var i in requestData.users) {
    //                     contest.users.push(requestData.users[i]);
    //                 }
    //             }
    //         } else { //edit only
    //             if (requestData.users && requestData.users.length > 0) {
    //                 for (var j in requestData.users) {
    //                     contest.users.pull(requestData.users[j]._id);
    //                     contest.users.push(requestData.users[j]);
    //                 }

    //             }
    //         }
    //         return contest;
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     * Data Mapping for Get All functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getAllData: function (resultSet) {
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                // console.log(resultSet[i]);
                row.id = resultSet[i]._id;
                row.contestId = resultSet[i].contestId;
                row.contestName = resultSet[i].contestName;
                row.entryFees = resultSet[i].entryFees;
                row.contestStartTime = resultSet[i].contestStartTime;
                row.userName = resultSet[i].userName;
                // row.entrantsCount = resultSet[i].entrantsCount;
                // row.description = resultSet[i].description;
                // row.visibility = resultSet[i].visibility;
                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get Games functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getGamesData: function (contestGames, contest, draftgroupId) {
        try {
            var game = []
            if (contestGames.length > 0) {
                games = contestGames[0].gameList;
                for (var i in games) {
                    if (games[i].eventId) {
                        var rowGame = {};
                        rowGame.draftGroupId = draftgroupId;
                        rowGame.gameId = games[i].eventId;
                        rowGame.matchTime = (games[i].startTimeUTC) ? moment(games[i].startTimeUTC, 'UTC').tz(process.env.dest_zone).format('ddd h:mm a') : '';
                        rowGame.gameStatus = games[i].gameStatus ? games[i].gameStatus : '';
                        rowGame.startTimeUTC = (games[i].startTimeUTC) ? moment(games[i].startTimeUTC, 'UTC').tz(process.env.dest_zone).format('ddd h:mm a') : '';
                        if (games[i].players != null) {
                            rowGame.team1 = games[i].players[0].competition.nameDisplay[0].htName;
                            rowGame.team1W = games[i].players[0].competition.nameDisplay[0].team1W ? games[i].players[0].competition.nameDisplay[0].team1W : '0';
                            rowGame.team1L = games[i].players[0].competition.nameDisplay[0].team1L ? games[i].players[0].competition.nameDisplay[0].team1L : '0';
                            rowGame.team2 = games[i].players[0].competition.nameDisplay[0].atName;
                            rowGame.team2W = games[i].players[0].competition.nameDisplay[0].team2W ? games[i].players[0].competition.nameDisplay[0].team2W : '0';
                            rowGame.team2L = games[i].players[0].competition.nameDisplay[0].team2L ? games[i].players[0].competition.nameDisplay[0].team2L : '0';
                        }
                        game.push(rowGame);
                    }
                }
            }
            return game;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Search
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchContestData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.contest_status = (!requestData.contest_status) ? [1, 2, 3] : requestData.contest_status;
            search.from_date = (!requestData.from_date) ? '' : requestData.from_date; // moment(requestData.from_date).format('YYYY-MM-DD');
            search.to_date = (!requestData.to_date) ? '' : requestData.to_date; // moment(requestData.to_date).format('YYYY-MM-DD');
            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get contest list as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getContestsData: function (resultSet) {
        try {
            var contests = [];
            for (var i in resultSet) {
                var row = {};
                row.id = resultSet[i]._id;
                row.contestId = resultSet[i].contestId;
                row.contestName = resultSet[i].contestName; // + '(' + resultSet[i].contestId + ')';
                row.visibility = resultSet[i].visibility;
                row.entryFees = resultSet[i].entryFees;
                row.createdBy = resultSet[i].userName;
                row.players = resultSet[i].entrants.length ? resultSet[i].entrants.length : '0';
                // row.players = resultSet[i].entrantsCount;
                row.startTime = moment(resultSet[i].contestStartTime, 'UTC').tz(process.env.dest_zone).format('MM/DD/YYYY')
                row.contentStatus = resultSet[i].contentStatus;
                row.gameType = resultSet[i].gameType;
                row.isInvolved = (resultSet[i].createdBy == global.userId) ? 1 : 0;
                row.isAdminRow = (resultSet[i].isAdminRow) ? resultSet[i].isAdminRow : false;
                row.createdAt = moment(resultSet[i].createdAt, 'UTC').tz(process.env.dest_zone).format('MM/DD/YYYY');
                row.updatedAt = moment(resultSet[i].updatedAt, 'UTC').tz(process.env.dest_zone).format('MM/DD/YYYY');
                row.contestStatus = resultSet[i].contestStatus;
                row.refundIssued = resultSet[i].refundIssued;
                contests.push(row);
            }
            return contests;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get Contest's Games and Standings
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    contestData: function (contestId) {
        try {
            contestId = parseInt(contestId);
            return contestId;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get contest lineups as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    contestLineUpsResultMap: function (resultSet) {
        try {
            var lineups = [];
            for (var i in resultSet) {
                var rowLineup = {};
                rowLineup.lineupId = resultSet[i].lineupId;
                rowLineup.contestId = resultSet[i].contestId;
                rowLineup.userId = resultSet[i].userId;
                rowLineup.draftgroupId = resultSet[i].draftgroupId;
                rowLineup.sportId = resultSet[i].sportId;
                playersList = [];
                players = resultSet[i].players;
                for (var j = 0; j < players.length; j++) {
                    rowPlayer = {};
                    rowPlayer.eventId = players[j].eventId;
                    rowPlayer.tmpPosId = players[j].tmpPosId;
                    rowPlayer.tmpPosAbbr = players[j].tmpPosAbbr;
                    rowPlayer.tmpPosName = players[j].tmpPosName;
                    rowPlayer.tmpId = players[j].tmpId;
                    rowPlayer.playerId = players[j].playerId;
                    rowPlayer.fName = players[j].fName;
                    rowPlayer.lName = players[j].lName;
                    rowPlayer.playerName = players[j].playerName;
                    rowPlayer.playerName = players[j].imgUrl;
                    competitionObj = {};
                    competitionObj.compId = (players[j].competition.compId) ? (players[j].competition.compId) : '';
                    nameDisplayList = [];
                    nameDisplayObj = {};
                    nameDisplayObj.htName = players[j].competition.nameDisplay[0].htName;
                    // nameDisplayObj.htScore = (players[j].competition.nameDisplay[0].htScore) ? players[j].competition.nameDisplay[0].htScore : '';
                    // nameDisplayObj.value = (players[j].competition.nameDisplay[0].value) ? players[j].competition.nameDisplay[0].value : '';
                    nameDisplayObj.atName = (players[j].competition.nameDisplay[0].atName) ? players[j].competition.nameDisplay[0].atName : '';
                    // nameDisplayObj.atScore = (players[j].competition.nameDisplay[0].atScore) ? players[j].competition.nameDisplay[0].atScore : '';
                    nameDisplayList.push(nameDisplayObj);
                    competitionObj.nameDisplay = nameDisplayList;
                    rowPlayer.competition = competitionObj;
                    rowPlayer.teamId = players[j].teamId;
                    rowPlayer.teamAbbr = players[j].teamAbbr;
                    rowPlayer.fanProjScore = players[j].fanProjScore;
                    playersList.push(rowPlayer);
                }
                rowLineup.players = playersList;
                lineups.push(rowLineup);
            }
            //console.log(lineups);process.exit();
            return lineups;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get Contest Standings
     * @param {Object} resultSet - Resultset of standings db
     * @param {number} contestId - COntest id
     * @param {Object} usersDb - Resultset of user db
     * @return {Object} Updated result object
     */
    getStandingData: function (resultSet, contestId, usersDb) {
        try {
            var result = [];
            var users = {};
            for (var i in usersDb) {
                users[usersDb[i].userId] = {
                    'userName': usersDb[i].userName,
                    'img': usersDb[i].imageName,
                    'currentLoginType': usersDb[i].currentLoginType,
                    'fbId': usersDb[i].loginTypes.FB.fbId
                };
            }
            for (var i in resultSet) {
                var row = {};
                row.contestId = contestId;
                row.participantId = resultSet[i].userId;
                row.participantName = users[row.participantId].userName ? users[row.participantId].userName : '';

                if (users[row.participantId].currentLoginType == 'FB' && users[row.participantId].fbId) {
                    row.participantImage = fbHelper.getFbPicture(users[row.participantId].fbId);
                } else {
                    row.participantImage = (users[row.participantId].img != '' && users[row.participantId].img != undefined) ? process.env.PROFILE_IMAGE_URL + users[row.participantId].img : '';
                }
                // row.participantImage = resultSet[i].userImgName ? resultSet[i].userImgName : '';

                row.position = resultSet[i].position ? resultSet[i].position : '0';
                row.points = resultSet[i].points ? resultSet[i].points : '0';
                row.winningAmount = resultSet[i].winning ? resultSet[i].winning : '0';
                row.entryCount = resultSet[i].entryCount ? resultSet[i].entryCount : '';
                row.lineupId = resultSet[i].lineupId ? resultSet[i].lineupId : '';
                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get Contest's Games
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    gamesData: function (contestId) {
        try {
            contestId = parseInt(contestId);
            return contestId;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get Contest's Games and Standings
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    LineUpData: function (lineupId) {
        try {
            var lineup = {};
            lineupId = parseInt(lineupId);
            return lineupId;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get lineup by Id as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    lineUpResultMap: function (resultSet) {
        try {
            var lineups = {};
            var rowLineup = {};
            rowLineup.lineupId = resultSet.lineupId;
            playersList = [];
            players = resultSet.players;
            for (var j = 0; j < players.length; j++) {
                rowPlayer = {};
                rowPlayer.playerId = players[j].playerId;
                rowPlayer.playerName = players[j].fName + ' ' + players[j].lName;
                rowPlayer.position = players[j].tmpPosAbbr;
                rowPlayer.team1 = players[j].competition.nameDisplay[0].htName;
                rowPlayer.team2 = players[j].competition.nameDisplay[0].atName;
                rowPlayer.salaryCap = players[j].fanProjSalary ? players[j].fanProjSalary : '';
                rowPlayer.ffp = parseFloat("" + players[j].fanProjScore + "").toFixed(2);
                playersList.push(rowPlayer);
            }
            rowLineup.players = playersList;
            lineups = rowLineup;
            return playersList;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get All functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getOneContestData: function (resultSet, profile, profile1, draftGroup, lineUp1) {
        try {
            var lg = ["NFL", "MLB", "NHL", "NBA", "GOLF"];
            var status = ["Completed", "live", "Yet To happen"];
            var row = {};
            row.contestId = resultSet.contestId;
            row.contestName = resultSet.contestName;
            row.entryFees = resultSet.entryFees;
            row.contestTypeId = resultSet.contestTypeId;
            row.contestType = resultSet.contestType;
            row.leagueType = lg[resultSet.sportId - 1];
            row.draftgroupId = resultSet.draftgroupId;
            row.draftGroupName = (draftGroup) ? (draftGroup) : '';;
            row.gameTypeId = resultSet.gameTypeId;
            row.gameType = resultSet.gameType;
            row.creatorId = resultSet.createdBy;
            row.creatorName = profile.userName;
            row.rake = (resultSet.rakePerc) ? (resultSet.rakePerc) : 0;
            row.winningAmount = (resultSet.amountWon) ? (resultSet.amountWon) : '0';
            row.currentStatus = status[resultSet.contestStatus - 1];
            row.leadingUserName = 'TBD';

            participant = {};
            participant.user1Points = 0;
            participant.user2Points = 0;
            participant.user1ineUpId = 0;
            participant.user2lineUpId = 0;
            for (var i in lineUp1) {

                if (lineUp1[i].userId == profile.userId) {
                    participant.user1Position = lineUp1[i].position;
                    participant.user1Points = lineUp1[i].points;
                    participant.user1ineUpId = lineUp1[i].lineupId;
                } else {
                    participant.user2Position = lineUp1[i].position;
                    participant.user2Points = lineUp1[i].points;
                    participant.user2lineUpId = lineUp1[i].lineupId;
                }
            }
            participant.user1Id = profile.userId;
            participant.user1Name = profile.userName;
            if (profile.currentLoginType == 'FB' && profile.loginTypes.FB.fbId) {
                participant.user1Image = fbHelper.getFbPicture(profile.loginTypes.FB.fbId);
            } else {
                participant.user1Image = (profile.imageName != '' && profile.imageName != undefined) ? process.env.PROFILE_IMAGE_URL + profile.imageName : '';
            }
            // participant.user1Image = (profile.imageName) ? (profile.imageName) : '';

            //  participant.user1Position=1;
            //  participant.user1Points=125;
            
            participant.user2Id = profile1.userId;
            participant.user2Name = profile1.userName;
            if (profile1.currentLoginType == 'FB' && profile1.loginTypes.FB.fbId) {
                participant.user2Image = fbHelper.getFbPicture(profile1.loginTypes.FB.fbId);
            } else {
                participant.user2Image = (profile1.imageName != '' && profile1.imageName != undefined) ? process.env.PROFILE_IMAGE_URL + profile1.imageName : '';
            }
            // participant.user2Image = (profile1.imageName) ? (profile1.imageName) : '';

            //participant.user2Position = 2;
            //  participant.user2Points=126;         
            row.participants = participant;
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get All functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getOnemultiplayerContestData: function (resultSet, profile, draftGroup) {
        try {

            var lg = ["NFL", "MLB", "NHL", "NBA", "GOLF"];
            var status = ["Completed", "live", "Yet To happen"];
            var row = {};
            row.contestId = resultSet.contestId;
            row.contestName = resultSet.contestName;
            row.prizePool = resultSet.prizePool;
            row.entryFees = resultSet.entryFees;
            row.contestTypeId = resultSet.contestTypeId;
            row.contestType = resultSet.contestType;
            row.leagueType = lg[resultSet.sportId - 1];
            row.draftgroupId = resultSet.draftgroupId;
            row.draftGroup = draftGroup;
            row.gameTypeId = resultSet.gameTypeId;
            row.gameType = resultSet.gameType;
            row.creatorId = resultSet.createdBy;
            //row.creatorName = (profile != null) ? profile.userName : '';
            row.creatorName = resultSet.userName;
            row.draftGroupName = (draftGroup) ? (draftGroup) : '';
            row.winningAmount = (resultSet.amountWon) ? (resultSet.amountWon) : '0';
            row.currentStatus = status[resultSet.contestStatus - 1];
            // row.rake = (resultSet.rakePerc) ? (resultSet.rakePerc) : '0';
            let totalEntrantsCnt = 0;
            for (const i in resultSet.entrants) {
                if (resultSet.entrants[i].userId) {
                    totalEntrantsCnt += resultSet.entrants[i].totalentry;
                }
            }
            row.rake = 1 - (resultSet.prizePool / (totalEntrantsCnt * resultSet.entryFees));
            row.entrantsCnt = totalEntrantsCnt;

            row.leadingUserId = 1;
            row.leadingUserName = "TBD";
            row.totalSeats = (resultSet.maxEntriesPerUser) ? (resultSet.maxEntriesPerUser) : '0';
            row.totalJoinees = (resultSet.entrants.length) ? resultSet.entrants.length : '0';
            return row;
        } catch (e) {
            throw e;
        }
    },

      /**
    * Data Mapping for created contest list as response
    * @param {Object} resultSet - Resultset
    * @return {Object} Updated result object
    */
   getUserCreatedContest: function (resultSet) {
    try {

        var result = {};
        var multiplayer = [];
        var h2h = [];
        for (var i in resultSet) {
            var lineupIds = [];

            var totalEntry = (resultSet[i].entrants).reduce(function (a, b) {
                return a + b.totalentry;
            }, 0);

            if (resultSet[i].contestTypeId == 1) {
                // var contestIds = [];
                //contestIds.push(resultSet[i].contestId);
                var multiplayerObj = {};
                multiplayerObj.type = resultSet[i].contestType;
                // multiplayerObj.id = resultSet[i]._id;
                multiplayerObj.contestTypeId = resultSet[i].contestTypeId;
                multiplayerObj.gameTypeId = resultSet[i].gameTypeId;
                multiplayerObj.me = resultSet[i].maxEntriesPerUser ? resultSet[i].maxEntriesPerUser : '';
                multiplayerObj.rewards = resultSet[i].rewards ? resultSet[i].rewards : '';
                multiplayerObj.contestId = resultSet[i].contestId;
                multiplayerObj.contestName = resultSet[i].contestName;
                multiplayerObj.username = resultSet[i].userName ? resultSet[i].userName : '';
                multiplayerObj.imageName = resultSet[i].imageName ? resultSet[i].imageName : '';
                //lineup section start
                lineupIds.push(null);
                multiplayerObj.lineupIds = lineupIds;
                //lineupsection end
                multiplayerObj.entryFees = resultSet[i].entryFees;
                multiplayerObj.po = resultSet[i].prizePool ? resultSet[i].prizePool : '';
                // multiplayerObj.description = resultSet[i].description;
                multiplayerObj.visibility = resultSet[i].visibility;
                multiplayerObj.draftgroupId = resultSet[i].draftgroupId;
                multiplayerObj.sportId = resultSet[i].sportId;
                //multiplayerObj.en = resultSet[i].entrants ? resultSet[i].entrants.length : 0;
                multiplayerObj.en = totalEntry;
                multiplayerObj.t = resultSet[i].maxLimit ? resultSet[i].maxLimit : '';
                multiplayerObj.sd = resultSet[i].contestStartTime ? resultSet[i].contestStartTime : '';
                multiplayerObj.isOwner = (resultSet[i].createdBy == global.userId) ? true : false;
                multiplayerObj.guarenteed = resultSet[i].isGuaranteed ? true : false;
                attr = {};
                sponsor = {};
                sponsor.sponsorName = resultSet[i].attributes.sponsor.sponsorName;
                sponsor.imgURL = resultSet[i].attributes.sponsor.imgUrl;
                attr.isVideo = resultSet[i].isVideoAvailable ? true : false;
                attr.tags = resultSet[i].labels;
                attr.sponsor = sponsor
                multiplayerObj.attributes = attr;
                multiplayerObj.sort = resultSet[i].sort;
                //multiplayer.push(multiplayerObj);
            }
            if (resultSet[i].contestTypeId == 2) {
                var h2hC = {};
                contestIds = [];
                var lineupContest = [];
                contestIds.push(resultSet[i].contestId);
                //lineup section start
                var lineupContestObj = {};
                if ((resultSet[i].createdBy == global.userId)) {
                    lineupContestObj.lineUp = null;
                    lineupContestObj.contest = resultSet[i].contestId;
                    lineupContest.push(lineupContestObj);
                }
                //lineup section end
                if (resultSet[i].contestGroupId) {
                    var count = 1;
                    var kArr = [];
                    //contestIds.push(resultSet[i].contestId);
                    for (var k in resultSet) {
                        if ((resultSet[k].contestGroupId == resultSet[i].contestGroupId) && (resultSet[k].contestId != resultSet[i].contestId)) {
                            count++;
                            kArr.push(k);
                            contestIds.push(resultSet[k].contestId);
                            //lineup section start
                            var lineupContestObj = {};
                            if ((resultSet[k].createdBy == global.userId)) {
                                lineupContestObj.lineUp = null;
                                lineupContestObj.contest = resultSet[k].contestId;
                                lineupContest.push(lineupContestObj);
                            }
                            //lineup section end
                        }
                    }
                    h2hC.contestCount = count;
                    for (var g = 0; g < kArr.length; g++) {
                        resultSet.splice(kArr[g] - g, 1);
                    }
                }
                //(contestIds.length > 1) ? (h2hC.contestIds = contestIds) : (h2hC.contestId = resultSet[i].contestId);
                h2hC.contestIds = contestIds;
                // h2hC.id = resultSet[i]._id;
                h2hC.contestGroupId = resultSet[i].contestGroupId;
                h2hC.contestName = resultSet[i].contestName ? resultSet[i].contestName : '';
                h2hC.lineupIds = lineupContest;
                h2hC.draftgroupId = resultSet[i].draftgroupId;
                h2hC.username = resultSet[i].userName? resultSet[i].userName : '';
                h2hC.imageName = resultSet[i].imageName ? resultSet[i].imageName : '';
                h2hC.displayName = (resultSet[i].fName && resultSet[i].lName) ? resultSet[i].fName + ' ' + resultSet[i].lName : '';
                h2hC.entryFees = resultSet[i].entryFees;
                h2hC.po = resultSet[i].prizePool ? resultSet[i].prizePool : '';
                // h2hC.description = resultSet[i].description;
                h2hC.visibility = resultSet[i].visibility;
                h2hC.type = resultSet[i].contestType;
                h2hC.contestTypeId = resultSet[i].contestTypeId;
                h2hC.me = resultSet[i].maxEntriesPerUser ? resultSet[i].maxEntriesPerUser : '';
                h2hC.sportId = resultSet[i].sportId;
                h2hC.sport = resultSet[i].sName;
                h2hC.en = resultSet[i].entrants ? resultSet[i].entrants.length : 0;
                h2hC.t = resultSet[i].maxLimit ? resultSet[i].maxLimit : '';
                h2hC.pid = resultSet[i].createdBy ? resultSet[i].createdBy : '';
                h2hC.cid = '';
                h2hC.sd = resultSet[i].contestStartTime ? resultSet[i].contestStartTime : '';
                h2hC.gameType = resultSet[i].gameType.split(" ")[0];
                h2hC.gameTypeId = resultSet[i].gameTypeId;
                h2hC.records = {};
                h2hC.sort = resultSet[i].sort;
             
                // h2h.push(h2hC);
            }
        }
        result = (multiplayerObj != null) ? multiplayerObj : h2hC;
        return result;
    } catch (e) {
        throw e;
    }
},




};