/**
 * Transaction Data Mapper
 * @exports Transaction/DataMapper
 */
var moment = require('moment');

module.exports = {

    /**
     * Data Mapping for notification pagination
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    // paginationData: function (requestData) {
    //     try {
    //         var pagination = {};
    //         pagination.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
    //         pagination.page = (!requestData.page_number) ? 0 : requestData.page_number;
    //         return pagination;
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     * Data Mapping for Search
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchDataCommon: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            // search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.transaction_type = (!requestData.transaction_type) ? '' : requestData.transaction_type;
            search.from_date = (!requestData.from_date) ? '' : requestData.from_date;
            search.to_date = (!requestData.to_date) ? '' : requestData.to_date;

            search.sort_field = (!requestData.sort_field) ? 'tplName' : requestData.sort_field;
            search.sort_order = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            switch (search.sort_field) {
                case 'userName':
                    search.sort_field = 'userName';
                    break;
                case 'transactionType':
                    search.sort_field = 'tranType';
                    break;
                case 'transactionDate':
                    search.sort_field = 'entryDate';
                    break;
                case 'amount':
                    search.sort_field = 'amount';
                    break;
                default:
                    search.sort_field = 'userName';
                    break;
            }
            return search;
        } catch (e) {
            throw e;
        }
    },


    /**
     * Data Mapping for getting common Transactions
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getTransactionsDataCommon: function (resultSet) {
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                row.transactionId = resultSet[i]._id;
                row.userName = resultSet[i].userName;
                // row.userName = resultSet[i].fName + ' ' + resultSet[i].lName;
                row.transactionType = (resultSet[i].tranType == 'D') ? 'Deposit' : (resultSet[i].tranType == 'W') ? 'Withdrawal' : (resultSet[i].tranType == 'TM') ? 'Ticket to Money' : 'Reward to Ticket';
                row.amount = resultSet[i].amount;
                row.transactionStatus = resultSet[i].tranStatus;
                row.transactionDate = moment(resultSet[i].entryDate).format('MM/DD/YYYY');
                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Search (contest transaction)
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchContestTransactionsData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : requestData.page_limit;
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.from_date = (!requestData.from_date) ? '' : requestData.from_date;
            search.to_date = (!requestData.to_date) ? '' : requestData.to_date;
            search.league_type = (!requestData.league_type) ? '1' : requestData.league_type;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.sort = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            search.sort_field = (!requestData.sort_field) ? 'contestName' : requestData.sort_field;
            switch (search.sort_field) {
                case 'contestName':
                    search.sort_field = 'contestName';
                    break;
                case 'startTime':
                    search.sort_field = 'contestStartTime';
                    break;
                case 'entryFees':
                    search.sort_field = 'entryFees';
                    break;
                default:
                    search.sort_field = 'contestName';
                    break;
            }
            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get Player Count from the resultset
     * @param {Array} entrants - Entrants
     * @return {Number} Player count
     */
    getPlayerCount: function (entrants) {
        try {
            var totEntries = 0;
            if (entrants) {
                for (entry of entrants) {
                    if (entry.totalentry) {
                        totEntries += entry.totalentry;
                    }
                }
            }
            return totEntries;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get Total Prize from the resultset
     * @param {Array} prizes - prizes
     * @return {Number} Total Prize
     */
    totalPrize: function (prizes) {
        try {
            var totPrizeAmount = 0;
            if (prizes) {
                for (prize of prizes) {
                    if (prize.amount) {
                        totPrizeAmount += prize.amount * (prize.toRange - prize.fromRange + 1);
                    }
                }
            }
            return totPrizeAmount;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get All contest transaction functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getContestTransactionsData: function (resultSet) {
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                row.contestId = resultSet[i].contestId;
                row.contestName = resultSet[i].contestName;
                row.entryFees = resultSet[i].entryFees;
                if (resultSet[i].contestStartTime) {
                    row.startTime = moment(resultSet[i].contestStartTime).format('MM/DD/YYYY h:mm a');
                } else {
                    row.startTime = '';
                }
                row.playerCount = this.getPlayerCount(resultSet[i].entrants);
                row.totalEntryFees = row.playerCount * row.entryFees;
                row.rakePercentage = resultSet[i].rakePerc;
                row.totalPrize = this.totalPrize(resultSet[i].prizes);
                row.totalRakeAmount = (row.totalEntryFees / 100) * resultSet[i].rakePerc;
                row.prizePool = resultSet[i].prizePool;
                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Contents (Transaction)
     * @param {Object} dbData
     * @return {Number} Result Amount
     */
    getTransactionData: function (dbData) {
        try {
            var rowObj = {
                deposit: 0,
                withdrawal: 0,
                totalCnt: 0
            };
            for (row of dbData) {
                if (row._id.tranType === 'D') {
                    rowObj.deposit = row.amt;
                } else if (row._id.tranType === 'W') {
                    rowObj.withdrawal = row.amt;
                }
            }
            rowObj.totalCnt = rowObj.deposit - rowObj.withdrawal;
            return rowObj.totalCnt;
        } catch (e) {
            throw e;
        }
    },
};