/**
 * PrizeTemplate Validation
 * @exports PrizeTemplate/Validation
 */
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/prizeTemplateTrans.json');
const numberRegEx = /^\d+(\.\d{1,2})?$/;
const emailRegEx = /\S+@\S+\.\S+/;


module.exports = {

	/**
	 * Validation for the data to be added
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False
	 */
	addValidation: function (req, res) {
		try {
			if (!req.body.prizeTemplate) {
				return generalHelper.handleError(req, res, "Invalid Input in template Name", _t.tmpNameRequired);
			}
			if (!req.body.leagueTypeId) {
				return generalHelper.handleError(req, res, "Invalid Input in league Type", _t.leagueTypeIdRequired);
			}
			if (!req.body.gameTypeId) {
				return generalHelper.handleError(req, res, "Invalid Input in game Type", _t.gameTypeIdRequired);
			}
			if (!req.body.prizeMode) {
				return generalHelper.handleError(req, res, "Invalid Input in prize Mode", _t.prizeModeRequired);
			} else if (req.body.prizeMode != 'C') {
				if (!req.body.prizeTickets) {
					return generalHelper.handleError(req, res, "Invalid Input in prize Tickets", _t.prizeTicketsRequired);
				}
			}
			if (!req.body.prizePool) {
				return generalHelper.handleError(req, res, "Invalid Input in prizePool", _t.prizePoolRequired);
			}
			// if (!req.body.rake) {
			// 	return generalHelper.handleError(req, res, "Invalid Input in rake", _t.rakeRequired);
			// }
			if (!req.body.minMembers) {
				return generalHelper.handleError(req, res, "Invalid Input in minMembers", _t.minMembersRequired);
			}
			if (!req.body.maxMembers) {
				return generalHelper.handleError(req, res, "Invalid Input in maxMembers", _t.maxMembersRequired);
			}
			if (!req.body.maxMultiEntries) {
				return generalHelper.handleError(req, res, "Invalid Input in max multi Entries", _t.maxMultiEntriesRequired);
			}
			if (!req.body.entryFees) {
				return generalHelper.handleError(req, res, "Invalid Input in entryFees", _t.entryFeesRequired);
			}
			if (!req.body.prizes) {
				return generalHelper.handleError(req, res, "Invalid Input in prizes", _t.prizesRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - update record
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	updateValidation: function (req, res) {
		if (!req.params.id) {
			return generalHelper.handleError(req, res, "Invalid Input in id", _t.idRequired);
		} else {
			return this.addValidation(req, res);
		}
	},

	/**
	 * Validation for the data - Update Status
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	updateStatusValidation: function (req, res) {
		if (!req.params.id) {
			return generalHelper.handleError(req, res, "Invalid Input in id", _t.idRequired);
		} else if (!req.body.status) {
			return generalHelper.handleError(req, res, "Invalid Input in status", _t.statusRequired);
		} else if (req.body.status != 1 && req.body.status != 2) {
			return generalHelper.handleError(req, res, "Invalid Input in status", _t.statusInvalid);
		}
	}

};