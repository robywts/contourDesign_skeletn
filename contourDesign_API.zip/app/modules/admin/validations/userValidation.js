/**
 * User Validation
 * @exports Admin/User/Validation
 */
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/userTrans.json');

module.exports = {

	/**
	 * Validation for the data - Update Status
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	updateStatusValidation: function (req, res) {
		if (!req.params.id) {
			return generalHelper.handleError(req, res, "Invalid Input in userId", _t.userIdRequired);
		}
		if (!req.body.status) {
			return generalHelper.handleError(req, res, "Invalid Input in status", _t.statusRequired);
		} else if (req.body.status != 1 && req.body.status != 2) {
			return generalHelper.handleError(req, res, "Invalid Input in status", _t.statusInvalid);
		}
	},

};