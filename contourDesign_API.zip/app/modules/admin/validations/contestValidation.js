/**
 * Contest Validation
 * @exports Admin/Contest/Validation
 */
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/contestTrans.json');

module.exports = {
	/**
	 * Validation for the data to be added
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	addValidation: function (req, res) {
		try {
			// if (!req.body.contestName) {
			// 	return generalHelper.handleError(req, res, "Invalid Input in name", _t.nameRequired);
			// }
			// if (!req.body.entryFees && req.body.entryFees < 0) {
			// 	return generalHelper.handleError(req, res, "Invalid Input in entry fees", _t.entryFeesRequired);
			// }
			if (!req.body.contestName) {
				return generalHelper.handleError(req, res, "Invalid Input in contest Name", _t.contestNameRequired);
			}
			if (!req.body.draftgroupId) {
				return generalHelper.handleError(req, res, "Invalid Input in Draftgroup", _t.draftGroupRequired);
			}
			if (!req.body.visibility) {
				return generalHelper.handleError(req, res, "Invalid Input in visibility", _t.visibilityRequired);
			}
			// if (!req.body.guaranteed) {
			// 	return generalHelper.handleError(req, res, "Invalid Input in guaranteed", _t.guaranteedRequired);
			// }
			// if (!req.body.video) {
			// 	return generalHelper.handleError(req, res, "Invalid Input in video", _t.videoRequired);
			// }
			if (!req.body.summary) {
				return generalHelper.handleError(req, res, "Invalid Input in summary", _t.summaryRequired);
			}
			// if (!req.body.prizeTemplate) {
			// 	return generalHelper.handleError(req, res, "Invalid Input in template", _t.tmpNameRequired);
			// }
			// if (!req.body.currentStatus) {
			// 	return generalHelper.handleError(req, res, "Invalid Input in status", _t.statusRequired);
			// }

			if (!req.body.leagueTypeId) {
				return generalHelper.handleError(req, res, "Invalid Input in league Type", _t.leagueTypeIdRequired);
			}
			if (!req.body.gameTypeId) {
				return generalHelper.handleError(req, res, "Invalid Input in game Type", _t.gameTypeIdRequired);
			}
			if (!req.body.prizeMode) {
				return generalHelper.handleError(req, res, "Invalid Input in prize Mode", _t.prizeModeRequired);
			} else if (req.body.prizeMode != 'C') {
				if (!req.body.prizeTickets) {
					return generalHelper.handleError(req, res, "Invalid Input in prize Tickets", _t.prizeTicketsRequired);
				}
			}
			if (!req.body.prizePool) {
				return generalHelper.handleError(req, res, "Invalid Input in prizePool", _t.prizePoolRequired);
			}
			// if (!req.body.rake) {
			// 	return generalHelper.handleError(req, res, "Invalid Input in rake", _t.rakeRequired);
			// }
			if (!req.body.minMembers) {
				return generalHelper.handleError(req, res, "Invalid Input in minMembers", _t.minMembersRequired);
			}
			if (!req.body.maxMembers) {
				return generalHelper.handleError(req, res, "Invalid Input in maxMembers", _t.maxMembersRequired);
			}
			if (!req.body.maxMultiEntries) {
				return generalHelper.handleError(req, res, "Invalid Input in maxMultiEntries", _t.maxMultiEntriesRequired);
			}
			if (!req.body.entryFees) {
				return generalHelper.handleError(req, res, "Invalid Input in entryFees", _t.entryFeesRequired);
			}
			if (!req.body.prizes) {
				return generalHelper.handleError(req, res, "Invalid Input in prizes", _t.prizesRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - update record
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	updateValidation: function (req, res) {
		try {
			// if (!req.body.contestName) {
			// 	return generalHelper.handleError(req, res, "Invalid Input in name", _t.nameRequired);
			// }
			// if (!req.body.entryFees) {
			// 	return generalHelper.handleError(req, res, "Invalid Input in entry fees", _t.entryFeesRequired);
			// }
			if (!req.params.id) {
				return generalHelper.handleError(req, res, "Invalid Input in id", _t.idRequired);
			} else {
				return this.addValidation(req, res);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - get contest's games and standings by contestId
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	getValidation: function (req, res) {
		try {
			if (!req.params.id || req.params.id == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in contestId", _t.contestIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - get lineup by lineUpId
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	getLineUpValidation: function (req, res) {
		try {
			if (!req.params.id || req.params.id == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in lineupId", _t.lineupIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - get standings by contestId
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	getStandingsValidation: function (req, res) {
		try {
			if (!req.params.id || req.params.id == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in contestId", _t.contestIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},

};