/**
 * Setting Validation
 * @exports Admin/Setting/Validation
 */
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/generalTrans.json');
const numberRegEx = /^\d+(\.\d{1,2})?$/;


module.exports = {

	/**
	 * Validation for the data - update Setting data
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	updateSettingDataValidation: function (req, res) {
		if (!req.body.rewardToDollar) {
			return generalHelper.handleError(req, res, "Invalid Input in rewardToDollar", _t.rewardToDollarRequired);
		} else if (!numberRegEx.test(req.body.rewardToDollar)) {
			return generalHelper.handleError(req, res, "Invalid rewardToDollar", _t.rewardToDollarInvalid);
		}

		if (!req.body.ticketToDollar) {
			return generalHelper.handleError(req, res, "Invalid Input in ticketToDollar", _t.ticketToDollarRequired);
		} else if (!numberRegEx.test(req.body.ticketToDollar)) {
			return generalHelper.handleError(req, res, "Invalid ticketToDollar", _t.ticketToDollarInvalid);
		}

		if (!req.body.rewardToTicket) {
			return generalHelper.handleError(req, res, "Invalid Input in rewardToTicket", _t.rewardToTicketRequired);
		} else if (!numberRegEx.test(req.body.rewardToTicket)) {
			return generalHelper.handleError(req, res, "Invalid rewardToTicket", _t.rewardToTicketInvalid);
		}
	},

};