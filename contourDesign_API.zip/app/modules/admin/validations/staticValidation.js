/**
 * Static Validation
 * @exports Admin/Static/Validation
 */
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/generalTrans.json');
const numberRegEx = /^\d+(\.\d{1,2})?$/;


module.exports = {

	/**
	 *  * Validation for the data - update Static data
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	updateStaticDataValidation: function (req, res) {
		// if (!req.body.name) {
		// 	return generalHelper.handleError(req, res, "Invalid Input in name", _t.nameRequired);
		// }
		if (!req.body.content) {
			return generalHelper.handleError(req, res, "Invalid Input in content", _t.contentRequired);
		}
	},	

};