/**
 * DraftGroup Validation
 * @exports DraftGroup/Validation
 */
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/draftGroupTrans.json');
const numberRegEx = /^\d+(\.\d{1,2})?$/;


module.exports = {

	/**
	 * Validation for the data - get draftgroups
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	listDraftValidation: function (req, res) {
		try {
			if (!req.query.week || req.query.week == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in week", _t.weekRequired);
			}
		   /*if (!req.query.season || req.query.season == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in season", _t.seasonRequired);
			}*/
			if (!req.query.sportId || req.query.sportId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in sportId", _t.sportIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},


	/**
	 * Validation for the data - get draftgroups details/players by id
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	DraftgroupIdValidation: function (req, res) {
		try {
			if (!req.params.id || req.params.id == 0) {
				return generalHelper.handleError(req, res, "Record not found", _t.draftgroupIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},

		/**
	 * Validation for the data - get DraftGroup Weeks
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	DraftGroupWeeksValidation: function (req, res) {
		try {	
			if (!req.params.id || req.params.id == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in sportId", _t.sportIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data to be added
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	addValidation: function (req, res) {
		try {
			if (!req.body.draftGroupName) {
				return generalHelper.handleError(req, res, "Invalid Input in draftGroupName", _t.dgNameRequired);
			}
			if (!req.body.sortOrder) {
				return generalHelper.handleError(req, res, "Invalid Input in sortOrder", _t.sortOrderRequired);
			}
			if (!req.body.weekId) {
				return generalHelper.handleError(req, res, "Invalid Input in week", _t.weekRequired);
			}
			if (!req.body.leagueType) {
				return generalHelper.handleError(req, res, "Invalid Input in leagueType", _t.leagueTypeRequired);
			}	
			if (!req.body.games) {
				return generalHelper.handleError(req, res, "Invalid Input in games", _t.gamesRequired);
			}		
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data to be update
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	updateValidation: function (req, res) {
		try {
			if (!req.params.id) {
				return generalHelper.handleError(req, res, "Invalid Input in draftgroupId", _t.draftgroupIdRequired);
			}
			if (!req.body.draftGroupName) {
				return generalHelper.handleError(req, res, "Invalid Input in draftGroupName", _t.dgNameRequired);
			}
			if (!req.body.sortOrder) {
				return generalHelper.handleError(req, res, "Invalid Input in sortOrder", _t.sortOrderRequired);
			}
			if (!req.body.weekId) {
				return generalHelper.handleError(req, res, "Invalid Input in week", _t.weekRequired);
			}
			if (!req.body.leagueType) {
				return generalHelper.handleError(req, res, "Invalid Input in leagueType", _t.leagueTypeRequired);
			}	
			if (!req.body.games) {
				return generalHelper.handleError(req, res, "Invalid Input in games", _t.gamesRequired);
			}		
		} catch (e) {
			throw e;
		}
	},

};