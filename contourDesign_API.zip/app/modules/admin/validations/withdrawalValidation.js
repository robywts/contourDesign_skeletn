/**
 * Withdrawal Validation
 * @exports Admin/Withdrawal/Validation
 */
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/withdrawalTrans.json');

module.exports = {

	/**
	 * Withdrawals Validation for the data - Update WithdrawalStatus
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	updateWithdrawalStatusValidation: function (req, res) {
		if (!req.params.id) {
			return generalHelper.handleError(req, res, "Invalid Input in WithdrawalId", _t.WithdrawalRequired);
		}
		if (!req.body.paymentType) {
			return generalHelper.handleError(req, res, "Invalid Input in paymentType", _t.paymentTypeRequired);
		}
		if (!req.body.status) {
			return generalHelper.handleError(req, res, "Invalid Input in status", _t.statusRequired);
		} else if (['P', 'I', 'C', 'R'].indexOf(req.body.status) <= -1) {
			return generalHelper.handleError(req, res, "Invalid Input in status", _t.statusInvalid);
		}
	},

};