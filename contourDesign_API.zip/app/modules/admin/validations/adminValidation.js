/**
 * Admin Validation
 * @exports Admin/User/Validation
 */
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/adminTrans.json');
const numberRegEx = /^\d+(\.\d{1,2})?$/;
const emailRegEx = /\S+@\S+\.\S+/;


module.exports = {

	/**
	 * Validation for the data - update user
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	updateProfileValidation: function (req, res) {
		if (!req.params.id) {
			return generalHelper.handleError(req, res, "Invalid Input in userId", _t.userIdRequired);
		} else if (req.params.id == 1) {
			return generalHelper.handleError(req, res, "Super admin userId", _t.userIdRestricted);
		}
		if (req.body.permission.length == 0) {
			return generalHelper.handleError(req, res, "Invalid Input in permissions", _t.permissionRequired);
		}
	},
	/**
	 * Validation for the data to be added
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False
	 */
	registerValidation: function (req, res) {
		try {
			if (!req.body.userName) {
				return generalHelper.handleError(req, res, "Invalid Input in user name", _t.userNameRequired);
			}
			if (!req.body.email) {
				return generalHelper.handleError(req, res, "Invalid Input in email", _t.emailRequired);
			} else {
				if (!emailRegEx.test(req.body.email)) {
					return generalHelper.handleError(req, res, "Invalid email", _t.emailInvalid);
				}
			}
			if (!req.body.password) {
				return generalHelper.handleError(req, res, "Invalid Input in password", _t.passwordRequired);
			}
			if (!req.body.permission) {
				return generalHelper.handleError(req, res, "Invalid Input in permissions", _t.permissionRequired);
			}

		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - update Status
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	updateStatusValidation: function (req, res) {
		if (!req.params.id) {
			return generalHelper.handleError(req, res, "Invalid Input in userId", _t.userIdRequired);
		} else if (req.params.id == 1) {
			return generalHelper.handleError(req, res, "Super admin userId", _t.userIdRestricted);
		}

		if (!req.body.status) {
			return generalHelper.handleError(req, res, "Invalid Input in status", _t.statusRequired);
		} else if (req.body.status != 1 && req.body.status != 2) {
			return generalHelper.handleError(req, res, "Invalid Input in status", _t.statusInvalid);
		}
	},

	/**
	 * Validation for the data - delete user
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	deleteValidation: function (req, res) {
		if (!req.params.id) {
			return generalHelper.handleError(req, res, "Invalid Input in userId", _t.userIdRequired);
		} else if (req.params.id == 1) {
			return generalHelper.handleError(req, res, "Super admin userId", _t.userIdRestricted);
		}
	},

};