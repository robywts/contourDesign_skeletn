/**
 * User Auth Validation
 * @exports Admin/UserAuth/Validation
 */
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/userAuthTrans.json');
const emailRegEx = /\S+@\S+\.\S+/;

module.exports = {

	/**
	 * Validation for the data to be login with
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	loginValidation: function (req, res) {
		try {
			if (!req.body.email) {
				return generalHelper.handleError(req, res, "Invalid Input in email", _t.emailRequired);
			}
			if (!req.body.pwd) {
				return generalHelper.handleError(req, res, "Invalid Input in password", _t.passwordRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - forgot password
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	forgotValidation: function (req, res) {
		try {
			if (!req.body.email) {
				return generalHelper.handleError(req, res, "Invalid Input in email", _t.emailRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - reset password
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	resetValidation: function (req, res) {
		try {
			if (!req.body.email) {
				return generalHelper.handleError(req, res, "Invalid Input in email", _t.emailRequired);
			}
			if (!req.body.resetCode) {
				return generalHelper.handleError(req, res, "Invalid reset code", _t.resetCodeRequired);
			}
			if (!req.body.pwd) {
				return generalHelper.handleError(req, res, "Invalid Input in password", _t.passwordRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - change password
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	changePasswordValidation: function (req, res) {
		try {
			if (!req.body.oldPwd) {
				return generalHelper.handleError(req, res, "Invalid Input in old password", _t.oldPasswordRequired);
			}
			if (!req.body.pwd) {
				return generalHelper.handleError(req, res, "Invalid Input in new password", _t.newPasswordRequired);
			}
			if (req.body.confirmPwd != req.body.pwd) {
				return generalHelper.handleError(req, res, "Passwords are not same", _t.confirmPasswordNotMatching);
			}
		} catch (e) {
			throw e;
		}
	},

	
};