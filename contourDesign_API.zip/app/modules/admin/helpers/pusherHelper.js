/**
 * Pusher Related Functions
 * @exports General/Helper/Pusher
 */

var Pusher = require('pusher');

// var _t = require('../translations/' + process.env.LANGUAGE + '/generalTrans.json');

var pusher = new Pusher({
	appId: process.env.PUSHER_APP_ID,
	key: process.env.PUSHER_APP_KEY,
	secret: process.env.PUSHER_APP_SECRET,
	cluster: process.env.PUSHER_APP_CLUSTER,
	encrypted: true
});

module.exports = {
	/**
	 * Function to send push
	 * @param {string} channelName - Channel Name
	 * @param {string} eventName - Event Name
	 * @param {string} message - Message
	 */
	sendPush: async function (channelName, eventName, message) {
		try {
			pusher.trigger(channelName, eventName, {
				"message": message
			});
		} catch (e) {
			throw e;
		}
	},

};