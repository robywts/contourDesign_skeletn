/**
 * FB Related Functions
 * @exports Admin/General/Helper/FB
 */

var FB = require('fb');
var _t = require('../translations/' + process.env.LANGUAGE + '/generalTrans.json');

FB.options({
	version: 'v2.11'
});

var fbToken = FB.api('oauth/access_token', {
	client_id: process.env.FB_APP_ID,
	client_secret: process.env.FB_APP_SECRET,
	grant_type: 'client_credentials'
});

FB.setAccessToken(fbToken.access_token);

module.exports = {
	/**
	 * Function to get the profile details using FB id
	 * @param {string} fbUserToken - Facebook User Token
	 * @returns {object} Response
	 */
	getFbProfile: async function (fbUserToken) {
		try {
			var fbResponse = await FB.api(
				'/me',
				'GET', {
					fields: 'id, name, email, first_name, last_name', // , picture.type(large), friends
					access_token: fbUserToken
				}
			);

			var response = {
				"id": fbResponse.id,
				"email": fbResponse.email,
				"firstName": fbResponse.first_name,
				"lastName": fbResponse.last_name,
				"name": fbResponse.name
			};
			return response;
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Function to get the friends who are using the same app
	 * @param {string} fbUserToken - Facebook User Token
	 * @returns {object} Response
	 */
	getFbFriendsInstalled: async function (fbUserToken) {
		try {
			var response = [];
			var fbResponse = await FB.api(
				'/me/friends',
				'GET', {
					access_token: fbUserToken,
					fields: 'id, name, email, first_name, last_name, picture, installed'
				}
			);

			// console.log(fbResponse.summary.total_count);
			for (fbFriend in fbResponse.data) {
				// console.log(fbResponse.data[fbFriend].installed);
				if (fbResponse.data[fbFriend].installed === true) {
					response.push(fbResponse.data[fbFriend].id);
					// response.push({
					// 	"id": fbResponse.data[fbFriend].id,
					// 	"name": fbResponse.data[fbFriend].name,
					// });
				}
			}
			// console.log(response);
			return response;
		} catch (e) {
			if (e.name == 'FacebookApiException') {
				return e.response;
			} else {
				throw e;
			}
		}
	},

	/**
	 * Function to get the fb profile picture path
	 * @param {string} fbUserid - Facebook User Id
	 * @returns {string} Path
	 */
	getFbPicture: function (fbUserid) {
		try {
			if (fbUserid != '') {
				return 'http://graph.facebook.com/' + fbUserid + '/picture';
			}
			return '';
		} catch (e) {
			throw e;
		}
	},
};