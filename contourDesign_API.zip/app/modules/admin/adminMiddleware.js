/**
 * Authentication in the Admin Middleware
 * @exports Admin/General/Middleware
 */
var UserModel = require('../../models/user');
var generalHelper = require('./helpers/generalHelper');
var _t = require('./translations/' + process.env.LANGUAGE + '/generalTrans.json');

module.exports = {

	/**
	 * Middleware Authentication (api auth and session auth)
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @param {Object} next - Next Object
	 */
	authentication: function (req, res, next) {
		try { //console.log(req.headers);
			if (process.env.RESTAPIKEY != req.headers['api-key']) { //checking for general api key
				generalHelper.handleError(req, res, 'API Auth Failed', _t.invalidApiKey, 1001);
			} else if (['/general/log', '/user/auth/login', '/user/auth/forgot', '/user/auth/reset'].includes(req.url)) { //routes which don't need session auth
				next();
			} else if (!req.headers['session-key'] || req.headers['session-key'] == null) {
				generalHelper.handleError(req, res, 'Session Auth Failed', _t.invalidSessionKey, 1002);
			} else { //checking for session key of user
				UserModel.findOne({
					'sessions.sessionToken': req.headers['session-key'],
					'userStatus': 1,
					'isAdmin': true
				}, '_id userId permissions', function (err, userDB) {
					if (err || userDB == null) {
						generalHelper.handleError(req, res, 'Session Auth Failed', _t.invalidSessionKey, 1002);
					} else { //successful authentication
						global.userId = userDB.userId;
						global.permissions = userDB.permissions;
						global.sessionToken = req.headers['session-key'];
						// if (req.url.match(/\/general\/ping.*/)) { // if ping request
						// 	if (req.query.module) { // if module is provided
						// 		if (req.query.module == 'D') { // allow dashboard without checking
						// 			next();
						// 		} else {
						// 			var permissions = (userDB.permissions) ? userDB.permissions : [];
						// 			if (permissions.includes(req.query.module)) { // if module id is found in the user permissions list
						// 				next();
						// 			} else {
						// 				generalHelper.handleError(req, res, 'Access Denied', _t.accessDenied, 1003);
						// 			}
						// 		}
						// 	} else { // if module is not provided
						// 		generalHelper.handleError(req, res, 'Access Denied', _t.accessDenied, 1003);
						// 	}
						// } else {
						next();
						// }
					}
				});
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	}
};