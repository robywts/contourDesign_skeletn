/**
 * Transaction Module
 * @exports Transaction/Controller
 */
var transactionService = require('../services/transactionService');
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/transactionTrans.json');
// var transactionValidation = require('../validations/transactionValidation');
var transactionDataMapper = require('../dataMappers/transactionDataMapper');
// var TransactionModel = require('../../../models/transaction');
var moment = require('moment');

module.exports = {

	/**
	 * Get all common transactiopns
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getCommonTransactions: async function (req, res) {
		try {
			var userId = (req.params.id) ? req.params.id : ''; // if user id is provided
			var search = transactionDataMapper.searchDataCommon(req.query);
			var resultDB = await transactionService.getTransactionsCommon(search, userId);
			var totalCount = await transactionService.getTransactionsCountCommon(search, userId);
			var result = transactionDataMapper.getTransactionsDataCommon(resultDB);
			var additionalData = {};
			additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, resultDB.length);
			generalHelper.handleSuccess(req, res, _t.transactionsRetrieved, result, additionalData);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get all contest transactiopns
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getContestTransactions: async function (req, res) {
		try {
			var userId = (req.params.id) ? req.params.id : ''; // if user id is provided
			var search = transactionDataMapper.searchContestTransactionsData(req.query);
			var contests = await transactionService.getContestTransactions(search, userId);
			var totalCount = await transactionService.getContestTransactionsCount(search, userId);
			var result = transactionDataMapper.getContestTransactionsData(contests);
			var additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, contests.length);
			var totalEarnings = await transactionService.transactionAmount();
			additionalData.totalEarnings = transactionDataMapper.getTransactionData(totalEarnings);
			generalHelper.handleSuccess(req, res, _t.contestTransactionsRetrieved, result, additionalData);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

};