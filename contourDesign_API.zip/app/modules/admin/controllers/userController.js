/**
 * User Module
 * @exports Admin/User/Controller
 */
var userService = require('../services/userService');
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/userTrans.json');
var userValidation = require('../validations/userValidation');
var userDataMapper = require('../dataMappers/userDataMapper');

module.exports = {

	/**
	 * Get user profile by id
	 * @param {object} req.header - Request object
	 * @param {object} res - Response object
	 */
	getProfile: async function (req, res) {
		try {
			var id = req.params.id;
			var profile = await userService.getProfile(id);
			if (profile == null) { //error
				generalHelper.handleError(req, res, {}, _t.failedGetProfile);
			} else {
				var result = userDataMapper.getProfileData(profile);
			}
			generalHelper.handleSuccess(req, res, _t.profileRetrieved, result);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get all Users
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	listUsers: async function (req, res) {
		try {
			var search = userDataMapper.searchUserData(req.query);
			var userDB = await userService.listUsers(search, global.userId);
			var totalCount = await userService.listUsersCount(search, global.userId);
			var result = userDataMapper.getUsersData(userDB);
			var additionalData = {};
			additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, userDB.length);
			generalHelper.handleSuccess(req, res, _t.usersListRetrieved, result, additionalData);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Update User status
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	updateStatus: async function (req, res) {
		try {
			if (userValidation.updateStatusValidation(req, res) != false) {
				var userProfile = userDataMapper.updateStatusData({}, req.body, req.params.id);
				var profileUpdate = await userService.updateStatus(userProfile);
				if (profileUpdate) {
					generalHelper.handleSuccess(req, res, _t.statusUpdate, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.invalidRequest);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get HtoH contests by user id
	 * @param {string} req.params.id Request object userId
	 * @param {object} res - Response object
	 */
	getHtHContest: async function (req, res) {
		try {
			var userId = req.params.id; // userDataMapper.getUserId({}, req.params.id);
			var search = userDataMapper.searchContestData(req.query);
			var userContestDB = await userService.getUserHtoHContest(search, userId);
			if (userContestDB != null) {
				var totalCount = await userService.getUserHtoHContestCount(search, userId);
				var result = userDataMapper.getUserContestsData(userContestDB);
				var additionalData = {};
				additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, userContestDB.length);
				generalHelper.handleSuccess(req, res, _t.userContestsRetrieved, result, additionalData);
			} else {
				generalHelper.handleError(req, res, {}, _t.userContestsEmpty);
			}

		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get Multiplayer contests by user id
	 * @param {string} req.query.userId Request object userId
	 * @param {object} res - Response object
	 */
	getMultiPlayerContest: async function (req, res) {
		try {
			var userId = req.params.id; // userDataMapper.getUserId({}, req.query.userId);
			var search = userDataMapper.searchContestData(req.query);
			var userContestDB = await userService.getUserMultiContest(search, userId);
			var userContestPointsDB = await userService.getUserMultiContestPoints(userContestDB, userId);
			if (userContestDB != null && userContestPointsDB != null) {
				var totalCount = await userService.getUserMultiContestCount(search, userId);
				var result = userDataMapper.getUserContestsData(userContestDB, userContestPointsDB);
				var additionalData = {};
				additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, userContestDB.length);
				generalHelper.handleSuccess(req, res, _t.userContestsRetrieved, result, additionalData);
			} else {
				generalHelper.handleError(req, res, {}, _t.userContestsEmpty);
			}

		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

};