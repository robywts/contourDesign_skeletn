/**
 * User Authentication Module
 * @exports Admin/UserAuth/Controller
 */
var UserModel = require('../../../models/user');
var userAuthService = require('../services/userAuthService');
var generalHelper = require('../helpers/generalHelper');
var bcryptHelper = require('../helpers/bcryptHelper');
var emailHelper = require('../helpers/emailHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/userAuthTrans.json');
var userAuthValidation = require('../validations/userAuthValidation');
var userAuthDataMapper = require('../dataMappers/userAuthDataMapper');

module.exports = {

	/**
	 * User Login
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	login: async function (req, res) {
		try {
			if (userAuthValidation.loginValidation(req, res) != false) {
				var userAuth = userAuthDataMapper.loginData({}, req.body);
				var user = await userAuthService.findUserByEmail(userAuth, 1);
				if (user != null) {
					if (!bcryptHelper.compare(userAuth.pwd, user.pwd)) { // password comparison
						generalHelper.handleError(req, res, 'Invalid password', _t.invalidCredentials);
					} else {
						var response = await userAuthService.updateUserSession(user.userId, userAuth);
						if (response.sessions != null) {
							response.sessions.sessionToken = response.sessions.pop().sessionToken; // get the last session
							var result = userAuthDataMapper.getOneUserData(response);
							generalHelper.handleSuccess(req, res, _t.userLogin, result);
						} else {
							generalHelper.handleError(req, res, 'Session not updated', _t.invalidRequest);
						}
					}
				} else {
					generalHelper.handleError(req, res, 'Invalid user', _t.invalidCredentials);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * User Forgot Password
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	forgot: async function (req, res) {
		try {
			if (userAuthValidation.forgotValidation(req, res) != false) {
				var userAuth = userAuthDataMapper.forgotData({}, req.body);
				var user = await userAuthService.findUserByEmail(userAuth, 1);
				if (user != null) {
					var response = await userAuthService.updateResetCode(user.userId, userAuth);
					if (response.resetCode != null) {
						emailHelper.sendMail(response.email, 'emailResetCodeSubject', './app/modules/admin/emailTemplates/resetCode.html', {
							resetCode: response.resetCode,
							name: response.userName.charAt(0).toUpperCase() + response.userName.slice(1).toLowerCase()
						}, ''); // email
						var result = userAuthDataMapper.getUserForgotData(response);
						generalHelper.handleSuccess(req, res, _t.userResetCode, result);
					} else {
						generalHelper.handleError(req, res, 'Reset code not updated', _t.invalidRequest);
					}
				} else {
					generalHelper.handleError(req, res, 'Email not exists', _t.invalidEmail);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * User Reset Password
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	reset: async function (req, res) {
		try {
			if (userAuthValidation.resetValidation(req, res) != false) {
				var userAuth = userAuthDataMapper.resetData({}, req.body);
				var user = await userAuthService.findActiveUserByResetCode(userAuth);
				if (user != null) {
					userAuth.pwd = bcryptHelper.encrypt(userAuth.pwd); //encryption
					var response = await userAuthService.resetPassword(user.userId, userAuth);
					if (response.sessions != null) {
						response.sessions.sessionToken = response.sessions.pop().sessionToken; // get the last session
						var result = userAuthDataMapper.getOneUserData(response);
						generalHelper.handleSuccess(req, res, _t.passwordReset, result);
					} else {
						generalHelper.handleError(req, res, 'password not updated', _t.invalidRequest);
					}
				} else {
					generalHelper.handleError(req, res, 'Invalid email or reset code', _t.invalidEmailOrResetCode);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * User Change Password
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	changePassword: async function (req, res) {
		try {
			if (userAuthValidation.changePasswordValidation(req, res) != false) {
				var user = await userAuthService.findActiveUserById(global.userId);
				if (user != null) {
					var userAuth = userAuthDataMapper.changePasswordData({}, req.body);
					if (!bcryptHelper.compare(userAuth.oldPwd, user.pwd)) { // password comparison
						generalHelper.handleError(req, res, 'Current password is wrong', _t.invalidOldPassword);
					} else {
						userAuth.pwd = bcryptHelper.encrypt(userAuth.pwd); // encryption
						var response = await userAuthService.changePassword(user.userId, userAuth);
						if (response.userId != null) {
							var result = userAuthDataMapper.getOneUserData(response);
							generalHelper.handleSuccess(req, res, _t.passwordChange, result);
						} else {
							generalHelper.handleError(req, res, 'password not updated', _t.invalidRequest);
						}
					}
				} else {
					generalHelper.handleError(req, res, 'Invalid user id', _t.invalidSessionKey);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * User Logout
	 * @param {object} req.headers - Request object
	 * @param {object} res - Response object
	 */
	logout: async function (req, res) {
		try {
			var response = await userAuthService.logout(global.userId, global.sessionToken);
			if (response != null) {
				generalHelper.handleSuccess(req, res, _t.userLogout, {});
			} else {
				generalHelper.handleError(req, res, 'Logout not successfull', _t.invalidRequest);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

};