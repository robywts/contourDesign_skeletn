/**
 * Static Module
 * @exports Admin/Static/Controller
 */
var staticService = require('../services/staticService');
var userService = require('../services/userService');
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/generalTrans.json');
var staticValidation = require('../validations/staticValidation');
var staticDataMapper = require('../dataMappers/staticDataMapper');
var StaticModel = require('../../../models/static');
var async = require('async');

module.exports = {

    /**
     * Get one static data by Id
     * @param {object} req.header - Request object (session data)
     * @param {object} res - Response object
     */
    getStaticData: async function (req, res) {
        try {
            var id = req.params.id;
            var data = await staticService.getStaticOne(id);
            if (data == null) { //error
                generalHelper.handleError(req, res, 'Record not found', _t.failedGetstaticData);
            } else {
                var result = staticDataMapper.getStaticDataOne(data);
                generalHelper.handleSuccess(req, res, _t.staticDataRetrieved, result);
            }
           
        } catch (e) {
            generalHelper.handleError(req, res, e.stack, _t.technicalError);
        }
    },

    /**
     * Update static data
     * @param {object} req.body - Request object
     * @param {object} res - Response object
     */
    updateStaticData: async function (req, res) {
        try {
            if (staticValidation.updateStaticDataValidation(req, res) != false) {
                var StaticModelDB = new StaticModel();
                var userDB = await userService.getProfile();
                var staticData = staticDataMapper.updateStaticData(StaticModelDB, req.body, userDB);
                var id = req.params.id;
                var staticDataUpdate = await staticService.updateStaticData(staticData, id);
                if (staticDataUpdate) {
                    generalHelper.handleSuccess(req, res, _t.staticDataUpdate, {});
                } else {
                    generalHelper.handleError(req, res, {}, _t.invalidRequest);
                }
            }
        } catch (e) {
            generalHelper.handleError(req, res, e.stack, _t.technicalError);
        }
    },

    /**
     * Get static data list
     * @param {object} req.query - Request object with request parameters
     * @param {object} res - Response object
     */
    getStaticDataList: async function (req, res) {
        try {
            var search = staticDataMapper.searchData(req.query); 
            var staticDB = await staticService.listStaticData(search);
            var totalCount = await staticService.StaticDataCount();
            var result = staticDataMapper.getStaticData(staticDB);
            var additionalData = {};
            additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, staticDB.length);
            generalHelper.handleSuccess(req, res, _t.staticDataListRetrieved, result, additionalData);
        } catch (e) {
            generalHelper.handleError(req, res, e.stack, _t.technicalError);
        }
    },

};