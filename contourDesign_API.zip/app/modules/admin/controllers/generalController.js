/**
 * General Module (Admin)
 * @exports Admin/General/Controller
 */

var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/generalTrans.json');


module.exports = {
	/**
	 * Ping
	 * @param {object} req - Request object
	 * @param {object} res - Response object
	 */
	ping: function (req, res) {
		try {
			generalHelper.handleSuccess(req, res, _t.authSuccess, {});
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Logger
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	log: function (req, res) {
		try {
			generalHelper.wsLogger(req, '', [req.body], 'ClientError');
			generalHelper.handleSuccess(req, res, _t.logSuccess, {});
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	
	/**
	 * Dummy Post
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	dummySave: function (req, res) {
		try {
			var msg = 'Unknown Method';
			if (req.method == "POST") {
				msg = 'Data Added Successfully';
			} else if (req.method == "PUT") {
				msg = 'Data Updated Successfully';
			} else if (req.method == "DELETE") {
				msg = 'Data Deleted Successfully';
			}
			// generalHelper.handleError(req, res, 'Test error', _t.technicalError);
			console.log(req.body);
			generalHelper.handleSuccess(req, res, msg, req.body);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

};