/**
 * Setting Module
 * @exports Admin/Setting/Controller
 */
var settingService = require('../services/settingService');
var userService = require('../services/userService');
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/generalTrans.json');
var settingValidation = require('../validations/settingValidation');
var settingDataMapper = require('../dataMappers/settingDataMapper');
// var SettingModel = require('../../../models/setting');
// var async = require('async');

module.exports = {

    /**
     * Get settings data
     * @param {object} req.header - Request object (session data)
     * @param {object} res - Response object
     */
    getSettings: async function (req, res) {
        try {
            var data = await settingService.getSettings();
            if (data == null) { // error
                generalHelper.handleError(req, res, 'Record not found', _t.failedGetsettingData);
            } else {
                var result = settingDataMapper.getSettingData(data);
                generalHelper.handleSuccess(req, res, _t.settingDataRetrieved, result);
            }
        } catch (e) {
            generalHelper.handleError(req, res, e.stack, _t.technicalError);
        }
    },

    /**
     * Update setting data
     * @param {object} req.body - Request object
     * @param {object} res - Response object
     */
    updateSettings: async function (req, res) {
        try {
            if (settingValidation.updateSettingDataValidation(req, res) != false) {
                var SettingModelDB = {} ; // new SettingModel();
                var userDB = await userService.getProfile();
                var settingData = settingDataMapper.updateSettingData(SettingModelDB, req.body, userDB);
                var settingDataUpdate = await settingService.updateSettingData(settingData);
                if (settingDataUpdate) {
                    generalHelper.handleSuccess(req, res, _t.settingDataUpdate, {});
                } else {
                    generalHelper.handleError(req, res, {}, _t.invalidRequest);
                }
            }
        } catch (e) {
            generalHelper.handleError(req, res, e.stack, _t.technicalError);
        }
    },

};