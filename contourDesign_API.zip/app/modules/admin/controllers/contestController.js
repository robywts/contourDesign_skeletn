/**
 * Contest Module
 * @exports Admin/Contest/Contorller
 */
var contestService = require('../services/contestService');
var userService = require('../services/userService');
var lineUpService = require('../services/lineUpService');
var draftGroupService = require('../services/draftGroupService');
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/contestTrans.json');
var contestValidation = require('../validations/contestValidation');
var contestDataMapper = require('../dataMappers/contestDataMapper');
var ContestModel = require('../../../models/contest');
var Pusher = require('../helpers/pusherHelper');

module.exports = {

	/**
	 * Get all contests
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 * @throws {object} e - Error
	 */
	getAll: async function (req, res) {
		try {
			var search = contestDataMapper.searchData(req.query);
			var contests = await contestService.getAll(search);
			var totalCount = await contestService.getAllCount(search, contests);
			var result = contestDataMapper.getAllData(contests);
			var additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, contests.length);
			generalHelper.handleSuccess(req, res, _t.contestRetrieved, result, additionalData);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get one contest by id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getOneH2H: async function (req, res) {
		try {

			// var userService = require('../services/userService');
			var contest = await contestService.getOneContest(req.params.id);
			var profile1Id = contest.createdBy;
			if (contest.entrants[1] != null) {
				if (contest.entrants[1].userId != contest.createdBy) {
					profile1Id = contest.entrants[1].userId;
				} else {
					profile1Id = contest.entrants[0].userId;
				}
			}
			var profile1 = await userService.getProfile(profile1Id);
			var profile = await userService.getProfile(contest.createdBy);
			var lineUp1 = await lineUpService.getLineupDetails(req.params.id, profile1Id, contest.createdBy);


			var draftGroup = await draftGroupService.getDraftGroupDetails(contest.draftgroupId);
			var dgName='';
			if(draftGroup != null)
			var dgName = draftGroup.dgName ? draftGroup.dgName : '';
			if (contest == null) {
				generalHelper.handleError(req, res, 'Record not found', _t.failedGetContest);
			} else {
				var result = contestDataMapper.getOneContestData(contest, profile, profile1, dgName, lineUp1);
				generalHelper.handleSuccess(req, res, _t.contestRetrieved, result);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get one multiplayer contest by id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getOnemultiplayer: async function (req, res) {
		try {
			// var userService = require('../services/userService');
			var contest = await contestService.getOneContest(req.params.id);
			if (contest == null) {
				generalHelper.handleError(req, res, 'Record not found', _t.failedGetContest);
			} else {
				var profile = await userService.getProfile(contest.createdBy);
				var draftGroup = await draftGroupService.getDraftGroupDetails(contest.draftgroupId);
	
				//var dgName = draftGroup.dgName ? draftGroup.dgName : '';
				if (draftGroup === null) {
					var dgName = '';
				} else {
					var dgName = draftGroup.dgName;
				}
				var result = contestDataMapper.getOnemultiplayerContestData(contest, profile, dgName);
				generalHelper.handleSuccess(req, res, _t.contestRetrieved, result);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get Contest by id (for Form)
	 * @param {object} req.header - Request object (session data)
	 * @param {object} res - Response object
	 */
	getOneFormContest: async function (req, res) {
		try {
			var resultDB = await contestService.getOneFormContest(req.params.id);
			if (resultDB == null) { //error
				generalHelper.handleError(req, res, {}, _t.failedGetContest);
			} else {
				var result = contestDataMapper.getOneFormContestData(resultDB);
			}
			generalHelper.handleSuccess(req, res, _t.contestRetrieved, result);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Add a contest
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	// add: async function (req, res) {
	// 	try {
	// 		if (contestValidation.addValidation(req, res) != false) {
	// 			var ContestModel = require('../../../models/contest');
	// 			var contestModel = new ContestModel();
	// 			contestModel.contestId = await generalHelper.updateCounter('contestId'); //unique key
	// 			if (contestModel.contestId != null) {
	// 				contestModel = contestDataMapper.addData(contestModel, req.body);
	// 				var response = await contestService.add(contestModel);
	// 				if (response._id != null) {
	// 					generalHelper.handleSuccess(req, res, _t.contestAdded, {
	// 						'id': response._id,
	// 						'contestId': response.contestId
	// 					});
	// 				} else {
	// 					generalHelper.handleError(req, res, 'Add record failed', _t.failedAddContest);
	// 				}
	// 			} else {
	// 				generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddContest);
	// 			}
	// 		}
	// 	} catch (e) {
	// 		generalHelper.handleError(req, res, e.stack, _t.technicalError);
	// 	}
	// },


	/**
	 * Update a contest
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	// update: async function (req, res) {
	// 	try {
	// 		if (contestValidation.editValidation(req, res) != false) {
	// 			var contest = await contestService.getOne(req.params.id);
	// 			if (contest == null) {
	// 				generalHelper.handleError(req, res, 'Record not found', _t.failedGetContest);
	// 			} else {
	// 				contest = contestDataMapper.editData(contest, req.body);
	// 				var response = await contestService.update(req.params.id, contest);
	// 				if (response.n == 1) {
	// 					generalHelper.handleSuccess(req, res, _t.contestUpdated, {});
	// 				} else {
	// 					generalHelper.handleError(req, res, 'Update record not found', _t.failedUpdateContest);
	// 				}
	// 			}
	// 		}
	// 	} catch (e) {
	// 		generalHelper.handleError(req, res, e.stack, _t.technicalError);
	// 	}
	// },

	/**
	 * Add Contest
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	addContest: async function (req, res) {
		try {
			// var userService = require('../services/userService');
			if (contestValidation.addValidation(req, res) != false) {
				var contestCreated = [];
				var profile = await userService.getProfile(global.userId);
				var reqData = contestDataMapper.addData({}, req.body, profile);
				var contest = await contestService.findContest(reqData);
				//if (contest == null) { //can add record
					var newRecord = new ContestModel();
					newRecord.contestId = await generalHelper.updateCounter('contestId'); // unique key
					var draftGroupDetailsDB = await draftGroupService.getDraftGroupDetails(req.body.draftgroupId);
					if (newRecord.contestId != null) {
						newRecord = contestDataMapper.addData(newRecord, req.body, profile, draftGroupDetailsDB.startTimeUTC);
						var response = await contestService.addContest(newRecord);
						if (response._id != null) {
							var result = contestDataMapper.getOneFormContestData(response);							
							    contestCreated.push(response);
								contest = contestDataMapper.getUserCreatedContest(contestCreated);
								if (profile != null) {
									contest.username = profile.userName ? profile.userName : '';									
									contest.imageName = '';
								}
							//pushing newly created contest
							Pusher.sendPush('draftgroup-channel', 'draftgroup-' + req.body.draftgroupId, contest);
							generalHelper.handleSuccess(req, res, _t.contestAdded, result);
						} else {
							generalHelper.handleError(req, res, 'Addition failed', _t.failedAddContest);
						}
					} else {
						generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddContest);
					}
				/*} else { // record existing
					if (contest.contestName == reqData.contestName) {
						generalHelper.handleError(req, res, 'Record exists', _t.contestExists);
					}
				}*/
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Update Contest
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	updateContest: async function (req, res) {
		try {
			if (contestValidation.updateValidation(req, res) != false) {
				var draftGroupDetailsDB = await draftGroupService.getDraftGroupDetails(req.body.draftgroupId);
				var reqData = contestDataMapper.updateData({}, req.body, draftGroupDetailsDB.startTimeUTC);
				var contest = await contestService.findContest(reqData, req.params.id);
				//if (contest == null) { //can update record
					var result = await contestService.updateContest(reqData, req.params.id);
					if (result) {
						generalHelper.handleSuccess(req, res, _t.contestUpdated, {});
					} else {
						generalHelper.handleError(req, res, {}, _t.invalidRequest);
					}
				/*} else { // record existing
					if (contest.contestName == reqData.contestName) {
						generalHelper.handleError(req, res, 'Record exists', _t.contestExists);
					}
				}*/
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Delete a contest
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	delete: async function (req, res) {
		try {
			var response = await contestService.delete(req.params.id);
			if (response.result.n == 1) {
				generalHelper.handleSuccess(req, res, _t.contestDeleted, {});
			} else {
				generalHelper.handleError(req, res, 'Delete record not found', _t.failedDeleteContest);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get HtoH contests
	 * @param {string} req.query.userId Request object userId
	 * @param {object} res - Response object
	 */
	getHtHContest: async function (req, res) {
		try {
			var search = contestDataMapper.getMultiSearchData(req.query);
			var userContestDB = await contestService.getUserHtoHContest(search, req.query.sportId);
			if (userContestDB != null) {
				var totalCount = await contestService.getUserHtoHContestAll(search, req.query.sportId);
				var result = contestDataMapper.getContestsData(userContestDB);
				var additionalData = {};
				additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, userContestDB.length);
				generalHelper.handleSuccess(req, res, _t.userContestsRetrieved, result, additionalData);
			} else {
				generalHelper.handleError(req, res, {}, _t.userContestsEmpty);
			}

		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get Multiplayer contests
	 * @param {string} req.query.userId Request object userId
	 * @param {object} res - Response object
	 */
	getMultiPlayerContest: async function (req, res) {
		try {
			var search = contestDataMapper.getMultiSearchData(req.query);
			var userContestDB = await contestService.getUserMultiContest(search, req.query.sportId);
			if (userContestDB != null) {
				var totalCount = await contestService.getUserMultiContestCount(search, req.query.sportId);
				var result = contestDataMapper.getContestsData(userContestDB);
				var additionalData = {};
				additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, userContestDB.length);
				generalHelper.handleSuccess(req, res, _t.userContestsRetrieved, result, additionalData);
			} else {
				generalHelper.handleError(req, res, {}, _t.userContestsEmpty);
			}

		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get lineups list by contest id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getLineUp: async function (req, res) {
		try {
			if (contestValidation.getValidation(req, res) != false) {
				contestMapData = contestDataMapper.contestData(req.params.id);
				var contestLineUpsDB = await lineUpService.getContestLineups(contestMapData);
				if (contestLineUpsDB != null) {
					result = contestDataMapper.contestLineUpsResultMap(contestLineUpsDB);
					generalHelper.handleSuccess(req, res, _t.contestLineupsRetrieved, result, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.contestLineupsEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get one contest's games by id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getMultiGames: async function (req, res) {
		try {
			if (contestValidation.getValidation(req, res) != false) {
				contestId = contestDataMapper.gamesData(req.params.id);
				//var search = contestDataMapper.searchData(req.query);
				var contestDB = await contestService.getOneContest(contestId);
				var contestGames = [];
				if (contestDB)
					contestGames = await draftGroupService.getDraftgroupGames(contestDB.draftgroupId);
				if (contestGames.length < 1 || contestDB == null) {
					generalHelper.handleError(req, res, 'Record not found', _t.failedGetContestGames);
				} else {
					var result = contestDataMapper.getGamesData(contestGames, contestDB, contestDB.draftgroupId);;
					generalHelper.handleSuccess(req, res, _t.contestGamesRetrieved, result, {});
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get standings in a contest
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 * @throws {object} e - Error
	 */
	getContestStandings: async function (req, res) {
		try {
			if (contestValidation.getStandingsValidation(req, res) != false) {
				contestMapData = contestDataMapper.contestData(req.params.id);
				var search = contestDataMapper.standingsSearchData(req.query);
				var contestStandings = await lineUpService.getUserContestStandings(contestMapData, search);
				if (contestStandings == null) {
					generalHelper.handleError(req, res, 'Record not found', _t.failedGetContestStandings);
				} else {
					var totalCount = await lineUpService.getAllCountContUser(contestMapData, search);
					var userIds = [];
					for (var i in contestStandings) {
						userIds.push(contestStandings[i].userId);
					}
					var usersDb = await userService.getUsersByIds(userIds);
					var result = contestDataMapper.getStandingData(contestStandings, contestMapData, usersDb);
					var additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, contestStandings.length);
					generalHelper.handleSuccess(req, res, _t.contestStandingsRetrieved, result, additionalData);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get Lineup Details By lineup id
	 * @param {string} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	getLineUpById: async function (req, res) {
		try {
			if (contestValidation.getLineUpValidation(req, res) != false) {
				LineUpMapData = contestDataMapper.LineUpData(req.params.id);
				var lineUpDB = await lineUpService.getLineup(LineUpMapData);
				if (lineUpDB) {
					result = contestDataMapper.lineUpResultMap(lineUpDB);
					generalHelper.handleSuccess(req, res, _t.lineUpRetrieved, result, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.lineUpEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get contests to be refunded.
	 * @param {string} req.query.userId Request object userId
	 * @param {object} res - Response object
	 */
	getContestToBeRefunded: async function (req, res) {
		try {
			var search = contestDataMapper.getMultiSearchData(req.query);			
			var userContestDB = await contestService.getAllContestToBeRefunded(search, req.query.sportId);
			if (userContestDB != null) {
				var totalCount = await contestService.getRefundedContestsCount(search, req.query.sportId);
				var result = contestDataMapper.getContestsData(userContestDB);
				var additionalData = {};
				additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, userContestDB.length);
				generalHelper.handleSuccess(req, res, _t.userRefundContestsRetrieved, result, additionalData);
			} else {
				generalHelper.handleError(req, res, {}, _t.userRefundContestsEmpty);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Refund contest by id
	 * @param {string} req.param.id Request object (id of the contest)
	 * @param {object} res - Response object
	 */
	refundContest: async function (req, res) {
		try {			
			var contest = await contestService.getRefundContest(req.params.id);			
			if(contest !== null)
			{
				var entrantsContest = contest.entrants;
                    if (entrantsContest.length > 0) {
                        for (var i = 0; i < entrantsContest.length; i++) {							
							var numOfEntry = (entrantsContest[i].totalentry == 0) ? 1 : entrantsContest[i].totalentry;							
							var totalFees = numOfEntry * contest.entryFees;											
							var result = await contestService.refundAmount(entrantsContest[i].userId, totalFees);
						}
						
						if(result)
						{
							var response = await contestService.updateContestStatus(contest.contestId);
							if (response) {
								generalHelper.handleSuccess(req, res, _t.refundSuccess, {});								
							} else {					
								generalHelper.handleError(req, res, {}, _t.failedToRefundContest);
							}
						}
					}				
			}else {
				generalHelper.handleError(req, res, {}, _t.userRefundContestsEmpty);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},
	

};