/**
 * Dashboard Module
 * @exports Dashboard/Controller
 */
var dashboardService = require('../services/dashboardService');
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/generalTrans.json');
var dashboardDataMapper = require('../dataMappers/dashboardDataMapper');

module.exports = {

	/**
	 * Get all dashboard content
	 * @param {object} req.query - Request object
	 * @param {object} res - Response object
	 */
	getDashboard: async function (req, res) {
		try {
			var users = false;
			var clans = false;
			var contests = false;
			var withdrawals = false;
			var transactions = false;

			if (global.permissions.includes("U") === true) {
				var userData = await dashboardService.userCount();
				users = dashboardDataMapper.getUserData(userData);
			}

			if (global.permissions.includes("CL") === true) {
				var clanData = await dashboardService.clanCount();
				clans = dashboardDataMapper.getClanData(clanData);
			}

			if (global.permissions.includes("MPC") === true || global.permissions.includes("HC") === true) {
				var contestData = await dashboardService.contestCount();
				contests = dashboardDataMapper.getContestData(contestData);
				if (global.permissions.includes("MPC") !== true) {
					contests.multi = false;
				}
				if (global.permissions.includes("HC") !== true) {
					contests.h2h = false;
				}
			}

			if (global.permissions.includes("WR") === true) {
				var withdrawalData = await dashboardService.withdrawalCount();
				withdrawals = dashboardDataMapper.getWithdrawalData(withdrawalData);
			}

			if (global.permissions.includes("TH") === true) {
				var transactionData = await dashboardService.transactionAmount();
				transactions = dashboardDataMapper.getTransactionData(transactionData);
			}

			var additionalData = {};
			generalHelper.handleSuccess(req, res, _t.dashboardRetrieved, {
				users,
				clans,
				contests,
				withdrawals,
				transactions
			}, additionalData);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

};