/**
 * DraftGroup Module
 * @exports DraftGroup/Controller
 */
var draftGroupService = require('../services/draftGroupService');
var contestService = require('../services/contestService');
var lineUpService = require('../services/lineUpService');
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/draftGroupTrans.json');
var darftGroupValidation = require('../validations/draftGroupValidation');
var draftGroupDataMapper = require('../dataMappers/draftGroupDataMapper');
var lineupTemplateService = require('../services/lineUpTemplateService');
var async = require('async');
var moment = require('moment');

module.exports = {

	/**
	 * Get all DraftGroups for Dropdown
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getDraftGroupsDD: async function (req, res) {
		try {
			var sportsId = (req.params.id) ? req.params.id : 1;
			var resultDB = await draftGroupService.getDraftGroupsDD(sportsId);
			var result = draftGroupDataMapper.getDraftGroupsDDData(resultDB);
			var additionalData = {};
			generalHelper.handleSuccess(req, res, _t.draftGroupsRetrieved, result, additionalData);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get DraftGroup List
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getDraftGroupList: async function (req, res) {
		try {
			if (darftGroupValidation.listDraftValidation(req, res) != false) {
				draftGroupMapData = draftGroupDataMapper.draftListData({}, req.query);
				var draftGroupDB = await draftGroupService.getDraftGroup(draftGroupMapData);
				// var lineuptemplates = await lineupTemplateService.getAllLineUpTemplate();
				if (draftGroupDB.length > 0) {
					//result = draftGroupDataMapper.draftGroupResultMap(draftGroupDB, lineuptemplates);
					result = draftGroupDataMapper.draftGroupResultList(draftGroupDB);
					generalHelper.handleSuccess(req, res, _t.draftGroupRetrieved, result, {});

				} else {
					if(draftGroupMapData.sportId==1) {
					generalHelper.handleError(req, res, {}, _t.draftGroupEmpty);}
					else {generalHelper.handleError(req, res, {}, _t.draftGroupEmptyDay);}
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get one draftgroup by id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getDraftGroupDetails: async function (req, res) {
		try {
			if (darftGroupValidation.DraftgroupIdValidation(req, res) != false) {
				draftDetailsMapData = draftGroupDataMapper.draftDetailsData(req.params.id);
				var draftGroupDetailsDB = await draftGroupService.getDraftGroupDetails(draftDetailsMapData);
				if (draftGroupDetailsDB != null) {
					result = draftGroupDataMapper.draftGroupDetailsResultMap(draftGroupDetailsDB);
					generalHelper.handleSuccess(req, res, _t.draftGroupDetailsRetrieved, result, {});

				} else {
					generalHelper.handleError(req, res, {}, _t.draftGroupDetailsEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get contest list by draftgroup id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getDraftGroupContestDetails: async function (req, res) {
		try {
			if (darftGroupValidation.DraftgroupIdValidation(req, res) != false) {
				draftDetailsMapData = draftGroupDataMapper.draftDetailsData(req.params.id);
				var draftGroupDetailsDB = await draftGroupService.getDraftGroupContest(draftDetailsMapData);
				if (draftGroupDetailsDB != null) {
					var draftGroupContestDetailsDB = await contestService.getDraftGroupContestDetails(draftGroupDetailsDB);
					result = draftGroupDataMapper.draftGroupContestResultMap(draftGroupContestDetailsDB);
					generalHelper.handleSuccess(req, res, _t.draftGroupContestRetrieved, result, {});

				} else {
					generalHelper.handleError(req, res, {}, _t.draftGroupContestEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get players list by draftgroup id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getAllPlayer: async function (req, res) {
		try {
			if (darftGroupValidation.DraftgroupIdValidation(req, res) != false) {
				draftPlayersMapData = draftGroupDataMapper.draftDetailsData(req.params.id);
				var search = draftGroupDataMapper.searchData(req.query);
				var draftGroupPlayersDB = await draftGroupService.getDraftGroupPlayers(draftPlayersMapData);
				if (draftGroupPlayersDB != null) {
					result = draftGroupDataMapper.draftGroupPlayersResultMap(draftGroupPlayersDB);
					//pagination after mapping
					resultPaginated = generalHelper.paginateArray(result, +search.limit, +search.page);
					var totalCount = result.length;
					var additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, resultPaginated.length);
					generalHelper.handleSuccess(req, res, _t.draftGroupPlayersRetrieved, resultPaginated, additionalData);
				} else {
					generalHelper.handleError(req, res, {}, _t.draftGroupPlayersEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},


	/**
	 * Get lineups list by draftgroup id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getLineUp: async function (req, res) {
		try {
			if (darftGroupValidation.DraftgroupIdValidation(req, res) != false) {
				draftLineUpMapData = draftGroupDataMapper.draftDetailsData(req.params.id);
				var draftGroupLineUpsDB = await lineUpService.getDraftGroupLineups(draftLineUpMapData);
				if (draftGroupLineUpsDB != null) {
					result = draftGroupDataMapper.draftGroupLineUpsResultMap(draftGroupLineUpsDB);
					generalHelper.handleSuccess(req, res, _t.draftGroupLineupsRetrieved, result, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.draftGroupLineupsEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get DraftGroup Weeks
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getDraftGroupWeeks: async function (req, res) {
		try {
			if (darftGroupValidation.DraftGroupWeeksValidation(req, res) != false) {
				draftGroupWeekMapData = draftGroupDataMapper.draftGroupWeekMapData({}, req.params);
				if (draftGroupWeekMapData.sportId == 1) {
					var resultSet = (await draftGroupService.getDraftGroupWeek(draftGroupWeekMapData)).map(a => a.week);
				} else if (draftGroupWeekMapData.sportId == 4 || draftGroupWeekMapData.sportId == 2 ) {
					var resultSet = (await draftGroupService.getDraftGroupDayNBA(draftGroupWeekMapData)).map(a => a.week);
				}
				var weeks = [];
				for (var i in resultSet) {
					var weekDuration = await draftGroupService.getWeekDuration(draftGroupWeekMapData, resultSet[i]);
					var row = {};
					row.weekId = resultSet[i];
					if (draftGroupWeekMapData.sportId == 1) {
						row.weekName = "WEEK " + resultSet[i];
					} else if (draftGroupWeekMapData.sportId == 4 || draftGroupWeekMapData.sportId == 2) {
						var datee = resultSet[i].toString();
						var yr = datee.slice(0, 4);
						var mnth = datee.slice(4, 6);
						var day = datee.slice(6, 8);
						var dateEvnt = yr + '-' + mnth + '-' + day;
						//console.log(dateEvnt);process.exit();
						row.weekName = moment(dateEvnt).format('MMMM DD, ddd')
					} else {
						row.weekName = ''
					}
					if (weekDuration.length > 0) {

						if (draftGroupWeekMapData.sportId == 1) { var dtFormat= "MM/DD/YYYY"; } else { var dtFormat= "ddd h:mm a"; }
						row.weekDuration = (weekDuration[0].min) ? moment(weekDuration[0].min, 'UTC').tz('EST').format(dtFormat) : '';
						if (weekDuration[0].min.toString() !== weekDuration[0].max.toString()) {
							row.weekDuration += " to " + moment(weekDuration[0].max, 'UTC').tz('EST').format(dtFormat);
						}
					} else {
						row.weekDuration = '';
					}
					row.draftGroupCount = 1;
					weeks.push(row);
				}
				if (weeks.length > 0) {
					//result = draftGroupDataMapper.draftGroupWeekResultMap(draftGroupDB, {});
					result = weeks;
					generalHelper.handleSuccess(req, res, _t.weekRetrieved, result, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.weektEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get Games  List
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getGameslist: async function (req, res) {
		try {
			if (darftGroupValidation.listDraftValidation(req, res) != false) {
				draftGroupMapData = draftGroupDataMapper.draftListData({}, req.query);
				var draftGroupDB = await draftGroupService.getGamesList(draftGroupMapData);
				if (draftGroupDB.length > 0) {
					result = draftGroupDataMapper.draftGroupGameListMap(draftGroupDB);
					generalHelper.handleSuccess(req, res, _t.draftGroupgamesRetrieved, result, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.gameListEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * create a draftgroup
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	cretae: async function (req, res) {
		try {
			if (darftGroupValidation.addValidation(req, res) != false) {
				var DraftGroupModel = require('../../../models/draftgroup');
				var darftGroupModel = new DraftGroupModel();
				darftGroupModel.draftgroupId = await generalHelper.updateCounter('draftgroupId'); //unique key
				if (darftGroupModel.draftgroupId != null) {
					var eventIds = draftGroupDataMapper.eventIds({}, req.body);
					var eventDB = await draftGroupService.getEventsList(eventIds);
					//	var eventDBData = await draftGroupService.getAllEventsList(eventDB);
					gameList = [];
					//	async.eachSeries(eventDB, async function (event, outCb) {						

						var minDate = new Date(Math.min.apply(null, eventDB.map(function(e) {
							return new Date(e.startTimeUTC);
						  })));						
					for (var i in eventDB) {
						daraftgroups = [];
						eventDB[i];
						game = {};
						game['eventId'] = eventDB[i].eventId;
						game['startTimeUTC'] = eventDB[i].startTimeUTC;
						game['gameStatus'] = '';
						//game player details
						players = [];
						//home team details
						homeTeamId = eventDB[i].homeTeam.teamId;
						awayTeamId = eventDB[i].awayTeam.teamId;
						playersDatas = [];
						var playersDatasHome = await draftGroupService.getHomePlayers(homeTeamId);
						var playersDatasAway = await draftGroupService.getAwayPlayers(awayTeamId);
						playersDatas = playersDatasHome.concat(playersDatasAway);
						if (playersDatas) {
							playersDatas.forEach(function (playersData) {
								var teamPlayers = {};
								teamPlayers.fName = playersData.fName;
								teamPlayers.lName = playersData.lName;
								teamPlayers.playerId = playersData.playerId;
								teamPlayers.posId = playersData.positions[0].posId;
								teamPlayers.posGen = playersData.positions[0].posGen;
								teamPlayers.posAbbr = playersData.positions[0].posAbbr;
								teamPlayers.CapValue = playersData.fanProjSalary;
								teamPlayers.isInjured = playersData.isInjured;
								competitionPlayer = {};
								competitionPlayer.compId = eventDB[i].eventId;
								competitionPlayer.nameDisplay = [{
									htAbbr: eventDB[i].homeTeam.tAbbr,
									htName: eventDB[i].homeTeam.tName,
									htScore: '',
									value: eventDB[i].awayTeam.tAbbr+ '@' + eventDB[i].homeTeam.tAbbr,
									atAbbr: eventDB[i].awayTeam.tAbbr,
									atName: eventDB[i].awayTeam.tName,
									atScore: ''
								}];

								teamPlayers.competition = competitionPlayer;
								teamPlayers.teamId = playersData.team.teamId;
								teamPlayers.teamAbbr = playersData.team.tAbbr;
								teamPlayers.fanProjSalary = playersData.fanProjSalary;
								teamPlayers.fanProjScore = playersData.fanProjPoints;
								players.push(teamPlayers);
							});
						}
						game['players'] = players;
						//away team details
						//awayTeamId = event.awayTeam.teamId
						League = {};
						League.leagueId = eventDB[i].league.leagueId;
						League.name = eventDB[i].league.name;
						League.abbr = eventDB[i].league.abbr;
						leagues = [];
						leagues.push(League);

						/*   var draftData = {
                            draftgroupId: await generalHelper.updateCounter('draftgroupId'),
                            week: event.week,
                            season: event.season,
                            sportId: event.sportId,
                            // sName: event.league.abbr,
                            league: leagues,
                            contestList: [],
                            sortOrder: 0,
                            startTimeUTC: '',
                            dgState: 'Upcoming',
                            gameList: [game]
						};   */

						//console.log('********');console.log(draftData.gameList[0].players[0]); process.exit();

						/* async.eachSeries(daraftgroups, async function (daraftgroup, innerCb) {
                            draftData.dgName = daraftgroup;
                            //console.log(draftData.dgName);process.exit();
                            checkExistDraft = await self.checkDraft(draftData);
                            if (!checkExistDraft) {
                                // console.log('insert');
                                draftInsert = await self.insertDraft(draftData);
                            } else {
                                // console.log('push');
                                checkEventExistIndraftGroup = await self.checkEventInDraft(draftData);
                           
                                if (checkEventExistIndraftGroup.gameList.length < 1) {
                                    //console.log('pushInsert');
                                    draftUpdate = await self.updateDraft(draftData);
                                }
                            }
                            innerCb(null);
                        });
						//}*/
						gameList.push(game);
						//  outCb(null);
						//});  
					}
                    
					darftGroupModel = draftGroupDataMapper.addData(darftGroupModel, req.body, gameList, leagues, minDate);
					var response = await draftGroupService.add(darftGroupModel);
					if (response._id != null) {						
						//Mvalue calculation starts here
						//To get max and min fantasy player positions			
						if (gameList != null && (darftGroupModel.sportId == 4 || darftGroupModel.sportId == 3  || darftGroupModel.sportId == 2)) {
                            //To get max and min fantasy player positions
							var minmax = await draftGroupService.getMinMaxNBA(darftGroupModel.draftgroupId);							
                            var gamesList = gameList;
                            for (var k = 0, len = gamesList.length; k < len; k++) {
                               // console.log(darftGroupModel.draftgroupId);
                                if (gamesList[k].players != null) {
                                    for (var j in gamesList[k].players) {
                                        for (var i in minmax) {
                                            if (minmax[i]._id == gamesList[k].players[j].posGen) {
                                                //setting min salary for player if 0
                                                var playerSalary = (gamesList[k].players[j].fanProjSalary == 0) ?  minmax[i].min : gamesList[k].players[j].fanProjSalary;
                                                mValue = await Math.round((1 + ((playerSalary - minmax[i].max) * (2 - 1)) / (minmax[i].min - minmax[i].max)) * 20) / 20;
                                                //updating mValue draftgroup schema
                                                var field = {};
                                                field["gameList.$.players." + j + ".mValue"] = mValue;                              
										     	var updateM = await draftGroupService.updateMvalue(darftGroupModel.draftgroupId, gamesList[k].players[j].playerId, field);
                                            };
                                        }
                                    }
                                }
                            }
						} 
						
						if (gameList != null && darftGroupModel.sportId != 4 && darftGroupModel.sportId != 3 && darftGroupModel.sportId != 2) {
                            //To get max and min fantasy player positions
							var minmax = await draftGroupService.getMinMaxNFL(darftGroupModel.draftgroupId);							
                            var gamesList = gameList;
                            for (var k = 0, len = gamesList.length; k < len; k++) {
                               // console.log(darftGroupModel.draftgroupId);
							   if (gamesList[k].players != null) {
								for (var j in gamesList[k].players) {
									for (var i in minmax) {
										if (minmax[i]._id == gamesList[k].players[j].posAbbr) {
											var playerSalary = (gamesList[k].players[j].fanProjSalary == 0) ? minmax[i].min : gamesList[k].players[j].fanProjSalary;
											mValue = await Math.round((1 + ((playerSalary - minmax[i].max) * (2 - 1)) / (minmax[i].min - minmax[i].max)) * 20) / 20;
											//updating mValue draftgroup schema
											var field = {};
											field["gameList.$.players." + j + ".mValue"] = mValue;
											var updateM = await draftGroupService.updateMvalue(darftGroupModel.draftgroupId, gamesList[k].players[j].playerId, field);
										};
									}
								}
							}
                            }
                        } 
						//Mvalue calculation ends here
						generalHelper.handleSuccess(req, res, _t.draftGrouptAdded, {
							'id': response._id,
							'draftgroupId': response.draftgroupId
						});
					} else {
						generalHelper.handleError(req, res, 'Add record failed', _t.failedAddDraftGroup);
					}
				} else {
					generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddDraftGroup);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * update a draftgroup
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	update: async function (req, res) {
		try {
			if (darftGroupValidation.updateValidation(req, res) != false) {
				var DraftGroupModel = require('../../../models/draftgroup');
				//	var darftGroupModel = new DraftGroupModel();
				var draftgroupId = draftDetailsMapData = draftGroupDataMapper.draftDetailsData(req.params.id);
				if (draftgroupId != null) {
					var eventIds = draftGroupDataMapper.eventIds({}, req.body);
					var eventDB = await draftGroupService.getEventsList(eventIds);
					//	var eventDBData = await draftGroupService.getAllEventsList(eventDB);

					var minDate = new Date(Math.min.apply(null, eventDB.map(function(e) {
						return new Date(e.startTimeUTC);
					  })));
					gameList = [];
					leagues = [];
					//	async.eachSeries(eventDB, async function (event, outCb) {
					for (var i in eventDB) {
						daraftgroups = [];
						eventDB[i];
						game = {};
						game['eventId'] = eventDB[i].eventId;
						game['startTimeUTC'] = eventDB[i].startTimeUTC;
						game['gameStatus'] = '';
						players = [];
						homeTeamId = eventDB[i].homeTeam.teamId;
						awayTeamId = eventDB[i].awayTeam.teamId;
						playersDatas = [];
						var playersDatasHome = await draftGroupService.getHomePlayers(homeTeamId);
						var playersDatasAway = await draftGroupService.getAwayPlayers(awayTeamId);
						playersDatas = playersDatasHome.concat(playersDatasAway);

						if (playersDatas) {
							playersDatas.forEach(function (playersData) {
								var teamPlayers = {};
								teamPlayers.fName = playersData.fName;
								teamPlayers.lName = playersData.lName;
								teamPlayers.playerId = playersData.playerId;
								teamPlayers.posGen = playersData.positions[0].posGen;
								teamPlayers.posId = playersData.positions[0].posId;
								teamPlayers.posAbbr = playersData.positions[0].posAbbr;
								teamPlayers.CapValue = playersData.fanProjSalary;
								teamPlayers.isInjured = playersData.isInjured;
								competitionPlayer = {};
								competitionPlayer.compId = eventDB[i].eventId;
								competitionPlayer.nameDisplay = [{
									htAbbr: eventDB[i].homeTeam.tAbbr,
									htName: eventDB[i].homeTeam.tName,
									htScore: '',
									value: eventDB[i].awayTeam.tAbbr+ '@' + eventDB[i].homeTeam.tAbbr,
									atAbbr: eventDB[i].awayTeam.tAbbr,
									atName: eventDB[i].awayTeam.tName,
									atScore: ''
								}];
								teamPlayers.competition = competitionPlayer;
								teamPlayers.teamId = playersData.team.teamId;
								teamPlayers.teamAbbr = playersData.team.tAbbr;
								teamPlayers.fanProjSalary = playersData.fanProjSalary;
								teamPlayers.fanProjScore = playersData.fanProjPoints;
								players.push(teamPlayers);
							});
						}
						game['players'] = players;
						League = {};
						League.leagueId = eventDB[i].league.leagueId;
						League.name = eventDB[i].league.name;
						League.abbr = eventDB[i].league.abbr;
						leagues = [];
						leagues.push(League);
						gameList.push(game);
					}
					var darftGroupModel = draftGroupDataMapper.updateData(req.body, gameList, leagues, minDate);
					var response = await draftGroupService.update(darftGroupModel, draftgroupId);
					if (response._id != null) {
                       //Mvalue calculation starts here
						//To get max and min fantasy player positions			
						if (gameList != null && (darftGroupModel.sportId == 4 || darftGroupModel.sportId == 3  || darftGroupModel.sportId == 2)) {
                            //To get max and min fantasy player positions
							var minmax = await draftGroupService.getMinMaxNBA(darftGroupModel.draftgroupId);							
                            var gamesList = gameList;
                            for (var k = 0, len = gamesList.length; k < len; k++) {
                               // console.log(darftGroupModel.draftgroupId);
                                if (gamesList[k].players != null) {
                                    for (var j in gamesList[k].players) {
                                        for (var i in minmax) {
                                            if (minmax[i]._id == gamesList[k].players[j].posGen) {
                                                //setting min salary for player if 0
                                                var playerSalary = (gamesList[k].players[j].fanProjSalary == 0) ?  minmax[i].min : gamesList[k].players[j].fanProjSalary;
                                                mValue = await Math.round((1 + ((playerSalary - minmax[i].max) * (2 - 1)) / (minmax[i].min - minmax[i].max)) * 20) / 20;
                                                //updating mValue draftgroup schema
                                                var field = {};
                                                field["gameList.$.players." + j + ".mValue"] = mValue;                              
										     	var updateM = await draftGroupService.updateMvalue(darftGroupModel.draftgroupId, gamesList[k].players[j].playerId, field);
                                            };
                                        }
                                    }
                                }
                            }
						} 
						
						if (gameList != null && darftGroupModel.sportId != 4 && darftGroupModel.sportId != 3 && darftGroupModel.sportId != 2) {
                            //To get max and min fantasy player positions
							var minmax = await draftGroupService.getMinMaxNFL(darftGroupModel.draftgroupId);							
                            var gamesList = gameList;
                            for (var k = 0, len = gamesList.length; k < len; k++) {
                               // console.log(darftGroupModel.draftgroupId);
							   if (gamesList[k].players != null) {
								for (var j in gamesList[k].players) {
									for (var i in minmax) {
										if (minmax[i]._id == gamesList[k].players[j].posAbbr) {
											var playerSalary = (gamesList[k].players[j].fanProjSalary == 0) ? minmax[i].min : gamesList[k].players[j].fanProjSalary;
											mValue = await Math.round((1 + ((playerSalary - minmax[i].max) * (2 - 1)) / (minmax[i].min - minmax[i].max)) * 20) / 20;
											//updating mValue draftgroup schema
											var field = {};
											field["gameList.$.players." + j + ".mValue"] = mValue;
											var updateM = await draftGroupService.updateMvalue(darftGroupModel.draftgroupId, gamesList[k].players[j].playerId, field);
										};
									}
								}
							}
                            }
                        } 
						//Mvalue calculation ends here
						generalHelper.handleSuccess(req, res, _t.draftGrouptUpdated, {
							'id': response._id,
							'draftgroupId': response.draftgroupId
						});
					} else {
						generalHelper.handleError(req, res, 'Add record failed', _t.failedAddDraftGroup);
					}
				} else {
					generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddDraftGroup);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Delete a draftgroup
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	delete: async function (req, res) {
		try {
			if (darftGroupValidation.DraftgroupIdValidation(req, res) != false) {
				var response = await draftGroupService.delete(req.params.id);
				if (response.result.n == 1) {
					generalHelper.handleSuccess(req, res, _t.draftGroupDeleted, {});
				} else {
					generalHelper.handleError(req, res, 'Delete record not found', _t.failedDeleteDraftGroup);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},



};