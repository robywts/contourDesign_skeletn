/**
 * Admin Module
 * @exports Admin/User/Controller
 */
var adminService = require('../services/adminService');
var generalHelper = require('../helpers/generalHelper');
var bcryptHelper = require('../helpers/bcryptHelper');
var emailHelper = require('../helpers/emailHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/adminTrans.json');
var adminValidation = require('../validations/adminValidation');
var adminDataMapper = require('../dataMappers/adminDataMapper');
// var emailHelper = require('../helpers/emailHelper');
var UserModel = require('../../../models/user');
// var async = require('async');

module.exports = {

	/**
	 * Get all Admin Users
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getUsers: async function (req, res) {
		try {
			var search = adminDataMapper.searchData(req.query);
			var userDB = await adminService.listUsers(search, global.userId);
			var totalCount = await adminService.listUsersCount(search, global.userId);
			var result = adminDataMapper.getUsersData(userDB);
			var additionalData = {};
			additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, userDB.length);
			generalHelper.handleSuccess(req, res, _t.adminListRetrieved, result, additionalData);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get admin user by id
	 * @param {object} req.header - Request object (session data)
	 * @param {object} res - Response object
	 */
	getUser: async function (req, res) {
		try {
			var id = req.params.id;
			var profile = await adminService.getProfile(id);
			if (profile == null) { //error
				generalHelper.handleError(req, res, {}, _t.failedGetAdmin);
			} else {
				var result = adminDataMapper.getProfileData(profile);
			}
			generalHelper.handleSuccess(req, res, _t.adminRetrieved, result);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Add Admin Users
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	addUser: async function (req, res) {
		try {
			if (adminValidation.registerValidation(req, res) != false) {
				var userAuth = adminDataMapper.registerData({}, req.body);
				var user = await adminService.findUser(userAuth);
				if (user == null) { //can create account
					var userAuthDBNew = new UserModel();
					userAuthDBNew.userId = await generalHelper.updateCounter('userId'); // unique key
					if (userAuthDBNew.userId != null) {
						userAuthDBNew = adminDataMapper.registerData(userAuthDBNew, req.body);
						var password = userAuthDBNew.pwd;
						userAuthDBNew.pwd = bcryptHelper.encrypt(userAuthDBNew.pwd); // encryption
						var response = await adminService.addUser(userAuthDBNew);
						if (response._id != null) {
							var result = adminDataMapper.getOneUserData(response);
							//sending mail to cretaed user
							var sendMail = emailHelper.sendMail(result.email, 'adminRegistrationSubject', './app/modules/admin/emailTemplates/admin.html', {
								Name: result.userName ? result.userName : '',
								Email: result.email,
								Password: password
							});
							generalHelper.handleSuccess(req, res, _t.adminRegistered, result);
						} else {
							generalHelper.handleError(req, res, 'Registration failed', _t.failedAdd);
						}
					} else {
						generalHelper.handleError(req, res, 'Id generation failed', _t.failedAdd);
					}
				} else { // account existing
					if (user.email == userAuth.email) {
						generalHelper.handleError(req, res, 'Email exists', _t.emailExists);
					} else if (user.userName == userAuth.userName) {
						generalHelper.handleError(req, res, 'userName exists', _t.userNameExists);
					}
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Update Admin User
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	updateUser: async function (req, res) {
		try {
			if (adminValidation.updateProfileValidation(req, res) != false) {
				var userProfile = adminDataMapper.updateProfileData({}, req.body);
				if (userProfile.pwd) {
					userProfile.pwd = bcryptHelper.encrypt(userProfile.pwd);
				} // encryption 			
				var profileUpdate = await adminService.updateProfile(userProfile, req.params.id);
				if (profileUpdate) {
					generalHelper.handleSuccess(req, res, _t.adminUserUpdate, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.invalidRequest);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Update Admin User Status
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	updateStatus: async function (req, res) {
		try {
			if (adminValidation.updateStatusValidation(req, res) != false) {
				var userProfile = adminDataMapper.updateStatusData({}, req.body, req.params.id);
				var profileUpdate = await adminService.updateStatus(userProfile.status, userProfile.userId);
				if (profileUpdate) {
					generalHelper.handleSuccess(req, res, _t.userStatusUpdate, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.invalidRequest);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Delete Admin User (soft delete)
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	deleteUser: async function (req, res) {
		try {
			if (adminValidation.deleteValidation(req, res) != false) {
				var deleteUser = await adminService.deleteUser(req.params.id);
				if (deleteUser) {
					generalHelper.handleSuccess(req, res, _t.userDeleted, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.invalidRequest);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

};