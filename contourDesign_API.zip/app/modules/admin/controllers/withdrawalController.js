/**
 * Withdrawal Module
 * @exports Admin/Withdrawal/Controller
 */
var withdrawalService = require('../services/withdrawalService');
var TransactionModel = require('../../../models/transaction');
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/withdrawalTrans.json');
var withdrawalValidation = require('../validations/withdrawalValidation');
var withdrawalDataMapper = require('../dataMappers/withdrawalDataMapper');

module.exports = {

	/**
	 * Get all Withdrawal Requests
	 * @param {object} req - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getWithdrawalRequests: async function (req, res) {
		try {
			var userId = (req.params.id) ? req.params.id : ''; // if user id is provided
			var search = withdrawalDataMapper.withdrawalData(req.query);
			var withdrawalDB = await withdrawalService.withdrawalRequests(search, userId);
			var totalCount = await withdrawalService.withdrawalRequestsCount(search, userId);
			var userIds = [];
			var userBals = [];
			for (var i = 0, len = withdrawalDB.length; i < len; i++) { // get all the userIds to get the balances
				userIds.push(withdrawalDB[i].userId);
			}
			var userDB = await withdrawalService.getUsersBalance(userIds);
			for (var i = 0, len = userDB.length; i < len; i++) { // get all the balance in the array with userId as the key
				userBals[userDB[i].userId] = userDB[i].balance;
			}
			var result = withdrawalDataMapper.getWithdrawalData(withdrawalDB, userBals);
			var additionalData = {};
			additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, withdrawalDB.length);
			generalHelper.handleSuccess(req, res, _t.withdrawalRequestsRetrieved, result, additionalData);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Update Withdrawalstatus by withdrawalId
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	updateWithdrawalStatus: async function (req, res) {
		try {
			if (withdrawalValidation.updateWithdrawalStatusValidation(req, res) != false) {
				var withdrawalId = req.params.id;
				var withdrawal = withdrawalDataMapper.updateWithdrawalStatusData({}, req.body, withdrawalId);
				var userDB = await withdrawalService.withdrawalRequestStatus(withdrawalId);
				if (!userDB) { // if request not found
					generalHelper.handleError(req, res, {}, _t.invalidRequest);
				} else {
					if (userDB.requestStatus == "C") { // if request is already closed
						generalHelper.handleError(req, res, '', _t.requestClosedAlready);
					} else {
						var withdrawalUpdate = await withdrawalService.updateWithdrawalStatus(withdrawal);
						if (withdrawalUpdate) { // if request updated successfully (update to user & transaction collections also)
							var updateUser = await withdrawalService.updateWithdrawalStatusUser(withdrawalUpdate);
							if (updateUser) {
								if (withdrawalUpdate.requestStatus == 'C') {
									// update transaction collection here (if closed)
									var transactionModel = new TransactionModel();
									transactionModel = withdrawalDataMapper.transactionData(transactionModel, updateUser, withdrawalUpdate.amount, 'W');
									var transactionResult = await withdrawalService.transactionEntry(transactionModel);
								}
								generalHelper.handleSuccess(req, res, _t.statusUpdate, {
									'balance': updateUser.balance
									// 'paymentType': withdrawalUpdate.paymentType,
									// 'status': withdrawalUpdate.requestStatus
								});
							} else {
								generalHelper.handleError(req, res, {}, _t.invalidRequest);
							}
						} else {
							generalHelper.handleError(req, res, {}, _t.invalidRequest);
						}
					}
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get User's Withdrawal Requests
	 * @param {object} req - Request object with request parameters
	 * @param {object} res - Response object
	 */
	// getUserWithdrawalRequests: async function (req, res) {
	// 	try {
	// 		var search = withdrawalDataMapper.userWithdrawalData(req.query);
	// 		var withdrawalDB = await withdrawalService.userWithdrawalRequests(search);		
	// 		var totalCount = await withdrawalService.userWithdrawalRequestsCount(search);
	// 		var result = withdrawalDataMapper.getWithdrawalData(withdrawalDB);
	// 		var additionalData = {};
	// 		additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, withdrawalDB.length);
	// 		generalHelper.handleSuccess(req, res, _t.withdrawalRequestsRetrieved, result, additionalData);
	// 	} catch (e) {
	// 		generalHelper.handleError(req, res, e.stack, _t.technicalError);
	// 	}
	// },


};