/**
 * PrizeTemplate Module
 * @exports PrizeTemplate/Controller
 */
var prizeTemplateService = require('../services/prizeTemplateService');
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/prizeTemplateTrans.json');
var prizeTemplateValidation = require('../validations/prizeTemplateValidation');
var prizeTemplateDataMapper = require('../dataMappers/prizeTemplateDataMapper');
var PrizeTemplateModel = require('../../../models/prizeTemplate');

module.exports = {

	/**
	 * Get all PrizeTemplate for Dropdown
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getPrizeTemplatesDD: async function (req, res) {
		try {
			var sportsId = (req.params.id) ? req.params.id : 1;
			var resultDB = await prizeTemplateService.getPrizeTemplatesDD(sportsId);
			var result = prizeTemplateDataMapper.getPrizeTemplatesDDData(resultDB);
			var additionalData = {};
			generalHelper.handleSuccess(req, res, _t.prizeTemplatesRetrieved, result, additionalData);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get all PrizeTemplate
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getPrizeTemplates: async function (req, res) {
		try {
			var search = prizeTemplateDataMapper.searchData(req.query);
			var resultDB = await prizeTemplateService.getPrizeTemplates(search);
			var totalCount = await prizeTemplateService.getPrizeTemplatesCount(search);
			var result = prizeTemplateDataMapper.getPrizeTemplatesData(resultDB);
			var additionalData = {};
			additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, resultDB.length);
			generalHelper.handleSuccess(req, res, _t.prizeTemplatesRetrieved, result, additionalData);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get PrizeTemplate by id
	 * @param {object} req.header - Request object (session data)
	 * @param {object} res - Response object
	 */
	getOnePrizeTemplate: async function (req, res) {
		try {
			var resultDB = await prizeTemplateService.getOnePrizeTemplate(req.params.id);
			if (resultDB == null) { //error
				generalHelper.handleError(req, res, {}, _t.failedGetPrizeTemplate);
			} else {
				var result = prizeTemplateDataMapper.getOnePrizeTemplateData(resultDB);
			}
			generalHelper.handleSuccess(req, res, _t.prizeTemplateRetrieved, result);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Add PrizeTemplate
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	addPrizeTemplates: async function (req, res) {
		try {
			if (prizeTemplateValidation.addValidation(req, res) != false) {
				var reqData = prizeTemplateDataMapper.addData({}, req.body);
				var prizeTemplate = await prizeTemplateService.findPrizeTemplate(reqData);
				if (prizeTemplate == null) { //can add record
					var newRecord = new PrizeTemplateModel();
					newRecord.prizeTmpId = await generalHelper.updateCounter('prizeTmpId'); // unique key
					if (newRecord.prizeTmpId != null) {
						newRecord = prizeTemplateDataMapper.addData(newRecord, req.body);
						var response = await prizeTemplateService.addPrizeTemplate(newRecord);
						if (response._id != null) {
							var result = prizeTemplateDataMapper.getOnePrizeTemplateData(response);
							generalHelper.handleSuccess(req, res, _t.prizeTemplateAdded, result);
						} else {
							generalHelper.handleError(req, res, 'Addition failed', _t.prizeTemplatefailedAdd);
						}
					} else {
						generalHelper.handleError(req, res, 'Id generation failed', _t.prizeTemplatefailedAdd);
					}
				} else { // record existing
					if (prizeTemplate.tmpName == reqData.tmpName) {
						generalHelper.handleError(req, res, 'Record exists', _t.prizeTemplateExists);
					}
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Update PrizeTemplate
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	updatePrizeTemplate: async function (req, res) {
		try {
			if (prizeTemplateValidation.updateValidation(req, res) != false) {
				var reqData = prizeTemplateDataMapper.updateData({}, req.body);
				var prizeTemplate = await prizeTemplateService.findPrizeTemplate(reqData, req.params.id);
				if (prizeTemplate == null) { //can update record
					var result = await prizeTemplateService.updatePrizeTemplate(reqData, req.params.id);
					if (result) {
						generalHelper.handleSuccess(req, res, _t.prizeTemplateUpdated, {});
					} else {
						generalHelper.handleError(req, res, {}, _t.invalidRequest);
					}
				} else { // record existing
					if (prizeTemplate.tmpName == reqData.tmpName) {
						generalHelper.handleError(req, res, 'Record exists', _t.prizeTemplateExists);
					}
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Update PrizeTemplate status
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	updateStatus: async function (req, res) {
		try {
			if (prizeTemplateValidation.updateStatusValidation(req, res) != false) {
				var dataObj = prizeTemplateDataMapper.updateStatusData({}, req.body);
				var result = await prizeTemplateService.updateStatus(dataObj.status, req.params.id);
				if (result) {
					generalHelper.handleSuccess(req, res, _t.statusUpdated, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.invalidRequest);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Delete PrizeTemplate
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	deletePrizeTemplate: async function (req, res) {
		try {
			var response = await prizeTemplateService.delete(req.params.id);
			if (response.result.n == 1) {
				generalHelper.handleSuccess(req, res, _t.prizeTemplateDeleted, {});
			} else {
				generalHelper.handleError(req, res, 'Delete record not found', _t.failedDeleteprizeTemplate);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},
};