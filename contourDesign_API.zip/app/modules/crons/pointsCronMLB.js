/**
 * General Module
 * @exports Cron/MLB/LineupScoreAndPosition
 */
var PlayerScoreModel = require('../../models/playerScore');
var DraftGroupModel = require('../../models/draftgroup');
var LineupModel = require('../../models/lineup');
var cronVar = require('./cronSettings');
var AutoContestLogics = require('../../models/autocontestlogics');
var ContestModel = require('../../models/contest');
var PrizeTempModel = require('../../models/prizeTemplate');
var UserModel = require('../../models/user');
var moment = require('moment');
var generalHelper = require('./helpers/generalHelper');
var async = require('async');
var Pusher = require('./helpers/pusherHelper');
var fbHelper = require('./helpers/fbHelper');
var NotificationsModel = require('../../models/notification');
var TransactionModel = require('../../models/transaction');

var self = module.exports = {

    testTime: async function () {
        try {
             console.log("here to test Time");

             var currDate = moment(new Date());
             currDate.set({hour:0,minute:0,second:0,millisecond:0})
             var prvDate = moment(new Date()).subtract(1, 'days');
             prvDate.set({hour:0,minute:0,second:0,millisecond:0})
             console.log("Current Date - Prev Date"+ currDate+" - "+ prvDate);
             var dfg = await DraftGroupModel.find({'sportId':1, 'dgState':"Completed",'gameList.startTimeUTC': { "$gte" : prvDate, "$lt" : currDate}});
             console.log("Count-"+ dfg.length);
             //.format('YYYY-MM-DD hh:mm:ss SSS')
            /* var exist = await UserModel.findOne({ "userId": 273, "sportsRanking.sportId":2 });
            if(exist != null){
                console.log("Exist");
                await UserModel.findOneAndUpdate({ "userId": 273, "sportsRanking.sportId":2 }, { $inc: {
                    "sportsRanking.$.points": 6
                    }, $set:{'updatedAt':new Date()}  }, {
                        safe: true,
                        upsert: true
                });
            }
            else{
                console.log("Not exist");
                    UserModel.update(
                        { 
                            "userId": 273
                        },
                        { 
                            $push: { 
                                "sportsRanking": {
                                    'sportId': 2,
                                    'rank': 0,
                                    'subRank': 0,
                                    'points': 15,                                    
                                    'imageName': "",
                                    'createdAt': new Date(),     
                                    'updatedAt': new Date(),
                                    'pointsForNextRank': 0,
                                    'pointsForNextSubRank': 0,
                                    'pointsForCurrentRank': 0,
                                    'pointsForCurrentSubRank': 0                                                                       
                                }
                            }
                        },
                        function(err,numAffected) {
                            
                        }
                    );                   
            }         */

        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To update points based on lineup position for MLB
     */
    updatePointsMLB: async function () {
        try { console.log("here MLB");
            var week =    moment(new Date()).format('YYYY-MM-DD').replace(/-+/g, '');
            var prvWeek = moment(new Date()).subtract(1, 'days').format('YYYY-MM-DD').replace(/-+/g, '');            
            var liveDrafts = await DraftGroupModel.find({ dgState: 'Completed', week: prvWeek, sportId: 2 });
            console.log(liveDrafts.length);
            for (var i = 0; i < liveDrafts.length; i++) {
                //console.log("Live Drafts Available.");
                //async.eachSeries(liveDrafts, async function (liveDraft, outest) {
                var contests = await ContestModel.find({ "draftgroupId": liveDrafts[i].draftgroupId, contestStatus: { $in: [1] } });
                //var contests = await ContestModel.find({ "contestId": 11656 });
                //for (var j = 0; j < contests.length; j++) {
                var freeUserWinData = [];    
                async.eachSeries(contests, async function (contestSingle, outrCb) {                     
                   // console.log("contestId - "+contestSingle.contestId);
                   // console.log("**************************");
                //var lineups = await LineupModel.find({ "contestId": contestSingle.contestId, points: { $gt: -100 } }).sort({ points: -1 });
                if(contestSingle.entryFees >0 ) {    
               if(contestSingle.contestTypeId == 2) {                   

                        var contestEntrants= contestSingle.entrants;
                        if(contestEntrants && contestEntrants.length > 0)  {                        
                            var userLoseRank;
                            var userWinRank;
                            var newPoints;
                            var userUpdateId;
                            var points = 1;
                            var userLineUp = await LineupModel.find({
                                'contestId': contestSingle.contestId                    
                            });
                            if(userLineUp != null)
                            {
                                var userExist;
                                var updateUserArray = [];
                                if(userLineUp.length == 2){
                                    var cnt = 0;
                                    for(var l = 0; l < userLineUp.length; l++){
                                        if(userLineUp[l].position == 1){
                                            var userWinInfo = await UserModel.findOne({
                                                'userId': userLineUp[l].userId,
                                                'sportsRanking.sportId':2
                                            },
                                            {_id: 0, sportsRanking: {$elemMatch: {sportId: 2 }}});
                                            
                                            if(userWinInfo != null){  
                                                if(userWinInfo.sportsRanking != null){                                              
                                                    userWinRank = userWinInfo.sportsRanking[0].rank;   
                                                }                                             
                                            }
                                            cnt++;
                                            updateUserArray.push(userLineUp[l].userId);                      
                                        }
                                        else{
                                            var userLoseInfo = await UserModel.findOne({
                                                'userId': userLineUp[l].userId,
                                                'sportsRanking.sportId':2
                                            },
                                            {_id: 0, sportsRanking: {$elemMatch: {sportId: 2 }}});
                                            if(userLoseInfo != null){      
                                                if(userLoseInfo.sportsRanking != null){                                              
                                                    userLoseRank = userLoseInfo.sportsRanking[0].rank;   
                                                }                                          
                                            }
                                            userExist = null;
                                            userExist = await UserModel.findOne({ "userId": userLineUp[l].userId, "sportsRanking.sportId":2 });
                                            if(userExist != null){
                                                await UserModel.findOneAndUpdate({ "userId": userLineUp[l].userId, "sportsRanking.sportId":2 }, { $inc: {
                                                    "sportsRanking.$.points": points
                                                    }, $set:{'updatedAt':new Date()}  }, {
                                                        safe: true,
                                                        upsert: true
                                                });
                                            }
                                            else{
                                                UserModel.update(
                                                    { 
                                                        "userId": userLineUp[l].userId
                                                    },
                                                    { 
                                                        $push: { 
                                                            "sportsRanking": {
                                                                'sportId': 2,
                                                                'rank': 0,
                                                                'subRank': 0,
                                                                'points': points,                                    
                                                                'imageName': "empty_mlb",
                                                                'createdAt': new Date(),     
                                                                'updatedAt': new Date(),
                                                                'pointsForNextRank': 0,
                                                                'pointsForNextSubRank': 0,
                                                                'pointsForCurrentRank': 0,
                                                                'pointsForCurrentSubRank': 0                                                                       
                                                            }
                                                        }
                                                    },
                                                    function(err,numAffected) {
                                                        
                                                    }
                                                );          
                                            }
                                            
                                        }
                                    }
                                
                                    if(cnt < 2){
                                      //  console.log("userWinRank- "+userWinRank);
                                       // console.log("userLoseRank- "+userLoseRank);
                                        if(userWinRank < userLoseRank){
                                            var rankDifference = userLoseRank - userWinRank;
                                            newPoints = (1 + parseFloat(process.env.WIN_POINTS)) + ((1 + parseFloat(process.env.WIN_POINTS)) * (rankDifference * 0.5))
                                        }
                                        else{
                                            newPoints = 1 + parseFloat(process.env.WIN_POINTS);
                                        }
                                       // console.log("newpoints- "+newPoints);
                                       if(updateUserArray[0]){
                                            userExist = null;
                                            userExist = await UserModel.findOne({ "userId": updateUserArray[0], "sportsRanking.sportId":2 });
                                            if(userExist != null){
                                                await UserModel.findOneAndUpdate({ "userId": updateUserArray[0], "sportsRanking.sportId":2 }, { $inc: {
                                                    "sportsRanking.$.points": newPoints
                                                    }, $set:{'updatedAt':new Date()}  }, {
                                                        safe: true,
                                                        upsert: true
                                                });
                                            }
                                        }
                                        else{
                                            UserModel.update(
                                                { 
                                                    "userId": updateUserArray[0]
                                                },
                                                { 
                                                    $push: { 
                                                        "sportsRanking": {
                                                            'sportId': 2,
                                                            'rank': 0,
                                                            'subRank': 0,
                                                            'points': newPoints,                                    
                                                            'imageName': "empty_mlb",
                                                            'createdAt': new Date(),     
                                                            'updatedAt': new Date(),
                                                            'pointsForNextRank': 0,
                                                            'pointsForNextSubRank': 0,
                                                            'pointsForCurrentRank': 0,
                                                            'pointsForCurrentSubRank': 0                                                                       
                                                        }
                                                    }
                                                },
                                                function(err,numAffected) {
                                                    
                                                }
                                            );          
                                        }
                                        }
                                    }
                                    else{
                                       // console.log("Users- "+updateUserArray.length);
                                        for(var b=0; b<updateUserArray.length; b++){
                                            newPoints = 1 + parseFloat(process.env.WIN_POINTS);
                                            userExist = null;
                                            userExist = await UserModel.findOne({ "userId": updateUserArray[b], "sportsRanking.sportId":2 });
                                            if(userExist != null){
                                                await UserModel.findOneAndUpdate({ "userId": updateUserArray[b], "sportsRanking.sportId":2 }, { $inc: {
                                                    "sportsRanking.$.points": newPoints
                                                    }, $set:{'updatedAt':new Date()}  }, {
                                                        safe: true,
                                                        upsert: true
                                                });
                                            }
                                            else{
                                                UserModel.update(
                                                    { 
                                                        "userId": updateUserArray[b]
                                                    },
                                                    { 
                                                        $push: { 
                                                            "sportsRanking": {
                                                                'sportId': 2,
                                                                'rank': 0,
                                                                'subRank': 0,
                                                                'points': newPoints,                                    
                                                                'imageName': "empty_mlb",
                                                                'createdAt': new Date(),     
                                                                'updatedAt': new Date(),
                                                                'pointsForNextRank': 0,
                                                                'pointsForNextSubRank': 0,
                                                                'pointsForCurrentRank': 0,
                                                                'pointsForCurrentSubRank': 0                                                                       
                                                            }
                                                        }
                                                    },
                                                    function(err,numAffected) {
                                                        
                                                    }
                                                );          
                                            }
                                        }
                                    }
                                }
                            }

                        }                    
                                         
                }
                // Multiplayer contest start.
                else if(contestSingle.contestTypeId == 1){                                         
                        var maxPrize;
                        var totalPoints;
                        var userMultiExist;      
                        var multiEntrants= contestSingle.entrants;
                        if(multiEntrants && multiEntrants.length > 0)  {
                            var prizeTemplateData = await PrizeTempModel.findOne({'prizeTmpId': contestSingle.prizeTmpId},'prizeTmpId tmpName');
                            if(prizeTemplateData != null)
                            {
                                maxPrize = prizeTemplateData.tmpName == 'Winner Take All' ? 1 : 
                                    (prizeTemplateData.tmpName == 'Top 2 Win' ? 2 : 
                                        (prizeTemplateData.tmpName == 'Top 3 Win' ? 3 : 0))
                            }
                            //console.log("Max Prize:- "+maxPrize);
                            var multiUserLineUp = await LineupModel.find({
                                'contestId': contestSingle.contestId                                                      
                            });
                            //console.log("Total-Size"+ multiEntrants.length);
                            if(multiEntrants.length > 20){                                  
                               // console.log("Lineup Position(>20)");                                    
                                if(multiUserLineUp != null)
                                {                                                                       
                                    for(var m = 0; m < multiUserLineUp.length; m++){
                                        totalPoints = 1;
                                        if(maxPrize == 1 || maxPrize == 2 || maxPrize == 3){
                                            if(multiUserLineUp[m].position == 1){
                                                totalPoints = totalPoints + parseFloat(process.env.MULTI_FIRST_PRIZE);
                                            }
                                        }
                                        if(maxPrize == 2 || maxPrize == 3){
                                            if(multiUserLineUp[m].position == 2){
                                                totalPoints = totalPoints + parseFloat(process.env.MULTI_SECOND_PRIZE);
                                            }
                                        }
                                        if(maxPrize == 3){
                                            if(multiUserLineUp[m].position == 3){
                                                totalPoints = totalPoints + parseFloat(process.env.MULTI_THIRD_PRIZE);
                                            }
                                        }
                                        userMultiExist = null;
                                        userMultiExist = await UserModel.findOne({ "userId": multiUserLineUp[m].userId, "sportsRanking.sportId":2 });
                                        if(userMultiExist != null){
                                            await UserModel.findOneAndUpdate({ "userId": multiUserLineUp[m].userId, "sportsRanking.sportId":2 }, { $inc: {
                                                "sportsRanking.$.points": totalPoints
                                                }  }, {
                                                    safe: true,
                                                    upsert: true
                                            });
                                        }
                                        else{
                                            UserModel.update(
                                                { 
                                                    "userId": multiUserLineUp[m].userId
                                                },
                                                { 
                                                    $push: { 
                                                        "sportsRanking": {
                                                            'sportId': 2,
                                                            'rank': 0,
                                                            'subRank': 0,
                                                            'points': totalPoints,                                    
                                                            'imageName': "empty_mlb",
                                                            'createdAt': new Date(),     
                                                            'updatedAt': new Date(),
                                                            'pointsForNextRank': 0,
                                                            'pointsForNextSubRank': 0,
                                                            'pointsForCurrentRank': 0,
                                                            'pointsForCurrentSubRank': 0                                                                       
                                                        }
                                                    }
                                                },
                                                function(err,numAffected) {
                                                    
                                                }
                                            );          
                                        }
                                    }
                                }
                            }
                            else{     
                                //console.log("Lineup Position(<20)");                           
                                for(var n = 0; n < multiUserLineUp.length; n++){
                                    totalPoints = 1;
                                    if(multiUserLineUp[n].position == 1){
                                        totalPoints = totalPoints + parseFloat(process.env.WIN_POINTS);
                                    }   
                                    userMultiExist = null;
                                    userMultiExist = await UserModel.findOne({ "userId": multiUserLineUp[m].userId, "sportsRanking.sportId":2 });
                                    if(userMultiExist != null){                                     
                                        await UserModel.findOneAndUpdate({ "userId": multiUserLineUp[n].userId, "sportsRanking.sportId":2 }, { $inc: {
                                            "sportsRanking.$.points": totalPoints
                                            }, $set:{'updatedAt':new Date()}  }, {
                                                safe: true,
                                                upsert: true
                                        });
                                    }
                                    else{
                                        UserModel.update(
                                            { 
                                                "userId": multiUserLineUp[n].userId
                                            },
                                            { 
                                                $push: { 
                                                    "sportsRanking": {
                                                        'sportId': 2,
                                                        'rank': 0,
                                                        'subRank': 0,
                                                        'points': totalPoints,                                    
                                                        'imageName': "empty_mlb",
                                                        'createdAt': new Date(),     
                                                        'updatedAt': new Date(),
                                                        'pointsForNextRank': 0,
                                                        'pointsForNextSubRank': 0,
                                                        'pointsForCurrentRank': 0,
                                                        'pointsForCurrentSubRank': 0                                                                       
                                                    }
                                                }
                                            },
                                            function(err,numAffected) {
                                                
                                            }
                                        );          
                                    }                                                                   
                            }
                        }  
                    }                 
                }
                // Free contest start.
                else{
                    var freeContestEntrants = contestSingle.entrants;
                    var userFreeExist;
                    if(freeContestEntrants && freeContestEntrants.length > 0)  {
                        var userInfo = await LineupModel.find({'contestId':contestSingle.contestId, 'position':1}, 'userId');
                        if(userInfo != null){  
                            for(var user = 0; user<userInfo.length; user++){
                                if(!freeUserWinData.includes(userInfo[user].userId)){
                                    freeUserWinData.push(userInfo[user].userId);
                                }
                            }
                        }
                    }
                    if(freeUserWinData != null){                    
                        for(var p = 0; p < freeUserWinData.length; p++){
                            userFreeExist = null;
                            userFreeExist = await UserModel.findOne({ "userId": freeUserWinData[p], "sportsRanking.sportId":2 });
                            if(userFreeExist != null){        
                                await UserModel.findOneAndUpdate({ "userId": freeUserWinData[p], "sportsRanking.sportId":2 }, { $inc: {
                                    "sportsRanking.$.points": parseFloat(process.env.WIN_POINTS)
                                    }, $set:{'updatedAt':new Date()}  }, {
                                        safe: true,
                                        upsert: true
                                });
                            }
                            else{
                                UserModel.update(
                                    { 
                                        "userId": freeUserWinData[p]
                                    },
                                    { 
                                        $push: { 
                                            "sportsRanking": {
                                                'sportId': 2,
                                                'rank': 0,
                                                'subRank': 0,
                                                'points': parseFloat(process.env.WIN_POINTS),                                    
                                                'imageName': "empty_mlb",
                                                'createdAt': new Date(),     
                                                'updatedAt': new Date(),
                                                'pointsForNextRank': 0,
                                                'pointsForNextSubRank': 0,
                                                'pointsForCurrentRank': 0,
                                                'pointsForCurrentSubRank': 0                                                                       
                                            }
                                        }
                                    },
                                    function(err,numAffected) {
                                        
                                    }
                                );          
                            }            
                        } 
                    }   
                }                

                    outrCb(null);
                });
            }
            //   outest(null);
            //  });
        } catch (e) {
            throw e;
        }
    }, 


    /**
     * Cron - To update points based on lineup position for NFL
     */

    updatePointsNFL: async function () {
        try { console.log("here NFL");
            var liveDrafts;            
            //var today = new Date();
            //var year = today.getFullYear();
            /* var weekInfo = await DraftGroupModel.findOne({sportId:1, dgState:'Completed',season:year}, 'week').sort({createdAt:-1});
            console.log("Week:-"); console.log(weekInfo != null ? weekInfo.week : 0);
            var week = weekInfo != null ? weekInfo.week : 0;
            var prvWeek = parseInt(week) - 1;
            if(week != 0){ */
             var currDate = moment(new Date()).format('YYYY-MM-DD');
             //currDate.set({hour:0,minute:0,second:0,millisecond:0})
             var prvDate = moment(new Date()).subtract(1, 'days').format('YYYY-MM-DD');
             //prvDate.set({hour:0,minute:0,second:0,millisecond:0})
             //console.log("Current Date - Prev Date"+ currDate.format('YYYY-MM-DD hh:mm:ss SSS')+" - "+ prvDate.format('YYYY-MM-DD hh:mm:ss SSS'));
             console.log("Current Date - "+ currDate+" Prev Date- "+ prvDate);

             liveDrafts = await DraftGroupModel.find({'sportId':1, 'dgState':"Completed",'gameList.startTimeUTC': { "$gte" : prvDate, "$lt" : currDate}});
             console.log("Draft Count-"+ liveDrafts.length);
                //liveDrafts = await DraftGroupModel.find({ dgState: 'Completed', season: year, week: { $in: [prvWeek, week] },sportId: 1 });
                for (var i = 0; i < liveDrafts.length; i++) {
                //async.eachSeries(liveDrafts, async function (liveDraft, outest) {
                var contests = await ContestModel.find({ "draftgroupId": liveDrafts[i].draftgroupId, contestStatus: { $in: [1] } });
                //for (var j = 0; j < contests.length; j++) {
                var freeUserWinData = [];    
                async.eachSeries(contests, async function (contestSingle, outrCb) {                     
                    //console.log("contestId - "+contestSingle.contestId);
                    //console.log("**************************");
                //var lineups = await LineupModel.find({ "contestId": contestSingle.contestId, points: { $gt: -100 } }).sort({ points: -1 });
               console.log("Contest Id-"+contestSingle.contestId);
               if(contestSingle.entryFees >0 ) {    
               if(contestSingle.contestTypeId == 2) {                 

                        var contestEntrants= contestSingle.entrants;
                        if(contestEntrants && contestEntrants.length > 0)  {                        
                            var userLoseRank;
                            var userWinRank;
                            var newPoints;
                            var userUpdateId;
                            var points = 1;
                            var userLineUp = await LineupModel.find({
                                'contestId': contestSingle.contestId                    
                            });
                            if(userLineUp != null)
                            {
                                var userExist;
                                var updateUserArray = [];
                                if(userLineUp.length == 2){
                                    var cnt = 0;
                                    for(var l = 0; l < userLineUp.length; l++){
                                        if(userLineUp[l].position == 1){
                                            var userWinInfo = await UserModel.findOne({
                                                'userId': userLineUp[l].userId,
                                                'sportsRanking.sportId':1
                                            },
                                            {_id: 0, sportsRanking: {$elemMatch: {sportId: 1 }}});
                                            
                                            if(userWinInfo != null){  
                                                if(userWinInfo.sportsRanking != null){                                              
                                                    userWinRank = userWinInfo.sportsRanking[0].rank;   
                                                }                                             
                                            }
                                            cnt++;
                                            updateUserArray.push(userLineUp[l].userId);                      
                                        }
                                        else{
                                            var userLoseInfo = await UserModel.findOne({
                                                'userId': userLineUp[l].userId,
                                                'sportsRanking.sportId':1
                                            },
                                            {_id: 0, sportsRanking: {$elemMatch: {sportId: 1 }}});
                                            if(userLoseInfo != null){      
                                                if(userLoseInfo.sportsRanking != null){                                              
                                                    userLoseRank = userLoseInfo.sportsRanking[0].rank;   
                                                }                                          
                                            }
                                            userExist = null;
                                            userExist = await UserModel.findOne({ "userId": userLineUp[l].userId, "sportsRanking.sportId":1 });
                                            if(userExist != null){
                                                await UserModel.findOneAndUpdate({ "userId": userLineUp[l].userId, "sportsRanking.sportId":1 }, { $inc: {
                                                    "sportsRanking.$.points": points
                                                    }, $set:{'updatedAt':new Date()}  }, {
                                                        safe: true,
                                                        upsert: true
                                                });
                                            }
                                            else{
                                                UserModel.update(
                                                    { 
                                                        "userId": userLineUp[l].userId
                                                    },
                                                    { 
                                                        $push: { 
                                                            "sportsRanking": {
                                                                'sportId': 1,
                                                                'rank': 0,
                                                                'subRank': 0,
                                                                'points': points,                                    
                                                                'imageName': "empty_mlb",
                                                                'createdAt': new Date(),     
                                                                'updatedAt': new Date(),
                                                                'pointsForNextRank': 0,
                                                                'pointsForNextSubRank': 0,
                                                                'pointsForCurrentRank': 0,
                                                                'pointsForCurrentSubRank': 0                                                                       
                                                            }
                                                        }
                                                    },
                                                    function(err,numAffected) {
                                                        
                                                    }
                                                );          
                                            }
                                            
                                        }
                                    }
                                
                                    if(cnt < 2){
                                      //  console.log("userWinRank- "+userWinRank);
                                       // console.log("userLoseRank- "+userLoseRank);
                                        if(userWinRank < userLoseRank){
                                            var rankDifference = userLoseRank - userWinRank;
                                            newPoints = (1 + parseFloat(process.env.WIN_POINTS)) + ((1 + parseFloat(process.env.WIN_POINTS)) * (rankDifference * 0.5))
                                        }
                                        else{
                                            newPoints = 1 + parseFloat(process.env.WIN_POINTS);
                                        }
                                       // console.log("newpoints- "+newPoints);
                                       if(updateUserArray[0]){
                                            userExist = null;
                                            userExist = await UserModel.findOne({ "userId": updateUserArray[0], "sportsRanking.sportId":1 });
                                            if(userExist != null){
                                                await UserModel.findOneAndUpdate({ "userId": updateUserArray[0], "sportsRanking.sportId":1 }, { $inc: {
                                                    "sportsRanking.$.points": newPoints
                                                    }, $set:{'updatedAt':new Date()}  }, {
                                                        safe: true,
                                                        upsert: true
                                                });
                                            }
                                        }
                                        else{
                                            UserModel.update(
                                                { 
                                                    "userId": updateUserArray[0]
                                                },
                                                { 
                                                    $push: { 
                                                        "sportsRanking": {
                                                            'sportId': 1,
                                                            'rank': 0,
                                                            'subRank': 0,
                                                            'points': newPoints,                                    
                                                            'imageName': "empty_mlb",
                                                            'createdAt': new Date(),     
                                                            'updatedAt': new Date(),
                                                            'pointsForNextRank': 0,
                                                            'pointsForNextSubRank': 0,
                                                            'pointsForCurrentRank': 0,
                                                            'pointsForCurrentSubRank': 0                                                                       
                                                        }
                                                    }
                                                },
                                                function(err,numAffected) {
                                                    
                                                }
                                            );          
                                        }
                                        }
                                    }
                                    else{
                                       // console.log("Users- "+updateUserArray.length);
                                        for(var b=0; b<updateUserArray.length; b++){
                                            newPoints = 1 + parseFloat(process.env.WIN_POINTS);
                                            userExist = null;
                                            userExist = await UserModel.findOne({ "userId": updateUserArray[b], "sportsRanking.sportId":2 });
                                            if(userExist != null){
                                                await UserModel.findOneAndUpdate({ "userId": updateUserArray[b], "sportsRanking.sportId":2 }, { $inc: {
                                                    "sportsRanking.$.points": newPoints
                                                    }, $set:{'updatedAt':new Date()}  }, {
                                                        safe: true,
                                                        upsert: true
                                                });
                                            }
                                            else{
                                                UserModel.update(
                                                    { 
                                                        "userId": updateUserArray[b]
                                                    },
                                                    { 
                                                        $push: { 
                                                            "sportsRanking": {
                                                                'sportId': 1,
                                                                'rank': 0,
                                                                'subRank': 0,
                                                                'points': newPoints,                                    
                                                                'imageName': "empty_mlb",
                                                                'createdAt': new Date(),     
                                                                'updatedAt': new Date(),
                                                                'pointsForNextRank': 0,
                                                                'pointsForNextSubRank': 0,
                                                                'pointsForCurrentRank': 0,
                                                                'pointsForCurrentSubRank': 0                                                                       
                                                            }
                                                        }
                                                    },
                                                    function(err,numAffected) {
                                                        
                                                    }
                                                );          
                                            }
                                        }
                                    }
                                }
                            }

                        }                    
                                         
                }
                // Multiplayer contest start.
                else if(contestSingle.contestTypeId == 1){                                         
                        var maxPrize;
                        var totalPoints;
                        var userMultiExist;      
                        var multiEntrants= contestSingle.entrants;
                        if(multiEntrants && multiEntrants.length > 0)  {
                            var prizeTemplateData = await PrizeTempModel.findOne({'prizeTmpId': contestSingle.prizeTmpId},'prizeTmpId tmpName');
                            if(prizeTemplateData != null)
                            {
                                maxPrize = prizeTemplateData.tmpName == 'Winner Take All' ? 1 : 
                                    (prizeTemplateData.tmpName == 'Top 2 Win' ? 2 : 
                                        (prizeTemplateData.tmpName == 'Top 3 Win' ? 3 : 0))
                            }
                            //console.log("Max Prize:- "+maxPrize);
                            var multiUserLineUp = await LineupModel.find({
                                'contestId': contestSingle.contestId                                                      
                            });
                            //console.log("Total-Size"+ multiEntrants.length);
                            if(multiEntrants.length > 20){                                  
                               // console.log("Lineup Position(>20)");                                    
                                if(multiUserLineUp != null)
                                {                                                                       
                                    for(var m = 0; m < multiUserLineUp.length; m++){
                                        totalPoints = 1;
                                        if(maxPrize == 1 || maxPrize == 2 || maxPrize == 3){
                                            if(multiUserLineUp[m].position == 1){
                                                totalPoints = totalPoints + parseFloat(process.env.MULTI_FIRST_PRIZE);
                                            }
                                        }
                                        if(maxPrize == 2 || maxPrize == 3){
                                            if(multiUserLineUp[m].position == 2){
                                                totalPoints = totalPoints + parseFloat(process.env.MULTI_SECOND_PRIZE);
                                            }
                                        }
                                        if(maxPrize == 3){
                                            if(multiUserLineUp[m].position == 3){
                                                totalPoints = totalPoints + parseFloat(process.env.MULTI_THIRD_PRIZE);
                                            }
                                        }
                                        userMultiExist = null;
                                        userMultiExist = await UserModel.findOne({ "userId": multiUserLineUp[m].userId, "sportsRanking.sportId":2 });
                                        if(userMultiExist != null){
                                            await UserModel.findOneAndUpdate({ "userId": multiUserLineUp[m].userId, "sportsRanking.sportId":2 }, { $inc: {
                                                "sportsRanking.$.points": totalPoints
                                                }  }, {
                                                    safe: true,
                                                    upsert: true
                                            });
                                        }
                                        else{
                                            UserModel.update(
                                                { 
                                                    "userId": multiUserLineUp[m].userId
                                                },
                                                { 
                                                    $push: { 
                                                        "sportsRanking": {
                                                            'sportId': 1,
                                                            'rank': 0,
                                                            'subRank': 0,
                                                            'points': totalPoints,                                    
                                                            'imageName': "empty_mlb",
                                                            'createdAt': new Date(),     
                                                            'updatedAt': new Date(),
                                                            'pointsForNextRank': 0,
                                                            'pointsForNextSubRank': 0,
                                                            'pointsForCurrentRank': 0,
                                                            'pointsForCurrentSubRank': 0                                                                       
                                                        }
                                                    }
                                                },
                                                function(err,numAffected) {
                                                    
                                                }
                                            );          
                                        }
                                    }
                                }
                            }
                            else{     
                                //console.log("Lineup Position(<20)");                           
                                for(var n = 0; n < multiUserLineUp.length; n++){
                                    totalPoints = 1;
                                    if(multiUserLineUp[n].position == 1){
                                        totalPoints = totalPoints + parseFloat(process.env.WIN_POINTS);
                                    }   
                                    userMultiExist = null;
                                    userMultiExist = await UserModel.findOne({ "userId": multiUserLineUp[m].userId, "sportsRanking.sportId":2 });
                                    if(userMultiExist != null){                                     
                                        await UserModel.findOneAndUpdate({ "userId": multiUserLineUp[n].userId, "sportsRanking.sportId":2 }, { $inc: {
                                            "sportsRanking.$.points": totalPoints
                                            }, $set:{'updatedAt':new Date()}  }, {
                                                safe: true,
                                                upsert: true
                                        });
                                    }
                                    else{
                                        UserModel.update(
                                            { 
                                                "userId": multiUserLineUp[n].userId
                                            },
                                            { 
                                                $push: { 
                                                    "sportsRanking": {
                                                        'sportId': 1,
                                                        'rank': 0,
                                                        'subRank': 0,
                                                        'points': totalPoints,                                    
                                                        'imageName': "empty_mlb",
                                                        'createdAt': new Date(),     
                                                        'updatedAt': new Date(),
                                                        'pointsForNextRank': 0,
                                                        'pointsForNextSubRank': 0,
                                                        'pointsForCurrentRank': 0,
                                                        'pointsForCurrentSubRank': 0                                                                       
                                                    }
                                                }
                                            },
                                            function(err,numAffected) {
                                                
                                            }
                                        );          
                                    }                                                                   
                            }
                        }  
                    }                 
                }
                // Free contest start.
                else{
                    var freeContestEntrants = contestSingle.entrants;
                    var userFreeExist;
                    if(freeContestEntrants && freeContestEntrants.length > 0)  {
                        var userInfo = await LineupModel.find({'contestId':contestSingle.contestId, 'position':1}, 'userId');
                        if(userInfo != null){  
                            for(var user = 0; user<userInfo.length; user++){
                                if(!freeUserWinData.includes(userInfo[user].userId)){
                                    freeUserWinData.push(userInfo[user].userId);
                                }
                            }
                        }
                    }
                    if(freeUserWinData != null){                    
                        for(var p = 0; p < freeUserWinData.length; p++){
                            userFreeExist = null;
                            userFreeExist = await UserModel.findOne({ "userId": freeUserWinData[p], "sportsRanking.sportId":2 });
                            if(userFreeExist != null){        
                                await UserModel.findOneAndUpdate({ "userId": freeUserWinData[p], "sportsRanking.sportId":2 }, { $inc: {
                                    "sportsRanking.$.points": parseFloat(process.env.WIN_POINTS)
                                    }, $set:{'updatedAt':new Date()}  }, {
                                        safe: true,
                                        upsert: true
                                });
                            }
                            else{
                                UserModel.update(
                                    { 
                                        "userId": freeUserWinData[p]
                                    },
                                    { 
                                        $push: { 
                                            "sportsRanking": {
                                                'sportId': 1,
                                                'rank': 0,
                                                'subRank': 0,
                                                'points': parseFloat(process.env.WIN_POINTS),                                    
                                                'imageName': "empty_mlb",
                                                'createdAt': new Date(),     
                                                'updatedAt': new Date(),
                                                'pointsForNextRank': 0,
                                                'pointsForNextSubRank': 0,
                                                'pointsForCurrentRank': 0,
                                                'pointsForCurrentSubRank': 0                                                                       
                                            }
                                        }
                                    },
                                    function(err,numAffected) {
                                        
                                    }
                                );          
                            }            
                        } 
                    }   
                }                

                    outrCb(null);
                });
            }        
            //   outest(null);
            //  });
        } catch (e) {
            throw e;
        }
    },    
}

