/**
 * DraftGroup Module - NBA
 * @exports Cron/DraftGroup
 */
var DraftGroupModel = require('../../models/draftgroup');
var GameModel = require('../../models/event');
var PlayerModel = require('../../models/player');
var moment = require('moment');
var generalHelper = require('../mobile/helpers/generalHelper');
var cronVar = require('./cronSettings');
var async = require('async');
var DraftLogicModel = require('../../models/draftgroupCreateLogic');

var self = module.exports = {
    /**
     * Cron - To create all predefined draftGroup set
     * To get all basic details related to players
     */

    getDraftGroupDetails: async function () {
        try {
            // var times = ['0', '1', '2', '3', '4', '5', '6',];
            // async.eachSeries(times, async function (time, outerCb) {


            var crrntDay = moment().tz("EST").format('YYYY-MM-DD HH:mm:ss');

            var insertdDraft = 0;
            for (var m = 1; m < 8; m++) {
                var nxtDay = moment(crrntDay).add(m, 'days').format('YYYY-MM-DD');
                //  console.log(nxtDay); process.exit();

                if (!insertdDraft) {
                    var events = await GameModel.find({ "sportId": 1 }, function (err, events) {
                        if (err)
                            console.log(err);
                        else {
                            async.eachSeries(events, async function (event, outCb) {
                                var eventDay = moment.utc(event.startTimeUTC).tz("EST").format('YYYY-MM-DD');

                                var s = moment.utc(event.startTimeUTC).tz("EST").format('YYYY-MM-DD HH:mm:ss');
                                var localHour = new Date(s).getHours();

                                if (eventDay == nxtDay) {
                                    var dgName = '';
                                    daraftgroups = [];
                                    var draftCreateLogics = await DraftLogicModel.find({ "sportId": 1 }, function (err, draftLogics) {
                                        //for (var m = 0; m < draftLogics.length; m++) {
                                        async.eachSeries(draftLogics, async function (draftLogic, logicCb) {
                                            //console.log(day); process.exit();
                                            if ((localHour >= draftLogic.startTimeRange) && (localHour <= draftLogic.endTimeRange)) {
                                                daraftgroups.push(draftLogic.startTimeSuffix);
                                            }
                                            //console.log(daraftgroups); process.exit();
                                            logicCb(null);
                                        });
                                    });
                                    game = {};
                                    game['eventId'] = event.eventId;
                                    game['startTimeUTC'] = event.startTimeUTC;
                                    game['gameStatus'] = ''; //console.log(event.eventId);
                                    game['venueName'] = event.venueName;
                                    weather = {};
                                    weather.conditionDesc = weather;
                                    game['weather'] = event.weather;
                                    game['startingLineupReady'] = 'False';
                                    //game player details
                                    players = [];
                                    //home team details
                                    homeTeamId = event.homeTeam.teamId;
                                    awayTeamId = event.awayTeam.teamId;
                                    //console.log(event.eventId);
                                    playersDatas = [];
                                    var playersDatasHome = await self.getHomePlayers(homeTeamId);
                                    var playersDatasAway = await self.getAwayPlayers(awayTeamId);
                                    playersDatas = playersDatasHome.concat(playersDatasAway);

                                    if (playersDatas) {
                                        slaryAvl = 0;
                                        playersDatas.forEach(function (playersData) {
                                            if (playersData.fanProjSalary && slaryAvl == 0)
                                                slaryAvl = (playersData.fanProjSalary > 0) ? 1 : 0
                                            var teamPlayers = {};// console.log(event.eventId); process.exit();
                                            teamPlayers.fName = playersData.fName;
                                            teamPlayers.lName = playersData.lName;
                                            teamPlayers.playerId = playersData.playerId;
                                            teamPlayers.posId = playersData.positions[0].posId;
                                            teamPlayers.posAbbr = playersData.positions[0].posAbbr;
                                            teamPlayers.CapValue = playersData.fanProjSalary;
                                            teamPlayers.isInjured = playersData.isInjured;
                                            competitionPlayer = {};
                                            competitionPlayer.compId = event.eventId;
                                            competitionPlayer.nameDisplay = [{
                                                htId: event.homeTeam.teamId, htName: event.homeTeam.tName, htAbbr: event.homeTeam.tAbbr, htCity: event.homeTeam.city, htScore: '', value: event.homeTeam.tAbbr + '@' + event.awayTeam.tAbbr,
                                                atId: event.awayTeam.teamId, atName: event.awayTeam.tName, atAbbr: event.awayTeam.tAbbr, atCity: event.awayTeam.city, atScore: ''
                                            }];

                                            teamPlayers.competition = competitionPlayer;
                                            teamPlayers.teamId = playersData.team.teamId;
                                            teamPlayers.teamAbbr = playersData.team.tAbbr;
                                            teamPlayers.fanProjSalary = playersData.fanProjSalary;
                                            teamPlayers.fanProjScore = playersData.fanProjPoints;
                                            players.push(teamPlayers);
                                        });
                                    }

                                    game['players'] = players;

                                    //away team details
                                    //awayTeamId = event.awayTeam.teamId
                                    League = {};
                                    League.leagueId = event.league.leagueId;
                                    League.name = event.league.name;
                                    League.abbr = event.league.abbr;
                                    leagues = [];
                                    leagues.push(League);
                                    var draftData = {
                                        season: event.season,
                                        sportId: event.sportId,
                                        // sName: event.league.abbr,
                                        league: leagues,
                                        contestList: [],
                                        sortOrder: 0,
                                        startTimeUTC: '',
                                        dgState: 'Upcoming',
                                        gameList: [game]
                                    };
                                    // console.log(draftData.gameList[0].players[10].competition.nameDisplay); process.exit();
                                    //console.log(draftData); process.exit();
                                    //saving or updating events data to DB
                                    if (slaryAvl) {
                                        insertdDraft = 1;
                                        async.eachSeries(daraftgroups, async function (daraftgroup, innerCb) {
                                            draftData.dgName = daraftgroup;
                                            //console.log(draftData.dgName);process.exit();
                                            checkExistDraft = await self.checkDraft(draftData);
                                            if (!checkExistDraft) {
                                                // console.log('insert');
                                                draftData.draftgroupId = await generalHelper.updateCounter('draftgroupId');
                                                draftInsert = await self.insertDraft(draftData);
                                            } else {
                                                // console.log('push');
                                                checkEventExistIndraftGroup = await self.checkEventInDraft(draftData);
                                                //console.log(checkEventExistIndraftGroup);
                                                //console.log(checkEventExistIndraftGroup.gameList.length);
                                                if (checkEventExistIndraftGroup.gameList.length < 1) {
                                                    console.log('pushInsert');
                                                    draftUpdate = await self.updateDraft(draftData);
                                                }
                                            }
                                            innerCb(null);
                                        });
                                    }
                                    //}
                                }
                                outCb(null);
                            });

                        }
                    });
                }
            }
            var drafts = await DraftGroupModel.find({ "sportId": 1 }, function () { });
            //console.log(drafts); process.exit();
            for (var k = 0; k < drafts.length; k++) {
                if (drafts[k].gameList.length < 2) {
                    await DraftGroupModel.remove({ draftgroupId: drafts[k].draftgroupId }, function (err) { });
                }
            }

        } catch (e) {
            throw e;
        }
    },

    getHomePlayers: async function (homeTeamId) {
        try {
            return await PlayerModel.find({ 'team.teamId': homeTeamId });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    getAwayPlayers: async function (awayTeamId) {
        try {
            return await PlayerModel.find({ 'team.teamId': awayTeamId });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    checkDraft: async function (draftData) {
        try {
            return await DraftGroupModel.findOne({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    insertDraft: async function (draftData) {
        try {
            return await DraftGroupModel.findOneAndUpdate({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season }, draftData, { upsert: true });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    checkEventInDraft: async function (draftData) {
        try {
            return await DraftGroupModel.findOne({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season }, { gameList: { $elemMatch: { eventId: draftData.gameList[0].eventId } } });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    updateDraft: async function (draftData) {
        try {
            return await DraftGroupModel.findOneAndUpdate({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season }, {
                $addToSet: {
                    gameList: draftData.gameList[0]
                }
            });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
}





