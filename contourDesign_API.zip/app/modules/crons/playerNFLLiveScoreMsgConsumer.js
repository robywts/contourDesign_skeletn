/**
 * Player MLB Live Score Module
 * @exports Cron/Player/MLB/LiveScore
 */
var PlayerScoreModel = require('../../models/playerScoreTest');
var DraftGroupModel = require('../../models/draftgroup');
var contestModel = require('../../models/contest');
// var UserModel = require('../../models/user');
var cronVar = require('./cronSettings');
//var moment = require('moment');
var fs = require('fs');
var xml2js = require('xml2js');
var Pusher = require('./helpers/pusherHelper');
var nflScoringRules = require('../../config/scoringRulesNFL');
var moment = cronVar.moment;
var request = cronVar.request;

var winston = require('winston');

var loggerGeneral = new(winston.Logger)({
    transports: [
        new(winston.transports.Console)(),
        new(winston.transports.File)({
            filename: './app/modules/crons/logs/cron_status.log'
        })
    ]
});

module.exports = {

    /**
    * Cron - To get all Player details from the xml file and parse it and update it to the db
    */
    nflPlayerScoreSocket: async function (fileName) {
        try {
            var logger = new(winston.Logger)({
                transports: [
                    new(winston.transports.Console)(),
                    new(winston.transports.File)({
                        filename: './app/modules/crons/logs/nfl_xml_parsing_consumer.log'
                        //filename: './logs/mlb_xml_parsing_consumer.log'
                    })
                ]
            });

            console.log('fileName: '+ fileName);

            var fileCont = fs.readFileSync('./temp/nfl/unprocessed/' + fileName);
            fileCont = fileCont.toString().replace('<?xml version="1.0" encoding="UTF-8"?>', '').trim();
            if (fileCont != '' && fileCont.indexOf("<nfl-event>") >= 0 && fileCont.indexOf("</nfl-event>") >= 0) { // if the file is not empty
                var parser = new xml2js.Parser();
                if (fileCont.indexOf("<nfl-event>") > 0) { //fix if the part of ping data is still in the file
                    var fileContArr = fileCont.split("<nfl-event>");
                    if (fileContArr[1]) {
                        fileCont = "<nfl-event>" + fileContArr[1];
                    }
                }

                parser.parseString(fileCont, async function (err, result) {
                    try {
                        if (err) {
                            logger.info('FileName: ' + fileName);
                            logger.info(err);
                        } else if (result) {
                            if (result['nfl-event']) {
                                var sportId = 1; // NFL
                                var eventCode = result['nfl-event']['gamecode'][0]['$']['code'];
                                var eventId = result['nfl-event']['gamecode'][0]['$']['global-id'];
                                var eventStatus = '';
                                var eventStatusId = result['nfl-event']['gamestate'][0]['$']['status'];
                                if(eventStatusId == 1 ){
                                    eventStatus = 'Pre-Game'
                                } else if(eventStatusId == 2 ){
                                    eventStatus = 'In-Progress'
                                }else if (eventStatusId == 4 ){
                                    eventStatus = 'Final'
                                }else if(eventStatusId == 5 ){
                                    eventStatus = 'Postponed'
                                }else if (eventStatusId == 9 ){
                                    eventStatus = 'Cancelled'
                                }else if (eventStatusId == 23 ){
                                    eventStatus = 'Delayed'
                                }
                                logger.info('FileName: ' + fileName + ' EventId: ' + eventId + ' eventStatus: ' + eventStatus);

                                if (eventStatus != 'Pre-Game') {
                                    var playerRecords = {};
                                    var eventDateTime = '';
                                    // if (result['nfl-event']['date']) {
                                    //     var dt = result['nfl-event']['date'][0]['$'];
                                    //     var t = result['nfl-event']['time'][0]['$'];
                                    //     try {
                                    //         var dtt = moment([dt['year'], dt['month'], dt['date'], t['hour'], t['minute'], 0, 0]).add({
                                    //             hours: t['utc-hour'],
                                    //             minutes: t['utc-minute']
                                    //         });
                                    //         var eventDateTime = dtt.format('YYYY-MM-DD hh:mm:ss A');
                                    //     } catch (e) {
                                    //         var eventDateTime = '';
                                    //     }
                                    // } else {
                                    //     var eventDateTime = '';
                                    // }
 
                                    var atBat = '';
                                    // if (result['nfl-event']['gamestate'][0]['batter']) {
                                    //     var atBat = result['nfl-event']['gamestate'][0]['batter'][0]['$']['global-id'];
                                    // }
                                    var atBall = '';
                                    // if (result['nfl-event']['gamestate'][0]['pitcher']) {
                                    //     var atBall = result['nfl-event']['gamestate'][0]['pitcher'][0]['$']['global-id'];
                                    // }

                                    var visitingScore = '';
                                    var homeScore = '';
                                    var visitingTeamAlias = '';
                                    var homeTeamAlias = '';
                                    var eventClock = '';
                                    var liveGameInfo = '';
                                    if (result['nfl-event']['visiting-team'] && result['nfl-event']['home-team']) {
                                        //var inning = result['nfl-event']['gamestate'][0]['game'][0]['$']['inning'];
                                        var quarter = result['nfl-event']['gamestate'][0]['$']['quarter'];

                                        // for (var i in result['nfl-event']['visiting-score']) {
                                        //     if (result['nfl-event']['visiting-score'][i]['$']['type'] == 'runs') {
                                        //         visitingScore = ' ' + result['nfl-event']['visiting-score'][i]['$']['number'];
                                        //         break;
                                        //     }
                                        // }
                                        if(result['nfl-event']['visiting-team'][0]['linescore'][0]['$']['score']){
                                            visitingScore = result['nfl-event']['visiting-team'][0]['linescore'][0]['$']['score']
                                        }
                                        
                                        // for (var i in result['nfl-event']['home-score']) {
                                        //     if (result['nfl-event']['home-score'][i]['$']['type'] == 'runs') {
                                        //         homeScore = ' ' + result['nfl-event']['home-score'][i]['$']['number'] + ' ';
                                        //         break;
                                        //     }
                                        // }
                                        if(result['nfl-event']['home-team'][0]['linescore'][0]['$']['score']){
                                            homeScore = result['nfl-event']['home-team'][0]['linescore'][0]['$']['score']
                                        }

                                        visitingTeamAlias = result['nfl-event']['visiting-team'][0]['team-name'][0]['$']['alias'];
                                        homeTeamAlias = result['nfl-event']['home-team'][0]['team-name'][0]['$']['alias'];

                                        // eventClock = ((result['nfl-event']['gamestate'][0]['game'][0]['$']['segment-division'] == 1) ? 'BOT' : 'TOP') +
                                        //     ' ' + inning + ((inning == 1) ? 'st' : ((inning == 2) ? 'nd' : ((inning == 3) ? 'rd' : 'th')));
                                        eventClock = quarter + ((quarter == 1) ?  'st' : ((quarter == 2) ? 'nd' : ((quarter == 3) ? 'rd' : 'th')));

                                        liveGameInfo = visitingTeamAlias + ' ' +
                                            visitingScore +
                                            ' @ ' +
                                            homeTeamAlias +  ' ' +
                                            homeScore +  ' ' +
                                            eventClock;
                                    }

                                    console.log(' quarter: '+ quarter + ' visitingScore: '+ visitingScore +' homeScore: '+ homeScore);
                                    console.log(' visitingTeamAlias: '+ visitingTeamAlias + ' homeTeamAlias: '+ homeTeamAlias +' eventClock: '+ eventClock);
                                    console.log('liveGameInfo: ' + liveGameInfo)

                                    var liveGameInfo2 = '';
                                    // if (result['nfl-event']['gamestate'][0]['batter'] && result['nfl-event']['gamestate'][0]['batter']) {
                                    //     if (result['nfl-event']['gamestate'][0]['batter'][0]['$']['first-name'] != '' && result['nfl-event']['gamestate'][0]['pitcher'][0]['$']['first-name'] != '') {
                                    //         liveGameInfo2 = '(' + result['nfl-event']['gamestate'][0]['batter'][0]['$']['batting-slot'] + ') ' + result['nfl-event']['gamestate'][0]['batter'][0]['$']['first-name'] + ' ' + result['nfl-event']['gamestate'][0]['batter'][0]['$']['last-name'] +
                                    //             ' (AT BAT) vs ' + result['nfl-event']['gamestate'][0]['pitcher'][0]['$']['first-name'] + ' ' + result['nfl-event']['gamestate'][0]['pitcher'][0]['$']['last-name'];
                                    //     }
                                    // }

                                    var downloadUpdate = 'N';
                                    var player = {};

                                    // ******
                                    await DraftGroupModel.update({
                                        'gameList.eventId': eventId
                                    }, {
                                        'gameList.$.gameStatus': eventStatus
                                    }, {
                                        multi: true
                                    });

                                    var dgs = await DraftGroupModel.find({
                                        'gameList.eventId': eventId
                                    }, 'gameList draftgroupId');


                                    for (var dg of dgs) {
                                        var status = '';
                                        var dgId = dg.draftgroupId;

                                        for (var thisGame of dg.gameList) {
                                            if (thisGame.eventId == eventId) {
                                                for (p of thisGame.players) { // fetching player details (DG->GameList->Players)
                                                    if (!player[p.playerId]) {
                                                        player[p.playerId] = {};
                                                    }
                                                    if (p.posGen) {
                                                        player[p.playerId]['posGen'] = p.posGen;
                                                    }

                                                    if (p.mValue) {
                                                        player[p.playerId]['multiplierVal'] = p.mValue.value;
                                                    }

                                                }
                                            }
                                        }

                                        var postponedMatchCnt = 0;
                                        var totalMatchCnt = dg.gameList.length;
                                        for (var g of dg.gameList) {
                                            if (g.gameStatus == 'In-Progress') {
                                                status = g.gameStatus;
                                                break;
                                            } else if (g.gameStatus == 'Cancelled') {
                                                // Do nothing
                                            } else if (g.gameStatus == 'Postponed') {
                                                postponedMatchCnt++;
                                                if (status == '') { // if all the matches are postponed
                                                    status == 'Postponed';
                                                }
                                            } else if (g.gameStatus == 'Final') {
                                                if (status == 'Upcoming') {
                                                    status = 'In-Progress';
                                                    break;
                                                }
                                                status = g.gameStatus;
                                            } else {
                                                if (status == 'Final') {
                                                    status = 'In-Progress';
                                                    break;
                                                }
                                                status = 'Upcoming';
                                            }
                                        }

                                        if (status == 'Final' && postponedMatchCnt == (totalMatchCnt - 1)) { // if n-1 matches gets postponed
                                            status = 'Postponed';
                                        }

                                        var contestStatus = 3;
                                        var dfStatus = 'Upcoming';
                                        if (status == 'Final') {
                                            contestStatus = 1
                                            dfStatus = 'Completed';
                                        } else if (status == 'In-Progress') {
                                            contestStatus = 2
                                            dfStatus = 'Live';
                                        } else if (status == 'Postponed') {
                                            contestStatus = 4
                                            dfStatus = 'Cancelled';
                                        }

                                        //**********    
                                        await DraftGroupModel.update({
                                            'draftgroupId': dgId
                                        }, {
                                            'dgState': dfStatus
                                        });

                                        await contestModel.update({
                                            'draftgroupId': dgId,
                                            'contestStatus': {
                                                $in: [1, 2, 3]
                                            }
                                        }, {
                                            'contestStatus': contestStatus
                                        }, {
                                            multi: true
                                        });

                                        logger.info('dgState : ' + dfStatus + '; contestStatus : ' + contestStatus); 

                                    }

                                    if (eventStatus == 'Final') { // fix for not to miss any player record if the status is final

                                        //**********  
                                        await PlayerScoreModel.update({
                                            'eventId': eventId
                                        }, {
                                            'eventStatus': eventStatus,
                                            'liveGameInfo': liveGameInfo,
                                            'liveGameInfo2': liveGameInfo2,
                                            //'isAtBat': false,
                                            //'possTeam': '',
                                            'homeScore': homeScore,
                                            'awayScore': visitingScore,
                                            'homeAbbr': homeTeamAlias,
                                            'awayAbbr': visitingTeamAlias,
                                            'clock': eventClock,
                                            'fileName': fileName
                                        }, {
                                            multi: true
                                        });

                                        logger.info('liveGameInfo : ' + liveGameInfo + '; liveGameInfo2 : ' + liveGameInfo2); 
                                    }

                                    if (eventStatus == 'In-Progress' || eventStatus == 'Final') { // consider inprogress and final only
                                        if (result['nfl-event']['home-team'] && result['nfl-event']['visiting-team']) {
                                            var homeTeamName = result['nfl-event']['home-team'][0]['team-name'][0]['$']['name'];
                                            var homeTeamId = result['nfl-event']['home-team'][0]['team-code'][0]['$']['id'];
                                            var visitingTeamName = result['nfl-event']['visiting-team'][0]['team-name'][0]['$']['name'];
                                            var visitingTeamId = result['nfl-event']['visiting-team'][0]['team-code'][0]['$']['id'];
                                            var battingTeam = '';

                                            console.log(' homeTeamName: '+ homeTeamName + ' homeTeamId: '+ homeTeamId );
                                            console.log(' visitingTeamName: '+ visitingTeamName + ' visitingTeamId: '+ visitingTeamId );

                                            if (result['nfl-event']['home-player-stats']) {
                                                var homeTeamLineup = result['nfl-event']['home-player-stats'][0]['home-player'];
                                                for (i in homeTeamLineup) { // looping the home team batting lineup
                                                    var playerId = homeTeamLineup[i]['player-code'][0]['$']['global-id'];
                                                    if (!player[playerId]) {
                                                        player[playerId] = {};
                                                        // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                    }
                                                    //if (player[playerId]['posGen'] == 'Hitter') { //only hitters are allowed in batting
                                                    playerRecords[playerId] = {};
                                                    playerRecords[playerId]['sportId'] = sportId;
                                                    playerRecords[playerId]['eventCode'] = eventCode;
                                                    playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                    playerRecords[playerId]['fileName'] = fileName;
                                                    playerRecords[playerId]['eventId'] = eventId;
                                                    playerRecords[playerId]['eventStatus'] = eventStatus;
                                                    playerRecords[playerId]['eventDateTime'] = eventDateTime;

                                                    //playerRecords[playerId]['isAtBat'] = (atBat == playerId) ? true : false;
                                                    playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                    playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                    // if (atBat == playerId) {
                                                    //     battingTeam = homeTeamAlias;
                                                    // }

                                                    playerRecords[playerId]['teamId'] = homeTeamId;
                                                    playerRecords[playerId]['teamName'] = homeTeamName;
                                                    playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                    playerRecords[playerId]['playerId'] = playerId;
                                                    //playerRecords[playerId]['playerPositionId'] = homeTeamLineup[i]['player-position'][0]['$']['id'];
                                                    //playerRecords[playerId]['playerPosition'] = homeTeamLineup[i]['player-position'][0]['$']['position'];
                                                    //playerRecords[playerId]['playerName'] = homeTeamLineup[i]['name'][0]['$']['first-name'] + ' ' + homeTeamLineup[i]['name'][0]['$']['last-name'];
                                                    playerRecords[playerId]['playerScore'] = 0;
                                                    playerRecords[playerId]['multiPlayerScore'] = {};

                                                    // playerRecords[playerId]['playerStats'] = {
                                                    //     "battingStats": {},
                                                    //     "pitchingStats": {}
                                                    // };
                                                    playerRecords[playerId]['playerStats'] = {};

                                                    if(homeTeamLineup[i]['rushing']){
                                                        playerRecords[playerId]['playerStats']['rushing-yards'] = {
                                                            'val': homeTeamLineup[i]['rushing'][0]['$']['yards'],
                                                            'pts': nflScoringRules.nflScore['rushing-yards']['pts'],
                                                            'abr': nflScoringRules.nflScore['rushing-yards']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing-yards']['val'] * playerRecords[playerId]['playerStats']['rushing-yards']['pts'];

                                                        if(playerRecords[playerId]['playerStats']['rushing-yards']['val'] > 100){
                                                            playerRecords[playerId]['playerStats']['rushing-yards-100'] = {
                                                            'val': homeTeamLineup[i]['rushing'][0]['$']['yards'],
                                                            'pts': nflScoringRules.nflScore['rushing-yards-100']['pts'],
                                                            'abr': nflScoringRules.nflScore['rushing-yards-100']['abr']
                                                            };
                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing-yards-100']['pts'];
                                                        }

                                                        playerRecords[playerId]['playerStats']['rushing-tds'] = {
                                                            'val': homeTeamLineup[i]['rushing'][0]['$']['tds'],
                                                            'pts': nflScoringRules.nflScore['rushing-tds']['pts'],
                                                            'abr': nflScoringRules.nflScore['rushing-tds']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing-tds']['val'] * playerRecords[playerId]['playerStats']['rushing-tds']['pts'];
                                                    }

                                                    if(homeTeamLineup[i]['passing']){
                                                        playerRecords[playerId]['playerStats']['passing-yards'] = {
                                                            'val': homeTeamLineup[i]['passing'][0]['$']['yards'],
                                                            'pts': nflScoringRules.nflScore['passing-yards']['pts'],
                                                            'abr': nflScoringRules.nflScore['passing-yards']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-yards']['val'] * playerRecords[playerId]['playerStats']['passing-yards']['pts'];

                                                        if(playerRecords[playerId]['playerStats']['passing-yards']['val'] > 100){
                                                            playerRecords[playerId]['playerStats']['passing-yards-100'] = {
                                                            'val': homeTeamLineup[i]['passing'][0]['$']['yards'],
                                                            'pts': nflScoringRules.nflScore['passing-yards-100']['pts'],
                                                            'abr': nflScoringRules.nflScore['passing-yards-100']['abr']
                                                            };
                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-yards-100']['pts'];
                                                        }

                                                        playerRecords[playerId]['playerStats']['passing-tds'] = {
                                                            'val': homeTeamLineup[i]['passing'][0]['$']['tds'],
                                                            'pts': nflScoringRules.nflScore['passing-tds']['pts'],
                                                            'abr': nflScoringRules.nflScore['passing-tds']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-tds']['val'] * playerRecords[playerId]['playerStats']['passing-tds']['pts'];

                                                        playerRecords[playerId]['playerStats']['passing-interceptions'] = {
                                                            'val': homeTeamLineup[i]['passing'][0]['$']['interceptions'],
                                                            'pts': nflScoringRules.nflScore['passing-interceptions']['pts'],
                                                            'abr': nflScoringRules.nflScore['passing-interceptions']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-interceptions']['val'] * playerRecords[playerId]['playerStats']['passing-interceptions']['pts'];
                                                    }

                                                    if(homeTeamLineup[i]['receiving']){
                                                        playerRecords[playerId]['playerStats']['receiving-yards'] = {
                                                            'val': homeTeamLineup[i]['receiving'][0]['$']['yards'],
                                                            'pts': nflScoringRules.nflScore['receiving-yards']['pts'],
                                                            'abr': nflScoringRules.nflScore['receiving-yards']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-yards']['val'] * playerRecords[playerId]['playerStats']['receiving-yards']['pts'];

                                                        if(playerRecords[playerId]['playerStats']['receiving-yards']['val'] > 100){
                                                            playerRecords[playerId]['playerStats']['receiving-yards-100'] = {
                                                            'val': homeTeamLineup[i]['receiving'][0]['$']['yards'],
                                                            'pts': nflScoringRules.nflScore['receiving-yards-100']['pts'],
                                                            'abr': nflScoringRules.nflScore['receiving-yards-100']['abr']
                                                            };
                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-yards-100']['pts'];
                                                        }

                                                        playerRecords[playerId]['playerStats']['receiving-tds'] = {
                                                            'val': homeTeamLineup[i]['receiving'][0]['$']['tds'],
                                                            'pts': nflScoringRules.nflScore['receiving-tds']['pts'],
                                                            'abr': nflScoringRules.nflScore['receiving-tds']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-tds']['val'] * playerRecords[playerId]['playerStats']['receiving-tds']['pts'];

                                                        playerRecords[playerId]['playerStats']['receiving-receptions'] = {
                                                            'val': homeTeamLineup[i]['receiving'][0]['$']['receptions'],
                                                            'pts': nflScoringRules.nflScore['receiving-receptions']['pts'],
                                                            'abr': nflScoringRules.nflScore['receiving-receptions']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-receptions']['val'] * playerRecords[playerId]['playerStats']['receiving-receptions']['pts'];
                                                    }

                                                    if(homeTeamLineup[i]['kick-returning']){
                                                        playerRecords[playerId]['playerStats']['kick-returning-tds'] = {
                                                            'val': homeTeamLineup[i]['kick-returning'][0]['$']['tds'],
                                                            'pts': nflScoringRules.nflScore['kick-returning-tds']['pts'],
                                                            'abr': nflScoringRules.nflScore['kick-returning-tds']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['kick-returning-tds']['val'] * playerRecords[playerId]['playerStats']['kick-returning-tds']['pts'];
                                                    }

                                                    if(homeTeamLineup[i]['punt-returning']){
                                                        playerRecords[playerId]['playerStats']['punt-returning-tds'] = {
                                                            'val': homeTeamLineup[i]['punt-returning'][0]['$']['tds'],
                                                            'pts': nflScoringRules.nflScore['punt-returning-tds']['pts'],
                                                            'abr': nflScoringRules.nflScore['punt-returning-tds']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['punt-returning-tds']['val'] * playerRecords[playerId]['playerStats']['punt-returning-tds']['pts'];
                                                    }
                                                    
                                                    if(homeTeamLineup[i]['fumbles-lost']){
                                                        playerRecords[playerId]['playerStats']['fumbles-lost-number'] = {
                                                            'val': homeTeamLineup[i]['fumbles-lost'][0]['$']['number'],
                                                            'pts': nflScoringRules.nflScore['fumbles-lost-number']['pts'],
                                                            'abr': nflScoringRules.nflScore['fumbles-lost-number']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['fumbles-lost-number']['val'] * playerRecords[playerId]['playerStats']['fumbles-lost-number']['pts'];
                                                    }

                                                    if(homeTeamLineup[i]['own-fumbles-recovered']){
                                                        playerRecords[playerId]['playerStats']['own-fumbles-recovered-tds'] = {
                                                            'val': homeTeamLineup[i]['own-fumbles-recovered'][0]['$']['tds'],
                                                            'pts': nflScoringRules.nflScore['own-fumbles-recovered-tds']['pts'],
                                                            'abr': nflScoringRules.nflScore['own-fumbles-recovered-tds']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['own-fumbles-recovered-tds']['val'] * playerRecords[playerId]['playerStats']['own-fumbles-recovered-tds']['pts'];
                                                    }

                                                    if(homeTeamLineup[i]['PAT']){

                                                        ///
                                                        /// Two more PAT items
                                                        ///
                                                        playerRecords[playerId]['playerStats']['PAT-made'] = {
                                                            'val': homeTeamLineup[i]['PAT'][0]['$']['made'],
                                                            'pts': nflScoringRules.nflScore['PAT-made']['pts'],
                                                            'abr': nflScoringRules.nflScore['PAT-made']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['PAT-made']['val'] * playerRecords[playerId]['playerStats']['PAT-made']['pts'];
                                                    }

                                                    if (!player[playerId]['multiplierVal']) {
                                                        // logger.info('Player Id (Hbatting) ' + playerId + ' has no mValue for event ' + eventId);
                                                        playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                    } else {
                                                        playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                    }
                                                }
                                            }

                                            if (result['nfl-event']['visiting-player-stats']) {
                                                var visitingTeamLineup = result['nfl-event']['visiting-player-stats'][0]['visiting-player'];
                                                for (i in visitingTeamLineup) { // looping the visiting team batting lineup
                                                    var playerId = visitingTeamLineup[i]['player-code'][0]['$']['global-id'];
                                                    if (!player[playerId]) {
                                                        player[playerId] = {};
                                                        // logger.info('Missing (VB) playerId: ' + playerId + ' for the event ' + eventId);
                                                    }
                                                    //if (player[playerId]['posGen'] == 'Hitter') { //only hitters are allowed in batting
                                                    playerRecords[playerId] = {};
                                                    playerRecords[playerId]['sportId'] = sportId;
                                                    playerRecords[playerId]['eventCode'] = eventCode;
                                                    playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                    playerRecords[playerId]['fileName'] = fileName;
                                                    playerRecords[playerId]['eventId'] = eventId;
                                                    playerRecords[playerId]['eventStatus'] = eventStatus;
                                                    playerRecords[playerId]['eventDateTime'] = eventDateTime;

                                                    //playerRecords[playerId]['isAtBat'] = (atBat == playerId) ? true : false;
                                                    playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                    playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                    // if (atBat == playerId) {
                                                    //     battingTeam = visitingTeamAlias;
                                                    // }

                                                    playerRecords[playerId]['teamId'] = visitingTeamId;
                                                    playerRecords[playerId]['teamName'] = visitingTeamName;
                                                    playerRecords[playerId]['teamAlias'] = visitingTeamAlias;
                                                    playerRecords[playerId]['playerId'] = playerId;
                                                    //playerRecords[playerId]['playerPositionId'] = visitingTeamLineup[i]['player-position'][0]['$']['id'];
                                                    //playerRecords[playerId]['playerPosition'] = visitingTeamLineup[i]['player-position'][0]['$']['position'];
                                                    //playerRecords[playerId]['playerName'] = visitingTeamLineup[i]['name'][0]['$']['first-name'] + ' ' + visitingTeamLineup[i]['name'][0]['$']['last-name'];
                                                    playerRecords[playerId]['playerScore'] = 0;
                                                    playerRecords[playerId]['multiPlayerScore'] = {};

                                                    // playerRecords[playerId]['playerStats'] = {
                                                    //     "battingStats": {},
                                                    //     "pitchingStats": {}
                                                    // };

                                                    playerRecords[playerId]['playerStats'] = {};

                                                    if(visitingTeamLineup[i]['rushing']){
                                                        playerRecords[playerId]['playerStats']['rushing-yards'] = {
                                                            'val': visitingTeamLineup[i]['rushing'][0]['$']['yards'],
                                                            'pts': nflScoringRules.nflScore['rushing-yards']['pts'],
                                                            'abr': nflScoringRules.nflScore['rushing-yards']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing-yards']['val'] * playerRecords[playerId]['playerStats']['rushing-yards']['pts'];

                                                        if(playerRecords[playerId]['playerStats']['rushing-yards']['val'] > 100){
                                                            playerRecords[playerId]['playerStats']['rushing-yards-100'] = {
                                                            'val': visitingTeamLineup[i]['rushing'][0]['$']['yards'],
                                                            'pts': nflScoringRules.nflScore['rushing-yards-100']['pts'],
                                                            'abr': nflScoringRules.nflScore['rushing-yards-100']['abr']
                                                            };
                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing-yards-100']['pts'];
                                                        }

                                                        playerRecords[playerId]['playerStats']['rushing-tds'] = {
                                                            'val': visitingTeamLineup[i]['rushing'][0]['$']['tds'],
                                                            'pts': nflScoringRules.nflScore['rushing-tds']['pts'],
                                                            'abr': nflScoringRules.nflScore['rushing-tds']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing-tds']['val'] * playerRecords[playerId]['playerStats']['rushing-tds']['pts'];
                                                    }

                                                    if(visitingTeamLineup[i]['passing']){
                                                        playerRecords[playerId]['playerStats']['passing-yards'] = {
                                                            'val': visitingTeamLineup[i]['passing'][0]['$']['yards'],
                                                            'pts': nflScoringRules.nflScore['passing-yards']['pts'],
                                                            'abr': nflScoringRules.nflScore['passing-yards']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-yards']['val'] * playerRecords[playerId]['playerStats']['passing-yards']['pts'];

                                                        if(playerRecords[playerId]['playerStats']['passing-yards']['val'] > 100){
                                                            playerRecords[playerId]['playerStats']['passing-yards-100'] = {
                                                            'val': visitingTeamLineup[i]['passing'][0]['$']['yards'],
                                                            'pts': nflScoringRules.nflScore['passing-yards-100']['pts'],
                                                            'abr': nflScoringRules.nflScore['passing-yards-100']['abr']
                                                            };
                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-yards-100']['pts'];
                                                        }

                                                        playerRecords[playerId]['playerStats']['passing-tds'] = {
                                                            'val': visitingTeamLineup[i]['passing'][0]['$']['tds'],
                                                            'pts': nflScoringRules.nflScore['passing-tds']['pts'],
                                                            'abr': nflScoringRules.nflScore['passing-tds']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-tds']['val'] * playerRecords[playerId]['playerStats']['passing-tds']['pts'];

                                                        playerRecords[playerId]['playerStats']['passing-interceptions'] = {
                                                            'val': visitingTeamLineup[i]['passing'][0]['$']['interceptions'],
                                                            'pts': nflScoringRules.nflScore['passing-interceptions']['pts'],
                                                            'abr': nflScoringRules.nflScore['passing-interceptions']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-interceptions']['val'] * playerRecords[playerId]['playerStats']['passing-interceptions']['pts'];
                                                    }

                                                    if(visitingTeamLineup[i]['receiving']){
                                                        playerRecords[playerId]['playerStats']['receiving-yards'] = {
                                                            'val': visitingTeamLineup[i]['receiving'][0]['$']['yards'],
                                                            'pts': nflScoringRules.nflScore['receiving-yards']['pts'],
                                                            'abr': nflScoringRules.nflScore['receiving-yards']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-yards']['val'] * playerRecords[playerId]['playerStats']['receiving-yards']['pts'];

                                                        if(playerRecords[playerId]['playerStats']['receiving-yards']['val'] > 100){
                                                            playerRecords[playerId]['playerStats']['receiving-yards-100'] = {
                                                            'val': visitingTeamLineup[i]['receiving'][0]['$']['yards'],
                                                            'pts': nflScoringRules.nflScore['receiving-yards-100']['pts'],
                                                            'abr': nflScoringRules.nflScore['receiving-yards-100']['abr']
                                                            };
                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-yards-100']['pts'];
                                                        }

                                                        playerRecords[playerId]['playerStats']['receiving-tds'] = {
                                                            'val': visitingTeamLineup[i]['receiving'][0]['$']['tds'],
                                                            'pts': nflScoringRules.nflScore['receiving-tds']['pts'],
                                                            'abr': nflScoringRules.nflScore['receiving-tds']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-tds']['val'] * playerRecords[playerId]['playerStats']['receiving-tds']['pts'];

                                                        playerRecords[playerId]['playerStats']['receiving-receptions'] = {
                                                            'val': visitingTeamLineup[i]['receiving'][0]['$']['receptions'],
                                                            'pts': nflScoringRules.nflScore['receiving-receptions']['pts'],
                                                            'abr': nflScoringRules.nflScore['receiving-receptions']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-receptions']['val'] * playerRecords[playerId]['playerStats']['receiving-receptions']['pts'];
                                                    }

                                                    if(visitingTeamLineup[i]['kick-returning']){
                                                        playerRecords[playerId]['playerStats']['kick-returning-tds'] = {
                                                            'val': visitingTeamLineup[i]['kick-returning'][0]['$']['tds'],
                                                            'pts': nflScoringRules.nflScore['kick-returning-tds']['pts'],
                                                            'abr': nflScoringRules.nflScore['kick-returning-tds']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['kick-returning-tds']['val'] * playerRecords[playerId]['playerStats']['kick-returning-tds']['pts'];
                                                    }

                                                    if(visitingTeamLineup[i]['punt-returning']){
                                                        playerRecords[playerId]['playerStats']['punt-returning-tds'] = {
                                                            'val': visitingTeamLineup[i]['punt-returning'][0]['$']['tds'],
                                                            'pts': nflScoringRules.nflScore['punt-returning-tds']['pts'],
                                                            'abr': nflScoringRules.nflScore['punt-returning-tds']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['punt-returning-tds']['val'] * playerRecords[playerId]['playerStats']['punt-returning-tds']['pts'];
                                                    }
                                                    
                                                    if(visitingTeamLineup[i]['fumbles-lost']){
                                                        playerRecords[playerId]['playerStats']['fumbles-lost-number'] = {
                                                            'val': visitingTeamLineup[i]['fumbles-lost'][0]['$']['number'],
                                                            'pts': nflScoringRules.nflScore['fumbles-lost-number']['pts'],
                                                            'abr': nflScoringRules.nflScore['fumbles-lost-number']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['fumbles-lost-number']['val'] * playerRecords[playerId]['playerStats']['fumbles-lost-number']['pts'];
                                                    }

                                                    if(visitingTeamLineup[i]['own-fumbles-recovered']){
                                                        playerRecords[playerId]['playerStats']['own-fumbles-recovered-tds'] = {
                                                            'val': visitingTeamLineup[i]['own-fumbles-recovered'][0]['$']['tds'],
                                                            'pts': nflScoringRules.nflScore['own-fumbles-recovered-tds']['pts'],
                                                            'abr': nflScoringRules.nflScore['own-fumbles-recovered-tds']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['own-fumbles-recovered-tds']['val'] * playerRecords[playerId]['playerStats']['own-fumbles-recovered-tds']['pts'];
                                                    }

                                                    if(visitingTeamLineup[i]['PAT']){

                                                        ///
                                                        /// Two more PAT items
                                                        ///
                                                        playerRecords[playerId]['playerStats']['PAT-made'] = {
                                                            'val': visitingTeamLineup[i]['PAT'][0]['$']['made'],
                                                            'pts': nflScoringRules.nflScore['PAT-made']['pts'],
                                                            'abr': nflScoringRules.nflScore['PAT-made']['abr']
                                                        };
                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['PAT-made']['val'] * playerRecords[playerId]['playerStats']['PAT-made']['pts'];
                                                    }



                                                    if (!player[playerId]['multiplierVal']) {
                                                        // logger.info('Player Id (Vbatting) ' + playerId + ' has no mValue for event ' + eventId);
                                                        playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                    } else {
                                                        playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                    }

                                                    //}
                                                }
                                            }

                                            //********
                                            await PlayerScoreModel.update({ // making the isAtBat false for an old player
                                                'eventId': eventId,
                                                //'isAtBat': 'true',
                                            }, {
                                                $set: {
                                                    'liveGameInfo': liveGameInfo,
                                                    'liveGameInfo2': liveGameInfo2,
                                                    'isAtBat': false,
                                                    'eventStatus': eventStatus,
                                                    //'possTeam': battingTeam,
                                                    'homeScore': homeScore,
                                                    'awayScore': visitingScore,
                                                    'homeAbbr': homeTeamAlias,
                                                    'awayAbbr': visitingTeamAlias,
                                                    'clock': eventClock
                                                }
                                            }, {
                                                upsert: false
                                            });

                                            var batterFound = 'N';
                                            var playerCnt = 0;
                                            for (var i in playerRecords) { // Updating the player records in the database
                                                playerCnt++;
                                                //playerRecords[i]['possTeam'] = battingTeam;

                                                playerRecords[i]['awayAbbr'] = visitingTeamAlias;
                                                playerRecords[i]['homeAbbr'] = homeTeamAlias;
                                                playerRecords[i]['awayScore'] = visitingScore;
                                                playerRecords[i]['homeScore'] = homeScore;
                                                playerRecords[i]['clock'] = eventClock;

                                                // if (playerRecords[i]['isAtBat'] == true) {
                                                //     batterFound = 'Y';
                                                // }

                                                //**********
                                                var playerUpdate = await PlayerScoreModel.update({
                                                    'playerId': playerRecords[i]['playerId'],
                                                    'eventId': playerRecords[i]['eventId']
                                                }, {
                                                    $set: playerRecords[i]
                                                }, {
                                                    upsert: true
                                                });

                                                logger.info('Inserted to db: ' + playerRecords[i]['eventId'] + '-' + playerRecords[i]['playerId'] + '-' + fileName);
                                                // logger.info(JSON.stringify(playerUpdate));

                                            }
                                            logger.info('Player Count: ' + playerCnt + ' in ' + fileName);

                                            if (batterFound == 'N' && atBat != '') { //if batter's record has not come with the data, update the existing record

                                                //********
                                                await PlayerScoreModel.update({
                                                    'playerId': atBat,
                                                    'eventId': eventId
                                                }, {
                                                    $set: {
                                                        'liveGameInfo': liveGameInfo,
                                                        'liveGameInfo2': liveGameInfo2,
                                                        'isAtBat': true,
                                                        'eventStatus': eventStatus,
                                                        'possTeam': battingTeam,
                                                        'homeScore': homeScore,
                                                        'awayScore': visitingScore,
                                                        'homeAbbr': homeTeamAlias,
                                                        'awayAbbr': visitingTeamAlias,
                                                        'clock': eventClock,
                                                        'fileName': fileName
                                                    }
                                                }, {
                                                    upsert: false
                                                });
                                            }
                                        }
                                    }


                                }
                            }
                        }
                    } catch (e) {
                        logger.info('FileName: ' + fileName);
                        logger.info(e);
                    }
                });
                fs.renameSync('./temp/nfl/unprocessed/' + fileName, './temp/nfl/processed/' + fileName);
            } 
        } catch (e) {
            logger.info(e);
        }
    },

    /**
     * Cron - To get all Player details from the DOWNLOADed xml file and parse it and update it to the db
     */
    nflPlayerScoreDownload: async function () {
        try {
            var logger = new(winston.Logger)({
                transports: [
                    new(winston.transports.Console)(),
                    new(winston.transports.File)({
                        filename: './app/modules/crons/logs/nfl_download_xml_parsing.log'
                    })
                ]
            });

            // var psData = await PlayerScoreModel.findOne({
            //     $or: [{
            //         $and: [{
            //                 'eventStatus': 'Final'
            //             },
            //             {
            //                 'downloadUpdate': 'N'
            //             },
            //             {
            //                 'eventCode': {
            //                     $exists: true
            //                 }
            //             }
            //         ]
            //     }, {
            //         $and: [{
            //                 'eventStatus': 'In-Progress'
            //             }, {
            //                 'createdAt': {
            //                     $lte: new Date(Date.now() - (1000 * 60 * 60 * 4)) // 4 hrs
            //                 }
            //             },
            //             {
            //                 'eventCode': {
            //                     $exists: true
            //                 }
            //             }
            //         ]
            //     }]
            // }, 'eventId eventCode eventStatus');

            psData = {
                eventCode: 20180820011
            };
            if (psData != null) {
                var downloadFile = 'NFL_FINALBOX_PRE$' + psData.eventCode + '.XML'; // to do
                // console.log(downloadFile);
                request({
                        'url': "http://downloads.stats.com/ContourDesign/" + downloadFile,
                        'auth': {
                            'user': 'ContourDesign',
                            'pass': 'football1738',
                            'sendImmediately': false
                        }
                    },
                    async function (err, response, body) {
                        try {
                            // parse the body as JSON
                            if (!err && response.statusCode == 200) {
                                var fileCont = body.toString().replace('<?xml version="1.0" encoding="UTF-8"?>', '').trim();
                                if (fileCont != '') { // if the file is not empty
                                    //console.log('File Downloaded: ' + downloadFile);
                                    var parser = new xml2js.Parser();
                                    parser.parseString(fileCont, async function (err, result) {
                                        try {
                                            if (err) {
                                                logger.info('FileName: ' + downloadFile);
                                                logger.info(err);
                                            } else if (result['sports-statistics']) {
                                                var playerRecords = {};
                                                var nflBoxScore = result['sports-statistics']['sports-boxscores'][0]['nfl-boxscores'][0]['nfl-boxscore'][0];
                                                if (nflBoxScore['date']) {
                                                    var dt = nflBoxScore['date'][0]['$'];
                                                    var t = nflBoxScore['time'][0]['$'];
                                                    try {
                                                        var dtt = moment([dt['year'], dt['month'], dt['date'], t['hour'], t['minute'], 0, 0]).add({
                                                            hours: t['utc-hour'],
                                                            minutes: t['utc-minute']
                                                        });
                                                        var eventDateTime = dtt.format('YYYY-MM-DD hh:mm:ss A');
                                                    } catch (e) {
                                                        var eventDateTime = '';
                                                    }
                                                } else {
                                                    var eventDateTime = '';
                                                }

                                                var sportId = 1; //NFL
                                                var eventCode = nflBoxScore['gamecode'][0]['$']['code'];
                                                var downloadUpdate = 'Y';
                                                var eventId = nflBoxScore['gamecode'][0]['$']['global-id'];
                                                var eventStatus = nflBoxScore['gamestate'][0]['$']['status'];
                                                var atBat = '';

                                                var visitingScore = '';
                                                var homeScore = '';
                                                var visitingTeamAlias = '';
                                                var homeTeamAlias = '';
                                                var eventClock = '';

                                                var liveGameInfo = '';
                                                var liveGameInfo2 = '';
                                                var possTeam = '';
                                                var player = {};

                                                logger.info('FileName: ' + downloadFile + ' EventId: ' + eventId + ' eventDateTime: ' + eventDateTime);
                                                //console.log('FileName: ' + downloadFile + ' EventId: ' + eventId + ' eventDateTime: ' + eventDateTime);

                                                await DraftGroupModel.update({
                                                    'gameList.eventId': eventId
                                                }, {
                                                    'gameList.$.gameStatus': eventStatus
                                                }, {
                                                    multi: true
                                                });

                                                var dgs = await DraftGroupModel.find({
                                                    'gameList.eventId': eventId
                                                }, 'gameList draftgroupId');
                                                //console.log('dgs: ' + ' -- ' + dgs.length);

                                                for (dg of dgs) {
                                                    var status = '';
                                                    var dgId = dg.draftgroupId;

                                                    for (var thisGame of dg.gameList) {
                                                        if (thisGame.eventId == eventId) {
                                                            for (p of thisGame.players) { // fetching player details (DG->GameList->Players)
                                                                if (!player[p.playerId]) {
                                                                    player[p.playerId] = {};
                                                                }
                                                                if (p.posGen) {
                                                                    player[p.playerId]['posGen'] = p.posGen;
                                                                }

                                                                if (p.mValue) {
                                                                    player[p.playerId]['multiplierVal'] = p.mValue.value;
                                                                }
                                                            }
                                                        }
                                                    }

                                                    var postponedMatchCnt = 0;
                                                    var totalMatchCnt = dg.gameList.length;
                                                    //console.log('dgName: ' + dg.dgName + ' totalMatchCnt: ' + totalMatchCnt);

                                                    for (var g of dg.gameList) {
                                                        if (g.gameStatus == 'In-Progress') {
                                                            status = g.gameStatus;
                                                            break;
                                                        } else if (g.gameStatus == 'Cancelled') {
                                                            // Do nothing
                                                        } else if (g.gameStatus == 'Postponed') {
                                                            postponedMatchCnt++;
                                                            if (status == '') { // if all the matches are postponed
                                                                status == 'Postponed';
                                                            }
                                                        } else if (g.gameStatus == 'Final') {
                                                            if (status == 'Upcoming') {
                                                                status = 'In-Progress';
                                                                break;
                                                            }
                                                            status = g.gameStatus;
                                                        } else {
                                                            if (status == 'Final') {
                                                                status = 'In-Progress';
                                                                break;
                                                            }
                                                            status = 'Upcoming';
                                                        }
                                                    }

                                                    if (status == 'Final' && postponedMatchCnt == (totalMatchCnt - 1)) { // if n-1 matches gets postponed
                                                        status = 'Postponed';
                                                    }

                                                    var contestStatus = 3;
                                                    var dfStatus = 'Upcoming';
                                                    if (status == 'Final') {
                                                        contestStatus = 1;
                                                        dfStatus = 'Completed';
                                                    } else if (status == 'In-Progress') {
                                                        contestStatus = 2;
                                                        dfStatus = 'Live';
                                                    } else if (status == 'Postponed') {
                                                        contestStatus = 4;
                                                        dfStatus = 'Cancelled';
                                                    }

                                                    await DraftGroupModel.update({
                                                        'draftgroupId': dgId
                                                    }, {
                                                        'dgState': dfStatus
                                                    });

                                                    await contestModel.update({
                                                        'draftgroupId': dgId,
                                                        'contestStatus': {
                                                            $in: [1, 2, 3]
                                                        }
                                                    }, {
                                                        'contestStatus': contestStatus
                                                    }, {
                                                        multi: true
                                                    });

                                                    //console.log('dgId: ' + dgId + ' dgState: ' + dfStatus + ' contestStatus: ' + contestStatus);    
                                                }

                                                if (eventStatus == 'Final') { // fix for not to miss any player record if the status is final
                                                    await PlayerScoreModel.update({
                                                        'eventId': eventId
                                                    }, {
                                                        'eventStatus': eventStatus,
                                                        'liveGameInfo': liveGameInfo,
                                                        'liveGameInfo2': liveGameInfo2,
                                                        'isAtBat': false,
                                                        'possTeam': '',
                                                        'homeScore': homeScore,
                                                        'awayScore': visitingScore,
                                                        'homeAbbr': homeTeamAlias,
                                                        'awayAbbr': visitingTeamAlias,
                                                        'clock': eventClock,
                                                        'downloadUpdate': downloadUpdate,
                                                        'fileName': downloadFile
                                                    }, {
                                                        multi: true
                                                    });
                                                }

                                                if (eventStatus == 'In-Progress' || eventStatus == 'Final') { // consider inprogress and final only
                                                    if (nflBoxScore['home-team'] && nflBoxScore['visiting-team']) {
                                                        var homeTeamName = nflBoxScore['home-team'][0]['team-name'][0]['$']['name'];
                                                        homeTeamAlias = nflBoxScore['home-team'][0]['team-name'][0]['$']['alias'];
                                                        var homeTeamId = nflBoxScore['home-team'][0]['team-code'][0]['$']['id'];
                                                        var visitingTeamName = nflBoxScore['visiting-team'][0]['team-name'][0]['$']['name'];
                                                        visitingTeamAlias = nflBoxScore['visiting-team'][0]['team-name'][0]['$']['alias'];
                                                        var visitingTeamId = nflBoxScore['visiting-team'][0]['team-code'][0]['$']['id'];

                                                         //console.log('homeTeamName: ' + homeTeamName + ' homeTeamAlias: ' + homeTeamAlias + ' homeTeamId: ' + homeTeamId);
                                                         //console.log('visitingTeamName: ' + visitingTeamName + ' visitingTeamAlias: ' + visitingTeamAlias + ' visitingTeamId: ' + visitingTeamId);  

                                                        // for (var i in nflBoxScore['visiting-score']) {
                                                        //     if (nflBoxScore['visiting-score'][i]['$']['type'] == 'runs') {
                                                        //         visitingScore = ' ' + nflBoxScore['visiting-score'][i]['$']['number'];
                                                        //         break;
                                                        //     }
                                                        // }
                                                        visitingScore = nflBoxScore['visiting-team'][0]['linescore'][0]['$']['score'];
                                                        // for (var i in nflBoxScore['home-score']) {
                                                        //     if (nflBoxScore['home-score'][i]['$']['type'] == 'runs') {
                                                        //         homeScore = ' ' + nflBoxScore['home-score'][i]['$']['number'] + ' ';
                                                        //         break;
                                                        //     }
                                                        // }
                                                        homeScore = nflBoxScore['home-team'][0]['linescore'][0]['$']['score'];

                                                        var inning = nflBoxScore['gamestate'][0]['$']['segment-number'];
                                                        //console.log('visitingScore: ' + visitingScore + ' homeScore: ' + homeScore + ' inning: ' + inning);
                                                        // eventClock = ((nflBoxScore['gamestate'][0]['$']['segment-division'] == 'Top') ? 'TOP' : 'BOT') +
                                                        //     ' ' + inning + ((inning == 1) ? 'st' : ((inning == 2) ? 'nd' : ((inning == 3) ? 'rd' : 'th')));
                                                        eventClock =  inning + ((inning == 1) ? 'st' : ((inning == 2) ? 'nd' : ((inning == 3) ? 'rd' : 'th')));
                                                        liveGameInfo = visitingTeamAlias + ' ' + visitingScore + ' @ ' + homeTeamAlias + ' ' + homeScore + ' ' + eventClock;

                                                        //console.log('eventClock: ' + eventClock + ' liveGameInfo: ' + liveGameInfo );

                                                        if (nflBoxScore['player-stats']) {
                                                            if(nflBoxScore['player-stats'][0]['home-player-stats']){
                                                                //Start Rushing
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['rushing']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['rushing'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        playerRecords[playerId]['playerStats']['rushing-yards'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['rushing-yards']['pts'],
                                                                            'abr': nflScoringRules.nflScore['rushing-yards']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing-yards']['val'] * playerRecords[playerId]['playerStats']['rushing-yards']['pts'];

                                                                        if(playerRecords[playerId]['playerStats']['rushing-yards']['val'] > 100){
                                                                            playerRecords[playerId]['playerStats']['rushing-yards-100'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['rushing-yards-100']['pts'],
                                                                            'abr': nflScoringRules.nflScore['rushing-yards-100']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing-yards-100']['pts'];
                                                                        }

                                                                        playerRecords[playerId]['playerStats']['rushing-tds'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['rushing-tds']['pts'],
                                                                            'abr': nflScoringRules.nflScore['rushing-tds']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing-tds']['val'] * playerRecords[playerId]['playerStats']['rushing-tds']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - Rushing    
                                                                //Start - Passing
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['passing']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['passing'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        playerRecords[playerId]['playerStats']['passing-yards'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['passing-yards']['pts'],
                                                                            'abr': nflScoringRules.nflScore['passing-yards']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-yards']['val'] * playerRecords[playerId]['playerStats']['passing-yards']['pts'];

                                                                        if(playerRecords[playerId]['playerStats']['passing-yards']['val'] > 300){
                                                                            playerRecords[playerId]['playerStats']['passing-yards-300'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['passing-yards-300']['pts'],
                                                                            'abr': nflScoringRules.nflScore['passing-yards-300']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-yards-300']['pts'];
                                                                        }

                                                                        playerRecords[playerId]['playerStats']['passing-tds'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['passing-tds']['pts'],
                                                                            'abr': nflScoringRules.nflScore['passing-tds']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-tds']['val'] * playerRecords[playerId]['playerStats']['passing-tds']['pts'];

                                                                        playerRecords[playerId]['playerStats']['passing-interceptions'] = {
                                                                            'val': playerEvent[i]['$']['interceptions'],
                                                                            'pts': nflScoringRules.nflScore['passing-interceptions']['pts'],
                                                                            'abr': nflScoringRules.nflScore['passing-interceptions']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-interceptions']['val'] * playerRecords[playerId]['playerStats']['passing-interceptions']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - Passing
                                                                //Start - Receiving
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['receiving']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['receiving'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        playerRecords[playerId]['playerStats']['receiving-yards'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['receiving-yards']['pts'],
                                                                            'abr': nflScoringRules.nflScore['receiving-yards']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-yards']['val'] * playerRecords[playerId]['playerStats']['receiving-yards']['pts'];

                                                                        if(playerRecords[playerId]['playerStats']['receiving-yards']['val'] > 100){
                                                                            playerRecords[playerId]['playerStats']['receiving-yards-100'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['receiving-yards-100']['pts'],
                                                                            'abr': nflScoringRules.nflScore['receiving-yards-100']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-yards-100']['pts'];
                                                                        }

                                                                        playerRecords[playerId]['playerStats']['receiving-tds'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['receiving-tds']['pts'],
                                                                            'abr': nflScoringRules.nflScore['receiving-tds']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-tds']['val'] * playerRecords[playerId]['playerStats']['receiving-tds']['pts'];

                                                                        playerRecords[playerId]['playerStats']['receiving-receptions'] = {
                                                                            'val': playerEvent[i]['$']['receptions'],
                                                                            'pts': nflScoringRules.nflScore['receiving-receptions']['pts'],
                                                                            'abr': nflScoringRules.nflScore['receiving-receptions']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-receptions']['val'] * playerRecords[playerId]['playerStats']['receiving-receptions']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - Receiving
                                                                //Start - kick-returning
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['kick-returning']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['kick-returning'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        playerRecords[playerId]['playerStats']['kick-returning-tds'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['kick-returning-tds']['pts'],
                                                                            'abr': nflScoringRules.nflScore['kick-returning-tds']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['kick-returning-tds']['val'] * playerRecords[playerId]['playerStats']['kick-returning-tds']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - kick-returning
                                                                //Start - punt-returning
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['punt-returning']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['punt-returning'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        playerRecords[playerId]['playerStats']['punt-returning-tds'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['punt-returning-tds']['pts'],
                                                                            'abr': nflScoringRules.nflScore['punt-returning-tds']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['punt-returning-tds']['val'] * playerRecords[playerId]['playerStats']['punt-returning-tds']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - punt-returning
                                                                //Start - fumbles-lost
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['fumbles-lost']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['fumbles-lost'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        playerRecords[playerId]['playerStats']['fumbles-lost-number'] = {
                                                                            'val': playerEvent[i]['$']['number'],
                                                                            'pts': nflScoringRules.nflScore['fumbles-lost-number']['pts'],
                                                                            'abr': nflScoringRules.nflScore['fumbles-lost-number']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['fumbles-lost-number']['val'] * playerRecords[playerId]['playerStats']['fumbles-lost-number']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - fumbles-lost
                                                                //Start - own-fumbles-recovered
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['own-fumbles-recovered']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['own-fumbles-recovered'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        playerRecords[playerId]['playerStats']['own-fumbles-recovered-tds'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['own-fumbles-recovered-tds']['pts'],
                                                                            'abr': nflScoringRules.nflScore['own-fumbles-recovered-tds']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['own-fumbles-recovered-tds']['val'] * playerRecords[playerId]['playerStats']['own-fumbles-recovered-tds']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - own-fumbles-recovered
                                                                //Start - PAT
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['PAT']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['PAT'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        ///
                                                                        /// Two more PAT items
                                                                        ///
                                                                        playerRecords[playerId]['playerStats']['PAT-made'] = {
                                                                            'val': playerEvent[i]['$']['made'],
                                                                            'pts': nflScoringRules.nflScore['PAT-made']['pts'],
                                                                            'abr': nflScoringRules.nflScore['PAT-made']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['PAT-made']['val'] * playerRecords[playerId]['playerStats']['PAT-made']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - PAT
                                                            }

                                                            if(nflBoxScore['player-stats'][0]['visiting-player-stats']){
                                                                //Start Rushing
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['rushing']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['rushing'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        playerRecords[playerId]['playerStats']['rushing-yards'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['rushing-yards']['pts'],
                                                                            'abr': nflScoringRules.nflScore['rushing-yards']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing-yards']['val'] * playerRecords[playerId]['playerStats']['rushing-yards']['pts'];

                                                                        if(playerRecords[playerId]['playerStats']['rushing-yards']['val'] > 100){
                                                                            playerRecords[playerId]['playerStats']['rushing-yards-100'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['rushing-yards-100']['pts'],
                                                                            'abr': nflScoringRules.nflScore['rushing-yards-100']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing-yards-100']['pts'];
                                                                        }

                                                                        playerRecords[playerId]['playerStats']['rushing-tds'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['rushing-tds']['pts'],
                                                                            'abr': nflScoringRules.nflScore['rushing-tds']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing-tds']['val'] * playerRecords[playerId]['playerStats']['rushing-tds']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - Rushing    
                                                                //Start - Passing
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['passing']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['passing'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        playerRecords[playerId]['playerStats']['passing-yards'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['passing-yards']['pts'],
                                                                            'abr': nflScoringRules.nflScore['passing-yards']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-yards']['val'] * playerRecords[playerId]['playerStats']['passing-yards']['pts'];

                                                                        if(playerRecords[playerId]['playerStats']['passing-yards']['val'] > 300){
                                                                            playerRecords[playerId]['playerStats']['passing-yards-300'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['passing-yards-300']['pts'],
                                                                            'abr': nflScoringRules.nflScore['passing-yards-300']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-yards-300']['pts'];
                                                                        }

                                                                        playerRecords[playerId]['playerStats']['passing-tds'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['passing-tds']['pts'],
                                                                            'abr': nflScoringRules.nflScore['passing-tds']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-tds']['val'] * playerRecords[playerId]['playerStats']['passing-tds']['pts'];

                                                                        playerRecords[playerId]['playerStats']['passing-interceptions'] = {
                                                                            'val': playerEvent[i]['$']['interceptions'],
                                                                            'pts': nflScoringRules.nflScore['passing-interceptions']['pts'],
                                                                            'abr': nflScoringRules.nflScore['passing-interceptions']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing-interceptions']['val'] * playerRecords[playerId]['playerStats']['passing-interceptions']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - Passing
                                                                //Start - Receiving
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['receiving']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['receiving'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        playerRecords[playerId]['playerStats']['receiving-yards'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['receiving-yards']['pts'],
                                                                            'abr': nflScoringRules.nflScore['receiving-yards']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-yards']['val'] * playerRecords[playerId]['playerStats']['receiving-yards']['pts'];

                                                                        if(playerRecords[playerId]['playerStats']['receiving-yards']['val'] > 100){
                                                                            playerRecords[playerId]['playerStats']['receiving-yards-100'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['receiving-yards-100']['pts'],
                                                                            'abr': nflScoringRules.nflScore['receiving-yards-100']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-yards-100']['pts'];
                                                                        }

                                                                        playerRecords[playerId]['playerStats']['receiving-tds'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['receiving-tds']['pts'],
                                                                            'abr': nflScoringRules.nflScore['receiving-tds']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-tds']['val'] * playerRecords[playerId]['playerStats']['receiving-tds']['pts'];

                                                                        playerRecords[playerId]['playerStats']['receiving-receptions'] = {
                                                                            'val': playerEvent[i]['$']['receptions'],
                                                                            'pts': nflScoringRules.nflScore['receiving-receptions']['pts'],
                                                                            'abr': nflScoringRules.nflScore['receiving-receptions']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving-receptions']['val'] * playerRecords[playerId]['playerStats']['receiving-receptions']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - Receiving
                                                                //Start - kick-returning
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['kick-returning']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['kick-returning'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        playerRecords[playerId]['playerStats']['kick-returning-tds'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['kick-returning-tds']['pts'],
                                                                            'abr': nflScoringRules.nflScore['kick-returning-tds']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['kick-returning-tds']['val'] * playerRecords[playerId]['playerStats']['kick-returning-tds']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - kick-returning
                                                                //Start - punt-returning
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['punt-returning']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['punt-returning'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        playerRecords[playerId]['playerStats']['punt-returning-tds'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['punt-returning-tds']['pts'],
                                                                            'abr': nflScoringRules.nflScore['punt-returning-tds']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['punt-returning-tds']['val'] * playerRecords[playerId]['playerStats']['punt-returning-tds']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - punt-returning
                                                                //Start - fumbles-lost
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['fumbles-lost']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['fumbles-lost'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        playerRecords[playerId]['playerStats']['fumbles-lost-number'] = {
                                                                            'val': playerEvent[i]['$']['number'],
                                                                            'pts': nflScoringRules.nflScore['fumbles-lost-number']['pts'],
                                                                            'abr': nflScoringRules.nflScore['fumbles-lost-number']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['fumbles-lost-number']['val'] * playerRecords[playerId]['playerStats']['fumbles-lost-number']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - fumbles-lost
                                                                //Start - own-fumbles-recovered
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['own-fumbles-recovered']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['own-fumbles-recovered'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        playerRecords[playerId]['playerStats']['own-fumbles-recovered-tds'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['own-fumbles-recovered-tds']['pts'],
                                                                            'abr': nflScoringRules.nflScore['own-fumbles-recovered-tds']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['own-fumbles-recovered-tds']['val'] * playerRecords[playerId]['playerStats']['own-fumbles-recovered-tds']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - own-fumbles-recovered
                                                                //Start - PAT
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['PAT']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['PAT'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                        }
                                                                        playerRecords[playerId]['sportId'] = sportId;
                                                                        playerRecords[playerId]['eventCode'] = eventCode;
                                                                        playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                        playerRecords[playerId]['fileName'] = downloadFile;
                                                                        playerRecords[playerId]['eventId'] = eventId;
                                                                        playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                        playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                        playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                        playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                        playerRecords[playerId]['possTeam'] = possTeam;
                                                                        playerRecords[playerId]['teamId'] = homeTeamId;
                                                                        playerRecords[playerId]['teamName'] = homeTeamName;
                                                                        playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                        playerRecords[playerId]['playerId'] = playerId;
                                                                        playerRecords[playerId]['playerScore'] = 0;
                                                                        playerRecords[playerId]['multiPlayerScore'] = {};
                                                                        playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                        playerRecords[playerId]['playerStats'] = {};
         
                                                                        ///
                                                                        /// Two more PAT items
                                                                        ///
                                                                        playerRecords[playerId]['playerStats']['PAT-made'] = {
                                                                            'val': playerEvent[i]['$']['made'],
                                                                            'pts': nflScoringRules.nflScore['PAT-made']['pts'],
                                                                            'abr': nflScoringRules.nflScore['PAT-made']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['PAT-made']['val'] * playerRecords[playerId]['playerStats']['PAT-made']['pts'];

                                                                        if (!player[playerId]['multiplierVal']) {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                        } else {
                                                                            playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - PAT
                                                            }
                                                        }

                                                        for (i in playerRecords) { // Updating the player records in the database
                                                            playerRecords[i]['awayAbbr'] = visitingTeamAlias;
                                                            playerRecords[i]['homeAbbr'] = homeTeamAlias;
                                                            playerRecords[i]['awayScore'] = visitingScore;
                                                            playerRecords[i]['homeScore'] = homeScore;
                                                            playerRecords[i]['clock'] = eventClock;

                                                            var playerUpdate = await PlayerScoreModel.update({
                                                                'playerId': playerRecords[i]['playerId'],
                                                                'eventId': playerRecords[i]['eventId']
                                                            }, {
                                                                $set: playerRecords[i]
                                                            }, {
                                                                upsert: true
                                                            });

                                                            logger.info('Inserted to db (from download): ' + playerRecords[i]['eventId'] + '-' + playerRecords[i]['playerId']);
                                                            // logger.info(JSON.stringify(playerUpdate));
                                                            //console.log('Inserted to db (from download): ' + playerRecords[i]['eventId'] + '-' + playerRecords[i]['playerId']);
                                                        }
                                                    }
                                                }
                                            }
                                        } catch (e) {
                                            logger.info('FileName: ' + downloadFile);
                                            logger.info(e);
                                        }
                                        // process.exit();
                                    });
                                } else {
                                    // process.exit();
                                }
                            } else {
                                logger.info('FileName: ' + downloadFile);
                                logger.info('Err: ' + err);
                                logger.info('ResonseCode: ' + response.statusCode);
                                // process.exit();
                            }
                        } catch (e) {
                            logger.info('FileName: ' + downloadFile);
                            logger.info(e);
                            // process.exit();
                        }
                    });
            } else {
                // process.exit();
            }
        } catch (e) {
            logger.info(e);
            // process.exit();
        }
    },
}