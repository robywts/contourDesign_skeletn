/**
 * General Module
 * @exports Cron/MLB/avgFppValue
 */
var PlayerModel = require('../../models/player');
var mlbScore = require('../../config/scoringRulesMLB');
var PlayerGames = require('../../models/playerGamesJson');
var async = require('async');

var self = module.exports = {
    /**
      * Cron - To update avgFpp value in PlayerModelSchema
      *
      */
    updateDraftAvgFPPValue: async function () {
        try {
          var allPlayers = await PlayerModel.find({sportId:2})
            for(var i = 0;i<allPlayers.length;i++){
              var avgFPP = 0
              var playerAllGames = await PlayerGames.findOne({playerId:allPlayers[i].playerId})
              if(playerAllGames !== null){
              var playerAllGamesAnnual = playerAllGames['gamesJson']['annualStats']
              if(playerAllGamesAnnual !== undefined){
                if(allPlayers[i].positions[0].posGen == "Hitter"){
                  avgFPP += mlbScore['mlbScore']['battingStats']['singles']['pts'] * playerAllGamesAnnual['battingStats']['hits']['singles']
                  avgFPP += mlbScore['mlbScore']['battingStats']['doubles']['pts'] * playerAllGamesAnnual['battingStats']['hits']['doubles']
                  avgFPP += mlbScore['mlbScore']['battingStats']['triples']['pts'] * playerAllGamesAnnual['battingStats']['hits']['triples']
                  avgFPP += mlbScore['mlbScore']['battingStats']['home-runs']['pts'] * playerAllGamesAnnual['battingStats']['hits']['homeRuns']
                  avgFPP += mlbScore['mlbScore']['battingStats']['runs-batted-in']['pts'] * playerAllGamesAnnual['battingStats']['runsBattedIn']['total']
                  avgFPP += mlbScore['mlbScore']['battingStats']['runs']['pts'] * playerAllGamesAnnual['battingStats']['runsScored']
                  avgFPP += mlbScore['mlbScore']['battingStats']['walks']['pts'] * playerAllGamesAnnual['battingStats']['walks']['total']
                  avgFPP += mlbScore['mlbScore']['battingStats']['stolen-bases']['pts'] * playerAllGamesAnnual['battingStats']['stolenBases']['total']
                  avgFPP = avgFPP/playerAllGamesAnnual['battingStats']['games']['total']
                }
                if(allPlayers[i].positions[0].posGen == "Pitcher"){
                  avgFPP += mlbScore['mlbScore']['pitchingStats']['innings-pitched']['pts'] * playerAllGamesAnnual['pitchingStats']['inningsPitched']
                  avgFPP += mlbScore['mlbScore']['pitchingStats']['strike-outs']['pts'] * playerAllGamesAnnual['pitchingStats']['strikeouts']['total']
                  avgFPP += mlbScore['mlbScore']['pitchingStats']['earned-runs']['pts'] * playerAllGamesAnnual['pitchingStats']['runsAllowed']['earnedRuns']
                  avgFPP += mlbScore['mlbScore']['pitchingStats']['hits']['pts'] * playerAllGamesAnnual['pitchingStats']['hitsAllowed']['total']
                  avgFPP += mlbScore['mlbScore']['pitchingStats']['wins']['pts'] * playerAllGamesAnnual['pitchingStats']['record']['wins']
                  avgFPP += mlbScore['mlbScore']['pitchingStats']['walks']['pts'] * playerAllGamesAnnual['pitchingStats']['walks']['total']
                  avgFPP += mlbScore['mlbScore']['pitchingStats']['hit-batsmen']['pts'] * playerAllGamesAnnual['pitchingStats']['hitBatsmen']
                  avgFPP += mlbScore['mlbScore']['pitchingStats']['gidp']['pts'] * playerAllGamesAnnual['pitchingStats']['groundIntoDoublePlays']['total']
                  avgFPP = avgFPP/playerAllGamesAnnual['pitchingStats']['games']['total']
                }
                var infoObj = {}
                var infoArray = []
                infoObj.title = "Average FP"
                infoObj.val = String(avgFPP)
                infoArray.push(infoObj)
                updateInfo = await PlayerModel.update({playerId:allPlayers[i].playerId},{"info":infoArray},{new:false},function(){})              }
              }
            }

        } catch (e) {
            throw e;
        }
    },

}
