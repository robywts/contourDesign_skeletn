/**
 * General Module
 * @exports Cron/MLB/RewardPoints
 */
var cronVar = require('./cronSettings');
var DraftGroupModel = require('../../models/draftgroup');
var ContestModel = require('../../models/contest');
var PrizeTempModel = require('../../models/prizeTemplate');
var UserModel = require('../../models/user');
var SettingModel = require('../../models/setting');
var moment = require('moment');
var generalHelper = require('./helpers/generalHelper');

var self = module.exports = {
    /**
     * Cron - To update lineups score value based on live player score
     */
    updateUserRewards: async function () {
        try {
            var week = moment.utc(new Date()).tz("EST5EDT").format('YYYY-MM-DD').replace(/-+/g, '');
            // var liveDrafts = await DraftGroupModel.find({ $or: [{ dgState: 'Live' }, { week: { $in: [prvWeek, week] } }] }).sort({ week: -1 }); //console.log(liveDrafts); process.exit();
            var liveDrafts = await DraftGroupModel.find({ dgState: 'Live', week: { $in: [week] } }); //console.log(liveDrafts); process.exit();
            var setting = await SettingModel.findOne({ settingId: 1 }, 'rewardToDollar');
            for (var i = 0; i < liveDrafts.length; i++) {
                var contests = await ContestModel.find({ draftgroupId: liveDrafts[i].draftgroupId, isGuaranteed: { $ne: true }, contestStatus: 2, rewardSettled: { $ne: 1 }, entryFees: { $gt: 0 } });
                for (var j = 0; j < contests.length; j++) {
                    var entrants = contests[j].entrants;
                    var reward = setting.rewardToDollar * contests[j].entryFees;
                    for (var k = 0; k < entrants.length; k++) {
                        var updateUserReward = await UserModel.findOneAndUpdate({ 'userId': entrants[k].userId }, {
                            $inc: {
                                'balanceRewards': reward,
                                'totalRewards': reward
                            }
                        }, {}, function (err, doc) { });
                    }
                    var contestsUpdate = await ContestModel.update({ contestId: contests[j].contestId }, { rewardSettled: 1, rewards: reward });
                }
            }

        } catch (e) {
            throw e;
        }
    },
}





