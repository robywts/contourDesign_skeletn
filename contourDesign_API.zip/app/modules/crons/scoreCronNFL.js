/**
 * General Module
 * @exports Cron/MLB/LineupScoreAndPosition
 */
var PlayerScoreModel = require('../../models/playerScore');
var DraftGroupModel = require('../../models/draftgroup');
var LineupModel = require('../../models/lineup');
var cronVar = require('./cronSettings');
var AutoContestLogics = require('../../models/autocontestlogics');
var ContestModel = require('../../models/contest');
var PrizeTempModel = require('../../models/prizeTemplate');
var UserModel = require('../../models/user');
var moment = require('moment');
var generalHelper = require('./helpers/generalHelper');
var async = require('async');
var Pusher = require('./helpers/pusherHelper');
var fbHelper = require('./helpers/fbHelper');
var NotificationsModel = require('../../models/notification');
var TransactionModel = require('../../models/transaction');

var self = module.exports = {
    /**
     * Cron - To update lineups score value based on live player score
     */
    updateScoreNFL: async function () {
        try {
            console.log("updateScoreNFL");
            //var week = moment.utc(new Date()).tz("EST5EDT").format('YYYY-MM-DD').replace(/-+/g, '');
            //var prvWeek = moment(new Date()).subtract(1, 'days').format('YYYY-MM-DD').replace(/-+/g, '');
            // var liveDrafts = await DraftGroupModel.find({ $or: [{ dgState: 'Live' }, { week: { $in: [prvWeek, week] } }] }).sort({ week: -1 }); //console.log(liveDrafts); process.exit();
            var today = new Date();
            var year = today.getFullYear();
            var weekInfo = await DraftGroupModel.findOne({ sportId: 1, dgState: { $ne: 'Upcoming' }, season: year }, 'week').sort({ createdAt: -1 }).limit(1);
            console.log("Week:-"); console.log(weekInfo != null ? weekInfo.week : 0);
            var week = weekInfo != null ? weekInfo.week : 0;
            //week = 5;
            //var liveDrafts = await DraftGroupModel.find({ dgState: { $ne: 'Upcoming' }, week: { $in: [prvWeek, week] } }).sort({ week: -1 }); //console.log(liveDrafts); process.exit();
            var liveDrafts = await DraftGroupModel.find({ sportId: 1, dgState: { $ne: 'Upcoming' }, week: week, season: year }).sort({ week: -1 });
            for (var i = 0; i < liveDrafts.length; i++) {
                // for (var j = 0; j < liveDrafts[i].gameList.length; j++) {
                async.eachSeries(liveDrafts[i].gameList, async function (gameSingle, out) {
                    if (gameSingle.gameStatus != 'Upcoming') {
                        var eventId = gameSingle.eventId;
                        var playerScores = await PlayerScoreModel.find({ eventId: eventId });
                        if (playerScores) {
                            // for (var k = 0; k < playerScores.length; k++) {
                            async.eachSeries(playerScores, async function (playerScoreSingle, outstCbb) {
                                //to update total player scores in all lineups where the player is found
                                var lineups = await LineupModel.find({ "players.playerId": playerScoreSingle.playerId, "players.eventId": gameSingle.eventId });
                                // for (var m = 0; m < lineups.length; m++) {
                                async.eachSeries(lineups, async function (lineupSingle, outrCbb) {
                                    var changeStandingScore = 1;
                                    //if the lineup is salary cap
                                    if (lineupSingle.gameTypeId > 5) {
                                        //updating player score to all lineups
                                        var update = await LineupModel.update({ "players.playerId": playerScoreSingle.playerId, "players.eventId": gameSingle.eventId }, { "$set": { "players.$.playerScore": playerScoreSingle.playerScore } }, { multi: true });
                                        var lineupUpdate = await LineupModel.aggregate([
                                            { "$match": { lineupId: lineupSingle.lineupId } },
                                            { "$unwind": "$players" },
                                            {
                                                "$group": {
                                                    "_id": "$_id",
                                                    "players": { "$push": "$players" },
                                                    "lineupId": { "$first": "$lineupId" },
                                                    "points": { "$sum": "$players.playerScore" }
                                                }
                                            }]);
                                        //console.log(lineupUpdate);
                                        //LineupModel.findOneAndUpdate({ 'lineupId': lineupSingle.lineupId }, { 'points': lineupUpdate[0].points }, {}, function (err, doc) { });
                                    }
                                    //if the lineup is multiplier
                                    else {
                                        /*var playerLive = gameSingle.players.find(function (obj) {
                                            return obj.playerId === playerScoreSingle.playerId;
                                        });*/
                                        // console.log(playerLive);process.exit();
                                        //updating player score to all lineups
                                        //var multiScore = await playerScoreSingle.playerScore * playerLive.mValue;//console.log(multiScore);process.exit();
                                        var multiScore = await playerScoreSingle.multiPlayerScore;//console.log(multiScore);process.exit();
                                        var update = await LineupModel.update({ "players.playerId": playerScoreSingle.playerId, "players.eventId": gameSingle.eventId }, { "$set": { "players.$.playerScore": playerScoreSingle.playerScore, "players.$.multiplierScore": multiScore } }, { multi: true });
                                        var lineupUpdate = await LineupModel.aggregate([
                                            { "$match": { lineupId: lineupSingle.lineupId } },
                                            { "$unwind": "$players" },
                                            {
                                                "$group": {
                                                    "_id": "$_id",
                                                    "players": { "$push": "$players" },
                                                    "lineupId": { "$first": "$lineupId" },
                                                    "points": { "$sum": "$players.multiplierScore" }
                                                }
                                            }]);
                                        //console.log(lineupUpdate);
                                        //LineupModel.findOneAndUpdate({ 'lineupId': lineupSingle.lineupId }, { 'points': lineupUpdate[0].points }, {}, function (err, doc) { });
                                    }
                                    var pointLineup = await LineupModel.findOne({ 'lineupId': lineupSingle.lineupId }, {}, {}, function (err, doc) { });
                                    //var pointLineupNW = await LineupModel.findOneAndUpdate({ 'lineupId': lineupSingle.lineupId }, { 'points': lineupUpdate[0].points, 'standingChange': changeStandingScore  }, {}, function (err, doc) { });
                                    if (pointLineup && pointLineup.points == lineupUpdate[0].points && pointLineup.standingChange != 1) {
                                        changeStandingScore = 0;
                                    }
                                    var pointLineupNW = await LineupModel.update({ 'lineupId': lineupSingle.lineupId }, { 'points': lineupUpdate[0].points, 'standingChange': changeStandingScore }, {}, function (err, doc) { });
                                    // }
                                    outrCbb(null);
                                });
                                // }
                                outstCbb(null);
                            });
                        }
                    }
                    //  }
                    out(null);
                });
            }

        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To update lineups positions based on live player score
     */
    updateLineupPositionNFL: async function () {
        try {
            console.log("updateLineupPositionNFL");
            //var week = moment.utc(new Date()).tz("EST5EDT").format('YYYY-MM-DD').replace(/-+/g, '');
            //var prvWeek = moment(new Date()).subtract(1, 'days').format('YYYY-MM-DD').replace(/-+/g, '');
            var today = new Date();
            var year = today.getFullYear();
            var weekInfo = await DraftGroupModel.findOne({ sportId: 1, dgState: { $ne: 'Upcoming' }, season: year }, 'week').sort({ createdAt: -1 }).limit(1);
            console.log("Week:-"); console.log(weekInfo != null ? weekInfo.week : 0);
            var week = weekInfo != null ? weekInfo.week : 0;
            //week = 5;
            //var liveDrafts = await DraftGroupModel.find({ dgState: { $ne: 'Upcoming' }, week: { $in: [prvWeek, week] } }).sort({ week: -1 });
            var liveDrafts = await DraftGroupModel.find({ sportId: 1, dgState: { $ne: 'Upcoming' }, week: week, season: year }).sort({ week: -1 });
            for (var i = 0; i < liveDrafts.length; i++) {
                //async.eachSeries(liveDrafts, async function (liveDraft, outest) {
                var contests = await ContestModel.find({ "draftgroupId": liveDrafts[i].draftgroupId, contestStatus: { $in: [1, 2] } });
                //for (var j = 0; j < contests.length; j++) {
                async.eachSeries(contests, async function (contestSingle, outrCb) {
                    var templateDetails = await PrizeTempModel.findOne({ "prizeTmpId": contestSingle.prizeTmpId });
                    if (!templateDetails || contestSingle.isAdminRow == true) {
                        templateDetails = {};
                        templateDetails.tmpName = 'Admin';
                        templateDetails.prizes = contestSingle.prizes;
                    }

                    var lineups = await LineupModel.find({ "contestId": contestSingle.contestId, points: { $gt: -100 } }).sort({ points: -1 });
                    //checking all the lineups have 0 points
                    var totalPoints = await (lineups).reduce(async function (a, b) {
                        return await a + b.points;
                    }, 0);
                    var positn = 0;
                    var count = 1;
                    var posNCount = [];
                    var changeStanding = 0;
                    var prevPoint = -1;
                    for (var k = 0; k < lineups.length; k++) {
                        // async.eachSeries(lineups, async function (lineupSingle, innrCb) {
                        if (prevPoint == lineups[k].points.value) {
                            //no position increment needed but position count needed
                            posNCount['position ' + positn] = ++count;
                        }
                        else {
                            positn = ++positn;
                            count = 1;
                            posNCount['position ' + positn] = count;
                        }
                        var lineupPosUpdate = await LineupModel.findOne({ 'lineupId': lineups[k].lineupId }, function () { });
                        // (positn != lineupPosUpdate.position && changeStanding == 0) ? changeStanding = 1 : '';
                        (lineupPosUpdate.standingChange == 1 && changeStanding == 0) ? changeStanding = 1 : '';
                        prevPoint = lineups[k].points.value;
                        await LineupModel.update({ 'lineupId': lineups[k].lineupId }, { 'position': positn, 'standingChange': 0 }, {}, function () { });
                    }
                    //  innrCb(null);
                    // });
                    //  console.log(templateDetails.tmpName); process.exit();
                    // sending push for updated lineup positions in a contests
                    if ((changeStanding || totalPoints == 0) && contestSingle.prizePool > 0) {
                        switch (templateDetails.tmpName) {
                            case 'Winner Take All':
                                for (var key in posNCount) {
                                    var pos = parseInt(key.split(' ')[1]);
                                    if (pos == 1) {
                                        var prizeAmt = contestSingle.prizePool / posNCount[key];
                                        var lineupWinUpdate = await LineupModel.update({ 'contestId': contestSingle.contestId, position: pos }, { 'winning': prizeAmt }, { multi: true });
                                    }
                                    else {
                                        var lineupWinUpdate = await LineupModel.update({ 'contestId': contestSingle.contestId, position: pos }, { 'winning': 0 }, { multi: true });
                                    }
                                }
                                break;
                            case 'Top 2 Win':
                                var totalPosNCount = 1;
                                for (var key in posNCount) {
                                    var pos = parseInt(key.split(' ')[1]);
                                    if (totalPosNCount < 3 && pos == 1 && posNCount[key] == 1) {
                                        var prizeAmt = contestSingle.prizePool * (2 / 3);
                                    }
                                    else if (totalPosNCount < 3 && pos == 2 && posNCount[key] == 1) {
                                        var prizeAmt = contestSingle.prizePool * (1 / 3);
                                    }
                                    else if (totalPosNCount < 3 && pos == 1 && posNCount[key] > 1) {
                                        var prizeAmt = contestSingle.prizePool / posNCount[key];
                                    }
                                    else if (totalPosNCount < 3 && pos == 2 && posNCount[key] > 1) {
                                        var prizeAmt = (contestSingle.prizePool * (1 / 3)) / posNCount[key];
                                    }
                                    else {
                                        var prizeAmt = 0
                                    }
                                    var lineupWinUpdate = await LineupModel.update({ 'contestId': contestSingle.contestId, position: pos }, { 'winning': prizeAmt }, { multi: true });
                                    totalPosNCount = totalPosNCount + posNCount[key];
                                }
                                break;
                            case 'Top 3 Win':
                                var totalPosNCount = 1;
                                for (var key in posNCount) {
                                    var pos = parseInt(key.split(' ')[1]);
                                    if (totalPosNCount < 4 && pos == 1 && posNCount[key] == 1) {
                                        var prizeAmt = contestSingle.prizePool * (50 / 100);
                                    }
                                    else if (totalPosNCount < 4 && pos == 2 && posNCount[key] == 1) {
                                        var prizeAmt = contestSingle.prizePool * (30 / 100);
                                    }
                                    else if (totalPosNCount < 4 && pos == 3 && posNCount[key] == 1) {
                                        var prizeAmt = contestSingle.prizePool * (20 / 100);
                                    }
                                    else if (totalPosNCount < 4 && pos == 1 && posNCount[key] == 2) {
                                        var prizeAmt = (contestSingle.prizePool * (80 / 100)) / posNCount[key];
                                    }
                                    else if (totalPosNCount < 4 && pos == 2 && posNCount[key] >= 2) {
                                        var prizeAmt = (contestSingle.prizePool * (50 / 100)) / posNCount[key];
                                    }
                                    else if (totalPosNCount < 4 && pos == 1 && posNCount[key] > 2) {
                                        var prizeAmt = (contestSingle.prizePool) / posNCount[key];
                                    }
                                    else if (totalPosNCount < 4 && pos == 3 && posNCount[key] >= 2) {
                                        var prizeAmt = (contestSingle.prizePool * (20 / 100)) / posNCount[key];
                                    }
                                    else {
                                        var prizeAmt = 0
                                    }
                                    var lineupWinUpdate = await LineupModel.update({ 'contestId': contestSingle.contestId, position: pos }, { 'winning': prizeAmt }, { multi: true });
                                    totalPosNCount = totalPosNCount + posNCount[key];
                                }
                                break;
                            default:
                                var prizeArr = templateDetails.prizes;
                                for (var i = 0; i < prizeArr.length; i++) {
                                    var lineupWinUpdate = await LineupModel.update({ 'contestId': contestSingle.contestId, position: { $gte: prizeArr[i].fromRange, $lte: prizeArr[i].toRange } }, { 'winning': prizeArr[i].amount }, { multi: true });
                                    var lastToRange = prizeArr[i].toRange;
                                }
                                var lineupWinReset = await LineupModel.update({ 'contestId': contestSingle.contestId, position: { $gt: lastToRange } }, { 'winning': 0 }, { multi: true });
                        }
                        var updatedLineups = await LineupModel.find({ "contestId": contestSingle.contestId, position: { $exists: true } });
                        var userIds = [];
                        for (var j in updatedLineups) {
                            userIds.push(updatedLineups[j].userId);
                        }
                        var usersDb = await UserModel.find({ "userId": { $in: userIds } });
                        var result = [];
                        var users = {};
                        for (var k in usersDb) {
                            users[usersDb[k].userId] = {
                                'userName': usersDb[k].userName,
                                'img': usersDb[k].imageName,
                                'currentLoginType': usersDb[k].currentLoginType,
                                'fbId': usersDb[k].loginTypes.FB.fbId
                            };
                        }
                        for (var l in updatedLineups) {
                            var row = {};
                            row.contestId = updatedLineups[j].contestId;
                            row.userId = updatedLineups[l].userId;
                            row.userName = users[row.userId].userName ? users[row.userId].userName : '';

                            if (users[row.userId].currentLoginType == 'FB' && users[row.userId].fbId) {
                                row.userImgName = fbHelper.getFbPicture(users[row.userId].fbId);
                            } else {
                                row.userImgName = (users[row.userId].img != '') ? process.env.PROFILE_IMAGE_URL + users[row.userId].img : '';
                            }

                            row.position = updatedLineups[l].position ? updatedLineups[l].position : '0';
                            row.score = updatedLineups[l].points ? updatedLineups[l].points : '0';
                            row.winning = updatedLineups[l].winning ? updatedLineups[l].winning : '';
                            row.lineupId = updatedLineups[l].lineupId ? updatedLineups[l].lineupId : '';
                            row.rem = updatedLineups[l].avgRemTimePerc ? updatedLineups[l].avgRemTimePerc : '';
                            result.push(row);
                        }
                        Pusher.sendPush('standings-channel', 'contestId-' + contestSingle.contestId, result);
                    }
                    //}
                    outrCb(null);
                });
            }
            //   outest(null);
            //  });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To update lineups positions based on live player score
     */
    removeUnsetPlayerScore: async function () {
        try {
            var week = moment.utc(new Date()).tz("EST5EDT").format('YYYY-MM-DD').replace(/-+/g, '');
            var prvWeek = moment(new Date()).subtract(1, 'days').format('YYYY-MM-DD').replace(/-+/g, '');
            // var liveDrafts = await DraftGroupModel.find({ $or: [{ dgState: 'Live' }, { week: { $in: [prvWeek, week] } }] }).sort({ week: -1 }); //console.log(liveDrafts); process.exit();
            var liveDrafts = await DraftGroupModel.find({ dgState: { $ne: 'Upcoming' }, week: { $in: [prvWeek, week] } }).sort({ week: -1 }); //console.log(liveDrafts); process.exit();
            for (var i = 0; i < liveDrafts.length; i++) {
                var lineups = await LineupModel.find({ draftgroupId: liveDrafts[i].draftgroupId, isReserved: { $ne: 1 } });
                for (var j = 0; j < lineups.length; j++) {
                    var lineupPlayers = lineups[j].players;
                    for (var k = 0; k < lineupPlayers.length; k++) {
                        var eventId = lineupPlayers[k].eventId;
                        var playerId = lineupPlayers[k].playerId;
                        var playerScores = await PlayerScoreModel.findOne({ eventId: eventId, playerId: playerId });
                        if (playerScores == null) {
                            var update = await LineupModel.update({ "players.playerId": playerId, "players.eventId": eventId }, { "$set": { "players.$.playerScore": 0, "players.$.multiplierScore": 0 } }, {
                                multi: true
                            });
                        }
                    }
                    var lineupUpdate = await LineupModel.aggregate([
                        { "$match": { lineupId: lineups[j].lineupId } },
                        { "$unwind": "$players" },
                        {
                            "$group": {
                                "_id": "$_id",
                                "players": { "$push": "$players" },
                                "lineupId": { "$first": "$lineupId" },
                                "points": { "$sum": "$players.playerScore" }
                            }
                        }]);
                    if (lineupUpdate[0].points == 0)
                        var pointLineupNW = await LineupModel.update({ 'lineupId': lineups[j].lineupId }, { 'points': lineupUpdate[0].points }, {}, function (err, doc) { });
                }
            }

        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - cron to distribute prize amount to users
     */
    winningDistribution: async function () {
        try {
            console.log("winningDistribution -----");

            //var prvWeek = moment(new Date()).subtract(1, 'days').format('YYYY-MM-DD').replace(/-+/g, '');
            //var prevDrafts = await DraftGroupModel.find({ dgState: 'Completed', week: prvWeek });     

            var prevDrafts;
            var currDate = moment(new Date()).format('YYYY-MM-DD');
            var prvDate = moment(new Date()).subtract(1, 'days').format('YYYY-MM-DD');
            console.log("Current Date - " + currDate + " Prev Date- " + prvDate);
            prevDrafts = await DraftGroupModel.find({ 'sportId': 1, 'dgState': "Completed", 'gameList.startTimeUTC': { "$gte": prvDate/*, "$lt" : currDate*/ } });

            for (var i = 0; i < prevDrafts.length; i++) {
                var lineups = await LineupModel.find({ draftgroupId: prevDrafts[i].draftgroupId, winning: { $gt: 0 }, winningSettled: { $ne: 1 } });
                for (var j = 0; j < lineups.length; j++) {
                    console.log(lineups[j].lineupId + '--' + lineups[j].winning);
                    var updateUserBalance = await UserModel.update({ 'userId': lineups[j].userId }, {
                        $inc: {
                            'balance': lineups[j].winning
                        }
                    }, {}, function (err, doc) { });
                    var lineupSettled = await LineupModel.update({ lineupId: lineups[j].lineupId }, { winningSettled: 1 });
                    //notification - start 
                    var contestDetail = await ContestModel.findOne({ "contestId": lineups[j].contestId });
                    //var notificationId = await generalHelper.updateCounter('notificationId'); //unique key
                    var notificationData = new NotificationsModel();
                    notificationData.userId = lineups[j].userId;
                    notificationData.message = "You won $" + lineups[j].winning + " from the " + contestDetail.contestName;
                    notificationData.isRead = 0;
                    notificationData.notificationTypeId = 2;
                    notificationData.deeplink = '';
                    notificationData.link = '';
                    var notificationUpdate = await notificationData.save();
                    //notification - end 
                    //transaction - start
                    var userDetail = await UserModel.findOne({ "userId": lineups[j].userId });
                    /*if (userDetail.currentLoginType == 'Normal') {
                        imageName = userDetail.imageName ? process.env.PROFILE_IMAGE_URL + userDetail.imageName : '';
                    } else if (userDetail.currentLoginType == 'FB') {
                        imageName = process.env.FB_IMAGE_URL.replace(new RegExp('{fbId}', "g"), userDetail.loginTypes.FB.fbId);
                    }*/
                    var transactionData = new TransactionModel();
                    transactionData.userId = lineups[j].userId;
                    transactionData.tranStatus = 1;
                    transactionData.tranType = 'WA';
                    transactionData.amount = lineups[j].winning;
                    transactionData.userName = userDetail.userName;
                    transactionData.userImg = userDetail.imageName;
                    transactionData.fName = userDetail.fName;
                    transactionData.lName = userDetail.lName;
                    var transUpdate = await transactionData.save();
                    //transaction - end
                }
            }

        } catch (e) {
            throw e;
        }
    },
}





