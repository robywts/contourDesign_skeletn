/**
 * Sport Ranking Module
 * @exports Cron/User/SportRanking
 */
var SportPointsModel = require('../../models/sportPoint');
var UserModel = require('../../models/user');
var RankImageModel = require('../../models/rankImage');
var async = require('async');

module.exports = {

    setUserRanking: async function () {
        try {
            var userInfo = await UserModel.find();
            if (userInfo != null) {                       
                for (var i = 0; i < userInfo.length; i++) {
                    console.log("User Id:- "+userInfo[i].userId);
                    var userRankImg;
                    var userRankName;
                    var rankTotal = 0;
                    if (userInfo[i].sportsRanking != null) {                       
                        for (var j = 0; j < (userInfo[i].sportsRanking).length; j++) {
                            //Sport ranking.
                            //console.log("Points--"+userInfo[i].sportsRanking[j].points);                            
                            var rankInfo = await SportPointsModel.find({ 'points': { $lte: userInfo[i].sportsRanking[j].points } }).sort({ 'pointId': -1 }).limit(1);
                            //console.log("Rankinfo:-"+rankInfo);
                           
                            //console.log("rankInfo ****************************************");
                            if (rankInfo.length > 0) {                               
                                if (rankInfo[0].rank != 0) {
                                    var imageInfo = await RankImageModel.findOne({ 'rank': rankInfo[0].rank })
                                    //console.log("rankInfo --------------------------------");console.log(rankInfo[0].subRank);
                                    var sportRankImg;
                                    if (imageInfo != null) {                                       
                                        sportRankImg = imageInfo.sportRankImage+ (userInfo[i].sportsRanking[j].sportId == 1 ? "_nfl" : 
                                                            (userInfo[i].sportsRanking[j].sportId == 2 ? "_mlb" :
                                                                (userInfo[i].sportsRanking[j].sportId == 3 ? "_nhl" :
                                                                    (userInfo[i].sportsRanking[j].sportId == 4 ? "_nba" :
                                                                        (userInfo[i].sportsRanking[j].sportId == 5 ? "_golf" :
                                                                    "")))));
                                    }
                                    else {
                                        if(rankInfo[0].rank == 0){
                                            sportRankImg = process.env.MAX_SPORT_RANK_IMG + (userInfo[i].sportsRanking[j].sportId == 1 ? "_nfl" : 
                                                                (userInfo[i].sportsRanking[j].sportId == 2 ? "_mlb" :
                                                                    (userInfo[i].sportsRanking[j].sportId == 3 ? "_nhl" :
                                                                        (userInfo[i].sportsRanking[j].sportId == 4 ? "_nba" :
                                                                            (userInfo[i].sportsRanking[j].sportId == 5 ? "_golf" :
                                                                        "")))));
                                        }
                                        else{
                                            sportRankImg = "empty"+ (userInfo[i].sportsRanking[j].sportId == 1 ? "_nfl" : 
                                                                (userInfo[i].sportsRanking[j].sportId == 2 ? "_mlb" :
                                                                    (userInfo[i].sportsRanking[j].sportId == 3 ? "_nhl" :
                                                                        (userInfo[i].sportsRanking[j].sportId == 4 ? "_nba" :
                                                                            (userInfo[i].sportsRanking[j].sportId == 5 ? "_golf" :
                                                                        "")))));
                                        }
                                    }

                                    var pointsForNextRank = 0;
                                    var pointsForNextSubRank = 0;
                                    var pointsForCurrentRank = 0;
                                    var pointsForCurrentSubRank = 0;;
                                    var nextRank = await SportPointsModel.find({ 'rank': { $gt: rankInfo[0].rank } }).limit(1);
                                    if (nextRank != null) {
                                        pointsForNextRank = nextRank[0].points;
                                    }
                                    else{
                                        pointsForNextRank = 0;
                                    }

                                    var requestedSubRank = rankInfo[0].subRank;
                                    var requestedRank = rankInfo[0].rank;
                                    if(rankInfo[0].subRank == 9){
                                        requestedSubRank = 0;
                                        requestedRank = parseInt(rankInfo[0].rank + 1);
                                    }
                                    else{
                                        requestedSubRank = parseInt(rankInfo[0].subRank) + 1;
                                    }
                                    var nextSubRank = await SportPointsModel.find({ 'rank': requestedRank, 'subRank': requestedSubRank }).limit(1);
                                    if (nextSubRank != null) {
                                        pointsForNextSubRank = nextSubRank[0].points;
                                    }
                                    else{
                                        pointsForNextSubRank = 0;
                                    }

                                    if(rankInfo[0].subRank == 0){
                                        pointsForCurrentRank = rankInfo[0].points;
                                    }
                                    else{
                                        var currentRank = await SportPointsModel.findOne({ 'rank': rankInfo[0].rank, 'subRank': 0 }).limit(1);
                                        if(currentRank){
                                            pointsForCurrentRank = currentRank.points;
                                        }
                                    }
                                    pointsForCurrentSubRank = rankInfo[0].points;

                                    await UserModel.findOneAndUpdate({
                                        'userId': userInfo[i].userId,
                                        'sportsRanking.sportId': userInfo[i].sportsRanking[j].sportId
                                    }, {
                                            $set: {
                                                'sportsRanking.$.rank': parseInt(rankInfo[0].rank),
                                                'sportsRanking.$.subRank': parseInt(rankInfo[0].subRank),
                                                'sportsRanking.$.imageName': sportRankImg,
                                                'sportsRanking.$.pointsForNextRank': pointsForNextRank,
                                                'sportsRanking.$.pointsForNextSubRank': pointsForNextSubRank,
                                                'sportsRanking.$.pointsForCurrentRank': pointsForCurrentRank,
                                                'sportsRanking.$.pointsForCurrentSubRank': pointsForCurrentSubRank                                                
                                            }
                                        }, {
                                            safe: true,
                                            upsert: true
                                        }, function (err, doc) {
                                            try {
                                                if (err) throw err;
                                            } catch (e) {
                                                console.log(e);
                                            }
                                        });

                                    var tempRank = parseFloat(rankInfo[0].rank + "." + parseInt(rankInfo[0].subRank));                                   
                                    rankTotal = parseFloat(rankTotal) + tempRank;
                                }
                            }
                            else{
                                if(userInfo[i].sportsRanking[j].points == 0){
                                    var firstRankInfo = await SportPointsModel.find().limit(1);
                                    if(firstRankInfo != null){
                                        var defaultImage = "empty"+ (userInfo[i].sportsRanking[j].sportId == 1 ? "_nfl" : 
                                        (userInfo[i].sportsRanking[j].sportId == 2 ? "_mlb" :
                                            (userInfo[i].sportsRanking[j].sportId == 3 ? "_nhl" :
                                                (userInfo[i].sportsRanking[j].sportId == 4 ? "_nba" :
                                                    (userInfo[i].sportsRanking[j].sportId == 5 ? "_golf" :
                                                "")))));
                                        await UserModel.findOneAndUpdate({
                                            'userId': userInfo[i].userId,
                                            'sportsRanking.sportId': userInfo[i].sportsRanking[j].sportId
                                        }, {
                                                $set: {                                                    
                                                    'sportsRanking.$.imageName': defaultImage,
                                                    'sportsRanking.$.pointsForNextRank': firstRankInfo[0].points,
                                                    'sportsRanking.$.pointsForNextSubRank': firstRankInfo[0].points,
                                                    'sportsRanking.$.pointsForCurrentRank': 0,
                                                    'sportsRanking.$.pointsForCurrentSubRank': 0                                                
                                                }
                                            }, {
                                                safe: true,
                                                upsert: true
                                            }, function (err, doc) {
                                                try {
                                                    if (err) throw err;
                                                } catch (e) {
                                                    console.log(e);
                                                }
                                            });        
                                    }            
                                }
                            }                           
                        }
                       
                        // User Ranking.          
                        if (rankTotal != 0) {
                            var mainRank = rankTotal.toString().split('.');                            
                            var userImageInfo = await RankImageModel.findOne({ 'rank': parseInt(mainRank[0]) })

                            if (userImageInfo != null) {
                                console.log("UserRankImage:- "+userImageInfo.userRankImage);
                                userRankImg = userImageInfo.userRankImage + "_" + (mainRank[1]? mainRank[1]:0);
                                userRankName = userImageInfo.userRankName;
                            }
                            else {
                                console.log("UserRankImage null:- "+process.env.MAX_USER_RANK_IMG + "_" + (mainRank[1]? mainRank[1]:0));
                                userRankImg = process.env.MAX_USER_RANK_IMG + "_" + (mainRank[1]? mainRank[1]:0);
                                userRankName = process.env.MAX_USER_RANK_NAME;
                            }
                            console.log("UserRankImage Final:- "+userRankImg);
                            await UserModel.findOneAndUpdate({
                                'userId': userInfo[i].userId
                            }, {
                                    $set: {
                                        'rank': mainRank[0] ? parseInt(mainRank[0]):0,
                                        'subRank': mainRank[1] ? parseInt(mainRank[1]):0,
                                        'rankName': userRankName,
                                        'rankImageName': userRankImg
                                    }
                                }, {
                                    safe: true,
                                    upsert: true
                                }, function (err, doc) {
                                    try {
                                        if (err) throw err;
                                    } catch (e) {
                                        console.log(e);
                                    }
                                });
                        }
                    }
                }                           
            }
        }
        catch (e) {
            throw e;
        }
    }

}