/**
 * General Module
 * @exports Cron/NBA/mValue
 */
var DraftGroupModel = require('../../models/draftgroup');
var contestModel = require('../../models/contest');
var EventModel = require('../../models/event');
var PlayerModel = require('../../models/player');
var cronVar = require('./cronSettings');
var async = require('async');
var moment = require('moment');

var self = module.exports = {
    /**
      * Cron - To update mValue value in a draftgroup schema
      * To update mValue in draftgroup schema based on the player fantasy salary
      */
    updateDraftMValue: async function () {
        try {
            var week = moment.utc(new Date()).tz("EST5EDT").format('YYYY-MM-DD').replace(/-+/g, '');
            var abort = false;
            for (var x = 1; x < 7 && !abort; x++) {
                var nxtWeek = moment(new Date()).add(x, 'days').format('YYYY-MM-DD').replace(/-+/g, '');
                var draftgroupsFound = await DraftGroupModel.findOne({ "week": nxtWeek, sportId: 4 });
                if (draftgroupsFound)
                    abort = true;
            }
            /* var events = await EventModel.find({ week: { $in: [week] }, sportId: 4 });
            var teamsArr = [];
            for (var i = 0; i < events.length; i++) {
                teamsArr.push(events[i].homeTeam.teamId);
                teamsArr.push(events[i].awayTeam.teamId);
            }
            //console.log(teamsArr.length); process.exit();
           var minmax = await PlayerModel.aggregate(
                [
                    { "$match": { "team.teamId": { $in: teamsArr } } },
                    { "$match": { "fanProjSalary": { "$gte": 1 } } },
                    { "$match": { "sportId": 4 } },
                    {
                        $group:
                        {
                            _id: "$positions.posGen",
                            min: { $min: "$fanProjSalary" },
                            max: { $max: "$fanProjSalary" }
                        }
                    }
                ]
            );*/
            var minmax = await DraftGroupModel.aggregate(
                [
                    { "$match": { "week": { $in: [parseInt(nxtWeek)] } } },
                    { "$match": { sportId: 4 } },
                    { $unwind: "$gameList" },
                    { $unwind: "$gameList.players" },
                    { "$match": { "gameList.players.fanProjSalary": { "$gte": 1 } } },
                    {
                        $group:
                        {
                            _id: "$gameList.players.posGen",
                            min: { $min: "$gameList.players.fanProjSalary" },
                            max: { $max: "$gameList.players.fanProjSalary" }
                        }
                    }
                ]
            );
            //var playersWeek = await PlayerModel.find({ "team.teamId": { $in: teamsArr }, sportId: 2 });
            var draftgroups = await DraftGroupModel.find({ "week": nxtWeek, sportId: 4 });
            for (var l = 0; l < draftgroups.length; l++) {
                var gamesList = draftgroups[l].gameList;
                for (var k = 0, len = gamesList.length; k < len; k++) {
                    console.log(draftgroups[l].draftgroupId);
                    if (gamesList[k].players != null) {
                        for (var j = 0; j < (gamesList[k].players).length; j++) {
                            for (var i = 0; i < minmax.length; i++) {
                                if (minmax[i]._id == gamesList[k].players[j].posGen) {
                                    //setting min salary for player if 0
                                    var playerSalary = (gamesList[k].players[j].fanProjSalary == 0 || isNaN(gamesList[k].players[j].fanProjSalary)) ? minmax[i].min : gamesList[k].players[j].fanProjSalary;
                                    mValue = await Math.round((1 + ((playerSalary - minmax[i].max) * (2 - 1)) / (minmax[i].min - minmax[i].max)) * 20) / 20;
                                    //updating mValue draftgroup schema
                                    var field = {};
                                    field["gameList." + k + ".players." + j + ".mValue"] = mValue;
                                    var updateM = await DraftGroupModel.update(
                                        { "draftgroupId": draftgroups[l].draftgroupId },

                                        { $set: field },
                                        {
                                            new: false
                                        }, function () { });
                                };
                            }
                        }
                    }
                }
            }

        } catch (e) {
            throw e;
        }
    },

}





