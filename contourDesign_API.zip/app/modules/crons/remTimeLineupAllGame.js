/**
 * General Module
 * @exports Cron/General/RemainingLineupTime
 */
var cronVar = require('./cronSettings');
var DraftGroupModel = require('../../models/draftgroup');
var UserModel = require('../../models/user');
var moment = require('moment');
var LineupModel = require('../../models/lineup');

var self = module.exports = {
    /**
     * Cron - To update lineup's player remaining time 
     */
    lineupRemainingTime: async function () {
        try {
            var liveDrafts = await DraftGroupModel.find({ dgState: { $in: ['Live'] } });
            for (var i = 0; i < liveDrafts.length; i++) {
                switch (liveDrafts[i].sportId) {
                    case 1:                       //NFL 3hrs
                        var totalTime = 180;      // minutes
                        break;
                    case 2:                       //MLB 2hrs 52 minutes
                        var totalTime = 172;      //minutes
                        break;
                    case 3:                       //NHL
                        // var totalTime = 172;
                        break;
                    case 4:                       //NBA
                        // var totalTime = 172;
                        break;
                    default:                       //GOLF
                        // var totalTime = 172;
                        break;
                }
                var lineups = await LineupModel.find({ draftgroupId: liveDrafts[i].draftgroupId, isReserved: { $ne: 1 } });
                for (var j = 0; j < lineups.length; j++) {


                    var st = await LineupModel.aggregate(
                        { "$match": { lineupId: lineups[j].lineupId } },
                        { $unwind: '$players' },
                        { $group: { _id: lineups[j].lineupId, minTime: { $min: '$players.eventST' }, maxTime: { $max: '$players.eventST' } } });
                    var remPlayerPerc = 0;
                    var totalGameStartTime = await Math.abs(st[0].maxTime - st[0].minTime);  //time diff between startingGameTime & lastGameTime 
                    var totalGameMinute = await totalTime + Math.floor((totalGameStartTime / 1000) / 60);  //adding sport time to min-&-max-gametime-diff and converting to minutes

                    var currntGameTime = await Math.abs(new Date() - st[0].minTime);  //calculating time diff between min-start-time and current-time
                    var remMinutes = await totalGameMinute - Math.floor((currntGameTime / 1000) / 60); //calculating total remaining time in minutes
                    if (remMinutes > 1)
                        remPlayerPerc = (remMinutes / totalGameMinute).toFixed(2);
                    /* var players = lineups[j].players; 
                     for (var k = 0; k < players.length; k++) {
                          var remPlayerPerc;
                          if (players[k].eventST <= new Date()) {
                              var diff = await Math.abs(new Date() - players[k].eventST);
                              var remMinutes = await totalTime - Math.floor((diff / 1000) / 60);
                              if (remMinutes < 1) {
                                  remPlayerPerc = 0;
                              }
                              else {
                                  remPlayerPerc = remMinutes / totalTime;
                              }
                          }
                          else {
                              remPlayerPerc = 1;
                          }
                          var update = await LineupModel.update({ "players.playerId": players[k].playerId, "players.eventId": players[k].eventId }, { "$set": { "players.$.remTimePerc": remPlayerPerc } }, {});
                      }
                      //update average of all event's remaining time to lineup
                      var lineupUpdate = await LineupModel.aggregate([
                          { "$match": { lineupId: lineups[j].lineupId } },
                          { "$unwind": "$players" },
                          {
                              "$group": {
                                  "_id": "$_id",
                                  "players": { "$push": "$players" },
                                  "lineupId": { "$first": "$lineupId" },
                                  "eventId": { "$players.eventId" },
                                  "totalRemTimePerc": { "$sum": "$players.remTimePerc" }
                              }
                          }]);
                      var avgRemTimePerc = (lineupUpdate[0].totalRemTimePerc / players.length).toFixed(2);
                      var pointLineupNW = await LineupModel.update({ 'lineupId': lineups[j].lineupId }, { 'avgRemTimePerc': avgRemTimePerc }, {}, function (err, doc) { });
                  */

                    var pointLineupNW = await LineupModel.update({ 'lineupId': lineups[j].lineupId }, { 'avgRemTimePerc': remPlayerPerc }, {}, function (err, doc) { });
                }
            }

        } catch (e) {
            throw e;
        }
    },
}





