/**
 * DraftGroup Module
 * @exports DraftGroup/Cron
 */
var DraftGroupModel = require('../../models/draftgroups');
var GameModel = require('../../models/event');
var PlayerModel = require('../../models/player');
var moment = require('moment');
var generalHelper = require('../mobile/helpers/generalHelper');
var cronVar = require('./cronSettings');
var async = require('async');

var self = module.exports = {
    /**
     * Cron - To create all predefined draftGroup set
     * To get all basic details related to players
     */

    getDraftGroupDetails: async function () {
        try {
            // var times = ['0', '1', '2', '3', '4', '5', '6',];
            // async.eachSeries(times, async function (time, outerCb) {
            var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            var events = GameModel.find({}, function (err, events) {
                if (err)
                    console.log(err);
                else {
                    //events.forEach(async function (event) {
                    // async.forEach(events, function (event, callback) {
                    async.eachSeries(events, async function (event, outCb) {
                        var zone = process.env.dest_zone;
                        var s = moment.utc(event.startTimeUTC).tz(zone).format('YYYY-MM-DD HH:mm:ss');
                        var localTime = new Date(s).toLocaleTimeString();
                        var localDate = new Date(s).toLocaleDateString();
                        var localHour = new Date(s).getHours()
                        // console.log(localDate); process.exit();
                        //var dateYMD = event.startTimeUTC.toISOString().split('T')[0];
                        // var dateYMD = s.toString().split('T')[0];
                        //var day = days[new Date(dateYMD).getDay()];
                        //console.log(new Date(localDate).getDay());process.exit();
                        var day = days[new Date(localDate).getDay()];
                        console.log(day); process.exit();
                        if (day == 'Sunday' && ((localHour >= 13) && (localHour <= 19))){

                        }
                        if ((day == 'Sunday' &&  (localHour >= 19)) || (day == 'Monday')){

                        }
                        if ((localHour >= '15:30') && (localHour <= 19)){

                        }
                        if (day == 'Thursday' || day == 'Friday' || day == 'Saturday' || day == 'Sunday' ||day == 'Monday'){

                        }
                        if ((day == 'Thursday' &&  (localHour >= 19)) || (day == 'Monday' &&  (localHour >= 19))){

                        }
                        if (day == 'Monday' &&  (localHour >= 19)){

                        }

                        game = {};
                        game['eventId'] = event.eventId;
                        game['startTimeUTC'] = event.startTimeUTC;
                        game['gameStatus'] = ''; //console.log(event.eventId);
                        //game player details
                        players = [];
                        //home team details
                        homeTeamId = event.homeTeam.teamId;
                        //console.log(event.eventId);
                        var playersDatas = await self.getHomePlayers(homeTeamId);
                        if (playersDatas) {

                            playersDatas.forEach(function (playersData) {
                                var teamPlayers = {}; console.log(event.eventId); process.exit();
                                teamPlayers.fName = playersData.fName;
                                teamPlayers.lName = playersData.lName;
                                teamPlayers.playerId = playersData.playerId;
                                teamPlayers.posId = playersData.positions[0].posId;
                                teamPlayers.posAbbr = playersData.positions[0].posAbbr;
                                teamPlayers.CapValue = playersData.fanProjSalary;
                                teamPlayers.isInjured = playersData.isInjured;
                                competitionPlayer = {};
                                competitionPlayer.compId = event.eventId;
                                competitionPlayer.nameDisplay = [{ htName: event.homeTeam.tAbbr, htScore: '' }, { value: '' }, { atName: event.homeTeam.tAbbr, bold: '', atScore: '' }];

                                teamPlayers.competition = competitionPlayer;
                                teamPlayers.teamId = playersData.team.teamId;
                                teamPlayers.teamAbbr = playersData.team.tAbbr;
                                teamPlayers.fanProjScore = playersData.fanProjPoints;
                                players.push(teamPlayers);
                            });
                        }

                        game['players'] = players;

                        //away team details
                        //awayTeamId = event.awayTeam.teamId
                        var draftData = {
                            draftgroupId: await generalHelper.updateCounter('draftgroupId'),
                            dgWeek: event.week,
                            dgSeason: event.season,
                            sportId: event.sportId,
                            sName: event.league.abbr,
                            contestList: [],
                            sortOrder: '',
                            gameList: [game]
                        };
                        console.log(event.eventId); process.exit();
                        //console.log(draftData); process.exit();
                        //saving or updating events data to DB
                        DraftGroupModel.findOneAndUpdate({ 'gameList.eventId': game['eventId'] }, draftData, { upsert: true }, function (err, doc) {
                            try {
                                if (err) throw err;
                                console.log('Success draft');
                            } catch (e) {
                                cronVar.logger.info(e);
                            }
                        });
                        //}
                        outCb(null);
                    });
                }
            });
            //  outerCb(null);
            //});




            /*
                        //events.forEach(async function (event) {
                       // async.mapSeries(events, function (event, callback) {
                           async.forEach(events, function (event, callback) {
                            var zone = process.env.dest_zone;
                            //var s = moment.utc(event.startTimeUTC).tz(zone).format();
                            //console.log(s);process.exit();
                            var dateYMD = new Date(event.startTimeUTC).toISOString().split('T')[0];
                            var day = days[new Date(dateYMD).getDay()];
                            //console.log(day);
                            if (day == 'Sunday') {
                                console.log(event.eventId);
                                game = {};
                                game['eventId'] = event.eventId;
                                game['startTimeUTC'] = event.startTimeUTC;
                                game['gameStatus'] = '';
                                //game player details
                                players = [];
                                //home team details
                                homeTeamId = event.homeTeam.teamId;
                                var playersDatas = PlayerModel.find({ 'team.teamId': homeTeamId }, function (err, playersDatas) {
                                    if (err)
                                        console.log(err);
                                    else {
                                        // console.log(event.eventId); process.exit();
                                        //callback();
                                    }
                                }); console.log('dsadsas');
                                process.exit();
                            }
                            callback();
                        }, function (err) {
                            // All contacts are processed
                            callback();
                        });*/



        } catch (e) {
            throw e;
        }
    },

    getHomePlayers: async function (homeTeamId) {
        return await PlayerModel.find({ 'team.teamId': homeTeamId });
    }

}





