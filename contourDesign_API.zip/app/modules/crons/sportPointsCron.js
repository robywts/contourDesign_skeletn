/**
 * Sport points Module
 * @exports Cron/User/SportPoints
 */
var SportPointsModel = require('../../models/sportPoint');
var async = require('async');

module.exports = {

    configureSportRankingPoints: async function () {
        try {
            var currentRank;
            var currentSubRank;
            var currentPoints;
            var currentIValue;            
            var currentLValue;
            var currentKValue;
            var currentPointId;
            var currentJValue;

            var rank;
            var subRank;
            var points;
            var iValue;
            var jValue;
            var lValue;
            var kValue;
            var pointId;
            var totalRank = parseInt(process.env.MAX_RANK);
            
            var pointData = await SportPointsModel.find().sort({'pointId': -1}).limit(1);     
            
            if(pointData != null){                          
                currentRank = pointData[0].rank;
                currentSubRank = pointData[0].subRank;
                currentPoints = pointData[0].points;
                currentIValue = pointData[0].iValue;                
                currentLValue = pointData[0].lValue;
                currentKValue = pointData[0].kValue;
                currentJValue = pointData[0].jValue;
                currentPointId = pointData[0].pointId;   
                             
                var pointsCollection = [];
                var i = currentRank;
                do {                    
                    lValue = currentLValue + 1;
                    kValue = currentKValue + 1;
                    if(currentJValue >= 2.5){
                        jValue = 2 + (lValue / 4);
                    }
                    else{
                        jValue = 2 + (lValue / 10);
                    }
                    
                    iValue = currentIValue + (5 * jValue);
                    points = currentPoints + iValue;

                    if(currentSubRank == 9){
                        rank = currentRank + 1;
                        subRank = 0;
                    }
                    else{
                        rank = currentRank;
                        subRank = currentSubRank + 1;
                    }

                    pointId = currentPointId + 1;

                    currentRank = rank;
                    currentSubRank = subRank;
                    currentPoints = points;
                    currentIValue = iValue;
                    currentLValue = lValue;
                    currentKValue = kValue;
                    currentJValue = jValue;
                    currentPointId = pointId;

                    var row = {};
                    row.pointId = pointId;
                    row.rank = rank;
                    row.subRank = subRank;
                    row.points = points;
                    row.iValue = iValue;
                    row.jValue = jValue;
                    row.lValue = lValue;
                    row.kValue = kValue;
                    row.createdAt = new Date().toISOString();
                    row.updatedAt = new Date().toISOString();
                    pointsCollection.push(row);

                    i = currentRank;                    
                }
                while(i < totalRank);
                
                if(pointsCollection != null)
                {
                   var resultSet = await SportPointsModel.collection.insert(pointsCollection);
                }
            }
        }
        catch (e) {
            throw e;
        }
    }

}