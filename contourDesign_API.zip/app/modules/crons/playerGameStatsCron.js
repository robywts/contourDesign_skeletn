/**
 * Player Games Stats Module
 * @exports Cron/Player/Game/Stats
 */
var PlayerGamesModel = require('../../models/playerGamesJson');
var cronVar = require('./cronSettings');
var Stats = require('./helpers/stats');
var request = cronVar.request;

var winston = require('winston');

var loggerGeneral = new(winston.Logger)({
    transports: [
        new(winston.transports.Console)(),
        new(winston.transports.File)({
            filename: './app/modules/crons/logs/cron_status.log'
        })
    ]
});

var logger = new(winston.Logger)({
    transports: [
        new(winston.transports.Console)(),
        new(winston.transports.File)({
            filename: './app/modules/crons/logs/player_games_stats_fetch.log'
        })
    ]
});

module.exports = {

    /**
     * Cron - To get all Player details (with games) from the stats and parse it and update it to the db
     */
    playerGameByGameStats: function (statsType, game) {
        try {
            loggerGeneral.info('PlayerGameStats STARTED - ' + statsType + ' - ' + game);
            var requestUrl = process.env.PLAYER_API; // NFL
            switch (game) {
                case '1': // NFL
                    {
                        requestUrl = process.env.PLAYER_API;
                        break;
                    }
                case '2': // MLB
                    {
                        requestUrl = process.env.MLB_PLAYER_API;
                        break;
                    }
                case '3': // NHL
                    {
                        requestUrl = process.env.NHL_PLAYER_API;
                        break;
                    }
                case '4': // NBA
                    {
                        requestUrl = process.env.NBA_PLAYER_API;
                        break;
                    }
                case '5': // GOLF
                    {
                        requestUrl = process.env.GOLF_PLAYER_API;
                        break;
                    }
            }
            var sigg = Stats.statsCred();
            var request = cronVar.request;
            request(requestUrl + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                function (err, response, body) {
                    try {
                        if (!err && response.statusCode == 200) {
                            var parsedBody = JSON.parse(body);
                            if (game == '5') { //GOLF
                                var arrResult = parsedBody.apiResults[0].league.subLeague.players;
                            } else {
                                var arrResult = parsedBody.apiResults[0].league.players;
                            }
                            module.exports.getPlayerStats(arrResult, statsType, game);
                        } else {
                            if (err != '') {
                                logger.info(err);
                            } else if (response) {
                                if (response.statusCode != '404') {
                                    logger.info('Get Player List Response code: ' + response.statusCode);
                                }
                            }
                        }
                    } catch (e) {
                        // logger.info(requestUrl);
                        // logger.info(statsType);
                        // logger.info(game);
                        logger.info('Request for player list');
                        logger.info(e);
                    }
                });
        } catch (e) {
            logger.info('Function for player list');
            logger.info(e);
        }
    },

    /**
     * Subtask of the PlayerGameByGameStats cron
     * @param {Array} players
     * @param {String} statsType (allGames or annualStats)
     */
    getPlayerStats: async function (players, statsType, game) {
        try {
            var start = new Date().getTime();
            while ((new Date().getTime() - start) < 500) { // for delay
                //loop here
            }

            // var logger = new(winston.Logger)({
            //     transports: [
            //         new(winston.transports.Console)(),
            //         new(winston.transports.File)({
            //             filename: './app/modules/crons/logs/player_games_stats_fetch.log'
            //         })
            //     ]
            // });

            var player = players.pop();
            if (player.isActive == false) {
                if (players.length > 0) {
                    module.exports.getPlayerStats(players, statsType, game);
                }
            } else { // if true
                var requestUrl = process.env.PLAYER_GAME_BY_GAME; // NFL
                switch (game) {
                    case '1': // NFL
                        {
                            requestUrl = process.env.PLAYER_GAME_BY_GAME;
                            break;
                        }
                    case '2': // MLB
                        {
                            requestUrl = process.env.MLB_PLAYER_GAME_BY_GAME;
                            break;
                        }
                    case '3': // NHL
                        {
                            requestUrl = process.env.NHL_PLAYER_GAME_BY_GAME;
                            break;
                        }
                    case '4': // NBA
                        {
                            requestUrl = process.env.NBA_PLAYER_GAME_BY_GAME;
                            break;
                        }
                    case '5': // GOLF
                        {
                            requestUrl = process.env.GOLF_PLAYER_GAME_BY_GAME;
                            break;
                        }
                }

                if (statsType == 'allGames') {
                    requestUrl = requestUrl + player.playerId + '/events/' + '?eventTypeId=1&api_key=' + cronVar.apiKey + '&sig=' + Stats.statsCred();
                } else { //annualStats
                    requestUrl = requestUrl + player.playerId + '?api_key=' + cronVar.apiKey + '&sig=' + Stats.statsCred();
                }
                request(requestUrl,
                    (err, response, body) => {
                        try {
                            // console.log('Remaining: ' + players.length);
                            if (!err && response.statusCode == 200) {
                                var parsedBody = JSON.parse(body);
                                if (statsType == 'allGames') {
                                    if (game == '5') { // GOLF
                                        var set = {
                                            'gamesJson.allGames': parsedBody.apiResults[0].league.subLeague.players[0].seasons[0].eventType[0].splits[0],
                                            'sportsId': game
                                        };
                                    } else {
                                        var set = {
                                            'gamesJson.allGames': parsedBody.apiResults[0].league.players[0].seasons[0].eventType[0].splits[0],
                                            'sportsId': game
                                        };
                                    }
                                } else { //annualStats
                                    if (game == '5') { // GOLF
                                        var set = {
                                            'gamesJson.annualStats': parsedBody.apiResults[0].league.subLeague.players[0].seasons[0].eventType[0].splits[0].golferStats,
                                            'sportsId': game
                                        };
                                    } else if (game == '3') { // NHL
                                        var set = {
                                            'gamesJson.annualStats': parsedBody.apiResults[0].league.players[0].seasons[0].eventType[0].splits[0].skaterStats,
                                            'sportsId': game
                                        };
                                    } else {
                                        var set = {
                                            'gamesJson.annualStats': parsedBody.apiResults[0].league.players[0].seasons[0].eventType[0].splits[0].playerStats,
                                            'sportsId': game
                                        };
                                    }
                                }
                                PlayerGamesModel.update({
                                    'playerId': player.playerId
                                }, {
                                    $set: set
                                }, {
                                    upsert: true
                                }, function (err, doc) {
                                    try {
                                        if (err != null) {
                                            logger.info(err);
                                        } else {
                                            logger.info('Inserted to db: ' + player.playerId);
                                        }
                                    } catch (e) {
                                        logger.info('Find and update catch');
                                        logger.info(e);
                                    }
                                });
                                if (players.length > 0) {
                                    module.exports.getPlayerStats(players, statsType, game);
                                }
                            } else {
                                if (err != null) {
                                    logger.info(err);
                                } else if (response) {
                                    if (response.statusCode != '404') {
                                        logger.info('Response code: ' + response.statusCode + ' for  playerId: ' + player.playerId);
                                    }
                                }

                                if (players.length > 0) {
                                    module.exports.getPlayerStats(players, statsType, game);
                                }
                            }
                        } catch (e) {
                            logger.info('Request for player stats');
                            logger.info(e);
                        }
                    });
            }
            if (players.length <= 0) {
                loggerGeneral.info('PlayerGameStats ENDED - ' + statsType + ' - ' + game);
            }
        } catch (e) {
            logger.info('Function for player stats');
            logger.info(e);
        }
    },
}