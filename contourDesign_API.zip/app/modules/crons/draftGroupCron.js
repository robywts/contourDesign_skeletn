/**
 * DraftGroup Module
 * @exports Cron/NFL/DraftGroup
 */
var DraftGroupModel = require('../../models/draftgroup');
var GameModel = require('../../models/event');
var PlayerModel = require('../../models/player');
var moment = require('moment');
var generalHelper = require('./helpers/generalHelper');
var cronVar = require('./cronSettings');
var async = require('async');
var AutoContestLogics = require('../../models/autocontestlogics');
var ContestModel = require('../../models/contest');

var self = module.exports = {
    /**
     * Cron - To create all predefined draftGroup set
     * To get all basic details related to players
     */

    getDraftGroupDetails: async function () {
        try {
            // var times = ['0', '1', '2', '3', '4', '5', '6',];
            // async.eachSeries(times, async function (time, outerCb) {
            var currSeason = moment(new Date()).format('YYYY');
            var nxtThirtyDay = moment(new Date()).add(30, 'days').format('YYYY-MM-DD');
            var withInThirtyDayEvent = await GameModel.findOne({ "sportId": 1, 'season': currSeason, 'startTimeUTC': { $lt: nxtThirtyDay } });
            if (withInThirtyDayEvent) {
                var nxtDay = moment(new Date()).add(2, 'days').format('YYYY-MM-DD'); //cron running every monday, hence fetching the games starting after wednesday
                var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                var events = await GameModel.find({ "sportId": 1, 'season': currSeason, 'startTimeUTC': { $gt: nxtDay } }); //console.log(events.length); process.exit();
                /* if (err)
                     console.log(err);
                 else {*/
                //events.forEach(async function (event) {
                // async.forEach(events, function (event, callback) {
                //   async.eachSeries(events, async function (event, outCb) {
                for (var i = 0; i < events.length; i++) {
                    var zone = process.env.dest_zone;
                    var s = moment.utc(events[i].startTimeUTC).tz(zone).format('YYYY-MM-DD HH:mm:ss');
                    var localTime = new Date(s).toLocaleTimeString();
                    var localDate = new Date(s).toLocaleDateString();
                    var localHour = new Date(s).getHours();
                    var localMinute = new Date(s).getMinutes();
                    //console.log(localMinute); process.exit();
                    //var dateYMD = events[i].startTimeUTC.toISOString().split('T')[0];
                    // var dateYMD = s.toString().split('T')[0];
                    //var day = days[new Date(dateYMD).getDay()];
                    //console.log(new Date(localDate).getDay());process.exit();
                    var day = days[new Date(localDate).getDay()];
                    var dgName = '';
                    var sortOrder = '';
                    daraftgroups = [];
                    //console.log(day); process.exit();
                    if (day == 'Sunday' && ((localHour >= 13) && (localHour <= 19))) {
                        dgName = 'NFL - Sunday Main';
                        sortOrder = 0;
                        daraftgroups.push({ dgName, sortOrder });
                    }
                    if ((day == 'Sunday' && (localHour >= 19)) || (day == 'Monday')) {
                        dgName = 'NFL - Sun and Mon Night';
                        sortOrder = 2;
                        daraftgroups.push({ dgName, sortOrder });
                    }
                    if (day == 'Sunday' && ((localHour == 15 && localMinute >= 30) || (localHour >= 16)) && ((localHour < 19) || (localHour == 19 && localMinute < 1))) {
                        dgName = 'NFL - Sunday Afternoon';
                        sortOrder = 3;
                        daraftgroups.push({ dgName, sortOrder });
                    }
                    if (day == 'Thursday' || day == 'Friday' || day == 'Saturday' || day == 'Sunday' || day == 'Monday') {
                        dgName = 'NFL - All Games';
                        sortOrder = 4;
                        daraftgroups.push({ dgName, sortOrder });
                    }
                    if ((day == 'Thursday' && (localHour >= 19)) || (day == 'Monday' && (localHour >= 19))) {
                        dgName = 'NFL - Thu and Mon Night';
                        sortOrder = 5;
                        daraftgroups.push({ dgName, sortOrder });
                    }
                    if (day == 'Monday' && (localHour >= 19)) {
                        dgName = 'NFL - Monday Night';
                        sortOrder = 6;
                        daraftgroups.push({ dgName, sortOrder });
                    }
                    if (day == 'Sunday' && ((localHour >= 13) && ((localHour == 15 && localMinute <= 30) || localHour <= 14))) {
                        dgName = 'NFL - Sunday Early';
                        sortOrder = 1;
                        daraftgroups.push({ dgName, sortOrder });
                    }
                    //console.log(daraftgroups); process.exit();

                    game = {};
                    game['eventId'] = events[i].eventId;
                    game['startTimeUTC'] = events[i].startTimeUTC;
                    game['gameStatus'] = ''; //console.log(events[i].eventId);
                    game['venueName'] = events[i].venueName;
                    weather = {};
                    weather.conditionDesc = weather;
                    game['weather'] = events[i].weather;
                    game['startingLineupReady'] = 'False';
                    //game player details
                    players = [];
                    //home team details
                    homeTeamId = events[i].homeTeam.teamId;
                    awayTeamId = events[i].awayTeam.teamId;
                    //console.log(events[i].eventId);
                    var playersDatas = [];
                    var playersDatasHome = [];
                    var playersDatasAway = [];
                    playersDatasHome = await self.getHomePlayers(homeTeamId);
                    playersDatasAway = await self.getAwayPlayers(awayTeamId);
                    playersDatas = playersDatasHome.concat(playersDatasAway);

                    if (playersDatas) {
                        var players = [];
                        // playersDatas.forEach(function (playersData) {
                        for (var k = 0; k < playersDatas.length; k++) {
                            var teamPlayers = {};// console.log(events[i].eventId); process.exit();
                            teamPlayers.fName = playersDatas[k].fName;
                            teamPlayers.lName = playersDatas[k].lName;
                            teamPlayers.playerId = playersDatas[k].playerId;
                            teamPlayers.uniform = playersDatas[k].uniform;
                            teamPlayers.posId = playersDatas[k].positions[0].posId;
                            teamPlayers.posAbbr = playersDatas[k].positions[0].posAbbr;
                            teamPlayers.CapValue = playersDatas[k].fanProjSalary;
                            teamPlayers.isInjured = playersDatas[k].isInjured;
                            competitionPlayer = {};
                            competitionPlayer.compId = events[i].eventId;
                            var recHT = {};
                            var recAT = {};
                            recHT.wins = events[i].homeTeam.record ? events[i].homeTeam.record.wins : '';
                            recHT.losses = events[i].homeTeam.record ? events[i].homeTeam.record.losses : '';
                            recAT.wins = events[i].awayTeam.record ? events[i].awayTeam.record.wins : '';
                            recAT.losses = events[i].awayTeam.record ? events[i].awayTeam.record.losses : '';
                            competitionPlayer.nameDisplay = [{
                                htId: events[i].homeTeam.teamId, htName: events[i].homeTeam.tName, htAbbr: events[i].homeTeam.tAbbr, htCity: events[i].homeTeam.city, htScore: events[i].homeTeam.score, value: events[i].awayTeam.tAbbr + '@' + events[i].homeTeam.tAbbr,
                                htRecord: recHT, atId: events[i].awayTeam.teamId, atName: events[i].awayTeam.tName, atAbbr: events[i].awayTeam.tAbbr, atCity: events[i].awayTeam.city, atScore: events[i].awayTeam.score, atRecord: recAT
                            }];

                            teamPlayers.competition = competitionPlayer;
                            teamPlayers.teamId = playersDatas[k].team.teamId;
                            teamPlayers.teamAbbr = playersDatas[k].team.tAbbr;
                            teamPlayers.fanProjSalary = playersDatas[k].fanProjSalary;
                            teamPlayers.fanProjScore = playersDatas[k].fanProjPoints;
                            teamPlayers.info = playersDatas[k].info ? playersDatas[k].info : '';
                            players.push(teamPlayers);
                            // });
                        }
                    }

                    game['players'] = players;

                    //away team details
                    //awayTeamId = events[i].awayTeam.teamId
                    League = {};
                    League.leagueId = events[i].league.leagueId;
                    League.name = events[i].league.name;
                    League.abbr = events[i].league.abbr;
                    leagues = [];
                    leagues.push(League);
                    var draftData = {
                        week: events[i].week,
                        eventTypeId: events[i].eventTypeId,
                        season: events[i].season,
                        sportId: 1,
                        autoContest: 0,
                        // sName: events[i].league.abbr,
                        league: leagues,
                        contestList: [],
                        //sortOrder: 0,
                        startTimeUTC: '',
                        dgState: 'Upcoming',
                        gameList: [game]
                    };
                    // console.log(draftData.gameList[0].players[10].competition.nameDisplay); process.exit();
                    //console.log(draftData); process.exit();
                    //saving or updating events data to DB
                    // async.eachSeries(daraftgroups, async function (daraftgroup, innerCb) {
                    for (var j = 0; j < daraftgroups.length; j++) {
                        draftData.dgName = daraftgroups[j].dgName;
                        draftData.sortOrder = daraftgroups[j].sortOrder;
                        //console.log(draftData.dgName);process.exit();
                        checkExistDraft = await self.checkDraft(draftData);
                        if (!checkExistDraft) {
                            // console.log('insert');//console.log(draftData);process.exit();
                            draftData.draftgroupId = await generalHelper.updateCounter('draftgroupId');
                            draftInsert = await self.insertDraft(draftData);
                        } else {
                            // console.log('push');
                            checkEventExistIndraftGroup = await self.checkEventInDraft(draftData);
                            //console.log(checkEventExistIndraftGroup);
                            //console.log(checkEventExistIndraftGroup.gameList.length);
                            if (checkEventExistIndraftGroup.gameList.length < 1) {
                                //console.log('pushInsert');
                                draftUpdate = await self.updateDraft(draftData);
                            }
                        }
                        // innerCb(null);
                        //});
                    }
                    //}
                    //     outCb(null);
                    // });
                }
                var drafts = await DraftGroupModel.find({ "sportId": 1, "dgState": 'Upcoming', 'season': currSeason, 'startTimeUTC': null }, function () { });
                //console.log(drafts); process.exit();
                for (var n = 0; n < drafts.length; n++) {
                    if (drafts[n].gameList.length < 2) {
                        await DraftGroupModel.remove({ draftgroupId: drafts[n].draftgroupId }, function (err) { });
                    }
                }
            }
            // }
            // });
            await self.autoCreateContest();
        } catch (e) {
            throw e;
        }
    },

    getHomePlayers: async function (homeTeamId) {
        try {
            return await PlayerModel.find({ 'team.teamId': homeTeamId });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    getAwayPlayers: async function (awayTeamId) {
        try {
            return await PlayerModel.find({ 'team.teamId': awayTeamId });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    checkDraft: async function (draftData) {
        try {
            return await DraftGroupModel.findOne({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season, 'eventTypeId': draftData.eventTypeId });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    insertDraft: async function (draftData) {
        try {
            return await DraftGroupModel.findOneAndUpdate({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season }, draftData, { upsert: true });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    checkEventInDraft: async function (draftData) {
        try {
            return await DraftGroupModel.findOne({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season }, { gameList: { $elemMatch: { eventId: draftData.gameList[0].eventId } } });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    updateDraft: async function (draftData) {
        try {
            return await DraftGroupModel.findOneAndUpdate({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season }, {
                $addToSet: {
                    gameList: draftData.gameList[0]
                }
            });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },

    /**
     * Cron - To auto create contest after draftgroup ceation
     */
    autoCreateContest: async function () {
        try {
            var newDrafts = await DraftGroupModel.find({ "sportId": 1, "startTimeUTC": null, "autoContest": 0 }, function () { }); //console.log(newDrafts);process.exit();
            var autoContestLogics = await AutoContestLogics.find({ "sportId": 1 }, function () { });
            for (var x = 0; x < newDrafts.length; x++) {
                var cnt = 0;
                var st = await DraftGroupModel.aggregate(
                    { "$match": { draftgroupId: newDrafts[x].draftgroupId } },
                    { $unwind: '$gameList' },
                    { $group: { _id: newDrafts[x].draftgroupId, minTime: { $min: '$gameList.startTimeUTC' } } });
                for (var j = 0; j < autoContestLogics.length; j++) {
                    for (var k = 0; k < (autoContestLogics[j].entryFees).length; k++) {
                        //console.log(newDrafts[x].draftgroupId); console.log(st);
                        //contest name start
                        var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                        var zone = process.env.dest_zone;
                        var s = moment.utc(st[0].minTime.toISOString()).tz(zone).format('YYYY-MM-DD HH:mm:ss');
                        var localDate = new Date(s).toLocaleDateString();
                        var localHour = new Date(s).getHours();
                        var utcHour = (st[0].minTime).getHours();
                        var localMinute = (new Date(s).getMinutes()) ? (':' + new Date(s).getMinutes()) : '';
                        var hours = (utcHour + 24 - 2) % 24;
                        var AM_or_PM = ' AM ';
                        localHour = (localHour == 12) ? localHour : localHour % 12;
                        if (hours == 0) { //At 00 hours we need to show 12 am
                            hours = 12;
                        }
                        else if (hours > 12) {
                            hours = hours % 12;
                            AM_or_PM = " PM ";
                        }
                        var day = days[new Date(localDate).getDay()];
                        contestName = (autoContestLogics[j].contestTypeId == 2) ? (newDrafts[x].league[0].abbr + ' ' + day + ' ' + 'H2H Tournament.') : (newDrafts[x].league[0].abbr + ' ' + day + ' ' + autoContestLogics[j].maxLimit + ' man Tournament.');
                        //contest name end
                        if (autoContestLogics[j].contestTypeId == 2)
                            var prizepool = ((autoContestLogics[j].entryFees[k] * 2) - (autoContestLogics[j].entryFees[k] * 2) * (10 / 100));
                        else
                            var prizepool = ((autoContestLogics[j].entryFees[k] * autoContestLogics[j].maxLimit) - (autoContestLogics[j].entryFees[k] * autoContestLogics[j].maxLimit) * (10 / 100));
                        var contest = {
                            contestId: await generalHelper.updateCounter('contestId'), //unique key
                            autoId: await generalHelper.updateCounter('autoId'), //unique key
                            entryFees: autoContestLogics[j].entryFees[k],
                            contestStartTime: st[0].minTime.toISOString(),
                            contestTypeId: autoContestLogics[j].contestTypeId,
                            contestType: (autoContestLogics[j].contestTypeId == 1) ? 'Multiplayer' : 'H2H',
                            contestName: contestName,
                            gameTypeId: autoContestLogics[j].gameTypeId,
                            gameType: autoContestLogics[j].gameType,
                            draftgroupId: newDrafts[x].draftgroupId,
                            visibility: 'Public',
                            sportId: 1,
                            contestStatus: 3,
                            prizePool: prizepool,
                            maxLimit: autoContestLogics[j].maxLimit,
                            minLimit: autoContestLogics[j].maxLimit,
                            maxEntriesPerUser: autoContestLogics[j].maxEntriesPerUser,
                            prizeMode: 'C',
                            summary: (autoContestLogics[j].contestTypeId == 1) ? 'Multiplayer Contest' : 'H2H Contest',
                            labels: [],
                            prizes: [],
                            prizeTickets: 0,
                            isVideoAvailable: false,
                            isAdminRow: false,
                            isGuaranteed: false,
                            matchMaking:false,
                            prizeTmpId: autoContestLogics[j].prizeTmpId
                        }
                        await ContestModel.findOneAndUpdate({ 'draftgroupId': newDrafts[x].draftgroupId, 'contestId': contest.contestId }, contest, { upsert: true }, function (err, doc) {
                            try {
                                if (err) throw err;
                                //console.log('Success auto contest');
                            } catch (e) {
                                cronVar.logger.info(e);
                            }
                        });
                        //adding contest to draftgroup
                        await DraftGroupModel.findOneAndUpdate({ draftgroupId: newDrafts[x].draftgroupId }, { $push: { contestList: contest.contestId } });
                    }
                }
                //changing draftgroup autoContest status to 1
                await DraftGroupModel.findOneAndUpdate({ 'draftgroupId': newDrafts[x].draftgroupId }, { autoContest: 1 });

            }

        } catch (e) {
            cronVar.logger.info(e);
        }
    }
}





