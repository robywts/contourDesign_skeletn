/**
 * Event Module
 * @exports Event/Cron
 */
var GameModel = require('../../models/event');
var cronVar = require('./cronSettings');
var async = require('async');

module.exports = {
    /**
     * Cron - To get all scheduled  events by week
     * To get all basic details related to games in a week
     */
    getEventScheduleDetails: function () {
        try {
            // var week = 1;
            var request = cronVar.request;
            /*  for (var week = 1; week < 6; week++) {
                  request(process.env.SCHEDULE_EVENT_API + '?week=' + week + '&api_key=' + cronVar.apiKey + '&sig=' + cronVar.sig,
                      function (err, response, body) {
                          try {
                              // parse the body as JSON
                              if (!err && response.statusCode == 200) {
                                  var parsedBody = JSON.parse(body);
                                  var res = parsedBody.apiResults;
                                  var eventArr = res[0].league.season.eventType[0].events;
                                  eventArr.forEach(function (event) {
                                      league = {};
                                      league['leagueId'] = res[0].league.leagueId;
                                      league['abbr'] = res[0].league.abbreviation;
                                      var homeTeam = {};
                                      var awayTeam = {};
                                      var gameInfo = {};
                                      teamArr = event.teams
                                      //obtaining home team and away team details
                                      teamArr.forEach(function (team) {
                                          if (team.teamLocationType.teamLocationTypeId == '1') {
                                              homeTeam.teamId = team.teamId;
                                              homeTeam.tAbbr = team.abbreviation;
                                              homeTeam.score = team.score;
                                              homeTeam.isWinner = team.isWinner ? 1 : 0;
                                          }
                                          else {
                                              awayTeam.teamId = team.teamId;
                                              awayTeam.tAbbr = team.abbreviation;
                                              awayTeam.score = team.score;
                                              awayTeam.isWinner = team.isWinner ? 1 : 0;
                                          }
                                      });
                                      //assigning relevant event datas to event_data variable   
                                      var event_data = {
                                          gameInfo: gameInfo,
                                          sportId: res[0].sportId,
                                          league: league,
                                          season: res[0].league.season.season,
                                          week: event.week,
                                          eventId: event.eventId,
                                          eventStatusId: event.eventStatus.eventStatusId,
                                          isActive: (event.eventStatus.isActive) ? 1 : 0,
                                          startTimeUTC: event.startDate[1].full,
                                          homeTeam: homeTeam,
                                          awayTeam: awayTeam,
                                      };
                                      //saving or updating events data to DB
                                      GameModel.findOneAndUpdate({ 'eventId': event.eventId }, event_data, { upsert: true }, function (err, doc) {
                                          try {
                                              if (err) throw err;
                                              //console.log('Success Game');
                                          } catch (e) {
                                              cronVar.logger.info(e);
                                          }
                                      });
                                  })
                              }
                              else {
                                  throw err;
                              }
                          } catch (e) {
                              cronVar.logger.info(e);
                          }
                      });
              }*/
            for (var week = 1; week < 6; week++) {
                async.series({
                    res: function (callback) {
                        request(process.env.SCHEDULE_EVENT_API + '?week=' + week + '&api_key=' + cronVar.apiKey + '&sig=' + cronVar.sig,
                            function (err, response, body) {
                                callback(null, body)
                            });
                    }
                },
                    function (err, results) {
                        //console.log(results.res);process.exit();
                        try {
                            // parse the body as JSON
                            if (results.res) {
                                var parsedBody = JSON.parse(results.res);
                                var res = parsedBody.apiResults;
                                var eventArr = res[0].league.season.eventType[0].events;
                                eventArr.forEach(function (event) {
                                    league = {};
                                    league['leagueId'] = res[0].league.leagueId;
                                    league['abbr'] = res[0].league.abbreviation;
                                    var homeTeam = {};
                                    var awayTeam = {};
                                    var gameInfo = {};
                                    teamArr = event.teams
                                    //obtaining home team and away team details
                                    teamArr.forEach(function (team) {
                                        if (team.teamLocationType.teamLocationTypeId == '1') {
                                            homeTeam.teamId = team.teamId;
                                            homeTeam.tAbbr = team.abbreviation;
                                            homeTeam.score = team.score;
                                            homeTeam.isWinner = team.isWinner ? 1 : 0;
                                        }
                                        else {
                                            awayTeam.teamId = team.teamId;
                                            awayTeam.tAbbr = team.abbreviation;
                                            awayTeam.score = team.score;
                                            awayTeam.isWinner = team.isWinner ? 1 : 0;
                                        }
                                    });
                                    //assigning relevant event datas to event_data variable   
                                    var event_data = {
                                        gameInfo: gameInfo,
                                        sportId: res[0].sportId,
                                        league: league,
                                        season: res[0].league.season.season,
                                        week: event.week,
                                        eventId: event.eventId,
                                        eventStatusId: event.eventStatus.eventStatusId,
                                        isActive: (event.eventStatus.isActive) ? 1 : 0,
                                        startTimeUTC: event.startDate[1].full,
                                        homeTeam: homeTeam,
                                        awayTeam: awayTeam,
                                    };
                                    //saving or updating events data to DB
                                    GameModel.findOneAndUpdate({ 'eventId': event.eventId }, event_data, { upsert: true }, function (err, doc) {
                                        try {
                                            if (err) throw err;
                                            console.log('Success Game');
                                        } catch (e) {
                                            cronVar.logger.info(e);
                                        }
                                    });
                                })
                            }
                            else {
                                throw err;
                            }
                        } catch (e) {
                            cronVar.logger.info(e);
                        }
                    });

            }
        });










        } catch (e) {
            throw e;
        }
    }
}





