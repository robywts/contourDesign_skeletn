/**
 * General Module
 * @exports Cron/GeneralSchemaUpdate
 */
var DraftGroupModel = require('../../models/draftgroup');
var ContestModel = require('../../models/contest');
var UserModel = require('../../models/user');
var PlayerNewsModel = require('../../models/playernews');
var LineUpModel = require('../../models/lineup');
var cronVar = require('./cronSettings');
var async = require('async');
var moment = require('moment');
var TransactionModel = require('../../models/transaction');
var UserTicketModel = require('../../models/userTicket');

var self = module.exports = {
    /**
     * Cron - To update gameStatus value in a draftgroup schema
     * To update gameStatus in draftgroup schema based on the event status
     */
    updateDraftPlayers: function () {
        try {
            var draftgroups = DraftGroupModel.find({}, function (err, draftgroups) {
                if (err)
                    console.log(err);
                else {
                    async.eachSeries(draftgroups, async function (draftgroup, outCb) {
                        if (draftgroup.gameList != null) {
                            async.eachSeries(draftgroup.gameList, async function (game, inCb) {
                                var current_time = (moment.utc(new Date()).format('YYYY-MM-DD HH:mm:ss'));
                                var game_time = (moment.utc(game.startTimeUTC).format('YYYY-MM-DD HH:mm:ss'));
                                if (game_time > current_time) {
                                    DraftGroupModel.findOneAndUpdate({ 'draftgroupId': draftgroup.draftgroupId, 'gameList.eventId': game.eventId }, { 'gameList.$.gameStatus': 'Upcoming' }, { multi: true }, function (err, doc) { });
                                }
                                //else
                                // console.log('Completed');
                                inCb(null);
                            });
                        }
                        outCb(null);
                    });
                }

            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To update mValue value in a draftgroup schema
     * To update mValue in draftgroup schema based on the player fantasy salary
     */
    updateDraftMValue: async function () {
        try {
            var draftgroups = DraftGroupModel.find({ dgState: { $ne: 'Completed' } }, async function (err, draftgroups) {
                if (err)
                    console.log(err);
                else {
                    //async.eachSeries(draftgroups, async function (draftgroup, outCb) {
                    for (var l in draftgroups) {
                        if (draftgroups[l].gameList != null && draftgroups[l].sportId != 4 && draftgroups[l].sportId != 3 && draftgroups[l].sportId != 2) {//console.log(draftgroups[l].draftgroupId);
                            //To get max and min fantasy player positions
                            var minmax = await DraftGroupModel.aggregate(
                                [
                                    { "$match": { draftgroupId: draftgroups[l].draftgroupId } },
                                    { $unwind: "$gameList" },
                                    { $unwind: "$gameList.players" },
                                    { "$match": { "gameList.players.fanProjSalary": { "$gte": 1 } } },
                                    {
                                        $group:
                                        {
                                            _id: "$gameList.players.posAbbr",
                                            min: { $min: "$gameList.players.fanProjSalary" },
                                            max: { $max: "$gameList.players.fanProjSalary" }
                                        }
                                    }
                                ]
                            );//console.log(minmax);
                            var gamesList = draftgroups[l].gameList;
                            for (var k = 0, len = gamesList.length; k < len; k++) {
                                //console.log(draftgroups[l].draftgroupId);
                                if (gamesList[k].players != null) {
                                    for (var j in gamesList[k].players) {
                                        for (var i in minmax) {
                                            if (minmax[i]._id == gamesList[k].players[j].posAbbr) {
                                                var playerSalary = (gamesList[k].players[j].fanProjSalary < 1 || gamesList[k].players[j].fanProjSalary == 0 || !gamesList[k].players[j].fanProjSalary) ? minmax[i].min : gamesList[k].players[j].fanProjSalary;
                                                mValue = await Math.round((1 + ((playerSalary - minmax[i].max) * (2 - 1)) / (minmax[i].min - minmax[i].max)) * 20) / 20;
                                                //updating mValue draftgroup schema
                                                var field = {};
                                                field["gameList.$.players." + j + ".mValue"] = mValue;
                                                var updateM = await DraftGroupModel.update(
                                                    { "draftgroupId": draftgroups[l].draftgroupId, "gameList.players.playerId": gamesList[k].players[j].playerId },

                                                    field,
                                                    {
                                                        new: false
                                                    }, function () { });//console.log('Mvalue');
                                            };
                                        }
                                    }
                                }
                            }
                        }
                        // outCb(null);
                        //  });
                    }
                    // console.log('finished');
                }

            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To update startTimeUTC value in a draftgroup schema
     * To update gameStatus in draftgroup schema based on the event status
     */
    draftGroupTime: async function () {
        try {
            var draftgroups = await DraftGroupModel.find({ dgState: { $ne: 'Completed' } }, function (err, draftgroups) { });
            for (var j = 0; j < draftgroups.length; j++) {
                if (!draftgroups[j].startTimeUTC || draftgroups[j].startTimeUTC == '') {
                    var st = await DraftGroupModel.aggregate(
                        { "$match": { draftgroupId: draftgroups[j].draftgroupId } },
                        { $unwind: '$gameList' },
                        { $group: { _id: draftgroups[j].draftgroupId, minTime: { $min: '$gameList.startTimeUTC' } } });
                    var updateM = await DraftGroupModel.findOneAndUpdate(
                        { "draftgroupId": draftgroups[j].draftgroupId },
                        //{ "startTimeUTC": st[0].minTime.toISOString() },
                        { "startTimeUTC": st[0].minTime },
                        {
                            new: false
                        });
                }
            }
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To update contest and draftgroup 
     * To update gameStatus in draftgroup schema based on the event status
     */
    updateDraftGroupStatus: async function () {
        try {
            var current_time = (moment.utc(new Date()).format('YYYY-MM-DD'));

            var draftgroups = await DraftGroupModel.find({ dgState: { $ne: 'Completed' } }, function (err, draftgroups) { });
            for (var j = 0; j < draftgroups.length; j++) {
                // if (draftgroups[j].dgState == 'Upcoming' || draftgroups[j].dgState == 'Live') {
                var st = await DraftGroupModel.aggregate(
                    { "$match": { draftgroupId: draftgroups[j].draftgroupId } },
                    { $unwind: '$gameList' },
                    { $group: { _id: draftgroups[j].draftgroupId, maxTime: { $max: '$gameList.startTimeUTC' } } });

                var draft_time = moment.utc(new Date(st[0].maxTime)).format('YYYY-MM-DD');

                if (current_time > draft_time) {
                    DraftGroupModel.findOneAndUpdate({ 'draftgroupId': draftgroups[j].draftgroupId }, { 'dgState': 'Completed' }, { multi: true }, function (err, doc) { });
                    ContestModel.update({ 'draftgroupId': draftgroups[j].draftgroupId }, { 'contestStatus': 1 }, { multi: true }, function (err, doc) { });
                }
                // }
            }
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To abort contest status that are not guaranteed or min entry not satisfied 
     * Aborting contest 30 seconds before it's start time
     */
    abortContest: async function () {
        try {
            var today = new Date();
            //var yesterday = new Date(new Date().setDate(new Date().getDate() - 1));
            //var tmrww = new Date(new Date().setDate(new Date().getDate() + 1));
            var thirtySecAftr = new Date(new Date().setSeconds(new Date().getSeconds() + 30));

            var contestList = await ContestModel.find({
                $and: [{
                    "contestStartTime": { '$lte': thirtySecAftr }
                }, {
                        "contestStartTime": { '$gte': today }
                    },
                    { contestStatus: { $in: [2, 3] } }, {
                        $or: [
                            { "isGuaranteed": { $exists: true, $ne: true } },
                            { "isGuaranteed": { $exists: false } }
                        ]
                    }],
            }).exec(); //console.log(today); console.log(thirtySecAftr); console.log(contestList);// process.exit();
            for (var i = 0; i < contestList.length; i++) {
                var minLimit = contestList[i].autoId ? contestList[i].maxLimit : contestList[i].minLimit;
                var totalEntry = contestList[i].entrants.reduce(function (a, b) {
                    return a + b.totalentry;
                }, 0);
                //adding reserved entry count---start
                var myEntry = (contestList[i].entrants).find(function (obj) {
                    return obj.userId === contestList[i].createdBy;
                });
                totalEntry = (myEntry && myEntry.totalentry == 0) ? totalEntry + 1 : totalEntry;
                //adding reserved entry count---end
                /*if (totalEntry < minLimit) {
                      var contestStatusUpdate = await ContestModel.findOneAndUpdate({ 'contestId': contestList[i].contestId }, { 'contestStatus': 4, 'refundIssued': 'Y' }, {}, function (err, doc) { });
                      //refund start
                      var entrantsContest = contestList[i].entrants;
                      if (entrantsContest.length > 0) {
                          for (var j = 0; j < entrantsContest.length; j++) {
                              var numOfEntry = (entrantsContest[j].totalentry == 0) ? 1 : entrantsContest[j].totalentry;
                              var totalFees = numOfEntry * contestList[i].entryFees;
                              var userBalanceUpdate = await UserModel.findOneAndUpdate({
                                  'userId': entrantsContest[j].userId
                              }, {
                                      $inc: {
                                          "balance": totalFees
                                      }
                                  }, {
                                      //  new: true
                                  }, function (err, doc) {
                                  });
                          }
                      }
                      //refund end
                  }*/
                if (totalEntry < minLimit) {
                    var contestStatusUpdate = await ContestModel.findOneAndUpdate({ 'contestId': contestList[i].contestId }, { 'contestStatus': 4, 'refundIssued': 'Y' }, {}, function (err, doc) { });
                    //refund start
                    var lineUpDB = await LineUpModel.find({ 'contestId': contestList[i].contestId, 'refundIssued': { $ne: 'Y' } }, function () { });
                    for (var k = 0; k < lineUpDB.length; k++) {
                        var myEntry = (contestList[i].entrants).find(function (obj) {
                            return obj.userId === lineUpDB[k].userId;
                        });
                        if ((!lineUpDB[k].ticketId) || (lineUpDB[k].ticketId && lineUpDB[k].ticketId == "N")) {
                            var updateBalance = await UserModel.update({
                                'userId': lineUpDB[k].userId
                            }, {
                                    $inc: {
                                        "balance": contestList[i].entryFees
                                    }
                                }, {
                                    new: true
                                });
                            if ((lineUpDB[k].transactionId && lineUpDB[k].transactionId != "N") || (myEntry.transactionId)) {
                                var userData = await UserModel.findOne({ 'userId': lineUpDB[k].userId });
                                var transaction = new TransactionModel();
                                transaction.amount = contestList[i].entryFees;
                                transaction.tranStatus = 1;
                                transaction.tranType = "CC";
                                transaction.userId = lineUpDB[k].userId;
                                transaction.userName = userData.userName;
                                transaction.userImg = userData.imageName;
                                transaction.fName = userData.fName;
                                transaction.lName = userData.lName;
                                var insertTransaction = await transaction.save();
                            }
                            if ((lineUpDB[k].referralMoney) || myEntry.referralMoney) {
                                if ((lineUpDB[k].referralMoney != 0) || myEntry.referralMoney != 0) {
                                    var refMoney = myEntry.referralMoney ? myEntry.referralMoney : lineUpDB[k].referralMoney;
                                    var addBalance = await UserModel.update({
                                        'userId': lineUpDB[k].userId
                                    }, {
                                            $inc: {
                                                "referralMoney": refMoney
                                            }
                                        });
                                }
                            }
                        } else {
                            if (lineUpDB[k].ticketId != "N") {
                                var updateTicket = await UserTicketModel.findOneAndUpdate({
                                    'userId': lineUpDB[k].userId,
                                    "ticketId": lineUpDB[k].ticketId
                                }, {
                                        $set: {
                                            "ticketStatus": 'N'
                                        }
                                    });
                            }
                        }
                        var lineupStatusUpdate = await LineUpModel.findOneAndUpdate({ 'lineupId': lineUpDB[k].lineupId }, { 'refundIssued': 'Y' }, {}, function (err, doc) { });
                    }
                    //refund start
                }
            }
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To remove player news which is older than a month 
     */
    removePlayerNews: async function () {
        try {
            var datetimemonth = new Date(new Date().setMonth(new Date().getMonth() - 1));
            if (datetimemonth)
                var olderPlayerNews = await PlayerNewsModel.remove({ 'originalDateUtc': { $lt: datetimemonth } });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To remove user lineups which is unused 
     */
    removeUnusedLineups: async function () {
        try {
            var date = new Date(); //console.log(date);
            //var unUsedLineups = await LineUpModel.find({ 'startTimeUTC': { $lt: date }, contestId: 0 });
            //if (unUsedLineups)
            var removeUnUsedLineups = await LineUpModel.remove({ 'startTimeUTC': { $lt: date }, contestId: 0 });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To calculate payout in multiplayer contest 
     */
    setContestPayout: async function () {
        try {
            var unsetPOContests = await ContestModel.find({ 'contestStatus': 2, 'prizePool': { $not: { $gt: 0 } }, 'contestTypeId': 1, 'entryFees': { $gt: 0 } });
            for (var i = 0; i < unsetPOContests.length; i++) {
                if (unsetPOContests[i].entrants) {
                    var totalEntry = (unsetPOContests[i].entrants).reduce(function (a, b) {
                        return a + b.totalentry;
                    }, 0);
                    var prizePool = (totalEntry * unsetPOContests[i].entryFees) - ((totalEntry * unsetPOContests[i].entryFees) * 10 / 100);
                    var updatePO = await ContestModel.findOneAndUpdate({ 'contestId': unsetPOContests[i].contestId }, { 'prizePool': prizePool }, { new: true });
                }
            }
        } catch (e) {
            throw e;
        }
    },
}





