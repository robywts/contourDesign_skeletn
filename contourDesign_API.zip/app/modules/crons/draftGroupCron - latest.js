/**
 * DraftGroup Module
 * @exports Cron/DraftGroup
 */
var DraftGroupModel = require('../../models/draftgroup');
var GameModel = require('../../models/event');
var PlayerModel = require('../../models/player');
var moment = require('moment');
var generalHelper = require('../mobile/helpers/generalHelper');
var cronVar = require('./cronSettings');
var async = require('async');

var self = module.exports = {
    /**
     * Cron - To create all predefined draftGroup set
     * To get all basic details related to players
     */

    getDraftGroupDetails: async function () {
        try {
            // var times = ['0', '1', '2', '3', '4', '5', '6',];
            // async.eachSeries(times, async function (time, outerCb) {
            var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            var events = GameModel.find({}, function (err, events) {
                if (err)
                    console.log(err);
                else {
                    //events.forEach(async function (event) {
                    // async.forEach(events, function (event, callback) {
                    async.eachSeries(events, async function (event, outCb) {
                        var zone = process.env.dest_zone;
                        var s = moment.utc(event.startTimeUTC).tz(zone).format('YYYY-MM-DD HH:mm:ss');
                        var localTime = new Date(s).toLocaleTimeString();
                        var localDate = new Date(s).toLocaleDateString();
                        var localHour = new Date(s).getHours();
                        var localMinute = new Date(s).getMinutes();
                        //console.log(localMinute); process.exit();
                        //var dateYMD = event.startTimeUTC.toISOString().split('T')[0];
                        // var dateYMD = s.toString().split('T')[0];
                        //var day = days[new Date(dateYMD).getDay()];
                        //console.log(new Date(localDate).getDay());process.exit();
                        var day = days[new Date(localDate).getDay()];
                        var dgName = '';
                        daraftgroups = [];
                        //console.log(day); process.exit();
                        if (day == 'Sunday' && ((localHour >= 13) && (localHour <= 19))) {
                            dgName = 'NFL - Sunday Main';
                            daraftgroups.push(dgName);
                        }
                        if ((day == 'Sunday' && (localHour >= 19)) || (day == 'Monday')) {
                            dgName = 'NFL - Sunday Night and Monday';
                            daraftgroups.push(dgName);
                        }
                        if (((localHour == 15 && localMinute >= 30) || (localHour >= 16)) && (localHour <= 19)) {
                            dgName = 'NFL - Afternoon';
                            daraftgroups.push(dgName);
                        }
                        if (day == 'Thursday' || day == 'Friday' || day == 'Saturday' || day == 'Sunday' || day == 'Monday') {
                            dgName = 'NFL - All Games';
                            daraftgroups.push(dgName);
                        }
                        if ((day == 'Thursday' && (localHour >= 19)) || (day == 'Monday' && (localHour >= 19))) {
                            dgName = 'NFL - Thursday and Monday, Night';
                            daraftgroups.push(dgName);
                        }
                        if (day == 'Monday' && (localHour >= 19)) {
                            dgName = 'NFL - Monday Night';
                            daraftgroups.push(dgName);
                        }
                        //console.log(daraftgroups); process.exit();

                        game = {};
                        game['eventId'] = event.eventId;
                        game['startTimeUTC'] = event.startTimeUTC;
                        game['gameStatus'] = ''; //console.log(event.eventId);
                        game['venueName'] = event.venueName;
                        weather = {};
                        weather.conditionDesc = weather;
                        game['weather'] = event.weather;
                        game['startingLineupReady'] = 'False';
                        //game player details
                        players = [];
                        //home team details
                        homeTeamId = event.homeTeam.teamId;
                        awayTeamId = event.awayTeam.teamId;
                        //console.log(event.eventId);
                        playersDatas = [];
                        var playersDatasHome = await self.getHomePlayers(homeTeamId);
                        var playersDatasAway = await self.getAwayPlayers(awayTeamId);
                        playersDatas = playersDatasHome.concat(playersDatasAway);

                        if (playersDatas) {
                            playersDatas.forEach(function (playersData) {
                                var teamPlayers = {};// console.log(event.eventId); process.exit();
                                teamPlayers.fName = playersData.fName;
                                teamPlayers.lName = playersData.lName;
                                teamPlayers.playerId = playersData.playerId;
                                teamPlayers.posId = playersData.positions[0].posId;
                                teamPlayers.posAbbr = playersData.positions[0].posAbbr;
                                teamPlayers.CapValue = playersData.fanProjSalary;
                                teamPlayers.isInjured = '';
                                competitionPlayer = {};
                                competitionPlayer.compId = event.eventId;
                                competitionPlayer.nameDisplay = [{
                                    htId: event.homeTeam.teamId, htName: event.homeTeam.tName, htAbbr: event.homeTeam.tAbbr, htCity: event.homeTeam.city, htScore: '', value: event.homeTeam.tAbbr + '@' + event.awayTeam.tAbbr,
                                    atId: event.awayTeam.teamId, atName: event.awayTeam.tName, atAbbr: event.awayTeam.tAbbr, atCity: event.awayTeam.city, atScore: ''
                                }];

                                teamPlayers.competition = competitionPlayer;
                                teamPlayers.teamId = playersData.team.teamId;
                                teamPlayers.teamAbbr = playersData.team.tAbbr;
                                teamPlayers.fanProjSalary = playersData.fanProjSalary;
                                teamPlayers.fanProjScore = playersData.fanProjPoints;
                                players.push(teamPlayers);
                            });
                        }

                        game['players'] = players;

                        //away team details
                        //awayTeamId = event.awayTeam.teamId
                        League = {};
                        League.leagueId = event.league.leagueId;
                        League.name = event.league.name;
                        League.abbr = event.league.abbr;
                        leagues = [];
                        leagues.push(League);
                        var draftData = {
                            draftgroupId: await generalHelper.updateCounter('draftgroupId'),
                            week: event.week,
                            season: event.season,
                            sportId: event.sportId,
                            // sName: event.league.abbr,
                            league: leagues,
                            contestList: [],
                            sortOrder: 0,
                            startTimeUTC: '',
                            dgState: 'Upcoming',
                            gameList: [game]
                        };
                        // console.log(draftData.gameList[0].players[10].competition.nameDisplay); process.exit();
                        //console.log(draftData); process.exit();
                        //saving or updating events data to DB
                        async.eachSeries(daraftgroups, async function (daraftgroup, innerCb) {
                            draftData.dgName = daraftgroup;
                            //console.log(draftData.dgName);process.exit();
                            checkExistDraft = await self.checkDraft(draftData);
                            if (!checkExistDraft) {
                                // console.log('insert');
                                draftInsert = await self.insertDraft(draftData);
                            } else {
                                // console.log('push');
                                checkEventExistIndraftGroup = await self.checkEventInDraft(draftData);
                                //console.log(checkEventExistIndraftGroup);
                                //console.log(checkEventExistIndraftGroup.gameList.length);
                                if (checkEventExistIndraftGroup.gameList.length < 1) {
                                    //console.log('pushInsert');
                                    draftUpdate = await self.updateDraft(draftData);
                                }
                            }
                            innerCb(null);
                        });
                        //}
                        outCb(null);
                    });
                }
            });

        } catch (e) {
            throw e;
        }
    },

    getHomePlayers: async function (homeTeamId) {
        try {
            return await PlayerModel.find({ 'team.teamId': homeTeamId });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    getAwayPlayers: async function (awayTeamId) {
        try {
            return await PlayerModel.find({ 'team.teamId': awayTeamId });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    checkDraft: async function (draftData) {
        try {
            return await DraftGroupModel.findOne({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    insertDraft: async function (draftData) {
        try {
            return await DraftGroupModel.findOneAndUpdate({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season }, draftData, { upsert: true });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    checkEventInDraft: async function (draftData) {
        try {
            return await DraftGroupModel.findOne({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season }, { gameList: { $elemMatch: { eventId: draftData.gameList[0].eventId } } });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    updateDraft: async function (draftData) {
        try {
            return await DraftGroupModel.findOneAndUpdate({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season }, {
                $addToSet: {
                    gameList: draftData.gameList[0]
                }
            });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
}





