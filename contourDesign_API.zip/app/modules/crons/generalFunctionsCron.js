/**
 * General Functions
 * @exports Cron/GeneralFunctions
 */

var cronVar = require('./cronSettings');
var fs = require('fs');
// var xml2js = require('xml2js');
// var moment = cronVar.moment;
// var request = cronVar.request;

var winston = require('winston');

module.exports = {

    testSocketData: function () {
        // fs.readdirSync('./temp/mlb/unprocessed/').forEach(fileName => {
        //     console.log(fileName);
        // });
        try {
            var file = 'mlb_xml_parsing.log';
            // var file = 'mlb_push.log';
            // var file = 'mlb_download_xml_parsing.log';
            // var file = 'player_games_stats_fetch.log';
            // var file = 'cronError.log';
            fs.readFileSync('./app/modules/crons/logs/' + file).toString().split(/\r?\n/).forEach(function (line) {
                // if (line.indexOf("FileName:") >= 0 || line.indexOf("Inserted to db") >= 0 || line.indexOf("no connection available to server") >= 0 || line.indexOf("MongoError:") >= 0 || line.indexOf("Player Id (") >= 0 || line.indexOf("Missing (") >= 0) {
                if (line.indexOf("FileName:") >= 0 || line.indexOf("to ds259270-a0.mlab.com:59270 timed out") >= 0 || line.indexOf("Player Id (") >= 0 || line.indexOf("Missing (") >= 0 || line.indexOf("Push sent for") >= 0 || line.indexOf("\"message\":\"\"") >= 0) { // mlb_xml_parsing.lo 
                    // if (line.indexOf("Push sent for") >= 0) { // mlb_push.log

                } else {
                    fs.appendFileSync('./app/modules/crons/logs/' + file, line + '\n');
                    console.log(line);
                }
            });

            // fs.readdirSync('./temp/mlb/processed/socketFiles12/').forEach(fileName => {
            //     console.log(fileName);
            // });
        } catch (e) {
            logger.info(e);
        }
        console.log('End of Execution');
    },

    /**
     * Cron - Clear Logs
     */
    clearLogs: function () {
        try {
            fs.readdirSync('./app/modules/crons/logs/').forEach(fileName => {
                const exec = require("child_process").exec;
                var cmd = ' > ./app/modules/crons/logs/' + fileName;

                exec(cmd, (error, stdout, stderr) => {
                    if (error) {
                        console.log(error);
                    } else {
                        console.log(fileName + ' is cleared.');
                    }
                });

            });
        } catch (e) {
            logger.info(e);
        }
    },

    /**
     * Cron - Description
     */
    fnName: function () {
        try {
            var logger = new(winston.Logger)({
                transports: [
                    new(winston.transports.Console)(),
                    new(winston.transports.File)({
                        filename: './app/modules/crons/logs/player_games_stats_fetch.log'
                    })
                ]
            });
        } catch (e) {
            logger.info(e);
        }
    },

}