/**
 * Depth Chart Module
 * @exports Cron/NFL/DepthChart
 */
var PlayerModel = require('../../models/player');
var cronVar = require('./cronSettings');
var async = require('async');

module.exports = {
    /**
     * Cron - To get all depthchart details of player - consist of two functions
     * Function to get standard player positions details(position Id and position abbreviation) from STATS api
     * Function to get player position data(abbreviation) in a season from STATS api
     */
    getDepthChartDetails: function () {
        try {console.log('dsadads');
            var sigg = statsCred();
            var request = cronVar.request;
            async.series({
                //stats api call to get position details standard
                posMaster: function (callback) {
                    try {
                        request(process.env.PLAYER_POSITION + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                            function (err, response, body) {
                                try {
                                    // parse the body as JSON
                                    if (!err && response.statusCode == 200) {
                                        var parsedBody = JSON.parse(body);
                                        var res = parsedBody.apiResults;
                                        var positionArr = res[0].league.positions;
                                        callback(null, positionArr);
                                    }
                                    else {
                                        cronVar.logger.info(err);
                                    }
                                } catch (e) {
                                    cronVar.logger.info(e);
                                }
                            });
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                }
            },
                //stats api call to get player position details from depth chart api
                function (err, positionsMaster) {
                    try {
                        request(process.env.DEPTH_CHART_API + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                            function (err, response, body) {
                                try {
                                    // parse the body as JSON
                                    if (!err && response.statusCode == 200) {
                                        var parsedBody = JSON.parse(body);
                                        var res = parsedBody.apiResults;
                                        var teamsArr = res[0].league.season.teams;
                                        teamsArr.forEach(function (team) {
                                            positionsArr = team.positions
                                            positionsArr.forEach(function (position) {
                                                (positionsMaster.posMaster).forEach(function (positionMaster) {
                                                    if (positionMaster.abbreviation == position.abbreviation) {
                                                        var positions = [];
                                                        positions.push({ "posId": positionMaster.positionId, "posAbbr": position.abbreviation });
                                                        depthChartsArr = position.depthChart;
                                                        depthChartsArr.forEach(function (depthChartArr) {
                                                            var playerId = depthChartArr.player.playerId;
                                                            //updating depthchart details to player schema
                                                            PlayerModel.findOneAndUpdate({ 'playerId': playerId }, { positions: positions }, { upsert: false }, function (err, doc) {
                                                                try {
                                                                    if (err) throw err;
                                                                    // console.log('Success Depth');
                                                                } catch (e) {
                                                                    cronVar.logger.info(e);
                                                                }
                                                            });
                                                        })
                                                    }
                                                })
                                            })
                                        })
                                    }
                                    else {
                                        cronVar.logger.info(err);
                                    }
                                } catch (e) {
                                    cronVar.logger.info(e);
                                }
                            });
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                });
        } catch (e) {
            throw e;
        }
    }

}

function statsCred() {
    // moment.js is the preferred date library
    var moment = require('moment');
    // access Node.js Crypto library for signature generation
    var crypto = require('crypto');
    // get the current time
    var timeFromEpoch = moment.utc().unix();
    // set the API key (note that this is not a valid key!)
    var apiKey = process.env.API_KEY;
    // set the shared secret key
    var secret = process.env.API_SECRET;
    // generate signature
    var sig = crypto.createHash('sha256').update(apiKey + secret + timeFromEpoch).digest('hex');

    return sig;
}