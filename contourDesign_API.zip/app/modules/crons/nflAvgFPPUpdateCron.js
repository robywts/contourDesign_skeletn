/**
 * General Module
 * @exports Cron/NFL/avgFppValue
 */
var PlayerModel = require('../../models/player');
var nflScore = require('../../config/scoringRulesNFL');
var PlayerGames = require('../../models/playerGamesJson');
var async = require('async');

var self = module.exports = {
    /**
      * Cron - To update avgFpp value in PlayerModelSchema
      *
      */
    updateDraftAvgFPPValue: async function () {
        try {
          var allPlayers = await PlayerModel.find({sportId:1})
            for(var i = 0;i<allPlayers.length;i++){
              var avgFPP = 0
              var playerAllGames = await PlayerGames.findOne({playerId:allPlayers[i].playerId})
              if(playerAllGames !== null){
              var playerAllGamesAnnual = playerAllGames['gamesJson']['annualStats']
              if(playerAllGamesAnnual !== undefined){
                  avgFPP += nflScore['nflScore']['passing']['passing-yards']['pts'] * (playerAllGamesAnnual['passing'] ? playerAllGamesAnnual['passing']['yards'] : 0)
                  avgFPP += nflScore['nflScore']['passing']['interceptions']['pts'] * (playerAllGamesAnnual['passing'] ? playerAllGamesAnnual['passing']['interceptions'] : 0)
                  avgFPP += nflScore['nflScore']['rushing']['rushing-yards']['pts'] *(playerAllGamesAnnual['rushing'] ? playerAllGamesAnnual['rushing']['yards'] : 0)
                  avgFPP += nflScore['nflScore']['receiving']['receiving-yards']['pts'] * (playerAllGamesAnnual['receiving'] ? playerAllGamesAnnual['receiving']['yards'] : 0)
                  avgFPP += nflScore['nflScore']['receiving']['receptions']['pts'] * (playerAllGamesAnnual['receiving'] ? playerAllGamesAnnual['receiving']['receptions'] : 0)
                  avgFPP += nflScore['nflScore']['scoring']['rushing-touchdowns']['pts'] * (playerAllGamesAnnual['scoring'] ? playerAllGamesAnnual['scoring']['touchdowns']['rushing'] : 0)
                  avgFPP += nflScore['nflScore']['scoring']['passing-touchdowns']['pts'] * (playerAllGamesAnnual['scoring'] ? playerAllGamesAnnual['scoring']['touchdowns']['passing'] : 0)
                  avgFPP += nflScore['nflScore']['scoring']['receiving-touchdowns']['pts'] * (playerAllGamesAnnual['scoring'] ? playerAllGamesAnnual['scoring']['touchdowns']['receiving'] : 0)
                  avgFPP += nflScore['nflScore']['scoring']['kickoff-touchdowns']['pts'] * (playerAllGamesAnnual['scoring'] ? playerAllGamesAnnual['scoring']['touchdowns']['kickoffReturn'] : 0)
                  avgFPP += nflScore['nflScore']['scoring']['punt-return-touchdowns']['pts'] * (playerAllGamesAnnual['scoring'] ? playerAllGamesAnnual['scoring']['touchdowns']['puntReturn'] : 0)
                  avgFPP += nflScore['nflScore']['scoring']['own-fumble-touchdowns']['pts'] * (playerAllGamesAnnual['scoring'] ? playerAllGamesAnnual['scoring']['touchdowns']['ownFumbleReturn'] !== null ? playerAllGamesAnnual['scoring']['touchdowns']['ownFumbleReturn'] : 0 : 0)
                  avgFPP += nflScore['nflScore']['scoring']['two-point-conversion']['pts'] * (playerAllGamesAnnual['scoring'] ? playerAllGamesAnnual['scoring']['twoPointConversions'] : 0)
                  avgFPP += nflScore['nflScore']['scoring']['extra-point-conversion']['pts'] * (playerAllGamesAnnual['scoring'] ? playerAllGamesAnnual['scoring']['extraPoints'] : 0)
                  avgFPP += nflScore['nflScore']['fumbles']['fumbles-lost']['pts'] * (playerAllGamesAnnual['fumblesLost'] ? playerAllGamesAnnual['fumblesLost']['total'] : 0)
                  avgFPP = avgFPP/playerAllGamesAnnual['gamesPlayed']
                }
                var infoObj = {}
                var infoArray = []
                infoObj.title = "Average FP"
                infoObj.val = String(avgFPP)
                infoArray.push(infoObj)
                updateInfo = await PlayerModel.update({playerId:allPlayers[i].playerId},{"info":infoArray},{new:false},function(){})
              }

            }

        } catch (e) {
            throw e;
        }
    },

}
