/**
 * Player MLB Live Score Module
 * @exports Cron/Player/MLB/LiveScore
 */
var PlayerScoreModel = require('../../models/playerScore');
var DraftGroupModel = require('../../models/draftgroup');
var contestModel = require('../../models/contest');
// var UserModel = require('../../models/user');
var cronVar = require('./cronSettings');
var fs = require('fs');
var xml2js = require('xml2js');
var Pusher = require('./helpers/pusherHelper');
var mlbScoringRules = require('../../config/scoringRulesMLB');
var moment = cronVar.moment;
var request = cronVar.request;

var winston = require('winston');

var loggerGeneral = new(winston.Logger)({
    transports: [
        new(winston.transports.Console)(),
        new(winston.transports.File)({
            filename: './app/modules/crons/logs/cron_status.log'
        })
    ]
});

module.exports = {

    /**
     * Cron - To zip all the processed files (.txt) and delete the files
     */
    mlbZipCommand: function () {
        try {
            loggerGeneral.info('MLB Zip STARTED');
            var logger = new(winston.Logger)({
                transports: [
                    new(winston.transports.Console)(),
                    new(winston.transports.File)({
                        filename: './app/modules/crons/logs/mlb_general.log'
                    })
                ]
            });
            const exec = require("child_process").exec;
            var dt = new Date(Date.now());
            var zipFile = dt.getFullYear() + '-' + dt.getMonth() + '-' + dt.getDate() + '.zip';
            var cmd = "cd ./temp/mlb/processed/ && zip " + zipFile + " * && mv ./" + zipFile + " ../" + zipFile;
            var cmd2 = "cd ./temp/mlb/processed/ && rm *";
            exec(cmd, {
                maxBuffer: 1024 * 10000 // increased to 10000 KB
            }, (error, stdout, stderr) => {
                if (error) {
                    logger.info(error);
                } else {
                    loggerGeneral.info('MLB Zip CREATED');
                    exec(cmd2, (error2, stdout2, stderr2) => {
                        if (error2) {
                            logger.info(error2);
                        } else {
                            loggerGeneral.info('MLB Zip DELETED ALL - ENDED');
                        }
                    });
                }
            });
        } catch (e) {
            logger.info(e);
        }
    },

    /**
     * Cron - To get all Player details from the xml file and parse it and update it to the db
     */
    mlbPlayerScoreSocket: async function () {
        try {
            var logger = new(winston.Logger)({
                transports: [
                    new(winston.transports.Console)(),
                    new(winston.transports.File)({
                        filename: './app/modules/crons/logs/mlb_xml_parsing.log'
                    })
                ]
            });

            var fileList = fs.readdirSync('./temp/mlb/unprocessed/');
            if (fileList.length > 0) {
                fileList.forEach(fileName => {
                    try {
                        var fileCont = fs.readFileSync('./temp/mlb/unprocessed/' + fileName);
                        fileCont = fileCont.toString().replace('<?xml version="1.0" encoding="UTF-8"?>', '').trim();
                        if (fileCont != '' && fileCont.indexOf("<MLB-event>") >= 0 && fileCont.indexOf("</MLB-event>") >= 0) { // if the file is not empty
                            var parser = new xml2js.Parser();
                            if (fileCont.indexOf("<MLB-event>") > 0) { //fix if the part of ping data is still in the file
                                var fileContArr = fileCont.split("<MLB-event>");
                                if (fileContArr[1]) {
                                    fileCont = "<MLB-event>" + fileContArr[1];
                                }
                            }

                            parser.parseString(fileCont, async function (err, result) {
                                try {
                                    if (err) {
                                        logger.info('FileName: ' + fileName);
                                        logger.info(err);
                                    } else if (result) {
                                        if (result['MLB-event']) {
                                            var sportId = 2; // MLB
                                            var eventCode = result['MLB-event']['gamecode'][0]['$']['code'];
                                            var eventId = result['MLB-event']['gamecode'][0]['$']['global-id'];
                                            var eventStatus = result['MLB-event']['gamestate'][0]['game'][0]['$']['status'];
                                            logger.info('FileName: ' + fileName + ' EventId: ' + eventId);
                                            if (eventStatus != 'Pre-Game') {
                                                var playerRecords = {};
                                                if (result['MLB-event']['date']) {
                                                    var dt = result['MLB-event']['date'][0]['$'];
                                                    var t = result['MLB-event']['time'][0]['$'];
                                                    try {
                                                        var dtt = moment([dt['year'], dt['month'], dt['date'], t['hour'], t['minute'], 0, 0]).add({
                                                            hours: t['utc-hour'],
                                                            minutes: t['utc-minute']
                                                        });
                                                        var eventDateTime = dtt.format('YYYY-MM-DD hh:mm:ss A');
                                                    } catch (e) {
                                                        var eventDateTime = '';
                                                    }
                                                } else {
                                                    var eventDateTime = '';
                                                }

                                                var atBat = '';
                                                if (result['MLB-event']['gamestate'][0]['batter']) {
                                                    var atBat = result['MLB-event']['gamestate'][0]['batter'][0]['$']['global-id'];
                                                }
                                                var atBall = '';
                                                if (result['MLB-event']['gamestate'][0]['pitcher']) {
                                                    var atBall = result['MLB-event']['gamestate'][0]['pitcher'][0]['$']['global-id'];
                                                }

                                                var visitingScore = '';
                                                var homeScore = '';
                                                var visitingTeamAlias = '';
                                                var homeTeamAlias = '';
                                                var eventClock = '';
                                                var liveGameInfo = '';
                                                if (result['MLB-event']['visiting-team'] && result['MLB-event']['home-team']) {
                                                    var inning = result['MLB-event']['gamestate'][0]['game'][0]['$']['inning'];

                                                    for (var i in result['MLB-event']['visiting-score']) {
                                                        if (result['MLB-event']['visiting-score'][i]['$']['type'] == 'runs') {
                                                            visitingScore = ' ' + result['MLB-event']['visiting-score'][i]['$']['number'];
                                                            break;
                                                        }
                                                    }
                                                    for (var i in result['MLB-event']['home-score']) {
                                                        if (result['MLB-event']['home-score'][i]['$']['type'] == 'runs') {
                                                            homeScore = ' ' + result['MLB-event']['home-score'][i]['$']['number'] + ' ';
                                                            break;
                                                        }
                                                    }

                                                    visitingTeamAlias = result['MLB-event']['visiting-team'][0]['team-name'][0]['$']['alias'];
                                                    homeTeamAlias = result['MLB-event']['home-team'][0]['team-name'][0]['$']['alias'];
                                                    //eventClock = ((result['MLB-event']['gamestate'][0]['game'][0]['$']['segment-division'] == 1) ? 'BOT' : 'TOP') +                                                 
                                                      eventClock = ((result['MLB-event']['gamestate'][0]['game'][0]['$']['segment-division'] == 1) ? 'TOP' : 'BOT') +
                                                        ' ' + inning + ((inning == 1) ? 'st' : ((inning == 2) ? 'nd' : ((inning == 3) ? 'rd' : 'th')));

                                                    liveGameInfo = visitingTeamAlias +
                                                        visitingScore +
                                                        ' @ ' +
                                                        homeTeamAlias +
                                                        homeScore +
                                                        eventClock;
                                                }

                                                var liveGameInfo2 = '';
                                                if (result['MLB-event']['gamestate'][0]['batter'] && result['MLB-event']['gamestate'][0]['batter']) {
                                                    if (result['MLB-event']['gamestate'][0]['batter'][0]['$']['first-name'] != '' && result['MLB-event']['gamestate'][0]['pitcher'][0]['$']['first-name'] != '') {
                                                        liveGameInfo2 = '(' + result['MLB-event']['gamestate'][0]['batter'][0]['$']['batting-slot'] + ') ' + result['MLB-event']['gamestate'][0]['batter'][0]['$']['first-name'] + ' ' + result['MLB-event']['gamestate'][0]['batter'][0]['$']['last-name'] +
                                                            ' (AT BAT) vs ' + result['MLB-event']['gamestate'][0]['pitcher'][0]['$']['first-name'] + ' ' + result['MLB-event']['gamestate'][0]['pitcher'][0]['$']['last-name'];
                                                    }
                                                }

                                                var downloadUpdate = 'N';
                                                var player = {};

                                                await DraftGroupModel.update({
                                                    'gameList.eventId': eventId
                                                }, {
                                                    'gameList.$.gameStatus': eventStatus
                                                }, {
                                                    multi: true
                                                });


                                                var dgs = await DraftGroupModel.find({
                                                    'gameList.eventId': eventId
                                                }, 'gameList draftgroupId');


                                                for (var dg of dgs) {
                                                    var status = '';
                                                    var dgId = dg.draftgroupId;

                                                    for (var thisGame of dg.gameList) {
                                                        if (thisGame.eventId == eventId) {
                                                            for (p of thisGame.players) { // fetching player details (DG->GameList->Players)
                                                                if (!player[p.playerId]) {
                                                                    player[p.playerId] = {};
                                                                }
                                                                if (p.posGen) {
                                                                    player[p.playerId]['posGen'] = p.posGen;
                                                                }

                                                                if (p.mValue) {
                                                                    player[p.playerId]['multiplierVal'] = p.mValue.value;
                                                                }

                                                            }
                                                        }
                                                    }

                                                    var postponedMatchCnt = 0;
                                                    var totalMatchCnt = dg.gameList.length;
                                                    for (var g of dg.gameList) {
                                                        if (g.gameStatus == 'In-Progress') {
                                                            status = g.gameStatus;
                                                            break;
                                                        } else if (g.gameStatus == 'Cancelled') {
                                                            // Do nothing
                                                        } else if (g.gameStatus == 'Postponed') {
                                                            postponedMatchCnt++;
                                                            if (status == '') { // if all the matches are postponed
                                                                status == 'Postponed';
                                                            }
                                                        } else if (g.gameStatus == 'Final') {
                                                            if (status == 'Upcoming') {
                                                                status = 'In-Progress';
                                                                break;
                                                            }
                                                            status = g.gameStatus;
                                                        } else {
                                                            if (status == 'Final') {
                                                                status = 'In-Progress';
                                                                break;
                                                            }
                                                            status = 'Upcoming';
                                                        }
                                                    }

                                                    if (status == 'Final' && postponedMatchCnt == (totalMatchCnt - 1)) { // if n-1 matches gets postponed
                                                        status = 'Postponed';
                                                    }

                                                    var contestStatus = 3;
                                                    var dfStatus = 'Upcoming';
                                                    if (status == 'Final') {
                                                        contestStatus = 1
                                                        dfStatus = 'Completed';
                                                    } else if (status == 'In-Progress') {
                                                        contestStatus = 2
                                                        dfStatus = 'Live';
                                                    } else if (status == 'Postponed') {
                                                        contestStatus = 4
                                                        dfStatus = 'Cancelled';
                                                    }

                                                    await DraftGroupModel.update({
                                                        'draftgroupId': dgId
                                                    }, {
                                                        'dgState': dfStatus
                                                    });


                                                    await contestModel.update({
                                                        'draftgroupId': dgId,
                                                        'contestStatus': {
                                                            $in: [1, 2, 3]
                                                        }
                                                    }, {
                                                        'contestStatus': contestStatus
                                                    }, {
                                                        multi: true
                                                    });

                                                }

                                                if (eventStatus == 'Final') { // fix for not to miss any player record if the status is final
                                                    await PlayerScoreModel.update({
                                                        'eventId': eventId
                                                    }, {
                                                        'eventStatus': eventStatus,
                                                        'liveGameInfo': liveGameInfo,
                                                        'liveGameInfo2': liveGameInfo2,
                                                        'isAtBat': false,
                                                        'possTeam': '',
                                                        'homeScore': homeScore,
                                                        'awayScore': visitingScore,
                                                        'homeAbbr': homeTeamAlias,
                                                        'awayAbbr': visitingTeamAlias,
                                                        'clock': eventClock,
                                                        'fileName': fileName
                                                    }, {
                                                        multi: true
                                                    });
                                                }

                                                if (eventStatus == 'In-Progress' || eventStatus == 'Final') { // consider inprogress and final only
                                                    if (result['MLB-event']['home-team'] && result['MLB-event']['visiting-team']) {
                                                        var homeTeamName = result['MLB-event']['home-team'][0]['team-name'][0]['$']['name'];
                                                        // var homeTeamAlias = result['MLB-event']['home-team'][0]['team-name'][0]['$']['alias'];
                                                        var homeTeamId = result['MLB-event']['home-team'][0]['team-code'][0]['$']['id'];
                                                        var visitingTeamName = result['MLB-event']['visiting-team'][0]['team-name'][0]['$']['name'];
                                                        // var visitingTeamAlias = result['MLB-event']['visiting-team'][0]['team-name'][0]['$']['alias'];
                                                        var visitingTeamId = result['MLB-event']['visiting-team'][0]['team-code'][0]['$']['id'];
                                                        var battingTeam = '';

                                                        if (result['MLB-event']['baseball-mlb-boxscore-home-team-batting-lineup']) {
                                                            var homeTeamBattingLineup = result['MLB-event']['baseball-mlb-boxscore-home-team-batting-lineup'][0]['baseball-mlb-boxscore-batting-lineup'];
                                                            for (i in homeTeamBattingLineup) { // looping the home team batting lineup
                                                                var playerId = homeTeamBattingLineup[i]['player-code'][0]['$']['global-id'];
                                                                if (!player[playerId]) {
                                                                    player[playerId] = {};
                                                                    // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                }
                                                                if (player[playerId]['posGen'] == 'Hitter') { //only hitters are allowed in batting
                                                                    playerRecords[playerId] = {};
                                                                    playerRecords[playerId]['sportId'] = sportId;
                                                                    playerRecords[playerId]['eventCode'] = eventCode;
                                                                    playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                    playerRecords[playerId]['fileName'] = fileName;
                                                                    playerRecords[playerId]['eventId'] = eventId;
                                                                    playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                    playerRecords[playerId]['eventDateTime'] = eventDateTime;

                                                                    playerRecords[playerId]['isAtBat'] = (atBat == playerId) ? true : false;
                                                                    playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                    playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                    if (atBat == playerId) {
                                                                        battingTeam = homeTeamAlias;
                                                                    }

                                                                    playerRecords[playerId]['teamId'] = homeTeamId;
                                                                    playerRecords[playerId]['teamName'] = homeTeamName;
                                                                    playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                    playerRecords[playerId]['playerId'] = playerId;
                                                                    playerRecords[playerId]['playerPositionId'] = homeTeamBattingLineup[i]['player-position'][0]['$']['id'];
                                                                    playerRecords[playerId]['playerPosition'] = homeTeamBattingLineup[i]['player-position'][0]['$']['position'];
                                                                    playerRecords[playerId]['playerName'] = homeTeamBattingLineup[i]['name'][0]['$']['first-name'] + ' ' + homeTeamBattingLineup[i]['name'][0]['$']['last-name'];
                                                                    playerRecords[playerId]['playerScore'] = 0;
                                                                    playerRecords[playerId]['multiPlayerScore'] = {};

                                                                    playerRecords[playerId]['playerStats'] = {
                                                                        "battingStats": {},
                                                                        "pitchingStats": {}
                                                                    };
                                                                    playerRecords[playerId]['playerStats']['battingStats']['singles'] = {
                                                                        'val': homeTeamBattingLineup[i]['hits'][0]['$']['hits'] - (homeTeamBattingLineup[i]['doubles'][0]['$']['doubles'] - homeTeamBattingLineup[i]['triples'][0]['$']['triples'] - homeTeamBattingLineup[i]['home-runs'][0]['$']['home-runs']),
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['singles']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['singles']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['singles']['val'] * playerRecords[playerId]['playerStats']['battingStats']['singles']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['doubles'] = {
                                                                        'val': homeTeamBattingLineup[i]['doubles'][0]['$']['doubles'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['doubles']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['doubles']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['doubles']['val'] * playerRecords[playerId]['playerStats']['battingStats']['doubles']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['triples'] = {
                                                                        'val': homeTeamBattingLineup[i]['triples'][0]['$']['triples'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['triples']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['triples']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['triples']['val'] * playerRecords[playerId]['playerStats']['battingStats']['triples']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['home-runs'] = {
                                                                        'val': homeTeamBattingLineup[i]['home-runs'][0]['$']['home-runs'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['home-runs']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['home-runs']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['home-runs']['val'] * playerRecords[playerId]['playerStats']['battingStats']['home-runs']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['runs-batted-in'] = {
                                                                        'val': homeTeamBattingLineup[i]['runs-batted-in'][0]['$']['runs-batted-in'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['runs-batted-in']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['runs-batted-in']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['runs-batted-in']['val'] * playerRecords[playerId]['playerStats']['battingStats']['runs-batted-in']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['runs'] = {
                                                                        'val': homeTeamBattingLineup[i]['runs'][0]['$']['runs'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['runs']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['runs']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['runs']['val'] * playerRecords[playerId]['playerStats']['battingStats']['runs']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['walks'] = {
                                                                        'val': homeTeamBattingLineup[i]['walks'][0]['$']['walks'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['walks']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['walks']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['walks']['val'] * playerRecords[playerId]['playerStats']['battingStats']['walks']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['stolen-bases'] = {
                                                                        'val': homeTeamBattingLineup[i]['stolen-bases'][0]['$']['stolen-bases'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['stolen-bases']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['stolen-bases']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['stolen-bases']['val'] * playerRecords[playerId]['playerStats']['battingStats']['stolen-bases']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['hit-by-pitch'] = {
                                                                        'val': homeTeamBattingLineup[i]['hit-by-pitch'][0]['$']['number'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['hit-by-pitch']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['hit-by-pitch']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['hit-by-pitch']['val'] * playerRecords[playerId]['playerStats']['battingStats']['hit-by-pitch']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['sacrifice-hits'] = {
                                                                        'val': homeTeamBattingLineup[i]['sacrifice-hits'][0]['$']['number'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['sacrifice-hits']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['sacrifice-hits']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['sacrifice-hits']['val'] * playerRecords[playerId]['playerStats']['battingStats']['sacrifice-hits']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['sacrifice-flies'] = {
                                                                        'val': homeTeamBattingLineup[i]['sacrifice-flies'][0]['$']['number'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['sacrifice-flies']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['sacrifice-flies']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['sacrifice-flies']['val'] * playerRecords[playerId]['playerStats']['battingStats']['sacrifice-flies']['pts'];

                                                                    if (!player[playerId]['multiplierVal']) {
                                                                        // logger.info('Player Id (Hbatting) ' + playerId + ' has no mValue for event ' + eventId);
                                                                        playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                    } else {
                                                                        playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                    }
                                                                    // for (var dgId in player[playerId]) {
                                                                    //     if (dgId == 'posGen'){
                                                                    //         continue;
                                                                    //     }
                                                                    //     if (!player[playerId][dgId]) {
                                                                    //         player[playerId][dgId] = {};
                                                                    //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                    //     } else if (!player[playerId][dgId]['multiplierVal']) {
                                                                    //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                    //     }
                                                                    //     playerRecords[playerId]['multiPlayerScore'][dgId] = playerRecords[playerId]['playerScore'] * player[playerId][dgId]['multiplierVal'];
                                                                    // }
                                                                }
                                                            }
                                                        }

                                                        if (result['MLB-event']['baseball-mlb-boxscore-home-team-pitching-lineup']) {
                                                            var homeTeamPitchingLineup = result['MLB-event']['baseball-mlb-boxscore-home-team-pitching-lineup'][0]['baseball-mlb-boxscore-pitching-lineup'];
                                                            for (i in homeTeamPitchingLineup) { // looping the home team pitching lineup
                                                                var playerId = homeTeamPitchingLineup[i]['player-code'][0]['$']['global-id'];
                                                                if (!player[playerId]) {
                                                                    player[playerId] = {};
                                                                    // logger.info('Missing (HP) playerId: ' + playerId + ' for the event ' + eventId);
                                                                }
                                                                if (!playerRecords[playerId]) {
                                                                    playerRecords[playerId] = {};
                                                                    playerRecords[playerId]['sportId'] = sportId;
                                                                    playerRecords[playerId]['eventCode'] = eventCode;
                                                                    playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                    playerRecords[playerId]['fileName'] = fileName;
                                                                    playerRecords[playerId]['eventId'] = eventId;
                                                                    playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                    playerRecords[playerId]['eventDateTime'] = eventDateTime;

                                                                    playerRecords[playerId]['isAtBat'] = (atBat == playerId) ? true : false;
                                                                    playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                    playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                    if (atBall == playerId) {
                                                                        battingTeam = visitingTeamAlias;
                                                                    }

                                                                    playerRecords[playerId]['teamId'] = homeTeamId;
                                                                    playerRecords[playerId]['teamName'] = homeTeamName;
                                                                    playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                    playerRecords[playerId]['playerId'] = playerId;
                                                                    playerRecords[playerId]['playerScore'] = 0;
                                                                    playerRecords[playerId]['multiPlayerScore'] = {};
                                                                }

                                                                if (homeTeamPitchingLineup[i]['player-position']) {
                                                                    playerRecords[playerId]['playerPositionId'] = homeTeamPitchingLineup[i]['player-position'][0]['$']['id'];
                                                                    playerRecords[playerId]['playerPosition'] = homeTeamPitchingLineup[i]['player-position'][0]['$']['position'];
                                                                }
                                                                playerRecords[playerId]['playerName'] = homeTeamPitchingLineup[i]['name'][0]['$']['first-name'] + ' ' + homeTeamPitchingLineup[i]['name'][0]['$']['last-name'];

                                                                if (!playerRecords[playerId]['playerStats']) {
                                                                    playerRecords[playerId]['playerStats'] = {
                                                                        "battingStats": {},
                                                                        "pitchingStats": {}
                                                                    };
                                                                }

                                                                var win = 0;
                                                                if (homeTeamPitchingLineup[i]['winning-pitcher']) {
                                                                    win = (homeTeamPitchingLineup[i]['winning-pitcher'][0]['$']['winning-pitcher'] == "true") ? 1 : 0;
                                                                }
                                                                playerRecords[playerId]['playerStats']['pitchingStats']['wins'] = {
                                                                    // 'val': homeTeamPitchingLineup[i]['wins'][0]['$']['number'],
                                                                    'val': win,
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['wins']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['wins']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['wins']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['wins']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['hits'] = {
                                                                    'val': homeTeamPitchingLineup[i]['hits'][0]['$']['hits'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['hits']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['hits']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['hits']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['hits']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['earned-runs'] = {
                                                                    'val': homeTeamPitchingLineup[i]['earned-runs'][0]['$']['earned-runs'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['earned-runs']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['earned-runs']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['earned-runs']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['earned-runs']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['strike-outs'] = {
                                                                    'val': homeTeamPitchingLineup[i]['strike-outs'][0]['$']['strike-outs'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['strike-outs']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['strike-outs']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['strike-outs']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['strike-outs']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['innings-pitched'] = {
                                                                    'val': homeTeamPitchingLineup[i]['innings-pitched'][0]['$']['innings'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['innings-pitched']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['innings-pitched']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['innings-pitched']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['innings-pitched']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['walks'] = {
                                                                    'val': homeTeamPitchingLineup[i]['walks'][0]['$']['walks'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['walks']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['walks']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['walks']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['walks']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['hit-batsmen'] = {
                                                                    'val': homeTeamPitchingLineup[i]['hit-batsmen'][0]['$']['number'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['hit-batsmen']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['hit-batsmen']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['hit-batsmen']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['hit-batsmen']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['gidp'] = {
                                                                    'val': homeTeamPitchingLineup[i]['gidp'][0]['$']['number'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['gidp']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['gidp']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['gidp']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['gidp']['pts'];

                                                                if (!player[playerId]['multiplierVal']) {
                                                                    // logger.info('Player Id (Hpitching) ' + playerId + ' has no mValue for event ' + eventId);
                                                                    playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                } else {
                                                                    playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                }
                                                                // for (var dgId in player[playerId]) {
                                                                //     if (dgId == 'posGen'){
                                                                //         continue;
                                                                //     }
                                                                //     if (!player[playerId][dgId]) {
                                                                //         player[playerId][dgId] = {};
                                                                //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                //     } else if (!player[playerId][dgId]['multiplierVal']) {
                                                                //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                //     }
                                                                //     playerRecords[playerId]['multiPlayerScore'][dgId] = playerRecords[playerId]['playerScore'] * player[playerId][dgId]['multiplierVal'];
                                                                // }
                                                            }
                                                        }

                                                        if (result['MLB-event']['baseball-mlb-boxscore-visiting-team-batting-lineup']) {
                                                            var visitingTeamBattingLineup = result['MLB-event']['baseball-mlb-boxscore-visiting-team-batting-lineup'][0]['baseball-mlb-boxscore-batting-lineup'];
                                                            for (i in visitingTeamBattingLineup) { // looping the visiting team batting lineup
                                                                var playerId = visitingTeamBattingLineup[i]['player-code'][0]['$']['global-id'];
                                                                if (!player[playerId]) {
                                                                    player[playerId] = {};
                                                                    // logger.info('Missing (VB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                }
                                                                if (player[playerId]['posGen'] == 'Hitter') { //only hitters are allowed in batting
                                                                    playerRecords[playerId] = {};
                                                                    playerRecords[playerId]['sportId'] = sportId;
                                                                    playerRecords[playerId]['eventCode'] = eventCode;
                                                                    playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                    playerRecords[playerId]['fileName'] = fileName;
                                                                    playerRecords[playerId]['eventId'] = eventId;
                                                                    playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                    playerRecords[playerId]['eventDateTime'] = eventDateTime;

                                                                    playerRecords[playerId]['isAtBat'] = (atBat == playerId) ? true : false;
                                                                    playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                    playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                    if (atBat == playerId) {
                                                                        battingTeam = visitingTeamAlias;
                                                                    }

                                                                    playerRecords[playerId]['teamId'] = visitingTeamId;
                                                                    playerRecords[playerId]['teamName'] = visitingTeamName;
                                                                    playerRecords[playerId]['teamAlias'] = visitingTeamAlias;
                                                                    playerRecords[playerId]['playerId'] = playerId;
                                                                    playerRecords[playerId]['playerPositionId'] = visitingTeamBattingLineup[i]['player-position'][0]['$']['id'];
                                                                    playerRecords[playerId]['playerPosition'] = visitingTeamBattingLineup[i]['player-position'][0]['$']['position'];
                                                                    playerRecords[playerId]['playerName'] = visitingTeamBattingLineup[i]['name'][0]['$']['first-name'] + ' ' + visitingTeamBattingLineup[i]['name'][0]['$']['last-name'];
                                                                    playerRecords[playerId]['playerScore'] = 0;
                                                                    playerRecords[playerId]['multiPlayerScore'] = {};

                                                                    playerRecords[playerId]['playerStats'] = {
                                                                        "battingStats": {},
                                                                        "pitchingStats": {}
                                                                    };
                                                                    playerRecords[playerId]['playerStats']['battingStats']['singles'] = {
                                                                        'val': visitingTeamBattingLineup[i]['hits'][0]['$']['hits'] - (visitingTeamBattingLineup[i]['doubles'][0]['$']['doubles'] - visitingTeamBattingLineup[i]['triples'][0]['$']['triples'] - visitingTeamBattingLineup[i]['home-runs'][0]['$']['home-runs']),
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['singles']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['singles']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['singles']['val'] * playerRecords[playerId]['playerStats']['battingStats']['singles']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['doubles'] = {
                                                                        'val': visitingTeamBattingLineup[i]['doubles'][0]['$']['doubles'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['doubles']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['doubles']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['doubles']['val'] * playerRecords[playerId]['playerStats']['battingStats']['doubles']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['triples'] = {
                                                                        'val': visitingTeamBattingLineup[i]['triples'][0]['$']['triples'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['triples']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['triples']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['triples']['val'] * playerRecords[playerId]['playerStats']['battingStats']['triples']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['home-runs'] = {
                                                                        'val': visitingTeamBattingLineup[i]['home-runs'][0]['$']['home-runs'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['home-runs']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['home-runs']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['home-runs']['val'] * playerRecords[playerId]['playerStats']['battingStats']['home-runs']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['runs-batted-in'] = {
                                                                        'val': visitingTeamBattingLineup[i]['runs-batted-in'][0]['$']['runs-batted-in'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['runs-batted-in']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['runs-batted-in']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['runs-batted-in']['val'] * playerRecords[playerId]['playerStats']['battingStats']['runs-batted-in']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['runs'] = {
                                                                        'val': visitingTeamBattingLineup[i]['runs'][0]['$']['runs'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['runs']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['runs']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['runs']['val'] * playerRecords[playerId]['playerStats']['battingStats']['runs']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['walks'] = {
                                                                        'val': visitingTeamBattingLineup[i]['walks'][0]['$']['walks'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['walks']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['walks']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['walks']['val'] * playerRecords[playerId]['playerStats']['battingStats']['walks']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['stolen-bases'] = {
                                                                        'val': visitingTeamBattingLineup[i]['stolen-bases'][0]['$']['stolen-bases'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['stolen-bases']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['stolen-bases']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['stolen-bases']['val'] * playerRecords[playerId]['playerStats']['battingStats']['stolen-bases']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['hit-by-pitch'] = {
                                                                        'val': visitingTeamBattingLineup[i]['hit-by-pitch'][0]['$']['number'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['hit-by-pitch']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['hit-by-pitch']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['hit-by-pitch']['val'] * playerRecords[playerId]['playerStats']['battingStats']['hit-by-pitch']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['sacrifice-hits'] = {
                                                                        'val': visitingTeamBattingLineup[i]['sacrifice-hits'][0]['$']['number'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['sacrifice-hits']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['sacrifice-hits']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['sacrifice-hits']['val'] * playerRecords[playerId]['playerStats']['battingStats']['sacrifice-hits']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['sacrifice-flies'] = {
                                                                        'val': visitingTeamBattingLineup[i]['sacrifice-flies'][0]['$']['number'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['sacrifice-flies']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['sacrifice-flies']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['sacrifice-flies']['val'] * playerRecords[playerId]['playerStats']['battingStats']['sacrifice-flies']['pts'];

                                                                    if (!player[playerId]['multiplierVal']) {
                                                                        // logger.info('Player Id (Vbatting) ' + playerId + ' has no mValue for event ' + eventId);
                                                                        playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                    } else {
                                                                        playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                    }
                                                                    // for (var dgId in player[playerId]) {
                                                                    //     if (dgId == 'posGen'){
                                                                    //         continue;
                                                                    //     }
                                                                    //     if (!player[playerId][dgId]) {
                                                                    //         player[playerId][dgId] = {};
                                                                    //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                    //     } else if (!player[playerId][dgId]['multiplierVal']) {
                                                                    //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                    //     }
                                                                    //     playerRecords[playerId]['multiPlayerScore'][dgId] = playerRecords[playerId]['playerScore'] * player[playerId][dgId]['multiplierVal'];
                                                                    // }
                                                                }
                                                            }
                                                        }

                                                        if (result['MLB-event']['baseball-mlb-boxscore-visiting-team-pitching-lineup']) {
                                                            var visitingTeamPitchingLineup = result['MLB-event']['baseball-mlb-boxscore-visiting-team-pitching-lineup'][0]['baseball-mlb-boxscore-pitching-lineup'];
                                                            for (i in visitingTeamPitchingLineup) { // looping the visiting team pitching lineup
                                                                var playerId = visitingTeamPitchingLineup[i]['player-code'][0]['$']['global-id'];
                                                                if (!player[playerId]) {
                                                                    player[playerId] = {};
                                                                    // logger.info('Missing (VP) playerId: ' + playerId + ' for the event ' + eventId);
                                                                }
                                                                if (!playerRecords[playerId]) {
                                                                    playerRecords[playerId] = {};

                                                                    playerRecords[playerId]['sportId'] = sportId;
                                                                    playerRecords[playerId]['eventCode'] = eventCode;
                                                                    playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                    playerRecords[playerId]['fileName'] = fileName;
                                                                    playerRecords[playerId]['eventId'] = eventId;
                                                                    playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                    playerRecords[playerId]['eventDateTime'] = eventDateTime;

                                                                    playerRecords[playerId]['isAtBat'] = (atBat == playerId) ? true : false;
                                                                    playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                    playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                    if (atBall == playerId) {
                                                                        battingTeam = homeTeamAlias;
                                                                    }

                                                                    playerRecords[playerId]['teamId'] = visitingTeamId;
                                                                    playerRecords[playerId]['teamName'] = visitingTeamName;
                                                                    playerRecords[playerId]['teamAlias'] = visitingTeamAlias;
                                                                    playerRecords[playerId]['playerId'] = playerId;
                                                                    playerRecords[playerId]['playerScore'] = 0;
                                                                    playerRecords[playerId]['multiPlayerScore'] = {};
                                                                }

                                                                if (visitingTeamPitchingLineup[i]['player-position']) {
                                                                    playerRecords[playerId]['playerPositionId'] = visitingTeamPitchingLineup[i]['player-position'][0]['$']['id'];
                                                                    playerRecords[playerId]['playerPosition'] = visitingTeamPitchingLineup[i]['player-position'][0]['$']['position'];
                                                                }
                                                                playerRecords[playerId]['playerName'] = visitingTeamPitchingLineup[i]['name'][0]['$']['first-name'] + ' ' + visitingTeamPitchingLineup[i]['name'][0]['$']['last-name'];

                                                                if (!playerRecords[playerId]['playerStats']) {
                                                                    playerRecords[playerId]['playerStats'] = {
                                                                        "battingStats": {},
                                                                        "pitchingStats": {}
                                                                    };
                                                                }

                                                                var win = 0;
                                                                if (visitingTeamPitchingLineup[i]['winning-pitcher']) {
                                                                    win = (visitingTeamPitchingLineup[i]['winning-pitcher'][0]['$']['winning-pitcher'] == "true") ? 1 : 0;
                                                                }
                                                                playerRecords[playerId]['playerStats']['pitchingStats']['wins'] = {
                                                                    // 'val': visitingTeamPitchingLineup[i]['wins'][0]['$']['number'],
                                                                    'val': win,
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['wins']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['wins']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['wins']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['wins']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['hits'] = {
                                                                    'val': visitingTeamPitchingLineup[i]['hits'][0]['$']['hits'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['hits']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['hits']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['hits']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['hits']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['earned-runs'] = {
                                                                    'val': visitingTeamPitchingLineup[i]['earned-runs'][0]['$']['earned-runs'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['earned-runs']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['earned-runs']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['earned-runs']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['earned-runs']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['strike-outs'] = {
                                                                    'val': visitingTeamPitchingLineup[i]['strike-outs'][0]['$']['strike-outs'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['strike-outs']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['strike-outs']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['strike-outs']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['strike-outs']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['innings-pitched'] = {
                                                                    'val': visitingTeamPitchingLineup[i]['innings-pitched'][0]['$']['innings'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['innings-pitched']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['innings-pitched']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['innings-pitched']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['innings-pitched']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['walks'] = {
                                                                    'val': visitingTeamPitchingLineup[i]['walks'][0]['$']['walks'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['walks']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['walks']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['walks']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['walks']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['hit-batsmen'] = {
                                                                    'val': visitingTeamPitchingLineup[i]['hit-batsmen'][0]['$']['number'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['hit-batsmen']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['hit-batsmen']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['hit-batsmen']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['hit-batsmen']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['gidp'] = {
                                                                    'val': visitingTeamPitchingLineup[i]['gidp'][0]['$']['number'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['gidp']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['gidp']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['gidp']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['gidp']['pts'];

                                                                if (!player[playerId]['multiplierVal']) {
                                                                    // logger.info('Player Id (Vpitching) ' + playerId + ' has no mValue for event ' + eventId);
                                                                    playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                } else {
                                                                    playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                }
                                                                // for (var dgId in player[playerId]) {
                                                                //     if (dgId == 'posGen'){
                                                                //         continue;
                                                                //     }
                                                                //     if (!player[playerId][dgId]) {
                                                                //         player[playerId][dgId] = {};
                                                                //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                //     } else if (!player[playerId][dgId]['multiplierVal']) {
                                                                //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                //     }
                                                                //     playerRecords[playerId]['multiPlayerScore'][dgId] = playerRecords[playerId]['playerScore'] * player[playerId][dgId]['multiplierVal'];
                                                                // }
                                                            }
                                                        }

                                                        await PlayerScoreModel.update({ // making the isAtBat false for an old player
                                                            'eventId': eventId,
                                                            'isAtBat': 'true',
                                                        }, {
                                                            $set: {
                                                                'liveGameInfo': liveGameInfo,
                                                                'liveGameInfo2': liveGameInfo2,
                                                                'isAtBat': false,
                                                                'eventStatus': eventStatus,
                                                                'possTeam': battingTeam,
                                                                'homeScore': homeScore,
                                                                'awayScore': visitingScore,
                                                                'homeAbbr': homeTeamAlias,
                                                                'awayAbbr': visitingTeamAlias,
                                                                'clock': eventClock
                                                            }
                                                        }, {
                                                            upsert: false
                                                        });

                                                        var batterFound = 'N';
                                                        var playerCnt = 0;
                                                        for (var i in playerRecords) { // Updating the player records in the database
                                                            playerCnt++;
                                                            playerRecords[i]['possTeam'] = battingTeam;

                                                            playerRecords[i]['awayAbbr'] = visitingTeamAlias;
                                                            playerRecords[i]['homeAbbr'] = homeTeamAlias;
                                                            playerRecords[i]['awayScore'] = visitingScore;
                                                            playerRecords[i]['homeScore'] = homeScore;
                                                            playerRecords[i]['clock'] = eventClock;

                                                            if (playerRecords[i]['isAtBat'] == true) {
                                                                batterFound = 'Y';
                                                            }

                                                            var playerUpdate = await PlayerScoreModel.update({
                                                                'playerId': playerRecords[i]['playerId'],
                                                                'eventId': playerRecords[i]['eventId']
                                                            }, {
                                                                $set: playerRecords[i]
                                                            }, {
                                                                upsert: true
                                                            });

                                                            logger.info('Inserted to db: ' + playerRecords[i]['eventId'] + '-' + playerRecords[i]['playerId'] + '-' + fileName);
                                                            // logger.info(JSON.stringify(playerUpdate));

                                                        }
                                                        logger.info('Player Count: ' + playerCnt + ' in ' + fileName);

                                                        if (batterFound == 'N' && atBat != '') { //if batter's record has not come with the data, update the existing record
                                                            await PlayerScoreModel.update({
                                                                'playerId': atBat,
                                                                'eventId': eventId
                                                            }, {
                                                                $set: {
                                                                    'liveGameInfo': liveGameInfo,
                                                                    'liveGameInfo2': liveGameInfo2,
                                                                    'isAtBat': true,
                                                                    'eventStatus': eventStatus,
                                                                    'possTeam': battingTeam,
                                                                    'homeScore': homeScore,
                                                                    'awayScore': visitingScore,
                                                                    'homeAbbr': homeTeamAlias,
                                                                    'awayAbbr': visitingTeamAlias,
                                                                    'clock': eventClock,
                                                                    'fileName': fileName
                                                                }
                                                            }, {
                                                                upsert: false
                                                            });
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } catch (e) {
                                    logger.info('FileName: ' + fileName);
                                    logger.info(e);
                                }
                                // process.exit();
                            });
                            fs.renameSync('./temp/mlb/unprocessed/' + fileName, './temp/mlb/processed/' + fileName);
                        } else {
                            // process.exit();
                        }
                    } catch (e) {
                        logger.info('FileName: ' + fileName);
                        logger.info(e);
                        // process.exit();
                    }
                });
            } else {
                logger.info('No File found');
                // process.exit();
            }
        } catch (e) {
            logger.info(e);
            // process.exit();
        }
    },

    /**
     * Cron - To get all Player details from the DOWNLOADed xml file and parse it and update it to the db
     */
    mlbPlayerScoreDownload: async function () {
        try {
            var logger = new(winston.Logger)({
                transports: [
                    new(winston.transports.Console)(),
                    new(winston.transports.File)({
                        filename: './app/modules/crons/logs/mlb_download_xml_parsing.log'
                    })
                ]
            });

            var psData = await PlayerScoreModel.findOne({
                $or: [{
                    $and: [{
                            'eventStatus': 'Final'
                        },
                        {
                            'downloadUpdate': 'N'
                        },
                        {
                            'sportId': 2
                        },
                        {
                            'eventCode': {
                                $exists: true
                            }
                        }
                    ]
                }, {
                    $and: [{
                            'eventStatus': 'In-Progress'
                        }, {
                            'createdAt': {
                                $lte: new Date(Date.now() - (1000 * 60 * 60 * 4)) // 4 hrs
                            }
                        },
                        {
                            'sportId': 2
                        },
                        {
                            'eventCode': {
                                $exists: true
                            }
                        }
                    ]
                }]
            }, 'eventId eventCode eventStatus');

            // psData = {
            //     eventCode: 380702119
            // };
            if (psData != null) {
                var downloadFile = 'MLB_FINALBOX$' + psData.eventCode + '.XML'; // to do
                // console.log(downloadFile);
                request({
                        'url': "http://downloads.stats.com/ContourDesign/" + downloadFile,
                        'auth': {
                            'user': 'ContourDesign',
                            'pass': 'football1738',
                            'sendImmediately': false
                        }
                    },
                    async function (err, response, body) {
                        try {
                            // parse the body as JSON
                            if (!err && response.statusCode == 200) {
                                var fileCont = body.toString().replace('<?xml version="1.0" encoding="UTF-8"?>', '').trim();
                                if (fileCont != '') { // if the file is not empty
                                    var parser = new xml2js.Parser();
                                    parser.parseString(fileCont, async function (err, result) {
                                        try {
                                            if (err) {
                                                logger.info('FileName: ' + downloadFile);
                                                logger.info(err);
                                            } else if (result['sports-statistics']) {
                                                var playerRecords = {};
                                                var mlbBoxScore = result['sports-statistics']['sports-boxscores'][0]['baseball-mlb-boxscores'][0]['baseball-mlb-boxscore'][0];
                                                if (mlbBoxScore['date']) {
                                                    var dt = mlbBoxScore['date'][0]['$'];
                                                    var t = mlbBoxScore['time'][0]['$'];
                                                    try {
                                                        var dtt = moment([dt['year'], dt['month'], dt['date'], t['hour'], t['minute'], 0, 0]).add({
                                                            hours: t['utc-hour'],
                                                            minutes: t['utc-minute']
                                                        });
                                                        var eventDateTime = dtt.format('YYYY-MM-DD hh:mm:ss A');
                                                    } catch (e) {
                                                        var eventDateTime = '';
                                                    }
                                                } else {
                                                    var eventDateTime = '';
                                                }

                                                var sportId = 2;
                                                var eventCode = mlbBoxScore['gamecode'][0]['$']['code'];
                                                var downloadUpdate = 'Y';
                                                var eventId = mlbBoxScore['gamecode'][0]['$']['global-id'];
                                                var eventStatus = mlbBoxScore['gamestate'][0]['$']['status'];
                                                var atBat = '';

                                                var visitingScore = '';
                                                var homeScore = '';
                                                var visitingTeamAlias = '';
                                                var homeTeamAlias = '';
                                                var eventClock = '';

                                                var liveGameInfo = '';
                                                var liveGameInfo2 = '';
                                                var possTeam = '';
                                                var player = {};

                                                logger.info('FileName: ' + downloadFile + ' EventId: ' + eventId);

                                                await DraftGroupModel.update({
                                                    'gameList.eventId': eventId
                                                }, {
                                                    'gameList.$.gameStatus': eventStatus
                                                }, {
                                                    multi: true
                                                });

                                                var dgs = await DraftGroupModel.find({
                                                    'gameList.eventId': eventId
                                                }, 'gameList draftgroupId');

                                                for (dg of dgs) {
                                                    var status = '';
                                                    var dgId = dg.draftgroupId;

                                                    for (var thisGame of dg.gameList) {
                                                        if (thisGame.eventId == eventId) {
                                                            for (p of thisGame.players) { // fetching player details (DG->GameList->Players)
                                                                if (!player[p.playerId]) {
                                                                    player[p.playerId] = {};
                                                                }
                                                                if (p.posGen) {
                                                                    player[p.playerId]['posGen'] = p.posGen;
                                                                }

                                                                if (p.mValue) {
                                                                    player[p.playerId]['multiplierVal'] = p.mValue.value;
                                                                }
                                                            }
                                                        }
                                                    }

                                                    var postponedMatchCnt = 0;
                                                    var totalMatchCnt = dg.gameList.length;
                                                    for (var g of dg.gameList) {
                                                        if (g.gameStatus == 'In-Progress') {
                                                            status = g.gameStatus;
                                                            break;
                                                        } else if (g.gameStatus == 'Cancelled') {
                                                            // Do nothing
                                                        } else if (g.gameStatus == 'Postponed') {
                                                            postponedMatchCnt++;
                                                            if (status == '') { // if all the matches are postponed
                                                                status == 'Postponed';
                                                            }
                                                        } else if (g.gameStatus == 'Final') {
                                                            if (status == 'Upcoming') {
                                                                status = 'In-Progress';
                                                                break;
                                                            }
                                                            status = g.gameStatus;
                                                        } else {
                                                            if (status == 'Final') {
                                                                status = 'In-Progress';
                                                                break;
                                                            }
                                                            status = 'Upcoming';
                                                        }
                                                    }

                                                    if (status == 'Final' && postponedMatchCnt == (totalMatchCnt - 1)) { // if n-1 matches gets postponed
                                                        status = 'Postponed';
                                                    }

                                                    var contestStatus = 3;
                                                    var dfStatus = 'Upcoming';
                                                    if (status == 'Final') {
                                                        contestStatus = 1;
                                                        dfStatus = 'Completed';
                                                    } else if (status == 'In-Progress') {
                                                        contestStatus = 2;
                                                        dfStatus = 'Live';
                                                    } else if (status == 'Postponed') {
                                                        contestStatus = 4;
                                                        dfStatus = 'Cancelled';
                                                    }

                                                    await DraftGroupModel.update({
                                                        'draftgroupId': dgId
                                                    }, {
                                                        'dgState': dfStatus
                                                    });

                                                    await contestModel.update({
                                                        'draftgroupId': dgId,
                                                        'contestStatus': {
                                                            $in: [1, 2, 3]
                                                        }
                                                    }, {
                                                        'contestStatus': contestStatus
                                                    }, {
                                                        multi: true
                                                    });
                                                }

                                                if (eventStatus == 'Final') { // fix for not to miss any player record if the status is final
                                                    await PlayerScoreModel.update({
                                                        'eventId': eventId
                                                    }, {
                                                        'eventStatus': eventStatus,
                                                        'liveGameInfo': liveGameInfo,
                                                        'liveGameInfo2': liveGameInfo2,
                                                        'isAtBat': false,
                                                        'possTeam': '',
                                                        'homeScore': homeScore,
                                                        'awayScore': visitingScore,
                                                        'homeAbbr': homeTeamAlias,
                                                        'awayAbbr': visitingTeamAlias,
                                                        'clock': eventClock,
                                                        'downloadUpdate': downloadUpdate,
                                                        'fileName': downloadFile
                                                    }, {
                                                        multi: true
                                                    });
                                                }

                                                if (eventStatus == 'In-Progress' || eventStatus == 'Final') { // consider inprogress and final only
                                                    if (mlbBoxScore['home-team'] && mlbBoxScore['visiting-team']) {
                                                        var homeTeamName = mlbBoxScore['home-team'][0]['team-name'][0]['$']['name'];
                                                        homeTeamAlias = mlbBoxScore['home-team'][0]['team-name'][0]['$']['alias'];
                                                        var homeTeamId = mlbBoxScore['home-team'][0]['team-code'][0]['$']['id'];
                                                        var visitingTeamName = mlbBoxScore['visiting-team'][0]['team-name'][0]['$']['name'];
                                                        visitingTeamAlias = mlbBoxScore['visiting-team'][0]['team-name'][0]['$']['alias'];
                                                        var visitingTeamId = mlbBoxScore['visiting-team'][0]['team-code'][0]['$']['id'];

                                                        for (var i in mlbBoxScore['visiting-score']) {
                                                            if (mlbBoxScore['visiting-score'][i]['$']['type'] == 'runs') {
                                                                visitingScore = ' ' + mlbBoxScore['visiting-score'][i]['$']['number'];
                                                                break;
                                                            }
                                                        }
                                                        for (var i in mlbBoxScore['home-score']) {
                                                            if (mlbBoxScore['home-score'][i]['$']['type'] == 'runs') {
                                                                homeScore = ' ' + mlbBoxScore['home-score'][i]['$']['number'] + ' ';
                                                                break;
                                                            }
                                                        }

                                                        var inning = mlbBoxScore['gamestate'][0]['$']['segment-number'];
                                                        //eventClock = ((mlbBoxScore['gamestate'][0]['$']['segment-division'] == 'Top') ? 'TOP' : 'BOT') +
                                                          eventClock = ((mlbBoxScore['gamestate'][0]['$']['segment-division'] == 'Top') ? 'BOT' : 'TOP') +
                                                            ' ' + inning + ((inning == 1) ? 'st' : ((inning == 2) ? 'nd' : ((inning == 3) ? 'rd' : 'th')));

                                                        liveGameInfo = visitingTeamAlias + ' ' + visitingScore + ' @ ' + homeTeamAlias + ' ' + homeScore + eventClock;

                                                        if (mlbBoxScore['baseball-mlb-boxscore-home-team-batting-lineup']) {
                                                            var homeTeamBattingLineup = mlbBoxScore['baseball-mlb-boxscore-home-team-batting-lineup'][0]['baseball-mlb-boxscore-batting-lineup'];
                                                            for (i in homeTeamBattingLineup) { // looping the home team batting lineup
                                                                var playerId = homeTeamBattingLineup[i]['player-code'][0]['$']['global-id'];
                                                                if (!player[playerId]) {
                                                                    player[playerId] = {};
                                                                    // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                }
                                                                if (player[playerId]['posGen'] == 'Hitter') { //only hitters are allowed in batting
                                                                    playerRecords[playerId] = {};
                                                                    playerRecords[playerId]['sportId'] = sportId;
                                                                    playerRecords[playerId]['eventCode'] = eventCode;
                                                                    playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                    playerRecords[playerId]['fileName'] = downloadFile;
                                                                    playerRecords[playerId]['eventId'] = eventId;
                                                                    playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                    playerRecords[playerId]['eventDateTime'] = eventDateTime;

                                                                    playerRecords[playerId]['isAtBat'] = (atBat == playerId) ? true : false;
                                                                    playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                    playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                    playerRecords[playerId]['possTeam'] = possTeam;

                                                                    playerRecords[playerId]['teamId'] = homeTeamId;
                                                                    playerRecords[playerId]['teamName'] = homeTeamName;
                                                                    playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                    playerRecords[playerId]['playerId'] = playerId;
                                                                    playerRecords[playerId]['playerScore'] = 0;
                                                                    playerRecords[playerId]['multiPlayerScore'] = {};
                                                                    playerRecords[playerId]['playerPositionId'] = homeTeamBattingLineup[i]['player-position'][0]['$']['id'];
                                                                    playerRecords[playerId]['playerPosition'] = homeTeamBattingLineup[i]['player-position'][0]['$']['position'];
                                                                    playerRecords[playerId]['playerName'] = homeTeamBattingLineup[i]['name'][0]['$']['first-name'] + ' ' + homeTeamBattingLineup[i]['name'][0]['$']['last-name'];

                                                                    playerRecords[playerId]['playerStats'] = {
                                                                        "battingStats": {},
                                                                        "pitchingStats": {}
                                                                    };
                                                                    playerRecords[playerId]['playerStats']['battingStats']['singles'] = {
                                                                        'val': homeTeamBattingLineup[i]['hits'][0]['$']['hits'] - (homeTeamBattingLineup[i]['doubles'][0]['$']['doubles'] - homeTeamBattingLineup[i]['triples'][0]['$']['triples'] - homeTeamBattingLineup[i]['home-runs'][0]['$']['home-runs'] - homeTeamBattingLineup[i]['grandslams'][0]['$']['grandslams']),
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['singles']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['singles']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['singles']['val'] * playerRecords[playerId]['playerStats']['battingStats']['singles']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['doubles'] = {
                                                                        'val': homeTeamBattingLineup[i]['doubles'][0]['$']['doubles'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['doubles']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['doubles']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['doubles']['val'] * playerRecords[playerId]['playerStats']['battingStats']['doubles']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['triples'] = {
                                                                        'val': homeTeamBattingLineup[i]['triples'][0]['$']['triples'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['triples']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['triples']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['triples']['val'] * playerRecords[playerId]['playerStats']['battingStats']['triples']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['home-runs'] = {
                                                                        'val': homeTeamBattingLineup[i]['home-runs'][0]['$']['home-runs']+homeTeamBattingLineup[i]['grandslams'][0]['$']['grandslams'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['home-runs']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['home-runs']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['home-runs']['val'] * playerRecords[playerId]['playerStats']['battingStats']['home-runs']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['runs-batted-in'] = {
                                                                        'val': homeTeamBattingLineup[i]['runs-batted-in'][0]['$']['runs-batted-in'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['runs-batted-in']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['runs-batted-in']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['runs-batted-in']['val'] * playerRecords[playerId]['playerStats']['battingStats']['runs-batted-in']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['runs'] = {
                                                                        'val': homeTeamBattingLineup[i]['runs'][0]['$']['runs'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['runs']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['runs']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['runs']['val'] * playerRecords[playerId]['playerStats']['battingStats']['runs']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['walks'] = {
                                                                        'val': homeTeamBattingLineup[i]['walks'][0]['$']['walks'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['walks']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['walks']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['walks']['val'] * playerRecords[playerId]['playerStats']['battingStats']['walks']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['stolen-bases'] = {
                                                                        'val': homeTeamBattingLineup[i]['stolen-bases'][0]['$']['stolen-bases'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['stolen-bases']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['stolen-bases']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['stolen-bases']['val'] * playerRecords[playerId]['playerStats']['battingStats']['stolen-bases']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['hit-by-pitch'] = {
                                                                        'val': homeTeamBattingLineup[i]['hit-by-pitch'][0]['$']['number'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['hit-by-pitch']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['hit-by-pitch']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['hit-by-pitch']['val'] * playerRecords[playerId]['playerStats']['battingStats']['hit-by-pitch']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['sacrifice-hits'] = {
                                                                        'val': homeTeamBattingLineup[i]['sacrifice-hits'][0]['$']['number'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['sacrifice-hits']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['sacrifice-hits']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['sacrifice-hits']['val'] * playerRecords[playerId]['playerStats']['battingStats']['sacrifice-hits']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['sacrifice-flies'] = {
                                                                        'val': homeTeamBattingLineup[i]['sacrifice-flies'][0]['$']['number'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['sacrifice-flies']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['sacrifice-flies']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['sacrifice-flies']['val'] * playerRecords[playerId]['playerStats']['battingStats']['sacrifice-flies']['pts'];

                                                                    if (!player[playerId]['multiplierVal']) {
                                                                        // logger.info('Player Id (Hbatting) ' + playerId + ' has no mValue for event ' + eventId);
                                                                        playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                    } else {
                                                                        playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                    }
                                                                    // for (var dgId in player[playerId]) {
                                                                    //     if (dgId == 'posGen'){
                                                                    //         continue;
                                                                    //     }
                                                                    //     if (!player[playerId][dgId]) {
                                                                    //         player[playerId][dgId] = {};
                                                                    //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                    //     } else if (!player[playerId][dgId]['multiplierVal']) {
                                                                    //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                    //     }
                                                                    //     playerRecords[playerId]['multiPlayerScore'][dgId] = playerRecords[playerId]['playerScore'] * player[playerId][dgId]['multiplierVal'];
                                                                    // }
                                                                }
                                                            }
                                                        }

                                                        if (mlbBoxScore['baseball-mlb-boxscore-home-team-pitching-lineup']) {
                                                            var homeTeamPitchingLineup = mlbBoxScore['baseball-mlb-boxscore-home-team-pitching-lineup'][0]['baseball-mlb-boxscore-pitching-lineup'];
                                                            for (i in homeTeamPitchingLineup) { // looping the home team pitching lineup
                                                                var playerId = homeTeamPitchingLineup[i]['player-code'][0]['$']['global-id'];
                                                                if (!player[playerId]) {
                                                                    player[playerId] = {};
                                                                    // logger.info('Missing (HP) playerId: ' + playerId + ' for the event ' + eventId);
                                                                }
                                                                if (!playerRecords[playerId]) {
                                                                    playerRecords[playerId] = {};
                                                                    playerRecords[playerId]['sportId'] = sportId;
                                                                    playerRecords[playerId]['eventCode'] = eventCode;
                                                                    playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                    playerRecords[playerId]['fileName'] = downloadFile;
                                                                    playerRecords[playerId]['eventId'] = eventId;
                                                                    playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                    playerRecords[playerId]['eventDateTime'] = eventDateTime;

                                                                    playerRecords[playerId]['isAtBat'] = (atBat == playerId) ? true : false;
                                                                    playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                    playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                    playerRecords[playerId]['possTeam'] = possTeam;

                                                                    playerRecords[playerId]['teamId'] = homeTeamId;
                                                                    playerRecords[playerId]['teamName'] = homeTeamName;
                                                                    playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                    playerRecords[playerId]['playerId'] = playerId;
                                                                    playerRecords[playerId]['playerScore'] = 0;
                                                                    playerRecords[playerId]['multiPlayerScore'] = {};
                                                                }
                                                                if (homeTeamPitchingLineup[i]['player-position']) {
                                                                    playerRecords[playerId]['playerPositionId'] = homeTeamPitchingLineup[i]['player-position'][0]['$']['id'];
                                                                    playerRecords[playerId]['playerPosition'] = homeTeamPitchingLineup[i]['player-position'][0]['$']['position'];
                                                                }
                                                                playerRecords[playerId]['playerName'] = homeTeamPitchingLineup[i]['name'][0]['$']['first-name'] + ' ' + homeTeamPitchingLineup[i]['name'][0]['$']['last-name'];

                                                                if (!playerRecords[playerId]['playerStats']) {
                                                                    playerRecords[playerId]['playerStats'] = {
                                                                        "battingStats": {},
                                                                        "pitchingStats": {}
                                                                    };
                                                                }

                                                                var win = 0;
                                                                if (homeTeamPitchingLineup[i]['winning-pitcher']) {
                                                                    win = (homeTeamPitchingLineup[i]['winning-pitcher'][0]['$']['winning-pitcher'] == "true") ? 1 : 0;
                                                                }
                                                                playerRecords[playerId]['playerStats']['pitchingStats']['wins'] = {
                                                                    // 'val': homeTeamPitchingLineup[i]['wins'][0]['$']['number'],
                                                                    'val': win,
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['wins']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['wins']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['wins']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['wins']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['hits'] = {
                                                                    'val': homeTeamPitchingLineup[i]['hits'][0]['$']['hits'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['hits']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['hits']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['hits']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['hits']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['earned-runs'] = {
                                                                    'val': homeTeamPitchingLineup[i]['earned-runs'][0]['$']['earned-runs'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['earned-runs']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['earned-runs']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['earned-runs']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['earned-runs']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['strike-outs'] = {
                                                                    'val': homeTeamPitchingLineup[i]['strike-outs'][0]['$']['strike-outs'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['strike-outs']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['strike-outs']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['strike-outs']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['strike-outs']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['innings-pitched'] = {
                                                                    'val': homeTeamPitchingLineup[i]['innings-pitched'][0]['$']['innings'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['innings-pitched']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['innings-pitched']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['innings-pitched']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['innings-pitched']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['walks'] = {
                                                                    'val': homeTeamPitchingLineup[i]['walks'][0]['$']['walks'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['walks']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['walks']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['walks']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['walks']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['hit-batsmen'] = {
                                                                    'val': homeTeamPitchingLineup[i]['hit-batsmen'][0]['$']['number'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['hit-batsmen']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['hit-batsmen']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['hit-batsmen']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['hit-batsmen']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['gidp'] = {
                                                                    'val': homeTeamPitchingLineup[i]['gidp'][0]['$']['number'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['gidp']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['gidp']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['gidp']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['gidp']['pts'];

                                                                if (!player[playerId]['multiplierVal']) {
                                                                    // logger.info('Player Id (Hpitching) ' + playerId + ' has no mValue for event ' + eventId);
                                                                    playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                } else {
                                                                    playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                }
                                                                // for (var dgId in player[playerId]) {
                                                                //     if (dgId == 'posGen'){
                                                                //         continue;
                                                                //     }
                                                                //     if (!player[playerId][dgId]) {
                                                                //         player[playerId][dgId] = {};
                                                                //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                //     } else if (!player[playerId][dgId]['multiplierVal']) {
                                                                //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                //     }
                                                                //     playerRecords[playerId]['multiPlayerScore'][dgId] = playerRecords[playerId]['playerScore'] * player[playerId][dgId]['multiplierVal'];
                                                                // }
                                                            }
                                                        }

                                                        if (mlbBoxScore['baseball-mlb-boxscore-visiting-team-batting-lineup']) {
                                                            var visitingTeamBattingLineup = mlbBoxScore['baseball-mlb-boxscore-visiting-team-batting-lineup'][0]['baseball-mlb-boxscore-batting-lineup'];
                                                            for (i in visitingTeamBattingLineup) { // looping the visiting team batting lineup
                                                                var playerId = visitingTeamBattingLineup[i]['player-code'][0]['$']['global-id'];
                                                                if (!player[playerId]) {
                                                                    player[playerId] = {};
                                                                    // logger.info('Missing (VB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                }
                                                                if (player[playerId]['posGen'] == 'Hitter') { //only hitters are allowed in batting
                                                                    playerRecords[playerId] = {};
                                                                    playerRecords[playerId]['sportId'] = sportId;
                                                                    playerRecords[playerId]['eventCode'] = eventCode;
                                                                    playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                    playerRecords[playerId]['fileName'] = downloadFile;
                                                                    playerRecords[playerId]['eventId'] = eventId;
                                                                    playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                    playerRecords[playerId]['eventDateTime'] = eventDateTime;

                                                                    playerRecords[playerId]['isAtBat'] = (atBat == playerId) ? true : false;
                                                                    playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                    playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                    playerRecords[playerId]['possTeam'] = possTeam;

                                                                    playerRecords[playerId]['teamId'] = visitingTeamId;
                                                                    playerRecords[playerId]['teamName'] = visitingTeamName;
                                                                    playerRecords[playerId]['teamAlias'] = visitingTeamAlias;
                                                                    playerRecords[playerId]['playerId'] = playerId;
                                                                    playerRecords[playerId]['playerScore'] = 0;
                                                                    playerRecords[playerId]['multiPlayerScore'] = {};
                                                                    playerRecords[playerId]['playerPositionId'] = visitingTeamBattingLineup[i]['player-position'][0]['$']['id'];
                                                                    playerRecords[playerId]['playerPosition'] = visitingTeamBattingLineup[i]['player-position'][0]['$']['position'];
                                                                    playerRecords[playerId]['playerName'] = visitingTeamBattingLineup[i]['name'][0]['$']['first-name'] + ' ' + visitingTeamBattingLineup[i]['name'][0]['$']['last-name'];

                                                                    playerRecords[playerId]['playerStats'] = {
                                                                        "battingStats": {},
                                                                        "pitchingStats": {}
                                                                    };
                                                                    playerRecords[playerId]['playerStats']['battingStats']['singles'] = {
                                                                        'val': visitingTeamBattingLineup[i]['hits'][0]['$']['hits'] - (visitingTeamBattingLineup[i]['doubles'][0]['$']['doubles'] - visitingTeamBattingLineup[i]['triples'][0]['$']['triples'] - visitingTeamBattingLineup[i]['home-runs'][0]['$']['home-runs'] - visitingTeamBattingLineup[i]['grandslams'][0]['$']['grandslams']),
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['singles']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['singles']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['singles']['val'] * playerRecords[playerId]['playerStats']['battingStats']['singles']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['doubles'] = {
                                                                        'val': visitingTeamBattingLineup[i]['doubles'][0]['$']['doubles'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['doubles']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['doubles']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['doubles']['val'] * playerRecords[playerId]['playerStats']['battingStats']['doubles']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['triples'] = {
                                                                        'val': visitingTeamBattingLineup[i]['triples'][0]['$']['triples'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['triples']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['triples']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['triples']['val'] * playerRecords[playerId]['playerStats']['battingStats']['triples']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['home-runs'] = {
                                                                        'val': visitingTeamBattingLineup[i]['home-runs'][0]['$']['home-runs']+visitingTeamBattingLineup[i]['grandslams'][0]['$']['grandslams'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['home-runs']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['home-runs']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['home-runs']['val'] * playerRecords[playerId]['playerStats']['battingStats']['home-runs']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['runs-batted-in'] = {
                                                                        'val': visitingTeamBattingLineup[i]['runs-batted-in'][0]['$']['runs-batted-in'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['runs-batted-in']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['runs-batted-in']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['runs-batted-in']['val'] * playerRecords[playerId]['playerStats']['battingStats']['runs-batted-in']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['runs'] = {
                                                                        'val': visitingTeamBattingLineup[i]['runs'][0]['$']['runs'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['runs']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['runs']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['runs']['val'] * playerRecords[playerId]['playerStats']['battingStats']['runs']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['walks'] = {
                                                                        'val': visitingTeamBattingLineup[i]['walks'][0]['$']['walks'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['walks']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['walks']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['walks']['val'] * playerRecords[playerId]['playerStats']['battingStats']['walks']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['stolen-bases'] = {
                                                                        'val': visitingTeamBattingLineup[i]['stolen-bases'][0]['$']['stolen-bases'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['stolen-bases']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['stolen-bases']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['stolen-bases']['val'] * playerRecords[playerId]['playerStats']['battingStats']['stolen-bases']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['hit-by-pitch'] = {
                                                                        'val': visitingTeamBattingLineup[i]['hit-by-pitch'][0]['$']['number'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['hit-by-pitch']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['hit-by-pitch']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['hit-by-pitch']['val'] * playerRecords[playerId]['playerStats']['battingStats']['hit-by-pitch']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['sacrifice-hits'] = {
                                                                        'val': visitingTeamBattingLineup[i]['sacrifice-hits'][0]['$']['number'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['sacrifice-hits']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['sacrifice-hits']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['sacrifice-hits']['val'] * playerRecords[playerId]['playerStats']['battingStats']['sacrifice-hits']['pts'];

                                                                    playerRecords[playerId]['playerStats']['battingStats']['sacrifice-flies'] = {
                                                                        'val': visitingTeamBattingLineup[i]['sacrifice-flies'][0]['$']['number'],
                                                                        'pts': mlbScoringRules.mlbScore['battingStats']['sacrifice-flies']['pts'],
                                                                        'abr': mlbScoringRules.mlbScore['battingStats']['sacrifice-flies']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['battingStats']['sacrifice-flies']['val'] * playerRecords[playerId]['playerStats']['battingStats']['sacrifice-flies']['pts'];

                                                                    if (!player[playerId]['multiplierVal']) {
                                                                        // logger.info('Player Id (Vbatting) ' + playerId + ' has no mValue for event ' + eventId);
                                                                        playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                    } else {
                                                                        playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                    }
                                                                    // for (var dgId in player[playerId]) {
                                                                    //     if (dgId == 'posGen'){
                                                                    //         continue;
                                                                    //     }
                                                                    //     if (!player[playerId][dgId]) {
                                                                    //         player[playerId][dgId] = {};
                                                                    //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                    //     } else if (!player[playerId][dgId]['multiplierVal']) {
                                                                    //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                    //     }
                                                                    //     playerRecords[playerId]['multiPlayerScore'][dgId] = playerRecords[playerId]['playerScore'] * player[playerId][dgId]['multiplierVal'];
                                                                    // }
                                                                }
                                                            }
                                                        }

                                                        if (mlbBoxScore['baseball-mlb-boxscore-visiting-team-pitching-lineup']) {
                                                            var visitingTeamPitchingLineup = mlbBoxScore['baseball-mlb-boxscore-visiting-team-pitching-lineup'][0]['baseball-mlb-boxscore-pitching-lineup'];
                                                            for (i in visitingTeamPitchingLineup) { // looping the visiting team pitching lineup
                                                                var playerId = visitingTeamPitchingLineup[i]['player-code'][0]['$']['global-id'];
                                                                if (!player[playerId]) {
                                                                    player[playerId] = {};
                                                                    // logger.info('Missing (VP) playerId: ' + playerId + ' for the event ' + eventId);
                                                                }
                                                                if (!playerRecords[playerId]) {
                                                                    playerRecords[playerId] = {};
                                                                    playerRecords[playerId]['sportId'] = sportId;
                                                                    playerRecords[playerId]['eventCode'] = eventCode;
                                                                    playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                    playerRecords[playerId]['fileName'] = downloadFile;
                                                                    playerRecords[playerId]['eventId'] = eventId;
                                                                    playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                    playerRecords[playerId]['eventDateTime'] = eventDateTime;

                                                                    playerRecords[playerId]['isAtBat'] = (atBat == playerId) ? true : false;
                                                                    playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                    playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                    playerRecords[playerId]['possTeam'] = possTeam;

                                                                    playerRecords[playerId]['teamId'] = visitingTeamId;
                                                                    playerRecords[playerId]['teamName'] = visitingTeamName;
                                                                    playerRecords[playerId]['teamAlias'] = visitingTeamAlias;
                                                                    playerRecords[playerId]['playerId'] = playerId;
                                                                    playerRecords[playerId]['playerScore'] = 0;
                                                                    playerRecords[playerId]['multiPlayerScore'] = {};
                                                                }
                                                                if (visitingTeamPitchingLineup[i]['player-position']) {
                                                                    playerRecords[playerId]['playerPositionId'] = visitingTeamPitchingLineup[i]['player-position'][0]['$']['id'];
                                                                    playerRecords[playerId]['playerPosition'] = visitingTeamPitchingLineup[i]['player-position'][0]['$']['position'];
                                                                }
                                                                playerRecords[playerId]['playerName'] = visitingTeamPitchingLineup[i]['name'][0]['$']['first-name'] + ' ' + visitingTeamPitchingLineup[i]['name'][0]['$']['last-name'];

                                                                if (!playerRecords[playerId]['playerStats']) {
                                                                    playerRecords[playerId]['playerStats'] = {
                                                                        "battingStats": {},
                                                                        "pitchingStats": {}
                                                                    };
                                                                }

                                                                var win = 0;
                                                                if (visitingTeamPitchingLineup[i]['winning-pitcher']) {
                                                                    win = (visitingTeamPitchingLineup[i]['winning-pitcher'][0]['$']['winning-pitcher'] == "true") ? 1 : 0;
                                                                }
                                                                playerRecords[playerId]['playerStats']['pitchingStats']['wins'] = {
                                                                    // 'val': visitingTeamPitchingLineup[i]['wins'][0]['$']['number'],
                                                                    'val': win,
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['wins']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['wins']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['wins']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['wins']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['hits'] = {
                                                                    'val': visitingTeamPitchingLineup[i]['hits'][0]['$']['hits'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['hits']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['hits']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['hits']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['hits']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['earned-runs'] = {
                                                                    'val': visitingTeamPitchingLineup[i]['earned-runs'][0]['$']['earned-runs'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['earned-runs']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['earned-runs']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['earned-runs']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['earned-runs']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['strike-outs'] = {
                                                                    'val': visitingTeamPitchingLineup[i]['strike-outs'][0]['$']['strike-outs'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['strike-outs']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['strike-outs']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['strike-outs']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['strike-outs']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['innings-pitched'] = {
                                                                    'val': visitingTeamPitchingLineup[i]['innings-pitched'][0]['$']['innings'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['innings-pitched']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['innings-pitched']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['innings-pitched']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['innings-pitched']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['walks'] = {
                                                                    'val': visitingTeamPitchingLineup[i]['walks'][0]['$']['walks'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['walks']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['walks']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['walks']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['walks']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['hit-batsmen'] = {
                                                                    'val': visitingTeamPitchingLineup[i]['hit-batsmen'][0]['$']['number'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['hit-batsmen']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['hit-batsmen']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['hit-batsmen']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['hit-batsmen']['pts'];

                                                                playerRecords[playerId]['playerStats']['pitchingStats']['gidp'] = {
                                                                    'val': visitingTeamPitchingLineup[i]['gidp'][0]['$']['number'],
                                                                    'pts': mlbScoringRules.mlbScore['pitchingStats']['gidp']['pts'],
                                                                    'abr': mlbScoringRules.mlbScore['pitchingStats']['gidp']['abr']
                                                                };
                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['pitchingStats']['gidp']['val'] * playerRecords[playerId]['playerStats']['pitchingStats']['gidp']['pts'];


                                                                if (!player[playerId]['multiplierVal']) {
                                                                    // logger.info('Player Id (Vpitching) ' + playerId + ' has no mValue for event ' + eventId);
                                                                    playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                } else {
                                                                    playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                }
                                                                // for (var dgId in player[playerId]) {
                                                                //     if (dgId == 'posGen'){
                                                                //         continue;
                                                                //     }
                                                                //     if (!player[playerId][dgId]) {
                                                                //         player[playerId][dgId] = {};
                                                                //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                //     } else if (!player[playerId][dgId]['multiplierVal']) {
                                                                //         player[playerId][dgId]['multiplierVal'] = 1;
                                                                //     }
                                                                //     playerRecords[playerId]['multiPlayerScore'][dgId] = playerRecords[playerId]['playerScore'] * player[playerId][dgId]['multiplierVal'];
                                                                // }
                                                            }
                                                        }

                                                        for (i in playerRecords) { // Updating the player records in the database
                                                            playerRecords[i]['awayAbbr'] = visitingTeamAlias;
                                                            playerRecords[i]['homeAbbr'] = homeTeamAlias;
                                                            playerRecords[i]['awayScore'] = visitingScore;
                                                            playerRecords[i]['homeScore'] = homeScore;
                                                            playerRecords[i]['clock'] = eventClock;

                                                            var playerUpdate = await PlayerScoreModel.update({
                                                                'playerId': playerRecords[i]['playerId'],
                                                                'eventId': playerRecords[i]['eventId']
                                                            }, {
                                                                $set: playerRecords[i]
                                                            }, {
                                                                upsert: true
                                                            });

                                                            logger.info('Inserted to db (from download): ' + playerRecords[i]['eventId'] + '-' + playerRecords[i]['playerId']);
                                                            // logger.info(JSON.stringify(playerUpdate));

                                                        }
                                                    }
                                                }
                                            }
                                        } catch (e) {
                                            logger.info('FileName: ' + downloadFile);
                                            logger.info(e);
                                        }
                                        // process.exit();
                                    });
                                } else {
                                    // process.exit();
                                }
                            } else {
                                logger.info('FileName: ' + downloadFile);
                                logger.info('Err: ' + err);
                                logger.info('ResonseCode: ' + response.statusCode);
                                // process.exit();
                            }
                        } catch (e) {
                            logger.info('FileName: ' + downloadFile);
                            logger.info(e);
                            // process.exit();
                        }
                    });
            } else {
                // process.exit();
            }
        } catch (e) {
            logger.info(e);
            // process.exit();
        }
    },

    /**
     * Cron - To get all Player details from the db and build it to a game json and send only the updated player details to the pusher
     */
    mlbPlayerScorePush: function () {
        try {
            var logger = new(winston.Logger)({
                transports: [
                    new(winston.transports.Console)(),
                    new(winston.transports.File)({
                        filename: './app/modules/crons/logs/mlb_push.log'
                    })
                ]
            });

            var lastProcessedDateTime = fs.readFileSync('./temp/mlb/lastProcessed.txt').toString().trim(); // '2018-01-01 00:00:00';
            var nextProcessingDateTime = moment().format("YYYY-MM-DD HH:mm:ss");
            return PlayerScoreModel.find({
                     $and: [{
                        'updatedAt': {
                            $gt: lastProcessedDateTime
                            },  
                        },
                        {
                            'sportId' : 2
                        }
                    ]
                })
                .sort({
                    'eventId': 1,
                    'updatedAt': 1
                })
                .exec(function (err, result) {
                    try {
                        if (err) {
                            logger.info(err);
                        } else {
                            var games = {};
                            var gIndx = -1;
                            var pIndx = 0;
                            var prevEventId = '';
                            for (var i in result) { // looping player records
                                if (prevEventId != result[i].eventId || pIndx == 5) {
                                    gIndx++;
                                    pIndx = 0;
                                }
                                pIndx++;
                                prevEventId = result[i].eventId;

                                if (!games[gIndx]) {
                                    games[gIndx] = {};
                                }
                                games[gIndx]['sportId'] = result[i].sportId;
                                games[gIndx]['gameId'] = result[i].eventId;
                                games[gIndx]['isFinal'] = (result[i].eventStatus == 'Final') ? true : false;

                                games[gIndx]['liveGameInfo'] = result[i].liveGameInfo;
                                games[gIndx]['liveGameInfo2'] = result[i].liveGameInfo2;
                                // if (result[i].possTeam) {
                                games[gIndx]['possTeam'] = result[i].possTeam;
                                // }

                                games[gIndx]['homeScore'] = result[i].homeScore;
                                games[gIndx]['awayScore'] = result[i].awayScore;
                                games[gIndx]['homeAbbr'] = result[i].homeAbbr;
                                games[gIndx]['awayAbbr'] = result[i].awayAbbr;
                                games[gIndx]['clock'] = result[i].clock;

                                // if (!games[gIndx]['possTeam']) {
                                //     games[gIndx]['possTeam'] = '';
                                // }

                                if (!games[gIndx]['players']) {
                                    games[gIndx]['players'] = [];
                                }
                                // if (!games[gIndx]['players'][result[i].playerId]) {
                                //     games[gIndx]['players'][result[i].playerId] = {};
                                // }
                                var player = {};

                                player['playerId'] = result[i].playerId;
                                player['isAtBat'] = (result[i].isAtBat == 'true') ? true : false;
                                player['playerName'] = result[i].playerName;
                                player['posId'] = result[i].playerPositionId;
                                player['pos'] = result[i].playerPosition;
                                player['team'] = result[i].teamName;
                                player['teamAlias'] = result[i].teamAlias;

                                player['scoring'] = [];
                                // var playerTotalScore = 0;
                                if(result[i]['playerStats']) {
                                for (var param in result[i]['playerStats']['battingStats']) {
                                    var playerParamScore = result[i]['playerStats']['battingStats'][param]['val'] * result[i]['playerStats']['battingStats'][param]['pts'];
                                    player['scoring'].push({
                                        't': param,
                                        'abr': result[i]['playerStats']['battingStats'][param]['abr'],
                                        'n': result[i]['playerStats']['battingStats'][param]['val'] * 1,
                                        'v': playerParamScore,
                                        's': 'pts'
                                    });
                                    // playerTotalScore += playerParamScore;
                                } }
                                if(result[i]['playerStats']) {
                                for (var param in result[i]['playerStats']['pitchingStats']) {
                                    var playerParamScore = result[i]['playerStats']['pitchingStats'][param]['val'] * result[i]['playerStats']['pitchingStats'][param]['pts'];
                                    player['scoring'].push({
                                        't': param,
                                        'abr': result[i]['playerStats']['pitchingStats'][param]['abr'],
                                        'n': result[i]['playerStats']['pitchingStats'][param]['val'] * 1,
                                        'v': playerParamScore,
                                        's': 'pts'
                                    });
                                    // playerTotalScore += playerParamScore;
                                } }
                                player['playerScore'] = result[i]['playerScore'];
                                player['multiPlayerScore'] = Math.round(result[i]['multiPlayerScore'] * 100) / 100;
                                games[gIndx]['players'].push(player);
                            }

                            for (var g in games) {
                                // if (games[g]['gameId'] == '1996899') {
                                Pusher.sendPush('game-channel', 'game-' + games[g]['gameId'], games[g]);
                                logger.info('Push sent for ' + games[g]['gameId'] + ' (' + g + ')');
                                var start = new Date().getTime();
                                while ((new Date().getTime() - start) < 150) {
                                    //loop here
                                }
                                // }
                            }
                            // fs.appendFileSync('./temp/mlb/telnet_mlb_db.txt', JSON.stringify(games));
                            fs.writeFileSync('./temp/mlb/lastProcessed.txt', nextProcessingDateTime);
                        }
                    } catch (e) {
                        logger.info(e);
                    }
                });
        } catch (e) {
            logger.info(e);
        }
    },

}