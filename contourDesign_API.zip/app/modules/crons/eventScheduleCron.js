/**
 * Event Module
 * @exports Cron/NFL/Event
 */
var GameModel = require('../../models/event');
var cronVar = require('./cronSettings');
var async = require('async');
var DraftGroupModel = require('../../models/draftgroup');
var moment = require('moment');

module.exports = {
    /**
     * Cron - To get all scheduled  events by week
     * To get all basic details related to games in a week
     */
    getEventScheduleDetails: async function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            var currSeason = moment(new Date()).format('YYYY');
            // for (var week = 1; week < 23; week++) {
            var cronSet = 1;
            var eventLast = await GameModel.findOne({ sportId: 1, season: currSeason }).sort({ createdAt: -1 });
            if (eventLast) {
                var evenTypeIdLast = eventLast.eventTypeId;
                var weekLast = eventLast.week;
            }
            else {
                var noIncWeek = 1
                var evenTypeIdLast = 0; //preaseason
                var weekLast = 1;
            }
            var checkCronLast = await DraftGroupModel.findOne({ sportId: 1, week: weekLast, eventTypeId: evenTypeIdLast, dgState: { $ne: 'Upcoming' } }).sort({ createdAt: -1 });
            if (checkCronLast == null) {
                cronSet = 0;
            }
            console.log('cron set out'); //process.exit();
            if (cronSet) {
                var eventSeasonExist = 0;
                weekLast = noIncWeek ? weekLast : weekLast + 1;
                console.log('cron set Inn'); //process.exit();
                for (var w = 0; w < 2 && eventSeasonExist != 1; w++) {
                    if (eventSeasonExist == 2) {
                        evenTypeIdLast = 1;//regular season
                        weekLast = 1;
                    }
                    request(process.env.SCHEDULE_EVENT_API + '?week=' + weekLast + '&eventTypeId=' + evenTypeIdLast + '&api_key=' + cronVar.apiKey + '&sig=' + sigg,
                        function (err, response, body) {
                            try {
                                console.log('NFL Events - ' + response.statusCode);
                                // parse the body as JSON
                                if (!err && response.statusCode == 200) {
                                    eventSeasonExist = 1;
                                    var parsedBody = JSON.parse(body);
                                    var res = parsedBody.apiResults;
                                    var eventArr = res[0].league.season.eventType[0].events;
                                    eventArr.forEach(function (event) {
                                        league = {};
                                        league['leagueId'] = res[0].league.leagueId;
                                        league['name'] = res[0].league.name;
                                        league['abbr'] = res[0].league.abbreviation;
                                        var homeTeam = {};
                                        var awayTeam = {};
                                        var gameInfo = {};
                                        teamArr = event.teams
                                        //obtaining home team and away team details
                                        teamArr.forEach(function (team) {
                                            if (team.teamLocationType.teamLocationTypeId == '1') {
                                                var rec = {};
                                                rec.wins = team.record.wins;
                                                rec.losses = team.record.losses;
                                                homeTeam.teamId = team.teamId;
                                                homeTeam.tName = team.nickname;
                                                homeTeam.city = team.location;
                                                homeTeam.tAbbr = team.abbreviation;
                                                homeTeam.score = team.score;
                                                homeTeam.record = rec;
                                                homeTeam.isWinner = team.isWinner ? 1 : 0;
                                            }
                                            else {
                                                var rec = {};
                                                rec.wins = team.record.wins;
                                                rec.losses = team.record.losses;
                                                awayTeam.teamId = team.teamId;
                                                awayTeam.tName = team.nickname;
                                                awayTeam.city = team.location;
                                                awayTeam.tAbbr = team.abbreviation;
                                                awayTeam.score = team.score;
                                                awayTeam.record = rec;
                                                awayTeam.isWinner = team.isWinner ? 1 : 0;
                                            }
                                        });
                                        //assigning relevant event datas to event_data variable   
                                        var event_data = {
                                            gameInfo: gameInfo,
                                            sportId: 1,
                                            league: league,
                                            eventTypeId: res[0].league.season.eventType[0].eventTypeId,
                                            season: res[0].league.season.season,
                                            week: event.week,
                                            eventId: event.eventId,
                                            eventStatusId: event.eventStatus.eventStatusId,
                                            isActive: (event.eventStatus.isActive) ? 1 : 0,
                                            startTimeUTC: event.startDate[1].full,
                                            homeTeam: homeTeam,
                                            awayTeam: awayTeam,
                                            venueName: event.venue.name,
                                        };
                                        //saving or updating events data to DB
                                        GameModel.findOneAndUpdate({ 'eventId': event.eventId }, event_data, { upsert: true }, function (err, doc) {
                                            try {
                                                if (err) throw err;
                                                //console.log('Success Game');
                                            } catch (e) {
                                                cronVar.logger.info(e);
                                            }
                                        });
                                    })
                                }
                                else {
                                    eventSeasonExist = 2;
                                    //  throw err;
                                }
                            } catch (e) {
                                cronVar.logger.info(e);
                            }
                        });
                }

            }
            // }

        } catch (e) {
            throw e;
        }
    },

    /**
    * Cron - To get event's weather
    * Function to get weather condition  
    */
    getEventWeatherDetails: function () {
        try {
            var events = GameModel.find({}, function (err, events) {
                if (err)
                    console.log(err);
                else {
                    var sigg = statsCred();
                    var request = cronVar.request;
                    async.eachSeries(events, async function (event, outCb) {
                        request(process.env.EVENT_WEATHER + event.eventId + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                            function (err, response, body) {
                                try {
                                    console.log('NFL Weather - ' + response.statusCode);
                                    // parse the body as JSON
                                    if (!err && response.statusCode == 200) {
                                        var parsedBody = JSON.parse(body);
                                        var res = parsedBody.apiResults;

                                        var eventWeather = res[0].league.season.eventType[0].weatherForecasts[0].forecasts[0].conditionDesc;
                                        //console.log(eventWeather); process.exit();
                                        //updating weather to event schema
                                        GameModel.findOneAndUpdate({ 'eventId': event.eventId }, { 'weather.conditionDesc': eventWeather }, { upsert: false }, function (err, doc) {
                                            try {
                                                if (err) throw err;
                                                // console.log('Success Event Weather');
                                            } catch (e) {
                                                cronVar.logger.info(e);
                                            }
                                        });
                                    }
                                    else {
                                        throw err;
                                    }
                                } catch (e) {
                                    cronVar.logger.info(e);
                                }
                            });
                        outCb(null);
                    });
                }
            });
        } catch (e) {
            throw e;
        }
    }
}

function statsCred() {
    // moment.js is the preferred date library
    var moment = require('moment');
    // access Node.js Crypto library for signature generation
    var crypto = require('crypto');
    // get the current time
    var timeFromEpoch = moment.utc().unix();
    // set the API key (note that this is not a valid key!)
    var apiKey = process.env.API_KEY;
    // set the shared secret key
    var secret = process.env.API_SECRET;
    // generate signature
    var sig = crypto.createHash('sha256').update(apiKey + secret + timeFromEpoch).digest('hex');

    return sig;
}




