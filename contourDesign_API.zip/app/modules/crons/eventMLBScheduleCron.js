/**
 * Event Module
 * @exports Cron/MLB/Event
 */
var GameModel = require('../../models/event');
var cronVar = require('./cronSettings');
var async = require('async');
var moment = require('moment');
var PlayerModel = require('../../models/player');
var PlayerNewsModel = require('../../models/playernews');
var Stats = require('./helpers/stats');
var LineupModel = require('../../models/lineup');
var DraftGroupModel = require('../../models/draftgroup');

var self = module.exports = {
    /**
     * Cron - To get all scheduled  events by day
     * To get all basic details related to games in a day
     */
    getEventScheduleDetails: function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            ks = [-2, -1, 0, 1, 2, 3, 4, 5, 6, 7];
            async.eachSeries(ks, async function (k, innerCb) {
                var datatoday = new Date();
                datatodays = datatoday.setDate(new Date(datatoday).getDate() + k);
                var todate = moment.utc(new Date(datatodays)).format('YYYY-MM-DD');
                //var statUrl = process.env.SCHEDULE_EVENT_MLB_API + '?date=' + todate + '&api_key=' + cronVar.apiKey + '&sig=' + sigg;
                request(process.env.SCHEDULE_EVENT_MLB_API + '?date=' + todate + '&api_key=' + cronVar.apiKey + '&sig=' + sigg,
                    function (err, response, body) {
                        try {
                            console.log('MLB Events - ' + response.statusCode);
                            // parse the body as JSON
                            if (!err && response.statusCode == 200) {

                                var parsedBody = JSON.parse(body);
                                var res = parsedBody.apiResults;
                                var eventArr = res[0].league.season.eventType[0].events;

                                async.eachSeries(eventArr, async function (event, innCb) {
                                    league = {};
                                    league['leagueId'] = res[0].league.leagueId;
                                    league['name'] = res[0].league.name;
                                    league['abbr'] = res[0].league.abbreviation;
                                    var homeTeam = {};
                                    var awayTeam = {};
                                    var gameInfo = {};
                                    teamArr = event.teams
                                    var eventDay = moment.utc(event.startDate[1].full + 'Z').tz("EST").format('YYYY-MM-DD');
                                    //obtaining home team and away team details
                                    teamArr.forEach(function (team) {
                                        var recrd = team.record ? team.record : team.series;
                                        if (team.teamLocationType.teamLocationTypeId == '1') {
                                            var rec = {};
                                            rec.wins = recrd.wins;
                                            rec.losses = recrd.losses;
                                            homeTeam.teamId = team.teamId;
                                            homeTeam.tName = team.nickname;
                                            homeTeam.city = team.location;
                                            homeTeam.tAbbr = team.abbreviation;
                                            homeTeam.score = team.score;
                                            homeTeam.record = rec;
                                            homeTeam.isWinner = team.isWinner ? 1 : 0;
                                        }
                                        else {
                                            var rec = {};
                                            rec.wins = recrd.wins;
                                            rec.losses = recrd.losses;
                                            awayTeam.teamId = team.teamId;
                                            awayTeam.tName = team.nickname;
                                            awayTeam.city = team.location;
                                            awayTeam.tAbbr = team.abbreviation;
                                            awayTeam.score = team.score;
                                            awayTeam.record = rec;
                                            awayTeam.isWinner = team.isWinner ? 1 : 0;
                                        }
                                    });
                                    //assigning relevant event datas to event_data variable   
                                    var event_data = {
                                        gameInfo: gameInfo,
                                        sportId: res[0].sportId,
                                        league: league,
                                        season: res[0].league.season.season,
                                        week: eventDay.replace(/-+/g, ''),
                                        eventId: event.eventId,
                                        eventStatusId: event.eventStatus.eventStatusId,
                                        // isActive: (event.eventStatus.isActive) ? 1 : 0,
                                        isActive: 1,
                                        startTimeUTC: new Date(event.startDate[1].full + 'Z'),
                                        homeTeam: homeTeam,
                                        awayTeam: awayTeam,
                                        venueName: event.venue.name,
                                    };
                                    //saving or updating events data to DB
                                    await GameModel.findOneAndUpdate({ 'eventId': event.eventId }, event_data, { upsert: true }, function (err, doc) {
                                        try {
                                            if (err) throw err;
                                            // console.log('Success Game MLB');
                                        } catch (e) {
                                            cronVar.logger.info(e);
                                        }
                                    });
                                    innCb(null);
                                });
                            }
                            /*else {
                                throw err;
                            }*/
                        } catch (e) {
                            cronVar.logger.info(e);
                        } innerCb(null);
                    });
            });

        } catch (e) {
            throw e;
        }
    },

    /**
       * Cron - To get all MLB Player details in a season
       * To get all basic details related to players
       */
    getPlayerDetails: function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            request(process.env.MLB_PLAYER_API + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                function (err, response, body) {
                    try {
                        console.log('MLB Players - ' + response.statusCode);
                        // parse the body as JSON
                        if (!err && response.statusCode == 200) {
                            var parsedBody = JSON.parse(body);
                            var res = parsedBody.apiResults;
                            var arrResult = res[0].league.players;
                            arrResult.forEach(function (item) {
                                if (item.team) {
                                    var positionsArr = item.positions;
                                    var positions = [];
                                    var playerImgName = '';
                                    positionsArr.forEach(function (position) {
                                        var posGName = (position.abbreviation == 'RP' || position.abbreviation == 'SP' || position.abbreviation == 'MR') ? 'Pitcher' : 'Hitter';
                                        positions.push({ "posId": position.positionId, "posAbbr": position.abbreviation, "posGen": posGName });
                                    });
                                    league = {};
                                    league['leagueId'] = res[0].league.leagueId;
                                    league['abbr'] = res[0].league.abbreviation;
                                    team = {};
                                    team['teamId'] = item.team.teamId;
                                    team['tAbbr'] = item.team.abbreviation;
                                    //assigning relevant player datas to player_data variable  
                                    var player_data = {
                                        sportId: res[0].sportId,
                                        league: league,
                                        fName: item.firstName,
                                        lName: item.lastName,
                                        playerId: item.playerId,
                                        uniform: item.uniform,
                                        team: team,
                                        positions: positions,
                                        isActive: (item.isActive) ? 1 : 0,
                                        isSuspend: (item.isSuspended) ? 1 : 0,
                                        isInjured: '',
                                        playerImgName: playerImgName,
                                    };
                                    //saving or updating player details to DB
                                    PlayerModel.findOneAndUpdate({ 'playerId': item.playerId }, player_data, { upsert: true }, function (err, doc) {
                                        try {
                                            if (err) throw err;
                                            // console.log('Success Player');
                                        } catch (e) {
                                            cronVar.logger.info(e);
                                        }
                                    });
                                }
                            })
                        }
                        else {
                            throw err;
                        }
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To get fantasy projection details of MLB player
     * Function to get salary,points related to a player from STATS api and calculating it's average  
     */
    getPlayerFantasyDetails: function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            var events = GameModel.find({ 'sportId': 2 }, 'eventId', function (err, events) {
                if (err)
                    console.log(err);
                else {
                    async.eachSeries(events, async function (event, outCb) {
                        request(process.env.MLB_PLAYER_FANTASY_API + event.eventId + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                            function (err, response, body) {
                                try {
                                    console.log('MLB Player Fantasy - ' + response.statusCode);
                                    // parse the body as JSON
                                    if (!err && response.statusCode == 200) {
                                        var parsedBody = JSON.parse(body);
                                        var res = parsedBody.apiResults;
                                        var eventTypeArr = res[0].league.season.eventType;
                                        eventTypeArr.forEach(function (eventType) {
                                            var playerFanatasyTeamArr = eventType.fantasyProjections.teams;
                                            playerFanatasyTeamArr.forEach(function (team) {
                                                var playerFanatasyArr = team.batters;
                                                var allPlayers = playerFanatasyArr.concat(team.pitchers);
                                                allPlayers.forEach(function (allPlayer) {
                                                    if (allPlayer.fantasyProjections.length > 1) {
                                                        var playerId = allPlayer.playerId;
                                                        var FantasyArr = allPlayer.fantasyProjections
                                                        var avgFanProjSalary = 0;
                                                        var avgFanProjPoints = 0;
                                                        var fanProjScore = 0;
                                                        //calculating average fantasy projection salary and points from 1st and 2nd site Id
                                                        FantasyArr.forEach(function (fantasy) {
                                                            if (fantasy.siteId == 1 || fantasy.siteId == 2) {
                                                                avgFanProjSalary = (+avgFanProjSalary) + ((+fantasy.salary > 0) ? +fantasy.salary : 0);
                                                                avgFanProjPoints = (+avgFanProjPoints) + ((+fantasy.points > 0) ? +fantasy.points : 0);
                                                            }
                                                        })
                                                        avgFanProjSalary = avgFanProjSalary / 2;
                                                        avgFanProjPoints = avgFanProjPoints / 2;
                                                        //updating fantasy details to player schema
                                                        PlayerModel.findOneAndUpdate({ 'playerId': playerId }, { fanProjSalary: avgFanProjSalary, fanProjPoints: avgFanProjPoints, fanProjScore: fanProjScore }, { upsert: false }, function (err, doc) {
                                                            try {
                                                                if (err) throw err;
                                                                // console.log('Success Player Fantasy');
                                                            } catch (e) {
                                                                cronVar.logger.info(e);
                                                            }
                                                        });
                                                    }
                                                })
                                            })
                                        })
                                    }
                                } catch (e) {
                                    cronVar.logger.info(e);
                                }//process.exit();
                                var start = new Date().getTime();
                                while ((new Date().getTime() - start) < 150) {
                                    //loop here
                                }
                                outCb(null);
                            });
                    });
                }
            });

        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To get MLB player's injury
     * Function to get injury details  
     */
    getInjuryDetails: function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            request(process.env.MLB_PLAYER_INJURY + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                function (err, response, body) {
                    try {
                        console.log('MLB Player Injury - ' + response.statusCode);
                        // parse the body as JSON
                        if (!err && response.statusCode == 200) {
                            var parsedBody = JSON.parse(body);
                            var res = parsedBody.apiResults;

                            var injuryArray = res[0].league.seasons[0].injuries;
                            injuryArray.forEach(function (injuryPlayer) {
                                var playerId = injuryPlayer.player.playerId;
                                var injury = injuryPlayer.status.description;
                                //updating injury to player schema
                                PlayerModel.findOneAndUpdate({ 'playerId': playerId }, { 'isInjured': injury }, { upsert: false }, function (err, doc) {
                                    try {
                                        if (err) throw err;
                                        // console.log('Success Player Injury');
                                    } catch (e) {
                                        cronVar.logger.info(e);
                                    }
                                });
                            });
                        }
                        else {
                            throw err;
                        }
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To get all depthchart details of MLB player - consist of two functions
     * Function to get standard player positions details(position Id and position abbreviation) from STATS api
     * Function to get player position data(abbreviation) in a season from STATS api
     */
    getDepthChartDetails: function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            async.series({
                //stats api call to get position details standard
                posMaster: function (callback) {
                    try {
                        request(process.env.MLB_PLAYER_POSITION + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                            function (err, response, body) {
                                try {
                                    console.log('MLB Player Depth - ' + response.statusCode);
                                    // parse the body as JSON
                                    if (!err && response.statusCode == 200) {
                                        var parsedBody = JSON.parse(body);
                                        var res = parsedBody.apiResults;
                                        var positionArr = res[0].league.positions;
                                        callback(null, positionArr);
                                    }
                                    else {
                                        cronVar.logger.info(err);
                                    }
                                } catch (e) {
                                    cronVar.logger.info(e);
                                }
                            });
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                }
            },
                //stats api call to get player position details from depth chart api
                function (err, positionsMaster) {
                    try {
                        request(process.env.MLB_DEPTH_CHART_API + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                            function (err, response, body) {
                                try {
                                    console.log('MLB Player Depth 1 - ' + response.statusCode);
                                    // parse the body as JSON
                                    if (!err && response.statusCode == 200) {
                                        var parsedBody = JSON.parse(body);
                                        var res = parsedBody.apiResults;
                                        var teamsArr = res[0].league.season.teams;
                                        teamsArr.forEach(function (team) {
                                            positionsArr = team.positions;
                                            //console.log(positionsMaster.posMaster);
                                            positionsArr.forEach(function (position) {
                                                (positionsMaster.posMaster).forEach(function (positionMaster) {
                                                    if (positionMaster.abbreviation == position.abbreviation) {
                                                        var positions = [];
                                                        var posGName = (position.abbreviation == 'RP' || position.abbreviation == 'SP' || position.abbreviation == 'MR') ? 'Pitcher' : 'Hitter';
                                                        positions.push({ "posId": positionMaster.positionId, "posAbbr": position.abbreviation, "posGen": posGName });
                                                        depthChartsArr = position.depthChart;
                                                        depthChartsArr.forEach(function (depthChartArr) {
                                                            var playerId = depthChartArr.player.playerId;
                                                            //updating depthchart details to player schema
                                                            PlayerModel.findOneAndUpdate({ 'playerId': playerId }, { positions: positions }, { upsert: false }, function (err, doc) {
                                                                try {
                                                                    if (err) throw err;
                                                                    //  console.log('Success Depth');
                                                                } catch (e) {
                                                                    cronVar.logger.info(e);
                                                                }
                                                            });
                                                        })
                                                    }
                                                })
                                            })
                                        })
                                    }
                                    else {
                                        cronVar.logger.info(err);
                                    }
                                } catch (e) {
                                    cronVar.logger.info(e);
                                }
                            });
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To get all MLB Player News details in a season
     * To get all basic news related to players
     */
    getNewsDetails: async function () {
        try {
            var request = cronVar.request;
            var today = new Date();
            var todaymoment = moment(today);
            var todayString = todaymoment.format('YYYYMMDD');
            var datetimemonth = moment(today).subtract(1, 'month');
            var datetimemonthString = datetimemonth.format('YYYYMMDD');
            var mlbPlayers = await PlayerModel.find({ 'sportId': 2 }, 'playerId', function () { });
            // for (var k = 0; k < mlbPlayers.length; k++) {
            async.eachSeries(mlbPlayers, async function (mlbPlayer, outCb) {
                // var sigg = await statsCred();
                setTimeout(function () {
                    request(process.env.MLB_SINGLE_PLAYER_NEWS + mlbPlayer.playerId + '?startDate=' + datetimemonthString + '&endDate=' + todayString + '&api_key=' + cronVar.apiKey + '&sig=' + Stats.statsCred(),
                        function (err, response, body) {
                            try {
                                //console.log(sigg);
                                // console.log(mlbPlayer.playerId);
                                console.log('MLB Player News - ' + response.statusCode);//process.exit();
                                // parse the body as JSON
                                if (!err && response.statusCode == 200) {
                                    var parsedBody = JSON.parse(body);
                                    var res = parsedBody.apiResults;
                                    var news = {};
                                    var League = {};
                                    news.sportId = 2;
                                    League.leagueId = res[0].league.leagueId;
                                    League.abbr = res[0].league.abbreviation;
                                    news.league = League;
                                    news.season = res[0].league.seasons[0].season;

                                    newsArray = res[0].league.seasons[0].playerNews;

                                    newsArray.forEach(function (newsPlayer) {
                                        news.playerId = newsPlayer.player.playerId;
                                        news.fName = newsPlayer.player.firstName;
                                        news.lName = newsPlayer.player.lastName;
                                        news.playerNewsId = newsPlayer.playerNewsId;
                                        news.newsText = newsPlayer.newsText;
                                        news.adviceText = newsPlayer.adviceText;
                                        var Team = {};
                                        Team.teamId = newsPlayer.team.teamId;
                                        Team.tAbbr = newsPlayer.team.abbreviation;
                                        news.team = Team;
                                        var Positions = [];
                                        positionArray = newsPlayer.positions;
                                        positionArray.forEach(function (position) {
                                            var postionObj = {};
                                            postionObj.posId = position.positionId;
                                            postionObj.posAbbr = position.abbreviation;
                                            postionObj.posName = position.name;
                                            postionObj.sequence = position.sequence;
                                            Positions.push(postionObj);
                                        })
                                        news.positions = Positions;
                                        news.originalDateLocal = newsPlayer.originalDate[0].full;
                                        news.timezone = newsPlayer.originalDate[0].dateType;
                                        news.originalDateUtc = new Date(newsPlayer.originalDate[1].full + 'Z');//console.log(news);process.exit();
                                        PlayerNewsModel.findOneAndUpdate({ 'playerId': news.playerId, 'playerNewsId': news.playerNewsId }, news, { upsert: true }, function (err, doc) {
                                            try {
                                                if (err) throw err;
                                                //console.log('Success Player News');
                                            } catch (e) {
                                                cronVar.logger.info(e);
                                            }
                                        });
                                    })
                                }
                                else {
                                    throw err;
                                }
                            } catch (e) {
                                cronVar.logger.info(e);
                            }

                            outCb();
                        })
                }, 1000);
            })
            // }
        } catch (e) {
            throw e;
        }
    },


    /**
     * Cron - To get MLB event's weather
     * Function to get weather condition  
     */
    getEventWeatherDetails: function () {
        try {
            var sigg = statsCred();
            var events = GameModel.find({ sportId: 2 }, function (err, events) {
                if (err)
                    console.log(err);
                else {
                    var request = cronVar.request;
                    async.eachSeries(events, async function (event, outCb) {
                        request(process.env.MLB_EVENT_WEATHER + event.eventId + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                            function (err, response, body) {
                                try {
                                    console.log('MLB Player Weather - ' + response.statusCode);
                                    // parse the body as JSON
                                    if (!err && response.statusCode == 200) {//console.log(response.statusCode);
                                        var parsedBody = JSON.parse(body);
                                        var res = parsedBody.apiResults;

                                        var eventWeather = res[0].league.season.eventType[0].weatherForecasts[0].forecasts[0].conditionDesc;
                                        //console.log(eventWeather); process.exit();
                                        //updating weather to event schema
                                        GameModel.findOneAndUpdate({ 'eventId': event.eventId }, { 'weather.conditionDesc': eventWeather }, { upsert: false }, function (err, doc) {
                                            try {
                                                if (err) throw err;
                                                // console.log('Success Event Weather');
                                            } catch (e) {
                                                cronVar.logger.info(e);
                                            }
                                        });
                                    }
                                    else {
                                        throw err;
                                    }
                                } catch (e) {
                                    cronVar.logger.info(e);
                                }
                                outCb(null); });                      
                    });
                }
            });
        } catch (e) {
            throw e;
        }
    },

       /**
       * Cron - To update starting lineup
       * To get all basic details related to players
       */
      getStartingLineupDetails: async function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            var date = moment.utc(new Date()).tz("EST5EDT").format('YYYY-MM-DD');

            var curDateTime = new Date();
            var dateTimeTwoHoursBack = new Date();
            var dateTimeTwoHoursForward = new Date();             
            dateTimeTwoHoursBack.setHours(dateTimeTwoHoursBack.getHours() - 3);
            //dateTimeTwoHoursBack.setMinutes(dateTimeTwoHoursBack.getMinutes() - 10);
            dateTimeTwoHoursForward.setHours(dateTimeTwoHoursForward.getHours() + 3);
            // dateTimeTwoHoursForward.setMinutes(dateTimeTwoHoursForward.getMinutes() + 10);
            // dateTimeTwoHours.setDate(dateTimeTwoHours.getDate() - 4);  
            console.log(dateTimeTwoHoursBack); console.log(dateTimeTwoHoursForward);
            var events = await GameModel.find({ 'sportId': 2, startTimeUTC: { '$gte': dateTimeTwoHoursBack, '$lte': dateTimeTwoHoursForward } }, 'eventId startTimeUTC', function (err, events) { 
            //events = [ { _id: "5ad84abfa0db7fe60dc8a31e", eventId: 1995492 }] ;
            async.eachSeries(events, function (event,innerCB) {  //console.log("event-"+event.eventId);        
            request(process.env.MLB_EVENT_STARTING_LINEUPS + event.eventId+'?api_key=' + cronVar.apiKey + '&box=true'+ '&sig=' + sigg,
               async function (err, response, body) {
                    try {                        
                        // parse the body as JSON
                        if (!err && response.statusCode == 200) {
                            var parsedBody = JSON.parse(body);   
                            var res = parsedBody.apiResults;
                            var arrResult = res[0].league.season.eventType[0].events; 
                            if(arrResult) {
                                //arrResult.forEach(async function (event) {
                                for(var z=0; z<arrResult.length;z++) {
                                if (arrResult[z].eventId) {
                                    
                                    var posDrafts =  await DraftGroupModel.find({"gameList.eventId": arrResult[z].eventId, sportId: 2 });

                                    var teamsArr = arrResult[z].teams;                            
                                    //teamsArr.forEach( async function (team) { 
                                        
                                        //console.log("teamsArr length------------------------------- "+teamsArr.length);
                                    for(var y= 0; y<teamsArr.length; y++) {                                         
                                    pitchersArry = teamsArr[y].pitchers;   
                                   // pitchersArry.forEach(async function (pitcher) {
                                       //console.log(" pitchersArry length------------------------------- "+pitchersArry.length);
                                    for(var x = 0; x<pitchersArry.length;x++) {

                                        console.log('team - ' + teamsArr[y].teamId);
                                        console.log('playerId - ' + pitchersArry[x].player.playerId); 

                                                                          
                                      var update1 = await LineupModel.update({ "players.teamId": teamsArr[y].teamId, "players.eventId": arrResult[z].eventId }, { $set: { "players.$.starting": "", "players.$.probable": false } }, { multi: true }, function (err, doc) {  });    
                                      var update =  await LineupModel.update({ "players.teamId": teamsArr[y].teamId, "players.playerId": pitchersArry[x].player.playerId, "players.eventId": arrResult[z].eventId }, { $set: { "players.$.starting": "p", "players.$.probable": true } }, { multi: true }, function (err, doc) {  }); 
                                      var fieldnull = {};
                                      fieldnull["gameList.$.players.$.starting"] = "";
                                      fieldnull["gameList.$.players.$.probable"] = false;
                                     var updateDraftGroup1 = await DraftGroupModel.update({"gameList.players.teamId": teamsArr[y].teamId, "gameList.eventId": arrResult[z].eventId}, { $set: fieldnull }, { multi: true }, function (err, doc) { });
                                        for (var a = 0; a < posDrafts.length; a++) {
                                            for (var b = 0; b < (posDrafts[a].gameList).length; b++) {
                                                if (posDrafts[a].gameList[b].eventId == arrResult[z].eventId) {
                                                    for (var c = 0; c < (posDrafts[a].gameList[b].players).length; c++) {
                                                        
                                                       // var fieldnull = {};
                                                       // fieldnull["gameList." + b + ".players." + c + ".starting"] = "";
                                                       // fieldnull["gameList." + b + ".players." + c + ".probable"] = false; console.log(fieldnull);
                                                        //var updateDraftGroup1 = await DraftGroupModel.update({ draftgroupId: posDrafts[a].draftgroupId, "gameList.players.teamId": teamsArr[y].teamId, "gameList.eventId": arrResult[z].eventId, "gameList.players.playerId": posDrafts[a].gameList[b].players[c].playerId }, { $set: fieldnull }, { multi: true }, function (err, doc) { });

                                                        if (posDrafts[a].gameList[b].players[c].playerId == pitchersArry[x].player.playerId) {
                                                            // if(teamsArr[y].teamId == 235) {
                                                            //console.log("------------------------------------");
                                                            // console.log('eventId - ' + posDrafts[a].gameList[b].eventId);
                                                            /* console.log('eventId Statsssss - ' + arrResult[z].eventId);
                                                            //console.log('team - ' + teamsArr[y].teamId);
                                                            console.log('playerId - ' + posDrafts[a].gameList[b].players[c].playerId);
                                                            console.log('playerId statsssss - ' + pitchersArry[x].player.playerId);
                                                            console.log('draftgroupId - ' + posDrafts[a].draftgroupId);
                                                            console.log('teamId - ' + teamsArr[y].teamId);*/
                                                            
                                                            //   }
                                                            var fieldV = {};
                                                            fieldV["gameList." + b + ".players." + c + ".starting"] = "P";
                                                            fieldV["gameList." + b + ".players." + c + ".probable"] = true;

                                                            //console.log(fieldV);
                                                            //console.log("**************************************");
                                                            var updateDraftGroup2 = await DraftGroupModel.update({ draftgroupId: posDrafts[a].draftgroupId, "gameList.players.teamId": teamsArr[y].teamId, "gameList.players.playerId": pitchersArry[x].player.playerId, "gameList.eventId": arrResult[z].eventId }, { $set: fieldV }, { multi: true }, function (err, doc) { });
                                                            //var updateDraftGroup2 = await DraftGroupModel.update({ draftgroupId: posDrafts[a].draftgroupId, "gameList.players.playerId": pitchersArry[x].player.playerId }, { $set: fieldval }, { multi: true }, function (err, doc) { });
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                     
                                      //   });
                                    }
                                    //});                                    
                                    }
                                    if(arrResult[z].boxscores && arrResult[z].boxscores != null) {
                                    var boxscoresArr = arrResult[z].boxscores;                            
                                   // boxscoresArr.forEach( async function (boxscore) {                                         
                                    for(var w =0 ; w<boxscoresArr.length; w++) {                                         
                                    //console.log("team-"+boxscore.teamId);  
                                    if(boxscoresArr[w].playerBattingStats && boxscoresArr[w].playerBattingStats != null) {
                                        var playerBattingStatsArr = boxscoresArr[w].playerBattingStats;                            
                                        //playerBattingStatsArr.forEach( async function (playerBattingStat) {     
                                        for(var v =0 ; v<playerBattingStatsArr.length;v++) {     
                                            
                                        //if(playerBattingStatsArr[v].player.playerId == 507106)   { 
                                       // console.log("playerId-"+playerBattingStatsArr[v].player.playerId);  
                                       // console.log("battingSlot-"+playerBattingStatsArr[v].battingSlot);  
                                       // console.log("atBatsgame-"+playerBattingStatsArr[v].atBats.game); //}
                                     //   if(playerBattingStatsArr[v].atBats.game > 0)  {                                                                       
                                        var update = await LineupModel.update({ "players.playerId": playerBattingStatsArr[v].player.playerId, "players.eventId": arrResult[z].eventId }, { $set: { "players.$.starting": playerBattingStatsArr[v].battingSlot, "players.$.probable": false } }, { multi: true }, function (err, doc) {  });  
                                       
                                      
                                       for(var j = 0; j<posDrafts.length; j++){
                                       for(var k = 0; k<(posDrafts[j].gameList).length; k++){
                                   if(posDrafts[j].gameList[k].eventId == arrResult[z].eventId){
                                    for(var l = 0; l<(posDrafts[j].gameList[k].players).length; l++){
                                        if(posDrafts[j].gameList[k].players[l].playerId == playerBattingStatsArr[v].player.playerId){
                                    var field = {};
                                    field["gameList." + k + ".players." + l + ".starting"] = playerBattingStatsArr[v].battingSlot;
                                    field["gameList." + k + ".players." + l + ".probable"] = false;
                                    //console.log(field);
                                   // console.log(l);
                                     var updateDraftGroup = await DraftGroupModel.update({ draftgroupId: posDrafts[j].draftgroupId, "gameList.players.playerId": playerBattingStatsArr[v].player.playerId, "gameList.eventId": arrResult[z].eventId }, { $set: field }, { multi: true }, function (err, doc) {  });  
                                        
                                    }
                                    }
                                        }
                                        }
                                        }
                                   // }

                                        //});
                                }                                    
                                       }                                     
                                   // });  
                                    }                                  
                                   }

                                }
                           // })
                            }
                         }
                        }
                        else {
                            throw err;
                        }
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                    var start = new Date().getTime();
                    while ((new Date().getTime() - start) < 1500) {
                        //loop here
                    }  //console.log('Loop- out');
                    innerCB(null); 
                });

               });  

            });

        } catch (e) {
            throw e;
        }
    },

      /**
       * get pitching - To get pitching probables
       * To get all basic details related to players
       */
      getPitchingProbables: function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;

            var crrntDay = moment().tz("EST").format('YYYY-MM-DD HH:mm:ss');
            var toDay = moment().tz("EST").format('YYYY-MM-DD');

            for (var m = 1; m < 7; m++) {

              var nxtDay =  moment(crrntDay).add(m, 'days').format('YYYY-MM-DD');
            request(process.env.MLB_EVENT_PITCHING_PROBABLES + '?api_key=' + cronVar.apiKey + '&box=true'+ '&date=' + nxtDay+ '&sig=' + sigg,
               async function (err, response, body) {
                    try {                        
                        // parse the body as JSON
                        if (!err && response.statusCode == 200) {
                            var parsedBody = JSON.parse(body);  
                            var res = parsedBody.apiResults;
                            var arrResult = res[0].league.season.eventType[0].events; 
                            if(arrResult) {
                                arrResult.forEach(async function (event) {  // console.log('eventId - ' + event.eventId);
                                if (event.eventId) {  
                                   // var teamsArr = event.teams;                            
                                   // teamsArr.forEach( async function (team) {  console.log('teamId - ' + team.teamId);  
                                   // console.log('pitchers - ' + team.pitchers);                                       
                                   // pitchersArry = team.pitchers;   
                                   pitchersArry = event.pitchers;

                                   if(pitchersArry) {
                                   pitchersArry.forEach(async function (pitcher) {
                                       //console.log('eventId - ' + event.eventId);
                                       //console.log('teamId - ' + pitcher.teamId);
                                       //console.log('playerId - ' + pitcher.player.playerId);
                                      /* var probables= [];
                                       var prob ={};
                                       prob.eventId=event.eventId;
                                       prob.starting="P";
                                       probables.push(prob);*/

                                      // console.log(probables);
                                    var updatePushl = await PlayerModel.update({ "team.teamId": pitcher.teamId}, { "$pull": { "probables": event.eventId } }, { multi: true }, function (err, doc) {  });  
                                    var updatePush =  await PlayerModel.update({ "playerId": pitcher.player.playerId,"team.teamId": pitcher.teamId}, { "$push": { "probables": event.eventId } }, {upsert: true }, function (err, doc) {  });    
                                                                                                          
                                        });
                                    }

                                   // });                            
                                }
                            }) }
                        }
                        else {
                            throw err;
                        }
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                });


            }


        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To unset posponed old event 
     */
    unsetPostponedEvents: async function () {
        try {
            var nxtWeek = moment(new Date()).add(1, 'days').format('YYYY-MM-DD').replace(/-+/g, '');
            var weekAftrNext = moment(new Date()).add(2, 'days').format('YYYY-MM-DD').replace(/-+/g, '');

            //   var events = await EventModel.find({ sportId: 2, week: { $in: [nxtWeek, weekAftrNext] } });

            var events = await GameModel.aggregate([
                {
                    $match: { sportId: 2, week: { $in: [nxtWeek, weekAftrNext] } }
                },
                {

                    $group: {
                        _id: { homeTeam: "$homeTeam.teamId", awayTeam: "$awayTeam.teamId", week: "$week" },
                        eventIds: { $addToSet: "$eventId" },
                        count: { $sum: 1 }
                    }
                },
                {
                    $match: {
                        count: { $gt: 1 }
                    }
                }
            ]);
            //as suggested, considering the eventDs > 2000000 as postponed/rescheduled
            for (var i = 0; i < events.length; i++) {
                var smEventId = (Math.min(...events[i].eventIds));
                var updateOldEvent = await GameModel.update({ sportId: 2, eventId: smEventId }, { week: 0 });
            }

        } catch (e) {
            throw e;
        }
    }

}

function statsCred() {
    // moment.js is the preferred date library
    var moment = require('moment');
    // access Node.js Crypto library for signature generation
    var crypto = require('crypto');
    // get the current time
    var timeFromEpoch = moment.utc().unix();
    // set the API key (note that this is not a valid key!)
    var apiKey = process.env.API_KEY;
    // set the shared secret key
    var secret = process.env.API_SECRET;
    // generate signature
    var sig = crypto.createHash('sha256').update(apiKey + secret + timeFromEpoch).digest('hex');

    return sig;
}


