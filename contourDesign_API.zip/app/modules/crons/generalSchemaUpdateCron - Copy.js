/**
 * General Module
 * @exports Cron/GeneralSchemaUpdate
 */
var DraftGroupModel = require('../../models/draftgroup');
var cronVar = require('./cronSettings');
var async = require('async');
var moment = require('moment');

var self = module.exports = {
    /**
     * Cron - To update gameStatus value in a draftgroup schema
     * To update gameStatus in draftgroup schema based on the event status
     */
    updateDraftPlayers: function () {
        try {
            var draftgroups = DraftGroupModel.find({}, function (err, draftgroups) {
                if (err)
                    console.log(err);
                else {
                    async.eachSeries(draftgroups, async function (draftgroup, outCb) {
                        if (draftgroup.gameList != null) {
                            async.eachSeries(draftgroup.gameList, async function (game, inCb) {
                                var current_time = (moment.utc(new Date()).format('YYYY-MM-DD HH:mm:ss'));
                                var game_time = (moment.utc(game.startTimeUTC).format('YYYY-MM-DD HH:mm:ss'));
                                if (game_time > current_time) {
                                    DraftGroupModel.findOneAndUpdate({ 'draftgroupId': draftgroup.draftgroupId, 'gameList.eventId': game.eventId }, { 'gameList.$.gameStatus': 'Upcoming' }, { multi: true }, function (err, doc) { });
                                }
                                //else
                                // console.log('Completed');
                                inCb(null);
                            });
                        }
                        outCb(null);
                    });
                }

            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To update mValue value in a draftgroup schema
     * To update mValue in draftgroup schema based on the player fantasy salary
     */
    updateDraftMValue: async function () {
        try {
            var draftgroups = DraftGroupModel.find({}, async function (err, draftgroups) {
                if (err)
                    console.log(err);
                else {
                    async.eachSeries(draftgroups, async function (draftgroup, outCb) {
                        if (draftgroup.gameList != null) {
                            //To get all player position in this draftgroup
                            /*    var pos = await DraftGroupModel.aggregate(
                                    { "$match": { draftgroupId: draftgroup.draftgroupId } },
                                    { $unwind: "$gameList" },
                                    { $unwind: "$gameList.players" },
                                    { $group: { _id: null, posAbbrs: { $addToSet: "$gameList.players.posAbbr" } } }
                                );*/
                            //To get max and min fantasy player positions

                            var minmax = await DraftGroupModel.aggregate(
                                [
                                    { "$match": { draftgroupId: draftgroup.draftgroupId } },
                                    { $unwind: "$gameList" },
                                    { $unwind: "$gameList.players" },
                                    {
                                        $group:
                                        {
                                            _id: "$gameList.players.posAbbr",
                                            min: { $min: "$gameList.players.fanProjSalary" },
                                            max: { $max: "$gameList.players.fanProjSalary" }
                                        }
                                    }
                                ]
                            );
                            async.eachSeries(draftgroup.gameList, async function (game, inCb) {
                                if (game.players != null) {
                                    await async.eachSeries(game.players, async function (player, innerCb) {
                                        index = game.players.indexOf(player);
                                        // console.log(index);
                                        //   await async.eachSeries(minmax, async function (pos, posCb) {
                                        for (var i in minmax) {
                                            if (minmax[i]._id == player.posAbbr) {
                                                mValue = await Math.round((1 + ((player.fanProjSalary - minmax[i].max) * (2 - 1)) / (minmax[i].min - minmax[i].max)) * 10) / 10;

                                                //updating mValue draftgroup schema
                                                //console.log(index);
                                                //var field = '"' + "gameList.$.players." + index + ".mValue" + '"';
                                                //console.log(field);
                                                console.log(draftgroup.draftgroupId);
                                                console.log(player.playerId);
                                                console.log(mValue);
                                                updateM = await self.updateDraft(draftgroup, player, mValue);
                                                /*var updateM = await DraftGroupModel.findOneAndUpdate(
                                                    { "draftgroupId": draftgroup.draftgroupId, "gameList.players.playerId": player.playerId },
                                                    {
                                                        "$set": {
                                                            "gameList.$.players.0.mValue": mValue
                                                        }
                                                    }, function (err, result) { });*/
                                                console.log('dfdsfdsf' + draftgroup.draftgroupId);
                                                // updatedd = await self.updateDraft(draftgroup, player, mValue);
                                                // await DraftGroupModel.findOneAndUpdate({ "draftgroupId": draftgroup.draftgroupId }, { 'dgState': 'Upcomingfgfg' });

                                            };
                                            //  posCb(null);
                                            // }); 
                                        }
                                        console.log('dsdsad'); // process.exit();
                                        innerCb(null);
                                    });
                                     process.exit();
                                }
                                inCb(null);
                            });
                        }
                        outCb(null);
                    });
                }

            });
        } catch (e) {
            throw e;
        }
    },


    updateDraft: async function (draftgroup) {
        try {
            console.log('qdfdsfdsf' + draftgroup.draftgroupId); //process.exit();

            return await DraftGroupModel.findOneAndUpdate({ "draftgroupId": draftgroup.draftgroupId }, {
                $set: { 'dgState': 'Upcomingfgfg' }
            }, {
                    upsert: true
                });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },

}





