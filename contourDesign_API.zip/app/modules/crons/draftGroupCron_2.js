/**
 * DraftGroup Module
 * @exports DraftGroup/Cron
 */
var DraftGroupModel = require('../../models/draftgroups');
var GameModel = require('../../models/event');
var PlayerModel = require('../../models/player');
var moment = require('moment');
var generalHelper = require('../mobile/helpers/generalHelper');
var cronVar = require('./cronSettings');
var async = require('async');

module.exports = {
    /**
     * Cron - To create all predefined draftGroup set
     * To get all basic details related to players
     */

    getDraftGroupDetails: function () {
        try {
            var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            var processEvents = async function (callback) {
                var events = await GameModel.find({}, function (err, events) {
                    if (err)
                        console.log(err);
                    else {
                        return events;
                    }
                });
                async.forEach(events, function (event, callback) {

                    var zone = process.env.dest_zone;
                    //var s = moment.utc(event.startTimeUTC).tz(zone).format();
                    //console.log(s);process.exit();
                    var dateYMD = new Date(event.startTimeUTC).toISOString().split('T')[0];
                    var day = days[new Date(dateYMD).getDay()];
                    //console.log(day);process.exit();
                    game = {};
                    game['eventId'] = event.eventId;
                    game['startTimeUTC'] = event.startTimeUTC;
                    game['gameStatus'] = ''; //console.log(event.eventId);
                    //game player details
                    players = [];
                    //home team details
                    homeTeamId = event.homeTeam.teamId;
                    if (day == 'Sunday') {
                        var playersDatas = PlayerModel.find({ 'team.teamId': homeTeamId }, function (err, playersDatas) {
                            if (err)
                                console.log(err);
                            else {
                                //console.log('dsada'+event.eventId);process.exit();
                                return playersDatas;
                            }
                        });

                        async.forEach(playersDatas, function (playersData, callback) {//console.log('dsada'+playersData);process.exit();
                            var teamPlayers = {};
                            teamPlayers.fName = playersData.fName;
                            teamPlayers.lName = playersData.lName;
                            teamPlayers.playerId = playersData.playerId;
                            teamPlayers.posId = playersData.positions[0].posId;
                            teamPlayers.posAbbr = playersData.positions[0].posAbbr;
                            teamPlayers.CapValue = playersData.fanProjSalary;
                            teamPlayers.isInjured = playersData.isInjured;
                            competitionPlayer = {};
                            competitionPlayer.compId = event.eventId;
                            competitionPlayer.nameDisplay = [{ htName: event.homeTeam.tAbbr, htScore: '' }, { value: '' }, { atName: event.homeTeam.tAbbr, bold: '', atScore: '' }];

                            teamPlayers.competition = competitionPlayer;
                            teamPlayers.teamId = playersData.team.teamId;
                            teamPlayers.teamAbbr = playersData.team.tAbbr;
                            teamPlayers.fanProjScore = playersData.fanProjPoints;
                            players.push(teamPlayers);
                            callback();

                        }, function (err) {
                            callback(undefined, players);
                        });


                    }
                    callback();
                }, function (err) {
                    callback(undefined, '');
                });

            };
            //console.log(processEvents[0]);process.exit();
            processEvents(function (err, events) {
                console.log(12121212); process.exit();
                console.log(events[0]); process.exit();
            });




        } catch (e) {
            throw e;
        }
    }
}





