/**
 * Player NFL Live Score Module
 * @exports Cron/Player/NFL/LiveScore
 */
var PlayerScoreModel = require('../../models/playerScore');
var DraftGroupModel = require('../../models/draftgroup');
var contestModel = require('../../models/contest');
//var UserModel = require('../../models/user');
var cronVar = require('./cronSettings');
var fs = require('fs');
var xml2js = require('xml2js');
var Pusher = require('./helpers/pusherHelper');
var nflScoringRules = require('../../config/scoringRulesNFL');
var moment = cronVar.moment;
var request = cronVar.request;

var winston = require('winston');

var loggerGeneral = new(winston.Logger)({
    transports: [
        new(winston.transports.Console)(),
        new(winston.transports.File)({
            filename: './app/modules/crons/logs/cron_status.log'
        })
    ]
});

module.exports = {
    /**
     * Cron - To zip all the processed files (.txt) and delete the files
     */
    nflZipCommand: function () {
        try {
            loggerGeneral.info('NFL Zip STARTED');
            var logger = new(winston.Logger)({
                transports: [
                    new(winston.transports.Console)(),
                    new(winston.transports.File)({
                        filename: './app/modules/crons/logs/nfl_general.log'
                    })
                ]
            });
            const exec = require("child_process").exec;
            var dt = new Date(Date.now());
            var zipFile = 'nfl-' + dt.getFullYear() + '-' + (dt.getMonth() + 1) + '-' + dt.getDate() + '.zip';
            var cmd = "cd ./temp/nfl/processed/ && zip " + zipFile + " * && mv ./" + zipFile + " ../" + zipFile;
            var cmd2 = "cd ./temp/nfl/processed/ && rm *";
            exec(cmd, {
                maxBuffer: 1024 * 10000 // increased to 10000 KB
            }, (error, stdout, stderr) => {
                if (error) {
                    logger.info(error);
                } else {
                    loggerGeneral.info('NFL Zip CREATED');
                    exec(cmd2, (error2, stdout2, stderr2) => {
                        if (error2) {
                            logger.info(error2);
                        } else {
                            loggerGeneral.info('NFL Zip DELETED ALL - ENDED');
                        }
                    });
                }
            });
        } catch (e) {
            logger.info(e);
        }
    },

        /**
     * Cron - To get all Player details from the xml file and parse it and update it to the db
     */
    nflPlayerScoreSocket: async function () {
        try {
            var logger = new(winston.Logger)({
                transports: [
                    new(winston.transports.Console)(),
                    new(winston.transports.File)({
                        filename: './app/modules/crons/logs/nfl_xml_parsing.log'
                    })
                ]
            });

            var fileList = fs.readdirSync('./temp/nfl/unprocessed/');
            if (fileList.length > 0) {
                fileList.forEach(fileName => {
                    try {
                        var fileCont = fs.readFileSync('./temp/nfl/unprocessed/' + fileName);
                        fileCont = fileCont.toString().replace('<?xml version="1.0" encoding="UTF-8"?>', '').trim();
                        if (fileCont != '' && fileCont.indexOf("<nfl-event>") >= 0 && fileCont.indexOf("</nfl-event>") >= 0) { // if the file is not empty
                            var parser = new xml2js.Parser();
                            if (fileCont.indexOf("<nfl-event>") > 0) { //fix if the part of ping data is still in the file
                                var fileContArr = fileCont.split("<nfl-event>");
                                if (fileContArr[1]) {
                                    fileCont = "<nfl-event>" + fileContArr[1];
                                }
                            }

                            parser.parseString(fileCont, async function (err, result) {
                                try {
                                    if (err) {
                                        logger.info('FileName: ' + fileName);
                                        logger.info(err);
                                    } else if (result) {
                                        if (result['nfl-event']) {
                                            var sportId = 1; // NFL
                                            var eventCode = result['nfl-event']['gamecode'][0]['$']['code'];
                                            var eventId = result['nfl-event']['gamecode'][0]['$']['global-id'];
                                            var eventStatus = '';
                                            var eventStatusId = result['nfl-event']['gamestate'][0]['$']['status'];
                                            if(eventStatusId == 1 ){
                                                eventStatus = 'Pre-Game'
                                            } else if(eventStatusId == 2 ){
                                                eventStatus = 'In-Progress'
                                            }else if (eventStatusId == 4 ){
                                                eventStatus = 'Final'
                                            }else if(eventStatusId == 5 ){
                                                eventStatus = 'Postponed'
                                            }else if (eventStatusId == 9 ){
                                                eventStatus = 'Cancelled'
                                            }else if (eventStatusId == 23 ){
                                                eventStatus = 'Delayed'
                                            }
                                            logger.info('FileName: ' + fileName + ' EventId: ' + eventId + ' eventStatus: ' + eventStatus);

                                            if (eventStatus != 'Pre-Game') {
                                                var playerRecords = {};
                                                var eventDateTime = '';
                                                var visitingScore = '';
                                                var homeScore = '';
                                                var visitingTeamAlias = '';
                                                var homeTeamAlias = '';
                                                var eventClock = '';
                                                var liveGameInfo = '';
                                                var gameStateMin = '';
                                                var gameStateSec = ''; 
                                                var possTeamId = '';
                                                var possTeam = '';
                                                var liveGameInfo2 = '';
                                                var yardsFromGoal = '';
                                                var fieldPos = 0;
                                                var gameDown = '';
                                                var gameDownVal = '';
                                                var gameDistance = '';
                                                if (result['nfl-event']['visiting-team'] && result['nfl-event']['home-team']) {
                                                    var quarter = result['nfl-event']['gamestate'][0]['$']['quarter'];

                                                    if(result['nfl-event']['gamestate'][0]['$']['minutes']){
                                                        gameStateMin = result['nfl-event']['gamestate'][0]['$']['minutes'];
                                                    }
                                                    if(result['nfl-event']['gamestate'][0]['$']['seconds']){
                                                        gameStateSec = result['nfl-event']['gamestate'][0]['$']['seconds'];
                                                    }
                                                    if(result['nfl-event']['visiting-team'][0]['linescore'][0]['$']['score']){
                                                        visitingScore = result['nfl-event']['visiting-team'][0]['linescore'][0]['$']['score']
                                                    }
                                                    if(result['nfl-event']['home-team'][0]['linescore'][0]['$']['score']){
                                                        homeScore = result['nfl-event']['home-team'][0]['linescore'][0]['$']['score']
                                                    }
                                                    visitingTeamAlias = result['nfl-event']['visiting-team'][0]['team-name'][0]['$']['alias'];
                                                    homeTeamAlias = result['nfl-event']['home-team'][0]['team-name'][0]['$']['alias'];
                                                    if(result['nfl-event']['gamestate'][0]['$']['minutes']){
                                                        gameStateMin = result['nfl-event']['gamestate'][0]['$']['minutes'];
                                                    }
                                                    if(result['nfl-event']['gamestate'][0]['$']['yards-from-goal']){
                                                        yardsFromGoal = Number(result['nfl-event']['gamestate'][0]['$']['yards-from-goal']);
                                                    }
                                                    if(result['nfl-event']['gamestate'][0]['$']['team-possession-global-id']){
                                                        possTeamId = result['nfl-event']['gamestate'][0]['$']['team-possession-global-id'];
                                                    }
                                                    if(result['nfl-event']['gamestate'][0]['$']['down']){
                                                        gameDown = result['nfl-event']['gamestate'][0]['$']['down'];
                                                        gameDownVal = gameDown + ((gameDown == 1) ? 'st and ' : ((gameDown == 2) ? 'nd and ' : ((gameDown == 3) ? 'rd and ' : 'th and ')));
                                                    }
                                                    if(result['nfl-event']['gamestate'][0]['$']['distance']){
                                                        gameDistance = result['nfl-event']['gamestate'][0]['$']['distance'] + ' on ';
                                                    }
                                                    if(possTeamId == result['nfl-event']['visiting-team'][0]['team-code'][0]['$']['global-id']){
                                                        possTeam = visitingTeamAlias;
                                                        // if(yardsFromGoal > 50){
                                                        //     liveGameInfo2 = possTeam + " Ball on " + visitingTeamAlias + ' ' + (100 - yardsFromGoal)
                                                        // }
                                                        // else if (yardsFromGoal == 50){
                                                        //     liveGameInfo2 = possTeam + " Ball on " + yardsFromGoal + " yardline" 
                                                        // }
                                                        // else if (yardsFromGoal < 50){
                                                        //     liveGameInfo2 = possTeam + " Ball on " + homeTeamAlias + ' ' + yardsFromGoal 
                                                        // }

                                                        if(yardsFromGoal > 50){
                                                            liveGameInfo2 = gameDownVal + gameDistance + possTeam + " " + (100 - yardsFromGoal) + " yardline"; 
                                                        }
                                                        else if (yardsFromGoal == 50){
                                                            liveGameInfo2 = gameDownVal + gameDistance + possTeam + " " + yardsFromGoal + " yardline";
                                                        }
                                                        else if (yardsFromGoal < 50){
                                                            liveGameInfo2 = gameDownVal + gameDistance + homeTeamAlias + " " + yardsFromGoal + " yardline";
                                                        }

                                                    }
                                                    else {
                                                        possTeam = homeTeamAlias;
                                                        // if(yardsFromGoal > 50){
                                                        //     liveGameInfo2 = possTeam + " Ball on " + homeTeamAlias + ' ' + (100 - yardsFromGoal)
                                                        // }
                                                        // else if (yardsFromGoal == 50){
                                                        //     liveGameInfo2 = possTeam + " Ball on " + yardsFromGoal + " yardline" 
                                                        // }
                                                        // else if (yardsFromGoal < 50){
                                                        //     liveGameInfo2 = possTeam + " Ball on " + visitingTeamAlias + ' ' + yardsFromGoal 
                                                        // }

                                                        if(yardsFromGoal > 50){
                                                            liveGameInfo2 = gameDownVal + gameDistance + possTeam + " " + (100 - yardsFromGoal) + " yardline";
                                                        }
                                                        else if (yardsFromGoal == 50){
                                                            liveGameInfo2 = gameDownVal + gameDistance + possTeam + " " + yardsFromGoal + " yardline";
                                                        }
                                                        else if (yardsFromGoal < 50){
                                                            liveGameInfo2 = gameDownVal + gameDistance + visitingTeamAlias + " " + yardsFromGoal + " yardline";
                                                        }
                                                    }

                                                    eventClock = quarter + 'Q - ' + gameStateMin + ':' + gameStateSec;
                                                    liveGameInfo = visitingTeamAlias + ' ' +
                                                        visitingScore +
                                                        ' @ ' +
                                                        homeTeamAlias +  ' ' +
                                                        homeScore +  ' ' +
                                                        eventClock;

                                                    fieldPos = (1 - (Number(yardsFromGoal) / 100))
                                                }

                                                console.log(' quarter: '+ quarter + ' visitingScore: '+ visitingScore +' homeScore: '+ homeScore);
                                                console.log(' visitingTeamAlias: '+ visitingTeamAlias + ' homeTeamAlias: '+ homeTeamAlias +' eventClock: '+ eventClock);
                                                console.log('possTeamId : ' + possTeamId + ' liveGameInfo: ' + liveGameInfo + ' liveGameInfo2: ' + liveGameInfo2)

                                                var downloadUpdate = 'N';
                                                var player = {};

                                                await DraftGroupModel.update({
                                                    'gameList.eventId': eventId
                                                }, {
                                                    'gameList.$.gameStatus': eventStatus
                                                }, {
                                                    multi: true
                                                });

                                                var dgs = await DraftGroupModel.find({
                                                    'gameList.eventId': eventId
                                                }, 'gameList draftgroupId');

                                                for (var dg of dgs) {
                                                    var status = '';
                                                    var dgId = dg.draftgroupId;

                                                    for (var thisGame of dg.gameList) {
                                                        if (thisGame.eventId == eventId) {
                                                            for (p of thisGame.players) { // fetching player details (DG->GameList->Players)
                                                                if (!player[p.playerId]) {
                                                                    player[p.playerId] = {};
                                                                }
                                                                if (p.posGen) {
                                                                    player[p.playerId]['posGen'] = p.posGen;
                                                                }

                                                                if (p.mValue) {
                                                                    player[p.playerId]['multiplierVal'] = p.mValue.value;
                                                                }
                                                            }
                                                        }
                                                    }

                                                    var postponedMatchCnt = 0;
                                                    var totalMatchCnt = dg.gameList.length;
                                                    for (var g of dg.gameList) {
                                                        if (g.gameStatus == 'In-Progress') {
                                                            status = g.gameStatus;
                                                            break;
                                                        } else if (g.gameStatus == 'Cancelled') {
                                                            // Do nothing
                                                        } else if (g.gameStatus == 'Postponed') {
                                                            postponedMatchCnt++;
                                                            if (status == '') { // if all the matches are postponed
                                                                status == 'Postponed';
                                                            }
                                                        } else if (g.gameStatus == 'Final') {
                                                            if (status == 'Upcoming') {
                                                                status = 'In-Progress';
                                                                break;
                                                            }
                                                            status = g.gameStatus;
                                                        } else {
                                                            if (status == 'Final') {
                                                                status = 'In-Progress';
                                                                break;
                                                            }
                                                            status = 'Upcoming';
                                                        }
                                                    }

                                                    if (status == 'Final' && postponedMatchCnt == (totalMatchCnt - 1)) { // if n-1 matches gets postponed
                                                        status = 'Postponed';
                                                    }

                                                    var contestStatus = 3;
                                                    var dfStatus = 'Upcoming';
                                                    if (status == 'Final') {
                                                        contestStatus = 1
                                                        dfStatus = 'Completed';
                                                    } else if (status == 'In-Progress') {
                                                        contestStatus = 2
                                                        dfStatus = 'Live';
                                                    } else if (status == 'Postponed') {
                                                        contestStatus = 4
                                                        dfStatus = 'Cancelled';
                                                    }

                                                    await DraftGroupModel.update({
                                                        'draftgroupId': dgId
                                                    }, {
                                                        'dgState': dfStatus
                                                    });

                                                    await contestModel.update({
                                                        'draftgroupId': dgId,
                                                        'contestStatus': {
                                                            $in: [1, 2, 3]
                                                        }
                                                    }, {
                                                        'contestStatus': contestStatus
                                                    }, {
                                                        multi: true
                                                    });

                                                    logger.info('dgState : ' + dfStatus + '; contestStatus : ' + contestStatus); 
                                                }

                                                if (eventStatus == 'Final') { // fix for not to miss any player record if the status is final
                                                    await PlayerScoreModel.update({
                                                        'eventId': eventId
                                                    }, {
                                                        'eventStatus': eventStatus,
                                                        'liveGameInfo': liveGameInfo,
                                                        'liveGameInfo2': liveGameInfo2,
                                                        'possTeam': possTeam,
                                                        'homeScore': homeScore,
                                                        'awayScore': visitingScore,
                                                        'homeAbbr': homeTeamAlias,
                                                        'awayAbbr': visitingTeamAlias,
                                                        'clock': eventClock,
                                                        'fileName': fileName
                                                    }, {
                                                        multi: true
                                                    });

                                                    logger.info('liveGameInfo : ' + liveGameInfo + '; liveGameInfo2 : ' + liveGameInfo2); 
                                                }

                                                if (eventStatus == 'In-Progress' || eventStatus == 'Final') { // consider inprogress and final only
                                                    if (result['nfl-event']['home-team'] && result['nfl-event']['visiting-team']) {
                                                        var homeTeamName = result['nfl-event']['home-team'][0]['team-name'][0]['$']['name'];
                                                        var homeTeamId = result['nfl-event']['home-team'][0]['team-code'][0]['$']['id'];
                                                        var visitingTeamName = result['nfl-event']['visiting-team'][0]['team-name'][0]['$']['name'];
                                                        var visitingTeamId = result['nfl-event']['visiting-team'][0]['team-code'][0]['$']['id'];

                                                        console.log(' homeTeamName: '+ homeTeamName + ' homeTeamId: '+ homeTeamId );
                                                        console.log(' visitingTeamName: '+ visitingTeamName + ' visitingTeamId: '+ visitingTeamId );

                                                        if (result['nfl-event']['home-player-stats']) {
                                                            var homeTeamLineup = result['nfl-event']['home-player-stats'][0]['home-player'];
                                                            for (i in homeTeamLineup) { // looping the home team batting lineup
                                                                var playerId = homeTeamLineup[i]['player-code'][0]['$']['global-id'];
                                                                if (!player[playerId]) {
                                                                    player[playerId] = {};
                                                                    // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                }
                                                                playerRecords[playerId] = {};
                                                                playerRecords[playerId]['sportId'] = sportId;
                                                                playerRecords[playerId]['eventCode'] = eventCode;
                                                                playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                playerRecords[playerId]['fileName'] = fileName;
                                                                playerRecords[playerId]['eventId'] = eventId;
                                                                playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                playerRecords[playerId]['teamId'] = homeTeamId;
                                                                playerRecords[playerId]['teamName'] = homeTeamName;
                                                                playerRecords[playerId]['teamAlias'] = homeTeamAlias;
                                                                playerRecords[playerId]['playerId'] = playerId;
                                                                playerRecords[playerId]['fieldPos'] = fieldPos;
                                                                playerRecords[playerId]['playerScore'] = 0;
                                                                playerRecords[playerId]['multiPlayerScore'] = {};
                                                                playerRecords[playerId]['playerStats'] = {
                                                                    "passing": {},
                                                                    "rushing": {},
                                                                    "receiving": {},
                                                                    "scoring": {},
                                                                    "fumbles": {}
                                                                };

                                                                if(homeTeamLineup[i]['rushing']){
                                                                    playerRecords[playerId]['playerStats']['rushing']['rushing-yards'] = {
                                                                        'val': homeTeamLineup[i]['rushing'][0]['$']['yards'],
                                                                        'pts': nflScoringRules.nflScore['rushing']['rushing-yards']['pts'],
                                                                        'abr': nflScoringRules.nflScore['rushing']['rushing-yards']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing']['rushing-yards']['val'] * playerRecords[playerId]['playerStats']['rushing']['rushing-yards']['pts'];

                                                                    if(playerRecords[playerId]['playerStats']['rushing']['rushing-yards']['val'] > 100){
                                                                        playerRecords[playerId]['playerStats']['rushing']['rushing-100yds+'] = {
                                                                        'val': 1,
                                                                        'pts': nflScoringRules.nflScore['rushing']['rushing-100yds+']['pts'],
                                                                        'abr': nflScoringRules.nflScore['rushing']['rushing-100yds+']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing']['rushing-100yds+']['pts'];
                                                                    }

                                                                    playerRecords[playerId]['playerStats']['scoring']['rushing-touchdowns'] = {
                                                                        'val': homeTeamLineup[i]['rushing'][0]['$']['tds'],
                                                                        'pts': nflScoringRules.nflScore['scoring']['rushing-touchdowns']['pts'],
                                                                        'abr': nflScoringRules.nflScore['scoring']['rushing-touchdowns']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['rushing-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['rushing-touchdowns']['pts'];
                                                                }

                                                                if(homeTeamLineup[i]['passing']){
                                                                    playerRecords[playerId]['playerStats']['passing']['passing-yards'] = {
                                                                        'val': homeTeamLineup[i]['passing'][0]['$']['yards'],
                                                                        'pts': nflScoringRules.nflScore['passing']['passing-yards']['pts'],
                                                                        'abr': nflScoringRules.nflScore['passing']['passing-yards']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing']['passing-yards']['val'] * playerRecords[playerId]['playerStats']['passing']['passing-yards']['pts'];

                                                                    if(playerRecords[playerId]['playerStats']['passing']['passing-yards']['val'] > 300){
                                                                        playerRecords[playerId]['playerStats']['passing']['passing-300yds+'] = {
                                                                        'val': 1,
                                                                        'pts': nflScoringRules.nflScore['passing']['passing-300yds+']['pts'],
                                                                        'abr': nflScoringRules.nflScore['passing']['passing-300yds+']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing']['passing-300yds+']['pts'];
                                                                    }

                                                                    playerRecords[playerId]['playerStats']['scoring']['passing-touchdowns'] = {
                                                                        'val': homeTeamLineup[i]['passing'][0]['$']['tds'],
                                                                        'pts': nflScoringRules.nflScore['scoring']['passing-touchdowns']['pts'],
                                                                        'abr': nflScoringRules.nflScore['scoring']['passing-touchdowns']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['passing-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['passing-touchdowns']['pts'];

                                                                    playerRecords[playerId]['playerStats']['passing']['interceptions'] = {
                                                                        'val': homeTeamLineup[i]['passing'][0]['$']['interceptions'],
                                                                        'pts': nflScoringRules.nflScore['passing']['interceptions']['pts'],
                                                                        'abr': nflScoringRules.nflScore['passing']['interceptions']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing']['interceptions']['val'] * playerRecords[playerId]['playerStats']['passing']['interceptions']['pts'];
                                                                }

                                                                if(homeTeamLineup[i]['receiving']){
                                                                    playerRecords[playerId]['playerStats']['receiving']['receiving-yards'] = {
                                                                        'val': homeTeamLineup[i]['receiving'][0]['$']['yards'],
                                                                        'pts': nflScoringRules.nflScore['receiving']['receiving-yards']['pts'],
                                                                        'abr': nflScoringRules.nflScore['receiving']['receiving-yards']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving']['receiving-yards']['val'] * playerRecords[playerId]['playerStats']['receiving']['receiving-yards']['pts'];

                                                                    if(playerRecords[playerId]['playerStats']['receiving']['receiving-yards']['val'] > 100){
                                                                        playerRecords[playerId]['playerStats']['receiving']['receiving-100yds+'] = {
                                                                        'val': 1,
                                                                        'pts': nflScoringRules.nflScore['receiving']['receiving-100yds+']['pts'],
                                                                        'abr': nflScoringRules.nflScore['receiving']['receiving-100yds+']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving']['receiving-100yds+']['pts'];
                                                                    }

                                                                    playerRecords[playerId]['playerStats']['scoring']['receiving-touchdowns'] = {
                                                                        'val': homeTeamLineup[i]['receiving'][0]['$']['tds'],
                                                                        'pts': nflScoringRules.nflScore['scoring']['receiving-touchdowns']['pts'],
                                                                        'abr': nflScoringRules.nflScore['scoring']['receiving-touchdowns']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['receiving-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['receiving-touchdowns']['pts'];

                                                                    playerRecords[playerId]['playerStats']['receiving']['receptions'] = {
                                                                        'val': homeTeamLineup[i]['receiving'][0]['$']['receptions'],
                                                                        'pts': nflScoringRules.nflScore['receiving']['receptions']['pts'],
                                                                        'abr': nflScoringRules.nflScore['receiving']['receptions']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving']['receptions']['val'] * playerRecords[playerId]['playerStats']['receiving']['receptions']['pts'];
                                                                }

                                                                if(homeTeamLineup[i]['kick-returning']){
                                                                    playerRecords[playerId]['playerStats']['scoring']['kickoff-touchdowns'] = {
                                                                        'val': homeTeamLineup[i]['kick-returning'][0]['$']['tds'],
                                                                        'pts': nflScoringRules.nflScore['scoring']['kickoff-touchdowns']['pts'],
                                                                        'abr': nflScoringRules.nflScore['scoring']['kickoff-touchdowns']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['kickoff-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['kickoff-touchdowns']['pts'];
                                                                }

                                                                if(homeTeamLineup[i]['punt-returning']){
                                                                    playerRecords[playerId]['playerStats']['scoring']['punt-return-touchdowns'] = {
                                                                        'val': homeTeamLineup[i]['punt-returning'][0]['$']['tds'],
                                                                        'pts': nflScoringRules.nflScore['scoring']['punt-return-touchdowns']['pts'],
                                                                        'abr': nflScoringRules.nflScore['scoring']['punt-return-touchdowns']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['punt-return-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['punt-return-touchdowns']['pts'];
                                                                }
                                                                
                                                                if(homeTeamLineup[i]['fumbles-lost']){
                                                                    playerRecords[playerId]['playerStats']['fumbles']['fumbles-lost'] = {
                                                                        'val': homeTeamLineup[i]['fumbles-lost'][0]['$']['number'],
                                                                        'pts': nflScoringRules.nflScore['fumbles']['fumbles-lost']['pts'],
                                                                        'abr': nflScoringRules.nflScore['fumbles']['fumbles-lost']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['fumbles']['fumbles-lost']['val'] * playerRecords[playerId]['playerStats']['fumbles']['fumbles-lost']['pts'];
                                                                }

                                                                if(homeTeamLineup[i]['own-fumbles-recovered']){
                                                                    playerRecords[playerId]['playerStats']['scoring']['own-fumble-touchdowns'] = {
                                                                        'val': homeTeamLineup[i]['own-fumbles-recovered'][0]['$']['tds'],
                                                                        'pts': nflScoringRules.nflScore['scoring']['own-fumble-touchdowns']['pts'],
                                                                        'abr': nflScoringRules.nflScore['scoring']['own-fumble-touchdowns']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['own-fumble-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['own-fumble-touchdowns']['pts'];
                                                                }

                                                                if(homeTeamLineup[i]['PAT']){
                                                                    if(homeTeamLineup[i]['PAT'][0]['type']){
                                                                        if(homeTeamLineup[i]['PAT'][0]['type'][0]['$']['points'] == 2 && homeTeamLineup[i]['PAT'][0]['type'][0]['$']['good'] == true){
                                                                            playerRecords[playerId]['playerStats']['scoring']['two-point-conversion'] = {
                                                                                'val': nflScoringRules.nflScore['scoring']['two-point-conversion']['pts'],
                                                                                'pts': nflScoringRules.nflScore['scoring']['two-point-conversion']['pts'],
                                                                                'abr': nflScoringRules.nflScore['scoring']['two-point-conversion']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['two-point-conversion']['val'];

                                                                            playerRecords[playerId]['playerStats']['scoring']['two-point-pass-conversion'] = {
                                                                                'val': nflScoringRules.nflScore['scoring']['two-point-pass-conversion']['pts'],
                                                                                'pts': nflScoringRules.nflScore['scoring']['two-point-pass-conversion']['pts'],
                                                                                'abr': nflScoringRules.nflScore['scoring']['two-point-pass-conversion']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['two-point-pass-conversion']['val'];
                                                                        }
                                                                    }

                                                                    if(homeTeamLineup[i]['PAT'][0]['$']['made']){
                                                                        playerRecords[playerId]['playerStats']['scoring']['extra-point-conversion'] = {
                                                                            'val': homeTeamLineup[i]['PAT'][0]['$']['made'],
                                                                            'pts': nflScoringRules.nflScore['scoring']['extra-point-conversion']['pts'],
                                                                            'abr': nflScoringRules.nflScore['scoring']['extra-point-conversion']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['extra-point-conversion']['val'] * playerRecords[playerId]['playerStats']['scoring']['extra-point-conversion']['pts'];
                                                                    }
                                                                }

                                                                if (!player[playerId]['multiplierVal']) {
                                                                    // logger.info('Player Id (Hbatting) ' + playerId + ' has no mValue for event ' + eventId);
                                                                    playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                } else {
                                                                    playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                }
                                                            }
                                                        }

                                                        if (result['nfl-event']['visiting-player-stats']) {
                                                            var visitingTeamLineup = result['nfl-event']['visiting-player-stats'][0]['visiting-player'];
                                                            for (i in visitingTeamLineup) { // looping the visiting team batting lineup
                                                                var playerId = visitingTeamLineup[i]['player-code'][0]['$']['global-id'];
                                                                if (!player[playerId]) {
                                                                    player[playerId] = {};
                                                                    // logger.info('Missing (VB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                }

                                                                playerRecords[playerId] = {};
                                                                playerRecords[playerId]['sportId'] = sportId;
                                                                playerRecords[playerId]['eventCode'] = eventCode;
                                                                playerRecords[playerId]['downloadUpdate'] = downloadUpdate;
                                                                playerRecords[playerId]['fileName'] = fileName;
                                                                playerRecords[playerId]['eventId'] = eventId;
                                                                playerRecords[playerId]['eventStatus'] = eventStatus;
                                                                playerRecords[playerId]['eventDateTime'] = eventDateTime;
                                                                playerRecords[playerId]['liveGameInfo'] = liveGameInfo;
                                                                playerRecords[playerId]['liveGameInfo2'] = liveGameInfo2;
                                                                playerRecords[playerId]['teamId'] = visitingTeamId;
                                                                playerRecords[playerId]['teamName'] = visitingTeamName;
                                                                playerRecords[playerId]['teamAlias'] = visitingTeamAlias;
                                                                playerRecords[playerId]['playerId'] = playerId;
                                                                playerRecords[playerId]['fieldPos'] = fieldPos;
                                                                playerRecords[playerId]['playerScore'] = 0;
                                                                playerRecords[playerId]['multiPlayerScore'] = {};
                                                                playerRecords[playerId]['playerStats'] = {
                                                                    "passing": {},
                                                                    "rushing": {},
                                                                    "receiving": {},
                                                                    "scoring": {},
                                                                    "fumbles": {}
                                                                };

                                                                if(visitingTeamLineup[i]['rushing']){
                                                                    playerRecords[playerId]['playerStats']['rushing']['rushing-yards'] = {
                                                                        'val': visitingTeamLineup[i]['rushing'][0]['$']['yards'],
                                                                        'pts': nflScoringRules.nflScore['rushing']['rushing-yards']['pts'],
                                                                        'abr': nflScoringRules.nflScore['rushing']['rushing-yards']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing']['rushing-yards']['val'] * playerRecords[playerId]['playerStats']['rushing']['rushing-yards']['pts'];

                                                                    if(playerRecords[playerId]['playerStats']['rushing']['rushing-yards']['val'] > 100){
                                                                        playerRecords[playerId]['playerStats']['rushing']['rushing-100yds+'] = {
                                                                        'val': 1,
                                                                        'pts': nflScoringRules.nflScore['rushing']['rushing-100yds+']['pts'],
                                                                        'abr': nflScoringRules.nflScore['rushing']['rushing-100yds+']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing']['rushing-100yds+']['pts'];
                                                                    }

                                                                    playerRecords[playerId]['playerStats']['scoring']['rushing-touchdowns'] = {
                                                                        'val': visitingTeamLineup[i]['rushing'][0]['$']['tds'],
                                                                        'pts': nflScoringRules.nflScore['scoring']['rushing-touchdowns']['pts'],
                                                                        'abr': nflScoringRules.nflScore['scoring']['rushing-touchdowns']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['rushing-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['rushing-touchdowns']['pts'];
                                                                }

                                                                if(visitingTeamLineup[i]['passing']){
                                                                    playerRecords[playerId]['playerStats']['passing']['passing-yards'] = {
                                                                        'val': visitingTeamLineup[i]['passing'][0]['$']['yards'],
                                                                        'pts': nflScoringRules.nflScore['passing']['passing-yards']['pts'],
                                                                        'abr': nflScoringRules.nflScore['passing']['passing-yards']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing']['passing-yards']['val'] * playerRecords[playerId]['playerStats']['passing']['passing-yards']['pts'];

                                                                    if(playerRecords[playerId]['playerStats']['passing']['passing-yards']['val'] > 300){
                                                                        playerRecords[playerId]['playerStats']['passing']['passing-300yds+'] = {
                                                                        'val': 1,
                                                                        'pts': nflScoringRules.nflScore['passing']['passing-300yds+']['pts'],
                                                                        'abr': nflScoringRules.nflScore['passing']['passing-300yds+']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing']['passing-300yds+']['pts'];
                                                                    }

                                                                    playerRecords[playerId]['playerStats']['scoring']['passing-touchdowns'] = {
                                                                        'val': visitingTeamLineup[i]['passing'][0]['$']['tds'],
                                                                        'pts': nflScoringRules.nflScore['scoring']['passing-touchdowns']['pts'],
                                                                        'abr': nflScoringRules.nflScore['scoring']['passing-touchdowns']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['passing-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['passing-touchdowns']['pts'];

                                                                    playerRecords[playerId]['playerStats']['passing']['interceptions'] = {
                                                                        'val': visitingTeamLineup[i]['passing'][0]['$']['interceptions'],
                                                                        'pts': nflScoringRules.nflScore['passing']['interceptions']['pts'],
                                                                        'abr': nflScoringRules.nflScore['passing']['interceptions']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing']['interceptions']['val'] * playerRecords[playerId]['playerStats']['passing']['interceptions']['pts'];
                                                                }

                                                                if(visitingTeamLineup[i]['receiving']){
                                                                    playerRecords[playerId]['playerStats']['receiving']['receiving-yards'] = {
                                                                        'val': visitingTeamLineup[i]['receiving'][0]['$']['yards'],
                                                                        'pts': nflScoringRules.nflScore['receiving']['receiving-yards']['pts'],
                                                                        'abr': nflScoringRules.nflScore['receiving']['receiving-yards']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving']['receiving-yards']['val'] * playerRecords[playerId]['playerStats']['receiving']['receiving-yards']['pts'];

                                                                    if(playerRecords[playerId]['playerStats']['receiving']['receiving-yards']['val'] > 100){
                                                                        playerRecords[playerId]['playerStats']['receiving']['receiving-100yds+'] = {
                                                                        'val': 1,
                                                                        'pts': nflScoringRules.nflScore['receiving']['receiving-100yds+']['pts'],
                                                                        'abr': nflScoringRules.nflScore['receiving']['receiving-100yds+']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving']['receiving-100yds+']['pts'];
                                                                    }

                                                                    playerRecords[playerId]['playerStats']['scoring']['receiving-touchdowns'] = {
                                                                        'val': visitingTeamLineup[i]['receiving'][0]['$']['tds'],
                                                                        'pts': nflScoringRules.nflScore['scoring']['receiving-touchdowns']['pts'],
                                                                        'abr': nflScoringRules.nflScore['scoring']['receiving-touchdowns']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['receiving-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['receiving-touchdowns']['pts'];

                                                                    playerRecords[playerId]['playerStats']['receiving']['receptions'] = {
                                                                        'val': visitingTeamLineup[i]['receiving'][0]['$']['receptions'],
                                                                        'pts': nflScoringRules.nflScore['receiving']['receptions']['pts'],
                                                                        'abr': nflScoringRules.nflScore['receiving']['receptions']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving']['receptions']['val'] * playerRecords[playerId]['playerStats']['receiving']['receptions']['pts'];
                                                                }

                                                                if(visitingTeamLineup[i]['kick-returning']){
                                                                    playerRecords[playerId]['playerStats']['scoring']['kickoff-touchdowns'] = {
                                                                        'val': visitingTeamLineup[i]['kick-returning'][0]['$']['tds'],
                                                                        'pts': nflScoringRules.nflScore['scoring']['kickoff-touchdowns']['pts'],
                                                                        'abr': nflScoringRules.nflScore['scoring']['kickoff-touchdowns']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['kickoff-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['kickoff-touchdowns']['pts'];
                                                                }

                                                                if(visitingTeamLineup[i]['punt-returning']){
                                                                    playerRecords[playerId]['playerStats']['scoring']['punt-return-touchdowns'] = {
                                                                        'val': visitingTeamLineup[i]['punt-returning'][0]['$']['tds'],
                                                                        'pts': nflScoringRules.nflScore['scoring']['punt-return-touchdowns']['pts'],
                                                                        'abr': nflScoringRules.nflScore['scoring']['punt-return-touchdowns']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['punt-return-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['punt-return-touchdowns']['pts'];
                                                                }
                                                                
                                                                if(visitingTeamLineup[i]['fumbles-lost']){
                                                                    playerRecords[playerId]['playerStats']['fumbles']['fumbles-lost'] = {
                                                                        'val': visitingTeamLineup[i]['fumbles-lost'][0]['$']['number'],
                                                                        'pts': nflScoringRules.nflScore['fumbles']['fumbles-lost']['pts'],
                                                                        'abr': nflScoringRules.nflScore['fumbles']['fumbles-lost']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['fumbles']['fumbles-lost']['val'] * playerRecords[playerId]['playerStats']['fumbles']['fumbles-lost']['pts'];
                                                                }

                                                                if(visitingTeamLineup[i]['own-fumbles-recovered']){
                                                                    playerRecords[playerId]['playerStats']['scoring']['own-fumble-touchdowns'] = {
                                                                        'val': visitingTeamLineup[i]['own-fumbles-recovered'][0]['$']['tds'],
                                                                        'pts': nflScoringRules.nflScore['scoring']['own-fumble-touchdowns']['pts'],
                                                                        'abr': nflScoringRules.nflScore['scoring']['own-fumble-touchdowns']['abr']
                                                                    };
                                                                    playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['own-fumble-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['own-fumble-touchdowns']['pts'];
                                                                }

                                                                if(visitingTeamLineup[i]['PAT']){
                                                                    if(visitingTeamLineup[i]['PAT'][0]['type']){
                                                                        if(visitingTeamLineup[i]['PAT'][0]['type'][0]['$']['points'] == 2 && visitingTeamLineup[i]['PAT'][0]['type'][0]['$']['good'] == true){
                                                                            playerRecords[playerId]['playerStats']['scoring']['two-point-conversion'] = {
                                                                                'val': nflScoringRules.nflScore['scoring']['two-point-conversion']['pts'],
                                                                                'pts': nflScoringRules.nflScore['scoring']['two-point-conversion']['pts'],
                                                                                'abr': nflScoringRules.nflScore['scoring']['two-point-conversion']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['two-point-conversion']['val'];

                                                                            playerRecords[playerId]['playerStats']['scoring']['two-point-pass-conversion'] = {
                                                                                'val': nflScoringRules.nflScore['scoring']['two-point-pass-conversion']['pts'],
                                                                                'pts': nflScoringRules.nflScore['scoring']['two-point-pass-conversion']['pts'],
                                                                                'abr': nflScoringRules.nflScore['scoring']['two-point-pass-conversion']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['two-point-pass-conversion']['val'];
                                                                        }
                                                                    }
                                                                    if(visitingTeamLineup[i]['PAT'][0]['$']['made']){
                                                                        playerRecords[playerId]['playerStats']['scoring']['extra-point-conversion'] = {
                                                                            'val': visitingTeamLineup[i]['PAT'][0]['$']['made'],
                                                                            'pts': nflScoringRules.nflScore['scoring']['extra-point-conversion']['pts'],
                                                                            'abr': nflScoringRules.nflScore['scoring']['extra-point-conversion']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['extra-point-conversion']['val'] * playerRecords[playerId]['playerStats']['scoring']['extra-point-conversion']['pts'];
                                                                    }
                                                                }

                                                                if (!player[playerId]['multiplierVal']) {
                                                                    // logger.info('Player Id (Vbatting) ' + playerId + ' has no mValue for event ' + eventId);
                                                                    playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                                } else {
                                                                    playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                                }
                                                            }
                                                        }

                                                        var playerCnt = 0;
                                                        for (var i in playerRecords) { // Updating the player records in the database
                                                            playerCnt++;
                                                            playerRecords[i]['possTeam'] = possTeam;
                                                            playerRecords[i]['awayAbbr'] = visitingTeamAlias;
                                                            playerRecords[i]['homeAbbr'] = homeTeamAlias;
                                                            playerRecords[i]['awayScore'] = visitingScore;
                                                            playerRecords[i]['homeScore'] = homeScore;
                                                            playerRecords[i]['clock'] = eventClock;

                                                            var playerUpdate = await PlayerScoreModel.update({
                                                                'playerId': playerRecords[i]['playerId'],
                                                                'eventId': playerRecords[i]['eventId']
                                                            }, {
                                                                $set: playerRecords[i]
                                                            }, {
                                                                upsert: true
                                                            });

                                                            logger.info('Inserted to db: ' + playerRecords[i]['eventId'] + '-' + playerRecords[i]['playerId'] + '-' + fileName);
                                                            // logger.info(JSON.stringify(playerUpdate));
                                                        }
                                                        logger.info('Player Count: ' + playerCnt + ' in ' + fileName);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } catch (e) {
                                    logger.info('FileName: ' + fileName);
                                    logger.info(e);
                                }
                            });
                            fs.renameSync('./temp/nfl/unprocessed/' + fileName, './temp/nfl/processed/' + fileName);
                        }
                    } catch (e) {
                        logger.info('FileName: ' + fileName);
                        logger.info(e);
                    }
                });
            } else {
                logger.info('No File found');
            }
        } catch (e) {
            logger.info(e);
        }
    },

     /**
     * Cron - To get all Player details from the DOWNLOADed xml file and parse it and update it to the db
     */
    nflPlayerScoreDownload: async function () {
        try {
            var logger = new(winston.Logger)({
                transports: [
                    new(winston.transports.Console)(),
                    new(winston.transports.File)({
                        filename: './app/modules/crons/logs/nfl_download_xml_parsing.log'
                    })
                ]
            });

            var psData = await PlayerScoreModel.findOne({
                $or: [{
                    $and: [{
                            'eventStatus': 'Final'
                        },
                        {
                            'downloadUpdate': 'N'
                        },
                        {
                            'sportId': 1
                        },
                        {
                            'eventCode': {
                                $exists: true
                            }
                        }
                    ]
                }, {
                    $and: [{
                            'eventStatus': 'In-Progress'
                        }, {
                            'createdAt': {
                                $lte: new Date(Date.now() - (1000 * 60 * 60 * 4)) // 4 hrs
                            }
                        },
                        {
                            'sportId': 1
                        },
                        {
                            'eventCode': {
                                $exists: true
                            }
                        }
                    ]
                }]
            }, 'eventId eventCode eventStatus');

            // var psData = {
            //     eventCode: 20180906021
            // };
            if (psData != null) {
                var downloadFile = 'NFL_FINALBOX$' + psData.eventCode + '.XML'; // to do
                // console.log(downloadFile);
                request({
                        'url': "http://downloads.stats.com/ContourDesign/" + downloadFile,
                        'auth': {
                            'user': 'ContourDesign',
                            'pass': 'football1738',
                            'sendImmediately': false
                        }
                    },
                    async function (err, response, body) {
                        try {
                            // parse the body as JSON
                            if (!err && response.statusCode == 200) {
                                var fileCont = body.toString().replace('<?xml version="1.0" encoding="UTF-8"?>', '').trim();
                                if (fileCont != '') { // if the file is not empty
                                    var parser = new xml2js.Parser();
                                    parser.parseString(fileCont, async function (err, result) {
                                        try {
                                            if (err) {
                                                logger.info('FileName: ' + downloadFile);
                                                logger.info(err);
                                            } else if (result['sports-statistics']) {
                                                var playerRecords = {};
                                                var nflBoxScore = result['sports-statistics']['sports-boxscores'][0]['nfl-boxscores'][0]['nfl-boxscore'][0];
                                                if (nflBoxScore['date']) {
                                                    var dt = nflBoxScore['date'][0]['$'];
                                                    var t = nflBoxScore['time'][0]['$'];
                                                    try {
                                                        var dtt = moment([dt['year'], (dt['month'] - 1), dt['date'], t['hour'], t['minute'], 0, 0]).add({
                                                            hours: t['utc-hour'],
                                                            minutes: t['utc-minute']
                                                        });
                                                        var eventDateTime = dtt.format('YYYY-MM-DD hh:mm:ss A');
                                                    } catch (e) {
                                                        var eventDateTime = '';
                                                    }
                                                } else {
                                                    var eventDateTime = '';
                                                }

                                                var sportId = 1; //NFL
                                                var eventCode = nflBoxScore['gamecode'][0]['$']['code'];
                                                var downloadUpdate = 'Y';
                                                var eventId = nflBoxScore['gamecode'][0]['$']['global-id'];
                                                var eventStatus = nflBoxScore['gamestate'][0]['$']['status'];
                                                //var atBat = '';
                                                var visitingScore = '';
                                                var homeScore = '';
                                                var visitingTeamAlias = '';
                                                var homeTeamAlias = '';
                                                var eventClock = '';
                                                var liveGameInfo = '';
                                                var liveGameInfo2 = '';
                                                var possTeam = '';
                                                var fieldPos = '';
                                                var player = {};

                                                logger.info('FileName: ' + downloadFile + ' EventId: ' + eventId + ' eventDateTime: ' + eventDateTime);

                                                await DraftGroupModel.update({
                                                    'gameList.eventId': eventId
                                                }, {
                                                    'gameList.$.gameStatus': eventStatus
                                                }, {
                                                    multi: true
                                                });

                                                var dgs = await DraftGroupModel.find({
                                                    'gameList.eventId': eventId
                                                }, 'gameList draftgroupId');

                                                for (dg of dgs) {
                                                    var status = '';
                                                    var dgId = dg.draftgroupId;

                                                    for (var thisGame of dg.gameList) {
                                                        if (thisGame.eventId == eventId) {
                                                            for (p of thisGame.players) { // fetching player details (DG->GameList->Players)
                                                                if (!player[p.playerId]) {
                                                                    player[p.playerId] = {};
                                                                }
                                                                if (p.posGen) {
                                                                    player[p.playerId]['posGen'] = p.posGen;
                                                                }

                                                                if (p.mValue) {
                                                                    player[p.playerId]['multiplierVal'] = p.mValue.value;
                                                                }
                                                            }
                                                        }
                                                    }

                                                    var postponedMatchCnt = 0;
                                                    var totalMatchCnt = dg.gameList.length;

                                                    for (var g of dg.gameList) {
                                                        if (g.gameStatus == 'In-Progress') {
                                                            status = g.gameStatus;
                                                            break;
                                                        } else if (g.gameStatus == 'Cancelled') {
                                                            // Do nothing
                                                        } else if (g.gameStatus == 'Postponed') {
                                                            postponedMatchCnt++;
                                                            if (status == '') { // if all the matches are postponed
                                                                status == 'Postponed';
                                                            }
                                                        } else if (g.gameStatus == 'Final') {
                                                            if (status == 'Upcoming') {
                                                                status = 'In-Progress';
                                                                break;
                                                            }
                                                            status = g.gameStatus;
                                                        } else {
                                                            if (status == 'Final') {
                                                                status = 'In-Progress';
                                                                break;
                                                            }
                                                            status = 'Upcoming';
                                                        }
                                                    }

                                                    if (status == 'Final' && postponedMatchCnt == (totalMatchCnt - 1)) { // if n-1 matches gets postponed
                                                        status = 'Postponed';
                                                    }

                                                    var contestStatus = 3;
                                                    var dfStatus = 'Upcoming';
                                                    if (status == 'Final') {
                                                        contestStatus = 1;
                                                        dfStatus = 'Completed';
                                                    } else if (status == 'In-Progress') {
                                                        contestStatus = 2;
                                                        dfStatus = 'Live';
                                                    } else if (status == 'Postponed') {
                                                        contestStatus = 4;
                                                        dfStatus = 'Cancelled';
                                                    }

                                                    await DraftGroupModel.update({
                                                        'draftgroupId': dgId
                                                    }, {
                                                        'dgState': dfStatus
                                                    });

                                                    await contestModel.update({
                                                        'draftgroupId': dgId,
                                                        'contestStatus': {
                                                            $in: [1, 2, 3]
                                                        }
                                                    }, {
                                                        'contestStatus': contestStatus
                                                    }, {
                                                        multi: true
                                                    });
                                                }

                                                if (eventStatus == 'Final') { // fix for not to miss any player record if the status is final
                                                    await PlayerScoreModel.update({
                                                        'eventId': eventId
                                                    }, {
                                                        'eventStatus': eventStatus,
                                                        'liveGameInfo': liveGameInfo,
                                                        'liveGameInfo2': liveGameInfo2,
                                                        'possTeam': '',
                                                        'homeScore': homeScore,
                                                        'awayScore': visitingScore,
                                                        'homeAbbr': homeTeamAlias,
                                                        'awayAbbr': visitingTeamAlias,
                                                        'clock': eventClock,
                                                        'downloadUpdate': downloadUpdate,
                                                        'fileName': downloadFile
                                                    }, {
                                                        multi: true
                                                    });
                                                }

                                                if (eventStatus == 'In-Progress' || eventStatus == 'Final') { // consider inprogress and final only
                                                    if (nflBoxScore['home-team'] && nflBoxScore['visiting-team']) {
                                                        var homeTeamName = nflBoxScore['home-team'][0]['team-name'][0]['$']['name'];
                                                        homeTeamAlias = nflBoxScore['home-team'][0]['team-name'][0]['$']['alias'];
                                                        var homeTeamId = nflBoxScore['home-team'][0]['team-code'][0]['$']['id'];
                                                        var visitingTeamName = nflBoxScore['visiting-team'][0]['team-name'][0]['$']['name'];
                                                        visitingTeamAlias = nflBoxScore['visiting-team'][0]['team-name'][0]['$']['alias'];
                                                        var visitingTeamId = nflBoxScore['visiting-team'][0]['team-code'][0]['$']['id'];
                                                        visitingScore = nflBoxScore['visiting-team'][0]['linescore'][0]['$']['score'];
                                                        homeScore = nflBoxScore['home-team'][0]['linescore'][0]['$']['score'];
                                                        var quarter = nflBoxScore['gamestate'][0]['$']['quarter'];
                                                        eventClock = quarter + 'Q';
                                                        liveGameInfo = visitingTeamAlias + ' ' + visitingScore + ' @ ' + homeTeamAlias + ' ' + homeScore + ' ' + eventClock;

                                                        if (nflBoxScore['player-stats']) {
                                                            if(nflBoxScore['player-stats'][0]['home-player-stats']){
                                                                //Start Rushing
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['rushing']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['rushing'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }

                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };
                                                                        }
        
                                                                        playerRecords[playerId]['playerStats']['rushing']['rushing-yards'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['rushing']['rushing-yards']['pts'],
                                                                            'abr': nflScoringRules.nflScore['rushing']['rushing-yards']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing']['rushing-yards']['val'] * playerRecords[playerId]['playerStats']['rushing']['rushing-yards']['pts'];

                                                                        if(playerRecords[playerId]['playerStats']['rushing']['rushing-yards']['val'] > 100){
                                                                            playerRecords[playerId]['playerStats']['rushing']['rushing-100yds+'] = {
                                                                            'val': 1,
                                                                            'pts': nflScoringRules.nflScore['rushing']['rushing-100yds+']['pts'],
                                                                            'abr': nflScoringRules.nflScore['rushing']['rushing-100yds+']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing']['rushing-100yds+']['pts'];
                                                                        }

                                                                        playerRecords[playerId]['playerStats']['scoring']['rushing-touchdowns'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['scoring']['rushing-touchdowns']['pts'],
                                                                            'abr': nflScoringRules.nflScore['scoring']['rushing-touchdowns']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['rushing-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['rushing-touchdowns']['pts'];
                                                                    }
                                                                }
                                                                //End - Rushing    
                                                                //Start - Passing
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['passing']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['passing'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];

                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };
                                                                        }
                                                                        playerRecords[playerId]['playerStats']['passing']['passing-yards'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['passing']['passing-yards']['pts'],
                                                                            'abr': nflScoringRules.nflScore['passing']['passing-yards']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing']['passing-yards']['val'] * playerRecords[playerId]['playerStats']['passing']['passing-yards']['pts'];

                                                                        if(playerRecords[playerId]['playerStats']['passing']['passing-yards']['val'] > 300){
                                                                            playerRecords[playerId]['playerStats']['passing']['passing-300yds+'] = {
                                                                            'val': 1,
                                                                            'pts': nflScoringRules.nflScore['passing']['passing-300yds+']['pts'],
                                                                            'abr': nflScoringRules.nflScore['passing']['passing-300yds+']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing']['passing-300yds+']['pts'];
                                                                        }

                                                                        playerRecords[playerId]['playerStats']['scoring']['passing-touchdowns'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['scoring']['passing-touchdowns']['pts'],
                                                                            'abr': nflScoringRules.nflScore['scoring']['passing-touchdowns']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['passing-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['passing-touchdowns']['pts'];

                                                                        playerRecords[playerId]['playerStats']['passing']['interceptions'] = {
                                                                            'val': playerEvent[i]['$']['interceptions'],
                                                                            'pts': nflScoringRules.nflScore['passing']['interceptions']['pts'],
                                                                            'abr': nflScoringRules.nflScore['passing']['interceptions']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing']['interceptions']['val'] * playerRecords[playerId]['playerStats']['passing']['interceptions']['pts'];
                                                                    }
                                                                }
                                                                //End - Passing
                                                                //Start - Receiving
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['receiving']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['receiving'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };
                                                                        }
         
                                                                        playerRecords[playerId]['playerStats']['receiving']['receiving-yards'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['receiving']['receiving-yards']['pts'],
                                                                            'abr': nflScoringRules.nflScore['receiving']['receiving-yards']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving']['receiving-yards']['val'] * playerRecords[playerId]['playerStats']['receiving']['receiving-yards']['pts'];

                                                                        if(playerRecords[playerId]['playerStats']['receiving']['receiving-yards']['val'] > 100){
                                                                            playerRecords[playerId]['playerStats']['receiving']['receiving-100yds+'] = {
                                                                            'val': 1,
                                                                            'pts': nflScoringRules.nflScore['receiving']['receiving-100yds+']['pts'],
                                                                            'abr': nflScoringRules.nflScore['receiving']['receiving-100yds+']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving']['receiving-100yds+']['pts'];
                                                                        }

                                                                        playerRecords[playerId]['playerStats']['scoring']['receiving-touchdowns'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['scoring']['receiving-touchdowns']['pts'],
                                                                            'abr': nflScoringRules.nflScore['scoring']['receiving-touchdowns']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['receiving-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['receiving-touchdowns']['pts'];

                                                                        playerRecords[playerId]['playerStats']['receiving']['receptions'] = {
                                                                            'val': playerEvent[i]['$']['receptions'],
                                                                            'pts': nflScoringRules.nflScore['receiving']['receptions']['pts'],
                                                                            'abr': nflScoringRules.nflScore['receiving']['receptions']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving']['receptions']['val'] * playerRecords[playerId]['playerStats']['receiving']['receptions']['pts'];
                                                                    }
                                                                }
                                                                //End - Receiving
                                                                //Start - kick-returning
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['kick-returning']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['kick-returning'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };                                                                          
                                                                        }
        
                                                                        playerRecords[playerId]['playerStats']['scoring']['kickoff-touchdowns'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['scoring']['kickoff-touchdowns']['pts'],
                                                                            'abr': nflScoringRules.nflScore['scoring']['kickoff-touchdowns']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['kickoff-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['kickoff-touchdowns']['pts'];
                                                                    }
                                                                }
                                                                //End - kick-returning
                                                                //Start - punt-returning
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['punt-returning']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['punt-returning'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };                                                                          
                                                                        }
         
                                                                        playerRecords[playerId]['playerStats']['scoring']['punt-return-touchdowns'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['scoring']['punt-return-touchdowns']['pts'],
                                                                            'abr': nflScoringRules.nflScore['scoring']['punt-return-touchdowns']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['punt-return-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['punt-return-touchdowns']['pts'];
                                                                    }
                                                                }
                                                                //End - punt-returning
                                                                //Start - fumbles-lost
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['fumbles-lost']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['fumbles-lost'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };                                                                          
                                                                        }
         
                                                                        playerRecords[playerId]['playerStats']['fumbles']['fumbles-lost'] = {
                                                                            'val': playerEvent[i]['$']['number'],
                                                                            'pts': nflScoringRules.nflScore['fumbles']['fumbles-lost']['pts'],
                                                                            'abr': nflScoringRules.nflScore['fumbles']['fumbles-lost']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['fumbles']['fumbles-lost']['val'] * playerRecords[playerId]['playerStats']['fumbles']['fumbles-lost']['pts'];
                                                                    }
                                                                }
                                                                //End - fumbles-lost
                                                                //Start - own-fumbles-recovered
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['own-fumbles-recovered']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['own-fumbles-recovered'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };
                                                                        }
         
                                                                        playerRecords[playerId]['playerStats']['scoring']['own-fumble-touchdowns'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['scoring']['own-fumble-touchdowns']['pts'],
                                                                            'abr': nflScoringRules.nflScore['scoring']['own-fumble-touchdowns']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['own-fumble-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['own-fumble-touchdowns']['pts'];
                                                                    }
                                                                }
                                                                //End - own-fumbles-recovered
                                                                //Start - PAT
                                                                if(nflBoxScore['player-stats'][0]['home-player-stats'][0]['PAT']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['home-player-stats'][0]['PAT'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };                                                                           
                                                                        }
         
                                                                        if(playerEvent[i]['type']){
                                                                            if(playerEvent[i]['type'][i]['$']['points'] == 2 && playerEvent[i]['type'][i]['$']['good'] == true){
                                                                                playerRecords[playerId]['playerStats']['scoring']['two-point-conversion'] = {
                                                                                    'val': nflScoringRules.nflScore['scoring']['two-point-conversion']['pts'],
                                                                                    'pts': nflScoringRules.nflScore['scoring']['two-point-conversion']['pts'],
                                                                                    'abr': nflScoringRules.nflScore['scoring']['two-point-conversion']['abr']
                                                                                };
                                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['two-point-conversion']['val'];

                                                                                playerRecords[playerId]['playerStats']['scoring']['two-point-pass-conversion'] = {
                                                                                    'val': nflScoringRules.nflScore['scoring']['two-point-pass-conversion']['pts'],
                                                                                    'pts': nflScoringRules.nflScore['scoring']['two-point-pass-conversion']['pts'],
                                                                                    'abr': nflScoringRules.nflScore['scoring']['two-point-pass-conversion']['abr']
                                                                                };
                                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['two-point-pass-conversion']['val'];
                                                                            }
                                                                        }
                                                                        if(playerEvent[i]['$']['made']){
                                                                            playerRecords[playerId]['playerStats']['scoring']['extra-point-conversion'] = {
                                                                                'val': playerEvent[i]['$']['made'],
                                                                                'pts': nflScoringRules.nflScore['scoring']['extra-point-conversion']['pts'],
                                                                                'abr': nflScoringRules.nflScore['scoring']['extra-point-conversion']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['extra-point-conversion']['val'] * playerRecords[playerId]['playerStats']['scoring']['extra-point-conversion']['pts'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - PAT
                                                            }

                                                            if(nflBoxScore['player-stats'][0]['visiting-player-stats']){
                                                                //Start Rushing
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['rushing']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['rushing'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };                                                                           
                                                                        }
         
                                                                        playerRecords[playerId]['playerStats']['rushing']['rushing-yards'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['rushing']['rushing-yards']['pts'],
                                                                            'abr': nflScoringRules.nflScore['rushing']['rushing-yards']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing']['rushing-yards']['val'] * playerRecords[playerId]['playerStats']['rushing']['rushing-yards']['pts'];

                                                                        if(playerRecords[playerId]['playerStats']['rushing']['rushing-yards']['val'] > 100){
                                                                            playerRecords[playerId]['playerStats']['rushing']['rushing-100yds+'] = {
                                                                            'val': 1,
                                                                            'pts': nflScoringRules.nflScore['rushing']['rushing-100yds+']['pts'],
                                                                            'abr': nflScoringRules.nflScore['rushing']['rushing-100yds+']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['rushing']['rushing-100yds+']['pts'];
                                                                        }

                                                                        playerRecords[playerId]['playerStats']['scoring']['rushing-touchdowns'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['scoring']['rushing-touchdowns']['pts'],
                                                                            'abr': nflScoringRules.nflScore['scoring']['rushing-touchdowns']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['rushing-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['rushing-touchdowns']['pts'];
                                                                    }
                                                                }
                                                                //End - Rushing    
                                                                //Start - Passing
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['passing']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['passing'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };
                                                                        }
                           
                                                                        playerRecords[playerId]['playerStats']['passing']['passing-yards'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['passing']['passing-yards']['pts'],
                                                                            'abr': nflScoringRules.nflScore['passing']['passing-yards']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing']['passing-yards']['val'] * playerRecords[playerId]['playerStats']['passing']['passing-yards']['pts'];

                                                                        if(playerRecords[playerId]['playerStats']['passing']['passing-yards']['val'] > 300){
                                                                            playerRecords[playerId]['playerStats']['passing']['passing-300yds+'] = {
                                                                            'val': 1,
                                                                            'pts': nflScoringRules.nflScore['passing']['passing-300yds+']['pts'],
                                                                            'abr': nflScoringRules.nflScore['passing']['passing-300yds+']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing']['passing-300yds+']['pts'];
                                                                        }

                                                                        playerRecords[playerId]['playerStats']['scoring']['passing-touchdowns'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['scoring']['passing-touchdowns']['pts'],
                                                                            'abr': nflScoringRules.nflScore['scoring']['passing-touchdowns']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['passing-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['passing-touchdowns']['pts'];

                                                                        playerRecords[playerId]['playerStats']['passing']['interceptions'] = {
                                                                            'val': playerEvent[i]['$']['interceptions'],
                                                                            'pts': nflScoringRules.nflScore['passing']['interceptions']['pts'],
                                                                            'abr': nflScoringRules.nflScore['passing']['interceptions']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['passing']['interceptions']['val'] * playerRecords[playerId]['playerStats']['passing']['interceptions']['pts'];
                                                                    }
                                                                }
                                                                //End - Passing
                                                                //Start - Receiving
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['receiving']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['receiving'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };
                                                                        }
        
                                                                        playerRecords[playerId]['playerStats']['receiving']['receiving-yards'] = {
                                                                            'val': playerEvent[i]['$']['yards'],
                                                                            'pts': nflScoringRules.nflScore['receiving']['receiving-yards']['pts'],
                                                                            'abr': nflScoringRules.nflScore['receiving']['receiving-yards']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving']['receiving-yards']['val'] * playerRecords[playerId]['playerStats']['receiving']['receiving-yards']['pts'];

                                                                        if(playerRecords[playerId]['playerStats']['receiving']['receiving-yards']['val'] > 100){
                                                                            playerRecords[playerId]['playerStats']['receiving']['receiving-100yds+'] = {
                                                                            'val': 1,
                                                                            'pts': nflScoringRules.nflScore['receiving']['receiving-100yds+']['pts'],
                                                                            'abr': nflScoringRules.nflScore['receiving']['receiving-100yds+']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving']['receiving-100yds+']['pts'];
                                                                        }

                                                                        playerRecords[playerId]['playerStats']['scoring']['receiving-touchdowns'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['scoring']['receiving-touchdowns']['pts'],
                                                                            'abr': nflScoringRules.nflScore['scoring']['receiving-touchdowns']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['receiving-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['receiving-touchdowns']['pts'];

                                                                        playerRecords[playerId]['playerStats']['receiving']['receptions'] = {
                                                                            'val': playerEvent[i]['$']['receptions'],
                                                                            'pts': nflScoringRules.nflScore['receiving']['receptions']['pts'],
                                                                            'abr': nflScoringRules.nflScore['receiving']['receptions']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['receiving']['receptions']['val'] * playerRecords[playerId]['playerStats']['receiving']['receptions']['pts'];
                                                                    }
                                                                }
                                                                //End - Receiving
                                                                //Start - kick-returning
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['kick-returning']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['kick-returning'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };
                                                                        }
         
                                                                        playerRecords[playerId]['playerStats']['scoring']['kickoff-touchdowns'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['scoring']['kickoff-touchdowns']['pts'],
                                                                            'abr': nflScoringRules.nflScore['scoring']['kickoff-touchdowns']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['kickoff-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['kickoff-touchdowns']['pts'];
                                                                    }
                                                                }
                                                                //End - kick-returning
                                                                //Start - punt-returning
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['punt-returning']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['punt-returning'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };
                                                                        }
         
                                                                        playerRecords[playerId]['playerStats']['scoring']['punt-return-touchdowns'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['scoring']['punt-return-touchdowns']['pts'],
                                                                            'abr': nflScoringRules.nflScore['scoring']['punt-return-touchdowns']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['punt-return-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['punt-return-touchdowns']['pts'];
                                                                    }
                                                                }
                                                                //End - punt-returning
                                                                //Start - fumbles-lost
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['fumbles-lost']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['fumbles-lost'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };
                                                                        }
         
                                                                        playerRecords[playerId]['playerStats']['fumbles']['fumbles-lost'] = {
                                                                            'val': playerEvent[i]['$']['number'],
                                                                            'pts': nflScoringRules.nflScore['fumbles']['fumbles-lost']['pts'],
                                                                            'abr': nflScoringRules.nflScore['fumbles']['fumbles-lost']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['fumbles']['fumbles-lost']['val'] * playerRecords[playerId]['playerStats']['fumbles']['fumbles-lost']['pts'];
                                                                    }
                                                                }
                                                                //End - fumbles-lost
                                                                //Start - own-fumbles-recovered
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['own-fumbles-recovered']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['own-fumbles-recovered'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };
                                                                        }
         
                                                                        playerRecords[playerId]['playerStats']['scoring']['own-fumble-touchdowns'] = {
                                                                            'val': playerEvent[i]['$']['tds'],
                                                                            'pts': nflScoringRules.nflScore['scoring']['own-fumble-touchdowns']['pts'],
                                                                            'abr': nflScoringRules.nflScore['scoring']['own-fumble-touchdowns']['abr']
                                                                        };
                                                                        playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['own-fumble-touchdowns']['val'] * playerRecords[playerId]['playerStats']['scoring']['own-fumble-touchdowns']['pts'];
                                                                    }
                                                                }
                                                                //End - own-fumbles-recovered
                                                                //Start - PAT
                                                                if(nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['PAT']){
                                                                    var playerEvent = nflBoxScore['player-stats'][0]['visiting-player-stats'][0]['PAT'];
                                                                    for (i in playerEvent) {
                                                                        var playerId = playerEvent[i]['player-code'][0]['$']['global-id'];
                                                                        if (!player[playerId]) {
                                                                            player[playerId] = {};
                                                                            // logger.info('Missing (HB) playerId: ' + playerId + ' for the event ' + eventId);
                                                                        }
                                                                        if(!playerRecords[playerId]){
                                                                            playerRecords[playerId] = {};
                                                                            playerRecords[playerId]['playerId'] = playerId;
                                                                            playerRecords[playerId]['playerScore'] = 0;
                                                                            playerRecords[playerId]['multiPlayerScore'] = {};
                                                                            playerRecords[playerId]['playerName'] = playerEvent[i]['name'][0]['$']['first-name'] + ' ' + playerEvent[i]['name'][0]['$']['last-name'];
                                                                            playerRecords[playerId]['playerStats'] = {
                                                                                "passing": {},
                                                                                "rushing": {},
                                                                                "receiving": {},
                                                                                "scoring": {},
                                                                                "fumbles": {}
                                                                            };
                                                                        }
                                                                                 
                                                                        if(playerEvent[i]['type']){
                                                                            if(playerEvent[i]['type'][i]['$']['points'] == 2 && playerEvent[i]['type'][i]['$']['good'] == true){
                                                                                playerRecords[playerId]['playerStats']['scoring']['two-point-conversion'] = {
                                                                                    'val': nflScoringRules.nflScore['scoring']['two-point-conversion']['pts'],
                                                                                    'pts': nflScoringRules.nflScore['scoring']['two-point-conversion']['pts'],
                                                                                    'abr': nflScoringRules.nflScore['scoring']['two-point-conversion']['abr']
                                                                                };
                                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['two-point-conversion']['val'];

                                                                                playerRecords[playerId]['playerStats']['scoring']['two-point-pass-conversion'] = {
                                                                                    'val': nflScoringRules.nflScore['scoring']['two-point-pass-conversion']['pts'],
                                                                                    'pts': nflScoringRules.nflScore['scoring']['two-point-pass-conversion']['pts'],
                                                                                    'abr': nflScoringRules.nflScore['scoring']['two-point-pass-conversion']['abr']
                                                                                };
                                                                                playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['two-point-pass-conversion']['val'];
                                                                            }
                                                                        }

                                                                        if(playerEvent[i]['$']['made']){
                                                                            playerRecords[playerId]['playerStats']['scoring']['extra-point-conversion'] = {
                                                                                'val': playerEvent[i]['$']['made'],
                                                                                'pts': nflScoringRules.nflScore['scoring']['extra-point-conversion']['pts'],
                                                                                'abr': nflScoringRules.nflScore['scoring']['extra-point-conversion']['abr']
                                                                            };
                                                                            playerRecords[playerId]['playerScore'] += playerRecords[playerId]['playerStats']['scoring']['extra-point-conversion']['val'] * playerRecords[playerId]['playerStats']['scoring']['extra-point-conversion']['pts'];
                                                                        }
                                                                    }
                                                                }
                                                                //End - PAT
                                                            }
                                                        }

                                                        for (i in playerRecords) { // Updating the player records in the database
                                                            playerRecords[i]['sportId'] = sportId;
                                                            playerRecords[i]['eventCode'] = eventCode;
                                                            playerRecords[i]['eventId'] = eventId;
                                                            playerRecords[i]['eventStatus'] = eventStatus;
                                                            playerRecords[i]['eventDateTime'] = eventDateTime;
                                                            playerRecords[i]['downloadUpdate'] = downloadUpdate;
                                                            playerRecords[i]['fileName'] = downloadFile;
                                                            playerRecords[i]['liveGameInfo'] = liveGameInfo;
                                                            playerRecords[i]['liveGameInfo2'] = liveGameInfo2;
                                                            playerRecords[i]['possTeam'] = possTeam;
                                                            playerRecords[i]['teamId'] = homeTeamId;
                                                            playerRecords[i]['teamName'] = homeTeamName;
                                                            playerRecords[i]['teamAlias'] = homeTeamAlias;
                                                            playerRecords[i]['fieldPos'] = fieldPos;
                                                            playerRecords[i]['awayAbbr'] = visitingTeamAlias;
                                                            playerRecords[i]['homeAbbr'] = homeTeamAlias;
                                                            playerRecords[i]['awayScore'] = visitingScore;
                                                            playerRecords[i]['homeScore'] = homeScore;
                                                            playerRecords[i]['clock'] = eventClock;

                                                            var playerId = playerRecords[i]['playerId'];

                                                            if (!player[playerId]['multiplierVal']) {
                                                                playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'];
                                                            } else {
                                                                playerRecords[playerId]['multiPlayerScore'] = playerRecords[playerId]['playerScore'] * player[playerId]['multiplierVal'];
                                                            }
                                                            logger.info('multiPlayerScore updated : ' + playerRecords[i]['eventId'] + '-' + playerRecords[i]['playerId']);

                                                            var playerUpdate = await PlayerScoreModel.update({
                                                                'playerId': playerRecords[i]['playerId'],
                                                                'eventId': playerRecords[i]['eventId']
                                                            }, {
                                                                $set: playerRecords[i]
                                                            }, {
                                                                upsert: true
                                                            });

                                                            logger.info('Inserted to db (from download): ' + playerRecords[i]['eventId'] + '-' + playerRecords[i]['playerId']);
                                                        }
                                                    }
                                                }
                                            }
                                        } catch (e) {
                                            logger.info('FileName: ' + downloadFile);
                                            logger.info(e);
                                        }
                                    });
                                } else {
                                }
                            } else {
                                logger.info('FileName: ' + downloadFile);
                                logger.info('Err: ' + err);
                                logger.info('ResonseCode: ' + response.statusCode);
                            }
                        } catch (e) {
                            logger.info('FileName: ' + downloadFile);
                            logger.info(e);
                        }
                    });
            } else {
            }
        } catch (e) {
            logger.info(e);
        }
    },

        /**
     * Cron - To get all Player details from the db and build it to a game json and send only the updated player details to the pusher
     */
    nflPlayerScorePush: function () {
        try {
            var logger = new(winston.Logger)({
                transports: [
                    new(winston.transports.Console)(),
                    new(winston.transports.File)({
                        filename: './app/modules/crons/logs/nfl_push.log'
                    })
                ]
            });

            var lastProcessedDateTime = fs.readFileSync('./temp/nfl/lastProcessed.txt').toString().trim(); // '2018-01-01 00:00:00';
            var nextProcessingDateTime = moment().format("YYYY-MM-DD HH:mm:ss");
            return PlayerScoreModel.find({
                    $and: [{
                        'updatedAt': {
                            $gt: lastProcessedDateTime
                            },  
                        },
                        {
                            'sportId' : 1
                        }
                    ]
                })
                .sort({
                    'eventId': 1,
                    'updatedAt': 1
                })
                .exec(function (err, result) {
                    try {
                        if (err) {
                            logger.info(err);
                        } else {
                            var games = {};
                            var gIndx = -1;
                            var pIndx = 0;
                            var prevEventId = '';
                            for (var i in result) { // looping player records
                                if (prevEventId != result[i].eventId || pIndx == 5) {
                                    gIndx++;
                                    pIndx = 0;
                                }
                                pIndx++;
                                prevEventId = result[i].eventId;

                                if (!games[gIndx]) {
                                    games[gIndx] = {};
                                }
                                games[gIndx]['sportId'] = result[i].sportId;
                                games[gIndx]['gameId'] = result[i].eventId;
                                games[gIndx]['isFinal'] = (result[i].eventStatus == 'Final') ? true : false;
                                games[gIndx]['liveGameInfo'] = result[i].liveGameInfo;
                                games[gIndx]['liveGameInfo2'] = result[i].liveGameInfo2;
                                games[gIndx]['possTeam'] = result[i].possTeam;
                                games[gIndx]['homeScore'] = result[i].homeScore;
                                games[gIndx]['awayScore'] = result[i].awayScore;
                                games[gIndx]['homeAbbr'] = result[i].homeAbbr;
                                games[gIndx]['awayAbbr'] = result[i].awayAbbr;
                                games[gIndx]['clock'] = result[i].clock;
                                games[gIndx]['fieldPos'] = result[i].fieldPos ? (Math.round(result[i].fieldPos * 100) / 100) : 0;

                                if (!games[gIndx]['players']) {
                                    games[gIndx]['players'] = [];
                                }

                                var player = {};
                                player['playerId'] = result[i].playerId;
                                player['playerName'] = result[i].playerName;
                                player['posId'] = result[i].playerPositionId;
                                player['pos'] = result[i].playerPosition;
                                player['team'] = result[i].teamName;
                                player['teamAlias'] = result[i].teamAlias;
                                player['scoring'] = [];

                                if(result[i]['playerStats']) {
                                    for (var param in result[i]['playerStats']['passing']) {
                                        var playerParamScore = Math.round((result[i]['playerStats']['passing'][param]['val'] * result[i]['playerStats']['passing'][param]['pts']) * 100) / 100;
                                        player['scoring'].push({
                                            't': param,
                                            'abr': result[i]['playerStats']['passing'][param]['abr'],
                                            'n': result[i]['playerStats']['passing'][param]['val'] * 1,
                                            'v': playerParamScore,
                                            's': 'pts'
                                        });
                                    }
                                }
                                if(result[i]['playerStats']) {
                                    for (var param in result[i]['playerStats']['rushing']) {
                                        var playerParamScore = Math.round((result[i]['playerStats']['rushing'][param]['val'] * result[i]['playerStats']['rushing'][param]['pts']) * 100) / 100;
                                        player['scoring'].push({
                                            't': param,
                                            'abr': result[i]['playerStats']['rushing'][param]['abr'],
                                            'n': result[i]['playerStats']['rushing'][param]['val'] * 1,
                                            'v': playerParamScore,
                                            's': 'pts'
                                        });
                                    }
                                }
                                if(result[i]['playerStats']) {
                                    for (var param in result[i]['playerStats']['receiving']) {
                                        var playerParamScore = Math.round((result[i]['playerStats']['receiving'][param]['val'] * result[i]['playerStats']['receiving'][param]['pts']) * 100) / 100;
                                        player['scoring'].push({
                                            't': param,
                                            'abr': result[i]['playerStats']['receiving'][param]['abr'],
                                            'n': result[i]['playerStats']['receiving'][param]['val'] * 1,
                                            'v': playerParamScore,
                                            's': 'pts'
                                        });
                                    }
                                }
                                if(result[i]['playerStats']) {
                                    for (var param in result[i]['playerStats']['scoring']) {
                                        var playerParamScore = Math.round((result[i]['playerStats']['scoring'][param]['val'] * result[i]['playerStats']['scoring'][param]['pts']) * 100) / 100;
                                        player['scoring'].push({
                                            't': param,
                                            'abr': result[i]['playerStats']['scoring'][param]['abr'],
                                            'n': result[i]['playerStats']['scoring'][param]['val'] * 1,
                                            'v': playerParamScore,
                                            's': 'pts'
                                        });
                                    }
                                }
                                if(result[i]['playerStats']) {
                                    for (var param in result[i]['playerStats']['fumbles']) {
                                        var playerParamScore = Math.round((result[i]['playerStats']['fumbles'][param]['val'] * result[i]['playerStats']['fumbles'][param]['pts']) * 100) / 100;
                                        player['scoring'].push({
                                            't': param,
                                            'abr': result[i]['playerStats']['fumbles'][param]['abr'],
                                            'n': result[i]['playerStats']['fumbles'][param]['val'] * 1,
                                            'v': playerParamScore,
                                            's': 'pts'
                                        });
                                    }
                                }
                                player['playerScore'] = Math.round(result[i]['playerScore'] * 100) / 100;
                                player['multiPlayerScore'] = Math.round(result[i]['multiPlayerScore'] * 100) / 100;
                                games[gIndx]['players'].push(player);
                            }

                            for (var g in games) {
                                Pusher.sendPush('game-channel', 'game-' + games[g]['gameId'], games[g]);
                                logger.info('Push sent for ' + games[g]['gameId'] + ' (' + g + ')');
                                //logger.info('game-channel', 'game-' + games[g]['gameId']  + ' - '+ games[g]);
                                var start = new Date().getTime();
                                while ((new Date().getTime() - start) < 150) {
                                    //loop here
                                }
                            }
                            fs.writeFileSync('./temp/nfl/lastProcessed.txt', nextProcessingDateTime);
                        }
                    } catch (e) {
                        logger.info(e);
                    }
                });
        } catch (e) {
            logger.info(e);
        }
    },
}