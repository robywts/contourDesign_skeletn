/**
 * General Module
 * @exports Cron/MLB/completedLineupRemainingTime
 */
var cronVar = require('./cronSettings');
var DraftGroupModel = require('../../models/draftgroup');
var UserModel = require('../../models/user');
var moment = require('moment');
var LineupModel = require('../../models/lineup');

var self = module.exports = {
    /**
     * Cron - Back-up cron to update lineup's remaining time for completed contest, for the sport MLB
     */
    lineupRemainingTimeMLB: async function () {
        try {
            var crrntWeek = moment.utc(new Date()).tz("EST5EDT").format('YYYY-MM-DD').replace(/-+/g, '');
            var completedDrafts = await DraftGroupModel.find({ week: crrntWeek, dgState: { $in: ['Completed'] }, sportId: 2 });
            for (var i = 0; i < completedDrafts.length; i++) {
                var lineups = await LineupModel.find({ draftgroupId: completedDrafts[i].draftgroupId, isReserved: { $ne: 1 } });
                for (var j = 0; j < lineups.length; j++) {
                    var players = lineups[j].players;
                    for (var k = 0; k < players.length; k++) {
                        var remPlayerPerc = 0;
                        var update = await LineupModel.update({ "players.playerId": players[k].playerId, "players.eventId": players[k].eventId }, { "$set": { "players.$.remTimePerc": remPlayerPerc } }, {});
                    }
                    var avgRemTimePerc = 0;
                    var pointLineupNW = await LineupModel.update({ 'lineupId': lineups[j].lineupId }, { 'avgRemTimePerc': avgRemTimePerc }, {}, function (err, doc) { });
                }
            }
        } catch (e) {
            throw e;
        }
    },
}





