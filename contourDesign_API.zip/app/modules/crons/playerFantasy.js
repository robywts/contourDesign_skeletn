/**
 * PlayerFantasy Module
 * @exports Cron/NFL/PlayerFantasy
 */
var PlayerModel = require('../../models/player');
var cronVar = require('./cronSettings');

module.exports = {
    /**
     * Cron - To get fantasy projection details of player
     * Function to get salary,points related to a player from STATS api and calculating it's average  
     */
    getPlayerFantasyDetails: function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            request(process.env.PLAYER_FANTASY_API + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                function (err, response, body) {
                    try {console.log('NFL Player Fantasy - '+ response.statusCode);
                        // parse the body as JSON
                        if (!err && response.statusCode == 200) {
                            var parsedBody = JSON.parse(body);
                            var res = parsedBody.apiResults;

                            var eventTypeArr = res[0].league.season.eventType;
                            eventTypeArr.forEach(function (eventType) {
                                var playerFanatasyArr = eventType.fantasyProjections.offensiveProjections;
                                playerFanatasyArr.forEach(function (playerFantasy) {
                                    var playerId = playerFantasy.player.playerId;
                                    var FantasyArr = playerFantasy.fantasyProjections
                                    var avgFanProjSalary = 0;
                                    var avgFanProjPoints = 0;
                                    var fanProjScore = 0;
                                    //calculating average fantasy projection salary and points from 1st and 2nd site Id
                                    FantasyArr.forEach(function (fantasy) {
                                        if (fantasy.siteId == 1 || fantasy.siteId == 2) {
                                            avgFanProjSalary = (+avgFanProjSalary) + ((+fantasy.salary > 0) ? +fantasy.salary : 0);
                                            avgFanProjPoints = (+avgFanProjPoints) + ((+fantasy.points > 0) ? +fantasy.points : 0);
                                        }
                                    })
                                    avgFanProjSalary = avgFanProjSalary / 2;
                                    avgFanProjPoints = avgFanProjPoints / 2;
                                    //updating fantasy details to player schema
                                    PlayerModel.findOneAndUpdate({ 'playerId': playerId }, { fanProjSalary: avgFanProjSalary, fanProjPoints: avgFanProjPoints, fanProjScore: fanProjScore}, { upsert: false }, function (err, doc) {
                                        try {
                                            if (err) throw err;
                                            // console.log('Success Player Fantasy');
                                        } catch (e) {
                                            cronVar.logger.info(e);
                                        }
                                    });
                                })
                            })
                        }
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                });
        } catch (e) {
            throw e;
        }
    }
}

function statsCred() {
    // moment.js is the preferred date library
    var moment = require('moment');
    // access Node.js Crypto library for signature generation
    var crypto = require('crypto');
    // get the current time
    var timeFromEpoch = moment.utc().unix(); 
    // set the API key (note that this is not a valid key!)
    var apiKey = process.env.API_KEY;
    // set the shared secret key
    var secret = process.env.API_SECRET;
    // generate signature
    var sig = crypto.createHash('sha256').update(apiKey + secret + timeFromEpoch).digest('hex');

    return sig;
}



