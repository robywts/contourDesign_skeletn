/**
 * Team Module
 * @exports Cron/Team
 */
var TeamModel = require('../../models/team');
var cronVar = require('./cronSettings');

module.exports = {
    /**
     * Cron - To get all Team details in a season
     * 
     */
    getTeamDetails: function () {
        var request = cronVar.request;
        request(process.env.TEAM_API + '?api_key=' + cronVar.apiKey + '&sig=' + cronVar.sig,
            function (err, response, body) {
                // parse the body as JSON
                if (!err && response.statusCode == 200) {
                    var parsedBody = JSON.parse(body);
                    var res = parsedBody.apiResults;
                    var arrResult = res[0].league.season.conferences;
                    arrResult.forEach(function (conference) {
                        divArr = conference.divisions;
                        divArr.forEach(function (division) {
                            teamArr = division.teams;
                            teamArr.forEach(function (team) {
                                var team_data = {
                                    teamId: team.teamId,
                                    nickName: team.nickname,
                                    country: team.country.name
                                };
                                //saving or updating events data to DB
                                TeamModel.findOneAndUpdate({ 'teamId': team.teamId }, team_data, { upsert: true }, function (err, doc) {
                                    if (err) console.log(err);
                                    console.log('Success Team');
                                });
                            })
                        })
                    })
                }
                else {
                    console.log(err);
                }
            });

    }
}





