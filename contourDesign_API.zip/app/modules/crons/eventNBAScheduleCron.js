/**
 * Event Module
 * @exports Cron/NBA/Event
 */
var GameModel = require('../../models/event');
var cronVar = require('./cronSettings');
var async = require('async');
var moment = require('moment');
var PlayerModel = require('../../models/player');
var PlayerNewsModel = require('../../models/playernews');
var Stats = require('./helpers/stats');

var self = module.exports = {
    /**
     * Cron - To get all scheduled  events by week
     * To get all basic details related to games in a week
     */
    getEventScheduleDetails: function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            ks = [-2, -1, 0, 1, 2, 3, 4, 5, 6, 7];
            async.eachSeries(ks, async function (k, innerCb) {
                var datatoday = new Date();
                datatodays = datatoday.setDate(new Date(datatoday).getDate() + k);
                var todate = moment.utc(new Date(datatodays)).format('YYYY-MM-DD');
                request(process.env.SCHEDULE_EVENT_NBA_API + '?date=' + todate + '&accept=json&api_key=' + cronVar.apiKey + '&sig=' + sigg,
                    function (err, response, body) {
                        try {
                            // parse the body as JSON
                            if (!err && response.statusCode == 200) {

                                var parsedBody = JSON.parse(body);
                                var res = parsedBody.apiResults;
                                var eventArr = res[0].league.season.eventType[0].events;

                                async.eachSeries(eventArr, async function (event, innCb) {
                                    league = {};
                                    league['leagueId'] = res[0].league.leagueId;
                                    league['name'] = res[0].league.name;
                                    league['abbr'] = res[0].league.abbreviation;
                                    var homeTeam = {};
                                    var awayTeam = {};
                                    var gameInfo = {};
                                    teamArr = event.teams
                                    var eventDay = moment.utc(event.startDate[1].full + 'Z').tz("EST").format('YYYY-MM-DD');
                                    //obtaining home team and away team details
                                    teamArr.forEach(function (team) {
                                        var recrd = team.record ? team.record : team.series;
                                        if (team.teamLocationType.teamLocationTypeId == '1') {
                                            var rec = {};
                                            rec.wins = recrd.wins;
                                            rec.losses = recrd.losses;
                                            homeTeam.teamId = team.teamId;
                                            homeTeam.tName = team.nickname;
                                            homeTeam.city = team.location;
                                            homeTeam.tAbbr = team.abbreviation;
                                            homeTeam.score = team.score;
                                            homeTeam.record = rec;
                                            homeTeam.isWinner = team.isWinner ? 1 : 0;
                                        }
                                        else {
                                            var rec = {};
                                            rec.wins = recrd.wins;
                                            rec.losses = recrd.losses;
                                            awayTeam.teamId = team.teamId;
                                            awayTeam.tName = team.nickname;
                                            awayTeam.city = team.location;
                                            awayTeam.tAbbr = team.abbreviation;
                                            awayTeam.score = team.score;
                                            awayTeam.record = rec;
                                            awayTeam.isWinner = team.isWinner ? 1 : 0;
                                        }
                                    });
                                    //assigning relevant event datas to event_data variable   
                                    var event_data = {
                                        gameInfo: gameInfo,
                                        sportId: 4,
                                        league: league,
                                        season: res[0].league.season.season,
                                        week: eventDay.replace(/-+/g, ''),
                                        eventId: event.eventId,
                                        eventStatusId: event.eventStatus.eventStatusId,
                                        // isActive: (event.eventStatus.isActive) ? 1 : 0,
                                        isActive: 1,
                                        startTimeUTC: new Date(event.startDate[1].full + 'Z'),
                                        homeTeam: homeTeam,
                                        awayTeam: awayTeam,
                                        venueName: event.venue.name,
                                    };
                                    //saving or updating events data to DB
                                    await GameModel.findOneAndUpdate({ 'eventId': event.eventId }, event_data, { upsert: true }, function (err, doc) {
                                        try {
                                            if (err) throw err;
                                            // console.log('Success Game NBA');
                                        } catch (e) {
                                            cronVar.logger.info(e);
                                        }
                                    });
                                    innCb(null);
                                });
                            }
                            /*else {
                                throw err;
                            }*/
                        } catch (e) {
                            cronVar.logger.info(e);
                        } innerCb(null);
                    });
            });

        } catch (e) {
            throw e;
        }
    },

    /**
       * Cron - To get all NBA Player details in a season
       * To get all basic details related to players
       */
    getPlayerDetails: function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            request(process.env.NBA_PLAYER_API + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                function (err, response, body) {
                    try {
                        console.log('NBA players - ' + response.statusCode);
                        // parse the body as JSON
                        if (!err && response.statusCode == 200) {
                            var parsedBody = JSON.parse(body);
                            var res = parsedBody.apiResults;
                            var arrResult = res[0].league.players;
                            arrResult.forEach(function (item) {
                                if (item.team) {
                                    var positionsArr = item.positions;
                                    var positions = [];
                                    var playerImgName = '';
                                    positionsArr.forEach(function (position) {
                                        var posGName = (position.name).split(" ").splice(-1)[0];
                                        positions.push({ "posId": position.positionId, "posAbbr": position.abbreviation, "posGen": posGName });
                                    });
                                    league = {};
                                    league['leagueId'] = res[0].league.leagueId;
                                    league['abbr'] = res[0].league.abbreviation;
                                    team = {};
                                    team['teamId'] = item.team.teamId;
                                    team['tAbbr'] = item.team.abbreviation;
                                    //assigning relevant player datas to player_data variable  
                                    var player_data = {
                                        sportId: 4,
                                        league: league,
                                        fName: item.firstName,
                                        lName: item.lastName,
                                        playerId: item.playerId,
                                        uniform: item.uniform,
                                        team: team,
                                        positions: positions,
                                        isActive: (item.isActive) ? 1 : 0,
                                        isSuspend: (item.isSuspended) ? 1 : 0,
                                        isInjured: '',
                                        playerImgName: playerImgName,
                                    };
                                    //saving or updating player details to DB
                                    PlayerModel.findOneAndUpdate({ 'playerId': item.playerId }, player_data, { upsert: true }, function (err, doc) {
                                        try {
                                            if (err) throw err;
                                            //console.log('Success Player');
                                        } catch (e) {
                                            cronVar.logger.info(e);
                                        }
                                    });
                                }
                            })
                        }
                        else {
                            throw err;
                        }
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To get fantasy projection details of NBA player
     * Function to get salary,points related to a player from STATS api and calculating it's average  
     */
    getPlayerFantasyDetails: function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            var events = GameModel.find({ 'sportId': 4 }, 'eventId', function (err, events) {
                if (err)
                    console.log(err);
                else {
                    async.eachSeries(events, async function (event, outCb) {
                        request(process.env.NBA_PLAYER_FANTASY_API + event.eventId + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                            function (err, response, body) {
                                try {
                                    console.log('NBA player fantasy - ' + response.statusCode);
                                    // parse the body as JSON
                                    if (!err && response.statusCode == 200) {
                                        var parsedBody = JSON.parse(body);
                                        var res = parsedBody.apiResults;
                                        var eventTypeArr = res[0].league.season.eventType;
                                        eventTypeArr.forEach(function (eventType) {
                                            var playerFanatasyTeamArr = eventType.fantasyProjections.teams;
                                            playerFanatasyTeamArr.forEach(function (team) {
                                                playerFanatasyArr = team.players
                                                playerFanatasyArr.forEach(function (playerFantasy) {
                                                    if (playerFantasy.fantasyProjections.length > 1) {
                                                        var playerId = playerFantasy.playerId;
                                                        var FantasyArr = playerFantasy.fantasyProjections
                                                        var avgFanProjSalary = 0;
                                                        var avgFanProjPoints = 0;
                                                        var fanProjScore = 0;
                                                        //calculating average fantasy projection salary and points from 1st and 2nd site Id
                                                        FantasyArr.forEach(function (fantasy) {
                                                            if (fantasy.siteId == 1 || fantasy.siteId == 2) {
                                                                avgFanProjSalary = (+avgFanProjSalary) + ((+fantasy.salary > 0) ? +fantasy.salary : 0);
                                                                avgFanProjPoints = (+avgFanProjPoints) + ((+fantasy.points > 0) ? +fantasy.points : 0);
                                                            }
                                                        })
                                                        avgFanProjSalary = avgFanProjSalary / 2;
                                                        avgFanProjPoints = avgFanProjPoints / 2;
                                                        //updating fantasy details to player schema
                                                        PlayerModel.findOneAndUpdate({ 'playerId': playerId }, { fanProjSalary: avgFanProjSalary, fanProjPoints: avgFanProjPoints, fanProjScore: fanProjScore }, { upsert: false }, function (err, doc) {
                                                            try {
                                                                if (err) throw err;
                                                                //console.log('Success Player Fantasy');
                                                            } catch (e) {
                                                                cronVar.logger.info(e);
                                                            }
                                                        });
                                                    }
                                                })
                                            })
                                        })
                                    }
                                } catch (e) {
                                    cronVar.logger.info(e);
                                }//process.exit();
                                outCb(null);
                            });
                    });
                }
            });

        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To get NBA player's injury
     * Function to get injury details  
     */
    getInjuryDetails: function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            request(process.env.NBA_PLAYER_INJURY + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                function (err, response, body) {
                    try {
                        console.log('NBA Injury - ' + response.statusCode);
                        // parse the body as JSON
                        if (!err && response.statusCode == 200) {
                            var parsedBody = JSON.parse(body);
                            var res = parsedBody.apiResults;

                            var injuryArray = res[0].league.seasons[0].injuries;
                            injuryArray.forEach(function (injuryPlayer) {
                                var playerId = injuryPlayer.player.playerId;
                                var injury = injuryPlayer.status.description;
                                //updating injury to player schema
                                PlayerModel.findOneAndUpdate({ 'playerId': playerId }, { 'isInjured': injury }, { upsert: false }, function (err, doc) {
                                    try {
                                        if (err) throw err;
                                        // console.log('Success Player Injury');
                                    } catch (e) {
                                        cronVar.logger.info(e);
                                    }
                                });
                            });
                        }
                        else {
                            throw err;
                        }
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To get all depthchart details of NBA player - consist of two functions
     * Function to get standard player positions details(position Id and position abbreviation) from STATS api
     * Function to get player position data(abbreviation) in a season from STATS api
     */
    getDepthChartDetails: function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            async.series({
                //stats api call to get position details standard
                posMaster: function (callback) {
                    try {
                        request(process.env.NBA_PLAYER_POSITION + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                            function (err, response, body) {
                                try {
                                    console.log('NBA depth - ' + response.statusCode);
                                    // parse the body as JSON
                                    if (!err && response.statusCode == 200) {
                                        var parsedBody = JSON.parse(body);
                                        var res = parsedBody.apiResults;
                                        var positionArr = res[0].league.positions;
                                        callback(null, positionArr);
                                    }
                                    else {
                                        cronVar.logger.info(err);
                                    }
                                } catch (e) {
                                    cronVar.logger.info(e);
                                }
                            });
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                }
            },
                //stats api call to get player position details from depth chart api
                function (err, positionsMaster) {
                    try {
                        request(process.env.NBA_DEPTH_CHART_API + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                            function (err, response, body) {
                                try {
                                    // parse the body as JSON
                                    if (!err && response.statusCode == 200) {
                                        var parsedBody = JSON.parse(body);
                                        var res = parsedBody.apiResults;
                                        var teamsArr = res[0].league.season.teams;
                                        teamsArr.forEach(function (team) {
                                            positionsArr = team.positions;
                                            //console.log(positionsMaster.posMaster);
                                            positionsArr.forEach(function (position) {
                                                (positionsMaster.posMaster).forEach(function (positionMaster) {
                                                    if (positionMaster.abbreviation == position.abbreviation) {
                                                        var positions = [];
                                                        var posGName = (position.name).split(" ").splice(-1)[0];
                                                        positions.push({ "posId": positionMaster.positionId, "posAbbr": position.abbreviation, "posGen": posGName });
                                                        depthChartsArr = position.depthChart;
                                                        depthChartsArr.forEach(function (depthChartArr) {
                                                            var playerId = depthChartArr.player.playerId;
                                                            //updating depthchart details to player schema
                                                            PlayerModel.findOneAndUpdate({ 'playerId': playerId }, { positions: positions }, { upsert: false }, function (err, doc) {
                                                                try {
                                                                    if (err) throw err;
                                                                    //console.log('Success Depth');
                                                                } catch (e) {
                                                                    cronVar.logger.info(e);
                                                                }
                                                            });
                                                        })
                                                    }
                                                })
                                            })
                                        })
                                    }
                                    else {
                                        cronVar.logger.info(err);
                                    }
                                } catch (e) {
                                    cronVar.logger.info(e);
                                }
                            });
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To get all NBA Player News details in a season
     * To get all basic news related to players
     */
    getNewsDetails: async function () {
        try {
            var request = cronVar.request;
            var today = new Date();
            var todaymoment = moment(today);
            var todayString = todaymoment.format('YYYYMMDD');
            var datetimemonth = moment(today).subtract(1, 'month');
            var datetimemonthString = datetimemonth.format('YYYYMMDD');
            var nbaPlayers = await PlayerModel.find({ 'sportId': 4 }, 'playerId', function () { });
            // for (var k = 0; k < mlbPlayers.length; k++) {
            async.eachSeries(nbaPlayers, async function (nbaPlayer, outCb) {
                // var sigg = await statsCred();
                setTimeout(function () {
                    request(process.env.NBA_SINGLE_PLAYER_NEWS + nbaPlayer.playerId + '?startDate=' + datetimemonthString + '&endDate=' + todayString + '&api_key=' + cronVar.apiKey + '&sig=' + Stats.statsCred(),
                        function (err, response, body) {
                            try {
                                //console.log(sigg);
                                //console.log(nbaPlayer.playerId);
                                console.log('NBA Player News - ' + response.statusCode);//process.exit();
                                // parse the body as JSON
                                if (!err && response.statusCode == 200) {
                                    var parsedBody = JSON.parse(body);
                                    var res = parsedBody.apiResults;
                                    var news = {};
                                    var League = {};
                                    news.sportId = 4;
                                    League.leagueId = res[0].league.leagueId;
                                    League.abbr = res[0].league.abbreviation;
                                    news.league = League;
                                    news.season = res[0].league.seasons[0].season;

                                    newsArray = res[0].league.seasons[0].playerNews;

                                    newsArray.forEach(function (newsPlayer) {
                                        news.playerId = newsPlayer.player.playerId;
                                        news.fName = newsPlayer.player.firstName;
                                        news.lName = newsPlayer.player.lastName;
                                        news.playerNewsId = newsPlayer.playerNewsId;
                                        news.newsText = newsPlayer.newsText;
                                        news.adviceText = newsPlayer.adviceText;
                                        var Team = {};
                                        Team.teamId = newsPlayer.team.teamId;
                                        Team.tAbbr = newsPlayer.team.abbreviation;
                                        news.team = Team;
                                        var Positions = [];
                                        positionArray = newsPlayer.positions;
                                        positionArray.forEach(function (position) {
                                            var postionObj = {};
                                            postionObj.posId = position.positionId;
                                            postionObj.posAbbr = position.abbreviation;
                                            postionObj.posName = position.name;
                                            postionObj.sequence = position.sequence;
                                            Positions.push(postionObj);
                                        })
                                        news.positions = Positions;
                                        news.originalDateLocal = newsPlayer.originalDate[0].full;
                                        news.timezone = newsPlayer.originalDate[0].dateType;
                                        news.originalDateUtc = new Date(newsPlayer.originalDate[1].full + 'Z');//console.log(news);process.exit();
                                        PlayerNewsModel.findOneAndUpdate({ 'playerId': news.playerId, 'playerNewsId': news.playerNewsId }, news, { upsert: true }, function (err, doc) {
                                            try {
                                                if (err) throw err;
                                                console.log('Success Player News');
                                            } catch (e) {
                                                cronVar.logger.info(e);
                                            }
                                        });
                                    })
                                }
                                else {
                                    throw err;
                                }
                            } catch (e) {
                                cronVar.logger.info(e);
                            }

                            outCb();
                        })
                }, 1000);
            })
            // }
        } catch (e) {
            throw e;
        }
    },
}

function statsCred() {
    // moment.js is the preferred date library
    var moment = require('moment');
    // access Node.js Crypto library for signature generation
    var crypto = require('crypto');
    // get the current time
    var timeFromEpoch = moment.utc().unix();
    // set the API key (note that this is not a valid key!)
    var apiKey = process.env.API_KEY;
    // set the shared secret key
    var secret = process.env.API_SECRET;
    // generate signature
    var sig = crypto.createHash('sha256').update(apiKey + secret + timeFromEpoch).digest('hex');

    return sig;
}



