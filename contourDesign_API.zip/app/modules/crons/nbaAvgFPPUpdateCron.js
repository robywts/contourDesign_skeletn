/**
 * General Module
 * @exports Cron/NBA/avgFppValue
 */
var PlayerModel = require('../../models/player');
var nbaScore = require('../../config/scoringRulesNBA');
var PlayerGames = require('../../models/playerGamesJson');
var async = require('async');

var self = module.exports = {
    /**
      * Cron - To update avgFpp value in PlayerModelSchema
      *
      */
    updateDraftAvgFPPValue: async function () {
        try {
          var allPlayers = await PlayerModel.find({sportId:4})
            for(var i = 0;i<allPlayers.length;i++){
              var avgFPP = 0
              var playerAllGames = await PlayerGames.findOne({playerId:allPlayers[i].playerId})
              if(playerAllGames !== null){
              var playerAllGamesAnnual = playerAllGames['gamesJson']['annualStats']
              if(playerAllGamesAnnual !== undefined){
                  avgFPP += nbaScore['nbaScore']['points']['pts'] * playerAllGamesAnnual['points']
                  avgFPP += nbaScore['nbaScore']['assists']['pts'] * playerAllGamesAnnual['assists']
                  avgFPP += nbaScore['nbaScore']['rebounds']['pts'] * (playerAllGamesAnnual['rebounds'] ? playerAllGamesAnnual['rebounds']['total'] : 0)
                  avgFPP += nbaScore['nbaScore']['steals']['pts'] * playerAllGamesAnnual['steals']
                  avgFPP += nbaScore['nbaScore']['blocks']['pts'] * playerAllGamesAnnual['blockedShots']
                  avgFPP += nbaScore['nbaScore']['turnovers']['pts'] * playerAllGamesAnnual['turnovers']
                  avgFPP += nbaScore['nbaScore']['3pt-FG']['pts'] * (playerAllGamesAnnual['threePointFieldGoals'] ? playerAllGamesAnnual['threePointFieldGoals']['made'] : 0)
                  avgFPP += nbaScore['nbaScore']['double-double']['pts'] * playerAllGamesAnnual['doubleDoubles']
                  avgFPP += nbaScore['nbaScore']['triple-double']['pts'] * playerAllGamesAnnual['tripleDoubles']
                  avgFPP = avgFPP/playerAllGamesAnnual['gamesPlayed']
                  console.log(avgFPP)
                }
                var infoObj = {}
                var infoArray = []
                infoObj.title = "Average FP"
                infoObj.val = String(avgFPP)
                infoArray.push(infoObj)
                updateInfo = await PlayerModel.update({playerId:allPlayers[i].playerId},{"info":infoArray},{new:false},function(){})              }
            }

        } catch (e) {
            throw e;
        }
    },

}
