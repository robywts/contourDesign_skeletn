/**
 * Player Module
 * @exports Cron/NFL/Player
 */
var PlayerModel = require('../../models/player');
var PlayerNewsModel = require('../../models/playernews');
var cronVar = require('./cronSettings');
var Stats = require('./helpers/stats');
var moment = require('moment');
var async = require('async');

module.exports = {
    /**
     * Cron - To get all Player details in a season
     * To get all basic details related to players
     */
    getPlayerDetails: function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            request(process.env.PLAYER_API + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                function (err, response, body) {
                    try {
                        console.log('NFL Player - ' + response.statusCode);
                        // parse the body as JSON
                        if (!err && response.statusCode == 200) {
                            var parsedBody = JSON.parse(body);
                            var res = parsedBody.apiResults;
                            var arrResult = res[0].league.players;
                            arrResult.forEach(function (item) {
                                if (item.team) {
                                    var positionsArr = item.positions;
                                    var positions = [];
                                    var playerImgName = '';
                                    positionsArr.forEach(function (position) {
                                        positions.push({ "posId": position.positionId, "posAbbr": position.abbreviation });
                                    });
                                    league = {};
                                    league['leagueId'] = res[0].league.leagueId;
                                    league['abbr'] = res[0].league.abbreviation;
                                    team = {};
                                    team['teamId'] = item.team.teamId;
                                    team['tAbbr'] = item.team.abbreviation;
                                    //assigning relevant player datas to player_data variable  
                                    var player_data = {
                                        sportId: 1,
                                        league: league,
                                        fName: item.firstName,
                                        lName: item.lastName,
                                        playerId: item.playerId,
                                        uniform: item.uniform,
                                        team: team,
                                        positions: positions,
                                        isActive: (item.isActive) ? 1 : 0,
                                        isSuspend: (item.isSuspended) ? 1 : 0,
                                        isInjured: '',
                                        playerImgName: playerImgName,
                                    };
                                    //saving or updating player details to DB
                                    PlayerModel.findOneAndUpdate({ 'playerId': item.playerId }, player_data, { upsert: true }, function (err, doc) {
                                        try {
                                            if (err) throw err;
                                            console.log('Success Player NFL');
                                        } catch (e) {
                                            cronVar.logger.info(e);
                                        }
                                    });
                                }
                            })
                        }
                        else {
                            throw err;
                        }
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - To get all Player News details in a season
     * To get all basic news related to players
     */
    getNewsDetails: async function () {
        try {
            var request = cronVar.request;
            var today = new Date();
            var todaymoment = moment(today);
            var todayString = todaymoment.format('YYYYMMDD');
            var datetimemonth = moment(today).subtract(1, 'month');
            var datetimemonthString = datetimemonth.format('YYYYMMDD');
            // var nflPlayers = await PlayerModel.find({ 'sportId': 1 }, 'playerId', function () { });
            // for (var k = 0; k < mlbPlayers.length; k++) {
            // async.eachSeries(nflPlayers, async function (nflPlayer, outCb) {
            // var sigg = await statsCred();
            // setTimeout(function () {
            //request(process.env.NFL_SINGLE_PLAYER_NEWS + nflPlayers.playerId + '?startDate=' + datetimemonthString + '&endDate=' + todayString + '&api_key=' + cronVar.apiKey + '&sig=' + Stats.statsCred(),
            request(process.env.PLAYER_NEWS + '?api_key=' + cronVar.apiKey + '&sig=' + Stats.statsCred(),
                function (err, response, body) {
                    try {
                        //console.log(sigg);
                        // console.log(nflPlayers.playerId);
                        console.log('NFL Player News - ' + response.statusCode);//process.exit();
                        // parse the body as JSON
                        if (!err && response.statusCode == 200) {
                            var parsedBody = JSON.parse(body);
                            var res = parsedBody.apiResults;
                            var news = {};
                            var League = {};
                            news.sportId = 1;
                            League.leagueId = res[0].league.leagueId;
                            League.abbr = res[0].league.abbreviation;
                            news.league = League;
                            news.season = res[0].league.seasons[0].season;

                            newsArray = res[0].league.seasons[0].playerNews;

                            newsArray.forEach(function (newsPlayer) {
                                news.playerId = newsPlayer.player.playerId;
                                news.fName = newsPlayer.player.firstName;
                                news.lName = newsPlayer.player.lastName;
                                news.playerNewsId = newsPlayer.playerNewsId;
                                news.newsText = newsPlayer.newsText;
                                news.adviceText = newsPlayer.adviceText;
                                var Team = {};
                                Team.teamId = newsPlayer.team.teamId;
                                Team.tAbbr = newsPlayer.team.abbreviation;
                                news.team = Team;
                                var Positions = [];
                                positionArray = newsPlayer.positions;
                                positionArray.forEach(function (position) {
                                    var postionObj = {};
                                    postionObj.posId = position.positionId;
                                    postionObj.posAbbr = position.abbreviation;
                                    postionObj.posName = position.name;
                                    postionObj.sequence = position.sequence;
                                    Positions.push(postionObj);
                                })
                                news.positions = Positions;
                                news.originalDateLocal = newsPlayer.originalDate[0].full;
                                news.timezone = newsPlayer.originalDate[0].dateType;
                                news.originalDateUtc = new Date(newsPlayer.originalDate[1].full + 'Z');//console.log(news);process.exit();
                                PlayerNewsModel.findOneAndUpdate({ 'playerId': news.playerId, 'playerNewsId': news.playerNewsId }, news, { upsert: true }, function (err, doc) {
                                    try {
                                        if (err) throw err;
                                        console.log('Success Player News');
                                    } catch (e) {
                                        cronVar.logger.info(e);
                                    }
                                });
                            })
                        }
                        else {
                            throw err;
                        }
                    } catch (e) {
                        cronVar.logger.info(e);
                    }

                    //  outCb();
                })
            //  }, 1000);
            //})
            // }
        } catch (e) {
            throw e;
        }
    },
    /**
    * Cron - To get player's injury
    * Function to get injury details  
    */
    getInjuryDetails: function () {
        try {
            var sigg = statsCred();
            var request = cronVar.request;
            request(process.env.PLAYER_INJURY + '?api_key=' + cronVar.apiKey + '&sig=' + sigg,
                function (err, response, body) {
                    try {
                        console.log('NFL Player Injury - ' + response.statusCode);
                        // parse the body as JSON
                        if (!err && response.statusCode == 200) {
                            var parsedBody = JSON.parse(body);
                            var res = parsedBody.apiResults;

                            var injuryArray = res[0].league.seasons[0].injuries;
                            injuryArray.forEach(function (injuryPlayer) {
                                var playerId = injuryPlayer.player.playerId;
                                var injury = injuryPlayer.status.description;
                                //updating injury to player schema
                                PlayerModel.findOneAndUpdate({ 'playerId': playerId }, { 'isInjured': injury }, { upsert: false }, function (err, doc) {
                                    try {
                                        if (err) throw err;
                                        //console.log('Success Player Injury');
                                    } catch (e) {
                                        cronVar.logger.info(e);
                                    }
                                });
                            });
                        }
                        else {
                            throw err;
                        }
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                });
        } catch (e) {
            throw e;
        }
    }
}

function statsCred() {
    // moment.js is the preferred date library
    var moment = require('moment');
    // access Node.js Crypto library for signature generation
    var crypto = require('crypto');
    // get the current time
    var timeFromEpoch = moment.utc().unix();
    // set the API key (note that this is not a valid key!)
    var apiKey = process.env.API_KEY;
    // set the shared secret key
    var secret = process.env.API_SECRET;
    // generate signature
    var sig = crypto.createHash('sha256').update(apiKey + secret + timeFromEpoch).digest('hex');

    return sig;
}



