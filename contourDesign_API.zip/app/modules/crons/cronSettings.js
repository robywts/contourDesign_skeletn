/**
 * STATS API Configuration
 * @exports Cron/Stats
 */

// moment.js is the preferred date library
var moment = require('moment');
// access Node.js Crypto library for signature generation
var crypto = require('crypto');
// use request or request-promise to call into STATS API
var request = require('request');
// get the current time
var timeFromEpoch = moment.utc().unix();
// set the API key (note that this is not a valid key!)
var apiKey = process.env.API_KEY;
// set the shared secret key
var secret = process.env.API_SECRET;
// generate signature
var sig = crypto.createHash('sha256').update(apiKey + secret + timeFromEpoch).digest('hex');
//error Logger
var winston = require('winston');
var logger = new (winston.Logger)({
  transports: [
    new (winston.transports.Console)(),
    new (winston.transports.File)({ filename: './app/modules/crons/logs/cronError.log' })
  ]
});

module.exports = {
  moment,
  request,
  apiKey,
  sig,
  logger
}