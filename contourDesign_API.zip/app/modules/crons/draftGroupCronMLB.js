/**
 * DraftGroup Module - MLB
 * @exports Cron/MLB/DraftGroup
 */
var DraftGroupModel = require('../../models/draftgroup');
var GameModel = require('../../models/event');
var PlayerModel = require('../../models/player');
var moment = require('moment');
var generalHelper = require('./helpers/generalHelper');
var cronVar = require('./cronSettings');
var async = require('async');
var DraftLogicModel = require('../../models/draftgroupCreateLogic');
var AutoContestLogics = require('../../models/autocontestlogics');
var ContestModel = require('../../models/contest');

var self = module.exports = {
    /**
     * Cron - To create all predefined draftGroup set
     * To get all basic details related to players
     */

    getDraftGroupDetails: async function () {
        try {
            // var times = ['0', '1', '2', '3', '4', '5', '6',];
            // async.eachSeries(times, async function (time, outerCb) {


            var crrntDay = moment().tz("EST").format('YYYY-MM-DD HH:mm:ss');
            var toDay = moment().tz("EST").format('YYYY-MM-DD');

            var insertdDraft = 0;
            var events = await GameModel.find({ "sportId": 2, startTimeUTC: { '$gte': new Date() } });
            for (var m = 0; m < 7; m++) {
                // console.log(insertdDraft);
                // ms = [1, 2, 3, 4, 5, 6, 7];
                // async.eachSeries(ms, async function (m, outrCb) {
                var nxtDay = await moment(crrntDay).add(m, 'days').format('YYYY-MM-DD');

                if (insertdDraft == 0) {
                    // async.eachSeries(events, async function (event, outCb) {
                    for (var o = 0; o < events.length; o++) {
                        var eventDay = moment.utc(events[o].startTimeUTC).tz("EST").format('YYYY-MM-DD');

                        var s = moment.utc(events[o].startTimeUTC).tz("EST").format('YYYY-MM-DD HH:mm:ss');
                        var localHour = new Date(s).getHours();
                        var eventTime = new Date(s).getTime();

                        if (eventDay == nxtDay) {//console.log(events[o].eventId);console.log(events[o].startTimeUTC);console.log(localHour);process.exit();
                            // console.log(eventDay + "=" + nxtDay); console.log(events[o].eventId);
                            var dgName = '';
                            daraftgroups = [];
                            draftCreateLogics = await DraftLogicModel.find({ "sportId": 2 });
                            for (var f = 0; f < draftCreateLogics.length; f++) {
                                var startTime = new Date(eventDay + ' ' + draftCreateLogics[f].startTimeRange).getTime();
                                var endTime = new Date(eventDay + ' ' + draftCreateLogics[f].endTimeRange).getTime();
                                // async.eachSeries(draftCreateLogics, async function (draftCreateLogic, logicCb) {
                                if ((eventTime >= startTime) && (eventTime <= endTime)) {
                                    daraftgroups.push(draftCreateLogics[f].startTimeSuffix);
                                }
                                // logicCb(null);
                                // });
                            } console.log(daraftgroups);
                            game = {};
                            game['eventId'] = events[o].eventId;
                            game['startTimeUTC'] = events[o].startTimeUTC;
                            game['gameStatus'] = '';
                            game['venueName'] = events[o].venueName;
                            weather = {};
                            weather.conditionDesc = weather;
                            game['weather'] = events[o].weather;
                            game['startingLineupReady'] = 'False';
                            //game player details
                            players = [];
                            //home team details
                            homeTeamId = events[o].homeTeam.teamId;
                            awayTeamId = events[o].awayTeam.teamId;
                            var playersDatas = [];
                            var playersDatasHome = [];
                            var playersDatasAway = [];
                            playersDatasHome = await self.getHomePlayers(homeTeamId);
                            playersDatasAway = await self.getAwayPlayers(awayTeamId);
                            playersDatas = playersDatasHome.concat(playersDatasAway);

                            console.log('players count before' + playersDatas.length);
                            //console.log(1);
                            //console.log('here');

                            if (playersDatas) {
                                var slaryAvl = 0;
                                var players = [];
                                //playersDatas.forEach(function (playersData) {
                                for (var k = 0; k < playersDatas.length; k++) {
                                    if (playersDatas[k].positions) {
                                        if (playersDatas[k].fanProjSalary && slaryAvl == 0)
                                            slaryAvl = (playersDatas[k].fanProjSalary > 0) ? 1 : 0
                                        var teamPlayers = {};
                                        teamPlayers.fName = playersDatas[k].fName;
                                        teamPlayers.lName = playersDatas[k].lName;
                                        teamPlayers.playerId = playersDatas[k].playerId;
                                        teamPlayers.uniform = playersDatas[k].uniform;
                                        teamPlayers.posId = playersDatas[k].positions[0].posId;
                                        teamPlayers.posAbbr = playersDatas[k].positions[0].posAbbr;
                                        teamPlayers.posGen = playersDatas[k].positions[0].posGen;
                                        teamPlayers.isInjured = playersDatas[k].isInjured;
                                        competitionPlayer = {};
                                        competitionPlayer.compId = events[o].eventId;
                                        var recHT = {};
                                        var recAT = {};
                                        recHT.wins = events[o].homeTeam.record.wins;
                                        recHT.losses = events[o].homeTeam.record.losses;
                                        recAT.wins = events[o].awayTeam.record.wins;
                                        recAT.losses = events[o].awayTeam.record.losses;
                                        competitionPlayer.nameDisplay = [{
                                            htId: events[o].homeTeam.teamId, htName: events[o].homeTeam.tName, htAbbr: events[o].homeTeam.tAbbr, htCity: events[o].homeTeam.city, htScore: '', value: events[o].awayTeam.tAbbr + '@' + events[o].homeTeam.tAbbr,
                                            htRecord: recHT, atId: events[o].awayTeam.teamId, atName: events[o].awayTeam.tName, atAbbr: events[o].awayTeam.tAbbr, atCity: events[o].awayTeam.city, atScore: '', atRecord: recAT
                                        }];

                                        teamPlayers.competition = competitionPlayer;
                                        teamPlayers.teamId = playersDatas[k].team.teamId;
                                        teamPlayers.teamAbbr = playersDatas[k].team.tAbbr;
                                        teamPlayers.fanProjSalary = playersDatas[k].fanProjSalary;
                                        teamPlayers.fanProjScore = playersDatas[k].fanProjPoints;
                                        //added for starting lineup ---start
                                        if (playersDatas[k].probables && (playersDatas[k].probables).indexOf(events[o].eventId) > -1) {
                                            teamPlayers.starting = '';
                                            teamPlayers.probable = true;
                                        }
                                        teamPlayers.info = playersDatas[k].info ? playersDatas[k].info : '';
                                        //added for starting lineup ---end
                                        players.push(teamPlayers);
                                        //});
                                    }
                                }
                            }
                            console.log('players count after draft' + players.length);
                            game['players'] = players;

                            //away team details
                            //awayTeamId = events[o].awayTeam.teamId
                            League = {};
                            League.leagueId = events[o].league.leagueId;
                            League.name = events[o].league.name;
                            League.abbr = events[o].league.abbr;
                            leagues = [];
                            leagues.push(League);
                            var draftData = {
                                week: eventDay.replace(/-+/g, ''),
                                season: events[o].season,
                                sportId: events[o].sportId,
                                autoContest: 0,
                                // sName: events[o].league.abbr,
                                league: leagues,
                                contestList: [],
                                sortOrder: 0,
                                startTimeUTC: '',
                                dgState: 'Upcoming',
                                gameList: [game]
                            };
                            //saving or updating events data to DB
                            if (slaryAvl == 1) {
                                //async.eachSeries(daraftgroups, async function (daraftgroup, innerCb) {
                                for (var j = 0; j < daraftgroups.length; j++) {
                                    draftData.dgName = daraftgroups[j];
                                    //console.log(draftData.dgName);process.exit();
                                    checkExistDraft = await self.checkDraft(draftData);
                                    if (!checkExistDraft) {
                                        //insertdDraft = 1;
                                        console.log('insert');
                                        draftData.draftgroupId = await generalHelper.updateCounter('draftgroupId');
                                        draftInsert = await self.insertDraft(draftData);
                                    } else {
                                        // console.log('push');
                                        checkEventExistIndraftGroup = await self.checkEventInDraft(draftData);
                                        //console.log(checkEventExistIndraftGroup);
                                        //console.log(checkEventExistIndraftGroup.gameList.length);
                                        if (checkEventExistIndraftGroup.gameList.length < 1) {
                                            //console.log('pushGame');
                                            draftUpdate = await self.updateDraft(draftData);
                                        }
                                    }
                                    //  innerCb(null);
                                    // });
                                    //checking if only one game total in All Games draftgroup
                                    (draftData.dgName == 'MLB - All Games' && !checkExistDraft) ? (insertdDraft = 0) : '';
                                    (draftData.dgName == 'MLB - All Games' && checkExistDraft && toDay != nxtDay) ? (insertdDraft = 1) : '';
                                }
                            }
                            //}

                        }
                        //     outCb(null);
                        // });
                    }

                    //  }

                }
            }
            //  outrCb(null);
            //});
            var drafts = await DraftGroupModel.find({ "sportId": 2, "dgState": 'Upcoming' }, function () { });
            //console.log(drafts); process.exit();
            for (var k = 0; k < drafts.length; k++) {
                if (drafts[k].gameList.length < 2) {
                    await DraftGroupModel.remove({ draftgroupId: drafts[k].draftgroupId }, function (err) { });
                }
            }

            //auto contest creation
            await self.autoCreateContest();

        } catch (e) {
            throw e;
        }
    },

    getHomePlayers: async function (homeTeamId) {
        try {
            return await PlayerModel.find({ 'team.teamId': homeTeamId });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    getAwayPlayers: async function (awayTeamId) {
        try {
            return await PlayerModel.find({ 'team.teamId': awayTeamId });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    checkDraft: function (draftData) {
        try {
            return DraftGroupModel.findOne({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    insertDraft: function (draftData) {
        try {
            return DraftGroupModel.findOneAndUpdate({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season }, draftData, { upsert: true });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    checkEventInDraft: function (draftData) {
        try {
            return DraftGroupModel.findOne({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season }, { gameList: { $elemMatch: { eventId: draftData.gameList[0].eventId } } });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },
    updateDraft: function (draftData) {
        try {
            return DraftGroupModel.findOneAndUpdate({ 'dgName': draftData.dgName, 'week': draftData.week, 'season': draftData.season }, {
                $addToSet: {
                    gameList: draftData.gameList[0]
                }
            });
        } catch (e) {
            cronVar.logger.info(e);
        }
    },

    /**
     * Cron - To auto create contest after draftgroup ceation
     */
    autoCreateContest: async function () {
        try {
            var newDrafts = await DraftGroupModel.find({ "sportId": 2, "startTimeUTC": null, "autoContest": 0 }, function () { }); //console.log(newDrafts);process.exit();
            var autoContestLogics = await AutoContestLogics.find({ "sportId": 2 }, function () { });
            for (var i = 0; i < newDrafts.length; i++) {
                var cnt = 0;
                var st = await DraftGroupModel.aggregate(
                    { "$match": { draftgroupId: newDrafts[i].draftgroupId } },
                    { $unwind: '$gameList' },
                    { $group: { _id: newDrafts[i].draftgroupId, minTime: { $min: '$gameList.startTimeUTC' } } });
                for (var j = 0; j < autoContestLogics.length; j++) {
                    for (var k = 0; k < (autoContestLogics[j].entryFees).length; k++) {
                        //contest name start
                        var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                        var zone = process.env.dest_zone;
                        var s = moment.utc(st[0].minTime.toISOString()).tz(zone).format('YYYY-MM-DD HH:mm:ss');
                        var localDate = new Date(s).toLocaleDateString();
                        var localHour = new Date(s).getHours();
                        var utcHour = (st[0].minTime).getHours();
                        var localMinute = (new Date(s).getMinutes()) ? (':' + new Date(s).getMinutes()) : '';
                        var hours = (utcHour + 24 - 2) % 24;
                        var AM_or_PM = ' AM ';
                        localHour = (localHour == 12) ? localHour : localHour % 12;
                        if (hours == 0) { //At 00 hours we need to show 12 am
                            hours = 12;
                        }
                        else if (hours > 12) {
                            hours = hours % 12;
                            AM_or_PM = " PM ";
                        }
                        var day = days[new Date(localDate).getDay()];
                        contestName = (autoContestLogics[j].contestTypeId == 2) ? (newDrafts[i].league[0].abbr + ' ' + day + ' ' + 'H2H Tournament.') : (newDrafts[i].league[0].abbr + ' ' + day + ' ' + autoContestLogics[j].maxLimit + ' man Tournament.');
                        //contest name end
                        if (autoContestLogics[j].contestTypeId == 2)
                            var prizepool = ((autoContestLogics[j].entryFees[k] * 2) - (autoContestLogics[j].entryFees[k] * 2) * (10 / 100));
                        else
                            var prizepool = ((autoContestLogics[j].entryFees[k] * autoContestLogics[j].maxLimit) - (autoContestLogics[j].entryFees[k] * autoContestLogics[j].maxLimit) * (10 / 100));
                        var contest = {
                            contestId: await generalHelper.updateCounter('contestId'), //unique key
                            autoId: await generalHelper.updateCounter('autoId'), //unique key
                            entryFees: autoContestLogics[j].entryFees[k],
                            contestStartTime: st[0].minTime.toISOString(),
                            contestTypeId: autoContestLogics[j].contestTypeId,
                            contestType: (autoContestLogics[j].contestTypeId == 1) ? 'Multiplayer' : 'H2H',
                            contestName: contestName,
                            gameTypeId: autoContestLogics[j].gameTypeId,
                            gameType: autoContestLogics[j].gameType,
                            draftgroupId: newDrafts[i].draftgroupId,
                            visibility: 'Public',
                            sportId: 2,
                            contestStatus: 3,
                            prizePool: prizepool,
                            maxLimit: autoContestLogics[j].maxLimit,
                            minLimit: autoContestLogics[j].maxLimit,
                            maxEntriesPerUser: autoContestLogics[j].maxEntriesPerUser,
                            prizeMode: 'C',
                            summary: (autoContestLogics[j].contestTypeId == 1) ? 'Multiplayer Contest' : 'H2H Contest',
                            labels: [],
                            prizes: [],
                            prizeTickets: 0,
                            isVideoAvailable: false,
                            isAdminRow: false,
                            isGuaranteed: false,
                            matchMaking:false,
                            prizeTmpId: autoContestLogics[j].prizeTmpId
                        }
                        await ContestModel.findOneAndUpdate({ 'draftgroupId': newDrafts[i].draftgroupId, 'contestId': contest.contestId }, contest, { upsert: true }, function (err, doc) {
                            try {
                                if (err) throw err;
                                //console.log('Success auto contest');
                            } catch (e) {
                                cronVar.logger.info(e);
                            }
                        });
                        //adding contest to draftgroup
                        await DraftGroupModel.findOneAndUpdate({ draftgroupId: newDrafts[i].draftgroupId }, { $push: { contestList: contest.contestId } });
                    }
                }
                //changing draftgroup autoContest status to 1
                await DraftGroupModel.findOneAndUpdate({ 'draftgroupId': newDrafts[i].draftgroupId }, { autoContest: 1 });

            }

        } catch (e) {
            cronVar.logger.info(e);
        }
    }
}





