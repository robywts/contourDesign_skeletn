/**
 * Pusher Helper
 * @exports Cron/Helper/Pusher
 */

var Pusher = require('pusher');

var pusher = new Pusher({
  appId: process.env.PUSHER_APP_ID,
  key: process.env.PUSHER_APP_KEY,
  secret: process.env.PUSHER_APP_SECRET,
  cluster: process.env.PUSHER_APP_CLUSTER,
  encrypted: true
});


module.exports = {
  /**
   * Push the data through pusher
   * @param {String} channel - Channel name
   * @param {String} event - Event name
   * @param {Object} data - Data Object
   */
  sendPush: function (channelName, eventName, data) {
    try {
      pusher.trigger(channelName, eventName, data);
    } catch (e) {
      throw e;
    }
  },


}