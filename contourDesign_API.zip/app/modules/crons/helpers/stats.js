/**
 * Stats Helper
 * @exports Cron/Helper/Stats
 */

// moment.js is the preferred date library
var moment = require('moment');
// access Node.js Crypto library for signature generation
var crypto = require('crypto');

module.exports = {
  /**
   * Create stats signature
   * @return {String} Stats Signature
   */
  statsCred:function statsCred() {
      // get the current time
      var timeFromEpoch = moment.utc().unix(); 
      // set the API key (note that this is not a valid key!)
      var apiKey = process.env.API_KEY;
      // set the shared secret key
      var secret = process.env.API_SECRET;
      // generate signature
      var sig = crypto.createHash('sha256').update(apiKey + secret + timeFromEpoch).digest('hex');
  
      return sig;
  }
}