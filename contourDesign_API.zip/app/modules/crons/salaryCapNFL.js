/**
 * General Module
 * @exports Cron/NFL/SalaryCap
 */
var TeamSalaryModifier = require('../../models/teamSalaryModifier');
var cronVar = require('./cronSettings');
var moment = require('moment');
var Stats = require('./helpers/stats');
var async = require('async');
var PlayerModel = require('../../models/player');
var PlayerEventScoreModel = require('../../models/playerEventScore');
var EventModel = require('../../models/event');
var nflScoringRules = require('../../config/scoringRulesNFL');

var self = module.exports = {

    /**
     * Cron - cron to get All NFL teams in current season
     */
    getAllTeam: async function () {
        try {
            var request = cronVar.request;
            var date = moment(new Date()).format('YYYY');
            request(process.env.NFL_TEAM + '?api_key=' + cronVar.apiKey + '&sig=' + Stats.statsCred(),
                function (err, response, body) {
                    try {
                        console.log('NFL SalaryCap - ' + response.statusCode);
                        // parse the body as JSON
                        if (!err && response.statusCode == 200) {
                            var parsedBody = JSON.parse(body);
                            var res = parsedBody.apiResults[0].league.season.conferences;
                            if (res) {
                                res.forEach(function (conference) {
                                    var divisions = conference.divisions;
                                    divisions.forEach(function (division) {
                                        var teams = division.teams;
                                        // teams.forEach(async function (team) {console.log(parsedBody.apiResults[0].league.season.season);
                                        async.eachSeries(teams, async function (team, outCb) {
                                            var team_data = {
                                                teamId: team.teamId,
                                                nickName: team.nickname,
                                                country: team.country.name,
                                                sportId: parsedBody.apiResults[0].sportId,
                                                season: parsedBody.apiResults[0].league.season.season
                                            };
                                            //saving or updating teams data to DB
                                            await TeamSalaryModifier.findOneAndUpdate({ 'teamId': team.teamId, sportId: 1, 'season': date }, team_data, { upsert: true }, function () { });
                                            console.log('Success Team');
                                            outCb(null);
                                        })
                                    })
                                })
                            }
                        }
                        else {
                            throw err;
                        }
                    } catch (e) {
                        cronVar.logger.info(e);
                    }
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - cron to calculate each NFL team's average point
     */
    getTeamSeasonPoints: async function () {
        try {
            var request = cronVar.request;
            var date = await moment(new Date()).format('YYYY');
            var teams = await TeamSalaryModifier.find({ "sportId": 2, season: date });
            var datetimeprevyear = await moment(new Date()).subtract(1, 'year');
            var prevYear = await moment(datetimeprevyear).format('YYYY');
            async.eachSeries(teams, function (team, outCb) {
                // var season = (team.gamePlayed && team.gamePlayed < 15) ? prevYear : date;
                request(process.env.NFL_TEAM_POINT + team.teamId + '/?season=' + date + '&api_key=' + cronVar.apiKey + '&sig=' + Stats.statsCred(),
                    function (err, response, body) {
                        try {
                            console.log('NFL Team Points - ' + response.statusCode);
                            // parse the body as JSON
                            if (!err && response.statusCode == 200) {
                                var parsedBody = JSON.parse(body);
                                console.log(team.teamId);
                                //for pitcher modifier based on hitting points                                
                                var hittingStats = parsedBody.apiResults[0].league.teams[0].seasons[0].eventType[0].splits[0].teamStats.battingStats;
                                var gamePlayed = hittingStats.games.total;
                                var strikeOuts = hittingStats.strikeouts;
                                var teamLosses = parsedBody.apiResults[0].league.teams[0].seasons[0].eventType[0].splits[0].teamStats.pitchingStats.record.losses;
                                var runs = hittingStats.runsScored;
                                var hits = hittingStats.hits.total;
                                var walks = hittingStats.walks.total;
                                var hitByPitch = hittingStats.hitByPitch;
                                var averagePointPitching = (((gamePlayed * 9 * 2) + (strikeOuts * 2) + (teamLosses * 4) - (runs * 2) - ((hits + walks + hitByPitch) * 0.5)) / gamePlayed);

                                //for hitter modifier based on pitching points         
                                var pitchingStats = parsedBody.apiResults[0].league.teams[0].seasons[0].eventType[0].splits[0].teamStats.pitchingStats;
                                var totalBases = (pitchingStats.hitsAllowed.total - pitchingStats.hitsAllowed.doubles - pitchingStats.hitsAllowed.triples - pitchingStats.hitsAllowed.homeRuns.total) + (pitchingStats.hitsAllowed.doubles * 2) + (pitchingStats.hitsAllowed.triples * 3) + (pitchingStats.hitsAllowed.homeRuns.total * 4);
                                var walksH = pitchingStats.walks.total;
                                var hitByPitchH = pitchingStats.hitBatsmen;
                                var stolenBases = pitchingStats.stolenBasesAgainst.total;
                                var runsHitter = pitchingStats.runsAllowed.earnedRuns;
                                var runsBattedIn = pitchingStats.runsAllowed.runsBattedIn;
                                var averagePointHitting = (((totalBases * 2) + (walksH * 2) + (hitByPitchH * 2) + (stolenBases * 4) + (runsHitter * 2.5) + (runsBattedIn * 3)) / gamePlayed);

                                var avgPoints = { 'avgPointsPitching': averagePointPitching, 'avgPointsHitting': averagePointHitting }
                                //console.log(averagePointPitching);console.log(averagePointHitting);process.exit();
                                TeamSalaryModifier.findOneAndUpdate({ 'teamId': team.teamId, sportId: 1, season: date }, { gamePlayed: gamePlayed, avgPoints: avgPoints }, { upsert: true }, function () { });
                            }
                            else {
                                throw err;
                            }
                        } catch (e) {
                            cronVar.logger.info(e);
                        }
                        var start = new Date().getTime();
                        while ((new Date().getTime() - start) < 150) {
                            //loop here
                        }
                        outCb(null);
                    });
            })
        } catch (e) {
            throw e;
        }
    },

    /**
     * Cron - cron to calculate NFL team's pitcher and hitter salary modifier
     */
    getTeamsModifier: async function () {
        try {
            var date = moment(new Date()).format('YYYY');
            var datetimeprevyear = moment(new Date()).subtract(1, 'year');
            var prevYear = await moment(datetimeprevyear).format('YYYY');
            var teamsCurrntSeason = await TeamSalaryModifier.find({ "sportId": 2, season: date });
            var teamsPrevSeason = await TeamSalaryModifier.find({ "sportId": 2, season: prevYear });
            console.log('NFL Team Modifier');
            for (var j = 0; j < teamsCurrntSeason.length; j++) {
                var teamValid = (teamsCurrntSeason[j].gamePlayed < 15) ? teamsPrevSeason : teamsCurrntSeason;

                var teamSingleCurrnt = (teamValid).find(function (obj) {
                    return obj.teamId === teamsCurrntSeason[j].teamId;
                });
                var leagueAverageHitter = (teamValid.reduce(function (a, b) {
                    return a + b.avgPoints.avgPointsHitting;
                }, 0)) / teamValid.length;
                var leagueAveragePitcher = (teamValid.reduce(function (a, b) {
                    return a + b.avgPoints.avgPointsPitching;
                }, 0)) / teamValid.length;
                var pitcherModifier = await self.RoundToNumber(teamSingleCurrnt.avgPoints.avgPointsPitching / leagueAveragePitcher);
                pitcherModifier = pitcherModifier > 1.1 ? 1.1 : pitcherModifier;
                pitcherModifier = pitcherModifier < 0.9 ? 0.9 : pitcherModifier;
                var hitterModifier = await self.RoundToNumber(teamSingleCurrnt.avgPoints.avgPointsHitting / leagueAverageHitter);
                hitterModifier = hitterModifier > 1.1 ? 1.1 : hitterModifier;
                hitterModifier = hitterModifier < 0.9 ? 0.9 : hitterModifier;
                modifier = { 'pitcherModifier': pitcherModifier, 'hitterModifier': hitterModifier };
                TeamSalaryModifier.findOneAndUpdate({ 'teamId': teamSingleCurrnt.teamId, sportId: 1, season: date }, { modifier: modifier }, { upsert: true },
                    function (err, data) { });
            }
        } catch (e) {
            throw e;
        }
    },

    /**
      * Cron - cron to get NFL player stats
      */
    getPlayersScoreStats: async function () {
        try {
            var request = cronVar.request;
            var date = moment(new Date()).format('YYYY');
            var datetimeprevyear = moment(new Date()).subtract(1, 'year');
            var prevYear = moment(datetimeprevyear).format('YYYY');
            var teams = await TeamSalaryModifier.find({ "sportId": 2, season: date });
            var playersArr = [];
            for (var j = 0; j < teams.length; j++) {
                var players = await PlayerModel.find({ "sportId": 2, "team.teamId": teams[j].teamId });
                for (var i = 0; i < players.length; i++) {
                    playersArr.push({ 'playerId': players[i].playerId, 'position': players[i].positions[0].posGen });
                }
            }
            async.eachSeries(playersArr, async function (player, innCB) {
                //var playerExistStats = await PlayerEventScoreModel.find({ "sportId": 2, season: date, playerId: player.playerId });
                // var statSeason = (playerExistStats && playerExistStats.length < 6) ? prevYear : date;
                request(process.env.NFL_PLAYER_GAME_BY_GAME + player.playerId + '/events/?season=' + date + '&api_key=' + cronVar.apiKey + '&sig=' + Stats.statsCred(),
                    async function (err, response, body) {
                        try {
                            // parse the body as JSON
                            if (!err && response.statusCode == 200) {
                                console.log('NFL Player Stats - ' + response.statusCode);
                                var parsedBody = JSON.parse(body);
                                //var season = date;
                                var hittingPitchingStats = parsedBody.apiResults[0].league.players[0].seasons[0].eventType[0].splits[0].events;
                                for (var k = 0; k < hittingPitchingStats.length; k++) {
                                    var eventId = hittingPitchingStats[k].eventId;
                                    var startTimeUTC = hittingPitchingStats[k].startDate[1].full;
                                    if (player.position == 'Hitter' && hittingPitchingStats[k].playerStats.battingStats) {
                                        var hittingStats = hittingPitchingStats[k].playerStats.battingStats;
                                        //batting points
                                        var single = hittingStats.hits ? (hittingStats.hits.singles * nflScoringRules.nflScore['battingStats']['singles']['pts']) : 0;
                                        var double = hittingStats.hits ? (hittingStats.hits.doubles * nflScoringRules.nflScore['battingStats']['doubles']['pts']) : 0;
                                        var triple = hittingStats.hits ? (hittingStats.hits.triples * nflScoringRules.nflScore['battingStats']['triples']['pts']) : 0;
                                        var homeRun = hittingStats.hits ? (hittingStats.hits.homeRuns * nflScoringRules.nflScore['battingStats']['home-runs']['pts']) : 0;
                                        var walk = hittingStats.walks.total * nflScoringRules.nflScore['battingStats']['walks']['pts'];
                                        var hitByPitch = hittingStats.hitByPitch * nflScoringRules.nflScore['battingStats']['hit-by-pitch']['pts'];
                                        var runScored = hittingStats.runsScored * nflScoringRules.nflScore['battingStats']['runs']['pts'];
                                        var runsBatteIn = hittingStats.runsBattedIn.total * nflScoringRules.nflScore['battingStats']['runs-batted-in']['pts'];
                                        var stolenBase = hittingStats.stolenBases.total * nflScoringRules.nflScore['battingStats']['stolen-bases']['pts'];
                                        var sacrificeHit = hittingStats.sacrifices.hits * nflScoringRules.nflScore['battingStats']['sacrifice-hits']['pts'];
                                        var sacrificeFly = hittingStats.sacrifices.flies * nflScoringRules.nflScore['battingStats']['sacrifice-flies']['pts'];
                                        var totalPlayerScore = await self.RoundToNumber(single + double + triple + homeRun + walk + hitByPitch + runScored + runsBatteIn + stolenBase + sacrificeHit + sacrificeFly);
                                        //console.log('Hitter---' + self.RoundToNumber(totalPlayerScore));
                                        await PlayerEventScoreModel.update({ 'playerId': player.playerId, eventId: eventId, season: date }, { startTimeUTC: startTimeUTC, sportId: 1, playerPosition: player.position, playerScore: totalPlayerScore }, { upsert: true }, function () { });

                                    }
                                    else if (player.position == 'Pitcher' && hittingPitchingStats[k].playerStats.pitchingStats) {
                                        var pitchingStats = hittingPitchingStats[k].playerStats.pitchingStats;
                                        //pitching points
                                        var inningsPitched = pitchingStats.inningsPitched ? (pitchingStats.inningsPitched * nflScoringRules.nflScore['pitchingStats']['innings-pitched']['pts']) : 0;
                                        var strikeouts = pitchingStats.strikeouts.total * nflScoringRules.nflScore['pitchingStats']['strike-outs']['pts'];
                                        var wins = pitchingStats.record.wins * nflScoringRules.nflScore['pitchingStats']['wins']['pts'];
                                        var GIDP = pitchingStats.groundIntoDoublePlays.total * nflScoringRules.nflScore['pitchingStats']['gidp']['pts'];
                                        var earnedRun = pitchingStats.runsAllowed.earnedRuns * (nflScoringRules.nflScore['pitchingStats']['earned-runs']['pts']);
                                        var hitAllowed = pitchingStats.hitsAllowed.total * (nflScoringRules.nflScore['pitchingStats']['hits']['pts']);
                                        var walkIssued = pitchingStats.walks.total * (nflScoringRules.nflScore['pitchingStats']['walks']['pts']);
                                        var hitBatsman = pitchingStats.hitBatsmen * (nflScoringRules.nflScore['pitchingStats']['hit-batsmen']['pts']);
                                        var totalPlayerScore = await self.RoundToNumber(inningsPitched + strikeouts + wins + GIDP + earnedRun + hitAllowed + walkIssued + hitBatsman);
                                        //console.log('Pitcher---' + self.RoundToNumber(totalPlayerScore)); 
                                        await PlayerEventScoreModel.update({ 'playerId': player.playerId, eventId: eventId, season: date }, { startTimeUTC: startTimeUTC, sportId: 1, playerPosition: player.position, playerScore: totalPlayerScore }, { upsert: true }, function () { });

                                    }
                                }
                            }
                            else {
                                throw err;
                            }
                        } catch (e) {
                            cronVar.logger.info(e);
                        }
                        var start = new Date().getTime();
                        while ((new Date().getTime() - start) < 150) {
                            //loop here
                        }
                        innCB(null);
                    });
            })
        } catch (e) {
            throw e;
        }
    },


    /**
      * Cron - cron to calculate NFL players salary
      */
    setPlayerSalary: async function () {
        try {
            var date = moment(new Date()).format('YYYY');
            var datetimeprevyear = moment(new Date()).subtract(1, 'year');
            var prevYear = moment(datetimeprevyear).format('YYYY');
            var nxtWeek = moment(new Date()).add(1, 'days').format('YYYY-MM-DD').replace(/-+/g, '');
            var weekAftrNext = moment(new Date()).add(2, 'days').format('YYYY-MM-DD').replace(/-+/g, '');

            var events = await EventModel.find({ sportId: 1, week: { $in: [nxtWeek, weekAftrNext] } });
            for (var i = 0; i < events.length; i++) {
                console.log('events-------------------------------' + events[i].eventId);
                var teamIds = [events[i].homeTeam.teamId, events[i].awayTeam.teamId];
                for (var j = 0; j < teamIds.length; j++) {
                    //console.log('teams------------------' + teamIds[j]);
                    if (j == 1) {
                        var opposingTeam = await TeamSalaryModifier.findOne({ "sportId": 2, season: date, teamId: teamIds[0] });
                    }
                    else {
                        var opposingTeam = await TeamSalaryModifier.findOne({ "sportId": 2, season: date, teamId: teamIds[1] });
                    }
                    // var eventPlayers = await PlayerModel.find({ "sportId": 2, "team.teamId": { $in: teamIds } });
                    var eventPlayers = await PlayerModel.find({ "sportId": 2, "team.teamId": teamIds[j] });
                    var teamCurrentPrevSeason = await TeamSalaryModifier.findOne({ teamId: opposingTeam.teamId, season: date });
                    if (teamCurrentPrevSeason.gamePlayed < 30) {
                        teamCurrentPrevSeason = await TeamSalaryModifier.findOne({ teamId: opposingTeam.teamId, season: prevYear });
                    }
                    for (var k = 0; k < eventPlayers.length; k++) {
                        var totalPlayerScore = 0;
                        if (eventPlayers[k].positions[0].posGen == 'Pitcher') {
                            var playerLastEvents = await PlayerEventScoreModel.find({ playerId: eventPlayers[k].playerId, season: date }).sort({ startTimeUTC: -1 }).limit(12);
                            if (playerLastEvents.length < 12) {
                                playerLastEvents = await PlayerEventScoreModel.find({ playerId: eventPlayers[k].playerId, season: prevYear }).sort({ startTimeUTC: -1 }).limit(12);
                            }
                            var sortedPlayerScoreEvent = playerLastEvents.sort(function (a, b) { return (a.playerScore < b.playerScore) ? 1 : ((b.playerScore < a.playerScore) ? -1 : 0); });
                            var playerEventLength = (sortedPlayerScoreEvent.length > 8) ? 9 : sortedPlayerScoreEvent.length;
                            var salaryModifier = teamCurrentPrevSeason.modifier.pitcherModifier;
                        }
                        else {
                            var playerLastEvents = await PlayerEventScoreModel.find({ playerId: eventPlayers[k].playerId, season: date }).sort({ startTimeUTC: -1 }).limit(30);
                            if (playerLastEvents.length < 30) {
                                playerLastEvents = await PlayerEventScoreModel.find({ playerId: eventPlayers[k].playerId, season: prevYear }).sort({ startTimeUTC: -1 }).limit(30);
                            }
                            var sortedPlayerScoreEvent = playerLastEvents.sort(function (a, b) { return (a.playerScore < b.playerScore) ? 1 : ((b.playerScore < a.playerScore) ? -1 : 0); });
                            var playerEventLength = (sortedPlayerScoreEvent.length > 23) ? 24 : sortedPlayerScoreEvent.length;
                            var salaryModifier = teamCurrentPrevSeason.modifier.hitterModifier;
                        }
                        for (var l = 0; l < playerEventLength; l++) {
                            totalPlayerScore = totalPlayerScore + sortedPlayerScoreEvent[l].playerScore;
                        }
                        //setting min and max for pitcher/hitter
                        if (eventPlayers[k].positions[0].posGen == 'Pitcher') {
                            var playerSalary = (totalPlayerScore / playerEventLength) * salaryModifier * 800;
                            var roundToNearestHundred = await Math.round(playerSalary / 100) * 100;
                            roundToNearestHundred = (roundToNearestHundred > 30000) ? 30000 : roundToNearestHundred;
                            roundToNearestHundred = (roundToNearestHundred < 10000) ? 10000 : roundToNearestHundred;
                        }
                        else {
                            var playerSalary = (totalPlayerScore / playerEventLength) * salaryModifier * 900;
                            var roundToNearestHundred = await Math.round(playerSalary / 100) * 100;
                            roundToNearestHundred = (roundToNearestHundred > 15000) ? 15000 : roundToNearestHundred;
                            roundToNearestHundred = (roundToNearestHundred < 5000) ? 5000 : roundToNearestHundred;
                        }
                        var updatePlayerSalary = await PlayerModel.update({ playerId: eventPlayers[k].playerId, sportId: 1 }, { fanProjSalary: roundToNearestHundred });

                    }
                }
            }
        } catch (e) {
            throw e;
        }
    },


    /**
      * Function to round number/decimal
      */
    RoundToNumber: function (num) {
        return +(Math.round(num + "e+2") + "e-2");
    }
}





