/**
 * General Module
 * @exports Cron/GeneralSchemaUpdate
 */
var DraftGroupModel = require('../../models/draftgroup');
var contestModel = require('../../models/contest');
var cronVar = require('./cronSettings');
var async = require('async');
var moment = require('moment');

var self = module.exports = {
    /**
      * Cron - To update mValue value in a draftgroup schema
      * To update mValue in draftgroup schema based on the player fantasy salary
      */
    updateDraftMValue: async function () {
        try {
            var draftgroups = DraftGroupModel.find({dgState: { $ne: 'Completed' }}, async function (err, draftgroups) {
                if (err)
                    console.log(err);
                else {
                    //async.eachSeries(draftgroups, async function (draftgroup, outCb) {
                    for (var l in draftgroups) {
                        if (draftgroups[l].gameList != null && (draftgroups[l].sportId == 4 || draftgroups[l].sportId == 3  || draftgroups[l].sportId == 2)) {
                            //To get max and min fantasy player positions
                            var minmax = await DraftGroupModel.aggregate(
                                [
                                    { "$match": { draftgroupId: draftgroups[l].draftgroupId } },
                                    { $unwind: "$gameList" },
                                    { $unwind: "$gameList.players" },
                                    { "$match": { "gameList.players.fanProjSalary": { "$gte": 1 } } },
                                    {
                                        $group:
                                        {
                                            _id: "$gameList.players.posGen",
                                            min: { $min: "$gameList.players.fanProjSalary" },
                                            max: { $max: "$gameList.players.fanProjSalary" }
                                        }
                                    }
                                ]
                            );
                            var gamesList = draftgroups[l].gameList;
                            for (var k = 0, len = gamesList.length; k < len; k++) {
                                console.log(draftgroups[l].draftgroupId);
                                if (gamesList[k].players != null) {
                                    for (var j in gamesList[k].players) {
                                        for (var i in minmax) {
                                            if (minmax[i]._id == gamesList[k].players[j].posGen) {
                                                //setting min salary for player if 0
                                                var playerSalary = (gamesList[k].players[j].fanProjSalary == 0) ?  minmax[i].min : gamesList[k].players[j].fanProjSalary;
                                                mValue = await Math.round((1 + ((playerSalary - minmax[i].max) * (2 - 1)) / (minmax[i].min - minmax[i].max)) * 20) / 20;
                                                //updating mValue draftgroup schema
                                                var field = {};
                                                field["gameList.$.players." + j + ".mValue"] = mValue;
                                                var updateM = await DraftGroupModel.findOneAndUpdate(
                                                    { "draftgroupId": draftgroups[l].draftgroupId, "gameList.players.playerId": gamesList[k].players[j].playerId },

                                                    field,
                                                    {
                                                        new: false
                                                    });
                                            };
                                        }
                                    }
                                }
                            }
                        }
                        // outCb(null);
                        //  });
                    }
                    // console.log('finished');
                }

            });
        } catch (e) {
            throw e;
        }
    },

}





