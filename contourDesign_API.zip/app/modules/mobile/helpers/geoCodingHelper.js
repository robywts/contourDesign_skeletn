/**
 * GeoCoding Related Functions
 * @exports General/Helper/GeoCoding
 */

const request = require("request");
let gUrl = "https://maps.googleapis.com/maps/api/geocode/json?";

// var _t = require('../translations/' + process.env.LANGUAGE + '/generalTrans.json');

module.exports = {

	/**
	 * Get the state code from lat lng
	 * @param {string} lat - Latitude
	 * @param {string} lng - Longitude
	 * @return {object} state and country codes
	 */
	getStateCode: async function (lat, lng) {
		try {
			var url = gUrl + "latlng=" + lat + ',' + lng + "&key=" + process.env.GOOGLE_API_KEY;
			var result = {
				'state': '',
				'country': ''
			};
			return new Promise(function (resolve, reject) {
				request(url, (error, response, body) => {
					if (!error && response.statusCode == 200) {
						let json = JSON.parse(body);
						if (json.results[0]) {
							for (address of json.results[0].address_components) {
								if (address.types.indexOf("administrative_area_level_1") > -1) {
									result.state = address.short_name
								}
								if (address.types.indexOf("country") > -1) {
									result.country = address.short_name
								}
							}
							resolve(result);
						} else {
							console.log('Address not found');
							console.log(json);
							// reject(json);
							resolve(result);
						}
					} else {
						console.log('Google api Error');
						console.log(error);
						// reject(error);
						resolve(result);
					}
				});
			});
		} catch (e) {
			throw e;
		}
	},

};