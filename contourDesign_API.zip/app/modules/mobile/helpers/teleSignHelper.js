/**
 * Tele sign Related Functions
 * @exports General/Helper/TeleSign
 */

const readline = require('readline');
var TeleSignSDK = require('telesignsdk');
const customerId = "BEB0B744-4538-4787-A13D-613AF692D019";
const apiKey = "0FXvM51mU/hAMLyK8Ns6B3geU9l0M9KCSbFuG2gCiwpLVauFEUqF4BAqoXpjuQ0llOWLXrUXNUylf9uRF2/9Ew==";
const rest_endpoint = "https://rest-api.telesign.com";
const timeout = 10 * 1000; // 10 secs

const client = new TeleSignSDK(customerId,
	apiKey,
	rest_endpoint,
	timeout // optional
	// userAgent
);

// const phoneNumber = "19788665573"; // 9783251139
// const messageType = "ARN";
// const verifyCode = "32658";
// const message = "Your code is " + verifyCode;

// console.log("## MessagingClient.message ##");

module.exports = {
	/**
	 * Function to send sms
	 * @param {string} phoneNumber - Phone No.
	 * @param {string} message - Message
	 * @param {string} messageType - Message Type
	 */
	sendSMS: async function (phoneNumber, message, messageType = "ARN") {
		try {
			client.sms.message(module.exports.messageCallback, phoneNumber, message, messageType);
		} catch (e) {
			throw e;
		}
	},

	messageCallback: function (error, responseBody) {
		if (error === null) {
			console.log(responseBody);
			console.log(`Messaging success` +
				` => code: ${responseBody['status']['code']}` +
				`, description: ${responseBody['status']['description']}`);

			// module.exports.prompt('Enter the verification code received:\n', function (input) {
			// 	if (input === verifyCode) {
			// 		console.log('Your code is correct.');
			// 	} else {
			// 		console.log('Your code is incorrect. input: ' + input + ", code: " + verifyCode);
			// 	}
			// 	process.exit();
			// });

		} else {
			console.error("Unable to send message. " + error);
		}
	},

	// prompt: function (question, callback) {
	// 	const stdin = process.stdin,
	// 		stdout = process.stdout;

	// 	stdin.resume();
	// 	stdout.write(question);

	// 	stdin.once('data', function (data) {
	// 		callback(data.toString().trim());
	// 	});
	// }

};