/**
 * Image Upload Helper
 * @exports General/Helper/ImageUpload
 */
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/generalTrans.json');
var multer = require('multer');
var sharp = require('sharp');
var AWS = require('aws-sdk');
var fs = require('fs');

module.exports = {
	/**
	 * Function to upload file
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @param {String} fieldName - Field Name
	 * @param {String} callback - Image name
	 */
	imageUpload: function (req, res, fieldName, callback) {
		try {
			var storage = multer.diskStorage({
				destination: function (req, file, cb) {
					cb(null, process.env[fieldName + '_PATH']);
				},
				filename: function (req, file, cb) {
					var fileExtension = '.jpg';
					if (file.mimetype == 'image/png') {
						fileExtension = '.png';
					}
					cb(null, file.fieldname + '-' + Math.floor(Math.random() * 1000) + '-' + Date.now() + fileExtension);
				}
			});

			var upload = multer({
				storage: storage,
				fileFilter: function (req, file, cb) {
					if (!['image/jpeg', 'image/png'].includes(file.mimetype)) { //image type validation
						return cb(_t.invalidImage, false);
					} else {
						cb(null, true);
					}
				}
			}).single(fieldName);

			upload(req, res, function (err) {
				try {
					if (err) {
						return generalHelper.handleError(req, res, err, _t.invalidPath);
					} else if (!req.file || !req.file.filename) {
						return generalHelper.handleError(req, res, 'Image not found', _t.imageRequired);
					} else { //successful upload to local
						callback(req.file.filename);
					}
				} catch (err) {
					return generalHelper.handleError(req, res, err.stack, _t.technicalError);
				}
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Resize function for image
	 * @param {String} fieldName - Field name
	 * @param {String} file - file object
	 * @param {String} size - This is mainly used for size and path specification
	 */
	resize: async function (file, fieldName, size) {
		try {
			return await sharp(process.env[fieldName + '_PATH'] + '/' + file.filename)
				.resize(size)
				.toFile(process.env[fieldName + '_PATH'] + '/' + size + '_' + size + '/' + file.filename);
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Upload file to s3 bucket
	 * @param {String} fieldName - Field name
	 * @param {String} file - file object
	 * @param {String} size - This is mainly used for size and path specification
	 */
	uploadS3: async function (file, fieldName, size = '') {
		try {
			AWS.config.update({
				accessKeyId: process.env.ACCESS_KEY_ID,
				secretAccessKey: process.env.SECRET_ACCESS_KEY
			});
			let s3 = new AWS.S3();
			let sizePath = '/';
			if (size != '') {
				sizePath = '/' + size + '_' + size + '/';
			}
			var params = {
				Bucket: process.env.S3_BUCKET,
				Key: fieldName + sizePath + file.filename,
				Body: fs.readFileSync(process.env[fieldName + '_PATH'] + sizePath + file.filename),
				ContentType: file.mimetype,
				ACL: 'public-read'
			};
			return await s3.upload(params, function () {});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Delete the local file
	 * @param {String} fieldName - Field name
	 * @param {String} imageName - Local Image name
	 * @param {String} size - This is mainly used for size and path specification
	 */
	deleteLocalImage: async function (fieldName, imageName, size = '') {
		try {
			let sizePath = '/';
			if (size != '') {
				sizePath = '/' + size + '_' + size + '/';
			}
			await fs.unlink(process.env[fieldName + '_PATH'] + sizePath + imageName, (err) => {});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Delete the old file
	 * @param {String} fieldName - Field name
	 * @param {String} filename - File name
	 * @param {String} size - This is mainly used for size and path specification
	 */
	deleteOldImage: async function (fieldName, filename, size = '') {
		try {
			let sizePath = '/';
			if (size != '') {
				sizePath = '/' + size + '_' + size + '/';
			}

			AWS.config.update({
				accessKeyId: process.env.ACCESS_KEY_ID,
				secretAccessKey: process.env.SECRET_ACCESS_KEY
			});
			let s3 = new AWS.S3();
			var params = {
				Bucket: process.env.S3_BUCKET,
				Key: fieldName + sizePath + filename
			};
			return await s3.deleteObject(params, function(err, data) {});
		} catch (e) {
			throw e;
		}
	}

};