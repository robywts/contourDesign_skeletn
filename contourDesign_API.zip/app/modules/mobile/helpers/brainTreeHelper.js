/**
 * Braintree Related Functions
 * @exports General/Helper/BrainTree
 */

var braintree = require('braintree');
var _t = require('../translations/' + process.env.LANGUAGE + '/generalTrans.json');

// var gateway = braintree.connect({
// 	environment: braintree.Environment.Sandbox,
// 	merchantId: "v2ccmg2h7xyvh7rg",
// 	publicKey: "6xdm4ckvq7567ws5",
// 	privateKey: "9669abdb358b4245c046db1a805a3cb1"
// });
var gateway = braintree.connect({
	environment: braintree.Environment.Sandbox,
	merchantId: process.env.BT_MERCHANT_ID,
	publicKey: process.env.BT_PUBLIC_KEY,
	privateKey: process.env.BT_PRIVATE_KEY
});

module.exports = {

	/**
	 * Function to create a BrainTree client
	 * @param {object} userData - User data
	 * @returns {object} Response
	 */
	createClient: async function (userData) {
		try {
			btCustomer = {};
			btCustomer.id = userData.btId;
			btCustomer.firstName = (userData.fName) ? userData.fName : '';
			btCustomer.lastName = (userData.lName) ? userData.lName : '';
			btCustomer.email = userData.email;
			return await gateway.customer.create(btCustomer);
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Function to update a BrainTree client
	 * @param {object} userData - User data
	 * @param {object} callback - Callback function
	 * @returns {object} Response
	 */
	updateClient: function (userData, callback) {
		try {
			btCustomer = {};
			// btCustomer.id = userData.btId;
			btCustomer.firstName = (userData.fName) ? userData.fName : '';
			btCustomer.lastName = (userData.lName) ? userData.lName : '';
			// btCustomer.email = userData.email;
			gateway.customer.update(userData.btId, btCustomer, callback);
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Function to get the BrainTree client
	 * @param {string} clientBtId - BrainTree user id
	 * @param {object} callback - Callback function
	 * @returns {object} Response
	 */
	getClient: function (clientBtId, callback) {
		try {
			gateway.customer.find(clientBtId, callback);
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Function to get the BrainTree client token
	 * @param {string} clientBtId - BrainTree user id
	 * @param {object} callback - Callback function
	 * @returns {object} Response
	 * @returns {string} response.clientToken
	 */
	getClientToken: function (clientBtId, callback) {
		try {
			// gateway.customer.find(clientBtId, function (err, customer) {
			// 	if (err) {
			// 		gateway.clientToken.generate({}, callback);
			// 	} else {
			// 		gateway.clientToken.generate({
			// 			customerId: clientBtId
			// 		}, callback);
			// 	}
			// });
			gateway.clientToken.generate({
				customerId: clientBtId
			}, callback);
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Function to get the BrainTree nonce
	 * @param {string} tokenP - BrainTree payment method token (not client token)
	 * @param {object} callback - Callback function
	 * @returns {object} Response
	 * @returns {string} response.paymentMethodNonce.nonce
	 */
	getNonce: async function (tokenP) {
		try {
			return await gateway.paymentMethodNonce.create(tokenP); // , callback
		} catch (e) {
			if (e.type == 'notFoundError') {
				return false;
			} else {
				throw e;
			}
		}
	},

	/**
	 * Function to pay in the BrainTree
	 * @param {string} nonce - BrainTree nonce
	 * @param {number} amount - Amount to pay
	 * @param {object} userData - User data
	 * @param {object} callback - Callback function
	 * @returns {object} Response
	 */
	paymentSubmit: function (amount, nonce, userData, customerId, callback) {
		try {
			userData.fName = (userData.fName) ? userData.fName : '';
			userData.lName = (userData.lName) ? userData.lName : '';
			var btOptions = {
				amount: amount,
				paymentMethodNonce: nonce,
				customer: {
					firstName: userData.fName,
					lastName: userData.lName,
					phone: "",
					email: userData.email,
				},
				billing: {
					firstName: userData.fName,
					lastName: userData.lName,
					streetAddress: "",
					extendedAddress: "",
					locality: "",
					region: "",
					postalCode: "",
					countryCodeAlpha2: "US"
				},
				options: {
					submitForSettlement: true,
					storeInVaultOnSuccess: true
				}
			};
			btOptions.customerId = customerId;

			console.log(btOptions);
			gateway.transaction.sale(btOptions, callback);
		} catch (e) {
			throw e;
		}
	}

};