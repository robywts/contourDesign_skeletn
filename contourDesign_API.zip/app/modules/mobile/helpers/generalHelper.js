/**
 * DB Configuration and Connection
 * @exports General/Helper/General
 */

var Counter = require('../../../models/counter');
var _t = require('../translations/' + process.env.LANGUAGE + '/generalTrans.json');
var UserModel = require('../../../models/user');

module.exports = {
	/**
	 * Function to handle any error reponse of the webservice
	 * @param {object} req - Request Object
	 * @param {object} res - Response Object
	 * @param {string} reason - Reason for developers
	 * @param {string} message - Message for end users
	 * @param {number} code - Code to return (default is 1)
	 * @returns {boolean}
	 * @returns {object} Error Message (Json result)
	 */
	handleError: function (req, res, reason, message, code = 1) {
		try {
			if (!res.headersSent) {
				var response = {
					"message": message,
					"errorCode": code
				};

				res.status(200).json(response);

				if (process.env.ERROR_LOG == 'yes') { //logging
					this.wsLogger(req, response, [reason, message], 'wsError');
				}
				if (process.env.LOG_ERROR_SHOW_IN_CONSOLE == 'yes') { //show error in the console
					console.log(message);
					console.log(reason);
				}
				return false;
			}
		} catch (e) {
			//this.handleError(req, res, e.stack, _t.technicalError);
			console.log(e);
		}
	},

	/**
	 * Function to handle any success reponse of the webservice
	 * @param {object} req - Request Object
	 * @param {object} res - Response Object
	 * @param {string} message - Message
	 * @param {object} result - Resultset
	 * @param {object} additionalData - Additional data to be sent
	 * @returns {object} Message and Resultset (Json result)
	 * @throws {object} error
	 */
	handleSuccess: function (req, res, message, result, additionalData) {
		try {
			var response = {
				"message": message,
				"errorCode": 0,
				"data": result,
				"info": {}
			};
			for (var dataKey in additionalData) {
				response.info[dataKey] = additionalData[dataKey];
			}
			res.status(200).json(response);
			if (process.env.SUCCESS_LOG == 'yes') { //logging
				this.wsLogger(req, response, [message], 'wsSuccess');
			}
		} catch (e) {
			this.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * This logs the request and reponse. This could be set to off in the .env file
	 * @param {object} req - Request Object
	 * @param {object} res - Response Object
	 * @param {array} data - Additional Data
	 * @param {string} type - Type of Log
	 */
	wsLogger: function (req, res, data = [], type) {
		try {
			var Logger = require('../../../models/logger');
			var logger = new Logger();
			logger.req = {
				"headers": req.headers,
				"url": req.url,
				"method": req.method,
				"params": req.params,
				"query": req.query,
				"body": req.body
			};
			if (process.env.LOG_WITH_RESULTSET == 'no') { //logging the result set
				res.result = '';
			}
			logger.res = res; // don't put the original response here
			logger.data = data;
			logger.type = type;
			logger.save();
		} catch (e) {
			console.log(e);
		}
	},

	/**
	 * This logs the email error response.
	 * @param {object} req - Object1
	 * @param {object} res - Object2
	 * @param {array} data - Additional Data
	 * @param {string} type - Type of Error
	 */
	errorLogger: function (req, res, data = [], type = 'error') {
		try {
			var Logger = require('../../../models/logger');
			var logger = new Logger();
			logger.req = req; // don't put the original request here
			logger.res = res; // don't put the original response here
			logger.data = data;
			logger.type = type;
			logger.save();
		} catch (e) {
			this.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * This updates the counter and returns the auto increment id
	 * @param {String} itemName - Collection which needs update
	 * @returns {Number} Updated counter id
	 * @throws {object} e - Error
	 */
	updateCounter: async function (itemName) {
		try {
			var counter = await Counter.findByIdAndUpdate({
				_id: itemName
			}, {
					$inc: {
						seq: 1
					}
				}, {
					new: true,
					upsert: true
				});
			return counter.seq;
			// Counter.findByIdAndUpdate({
			// 	_id: itemName
			// }, {
			// 	$inc: {
			// 		seq: 1
			// 	}
			// }, {
			// 	new: true,
			// 	upsert: true
			// }, function (err, counter) {
			// 	if (err) {
			// 		callback(err, '');
			// 	} else {
			// 		callback(false, counter.seq);
			// 	}
			// });
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Data Mapping for pagination info
	 * @param {Object} pageLimit - Requests page max limit
	 * @param {Object} totalCount - Total count of records (without pagination limits)
	 * @param {Object} pageNumber - Current page number
	 * @param {Object} actualPageSize - Actual no. of records
	 * @return {Object} pagination Info
	 */
	paginationInfo: function (pageLimit, totalCount, pageNumber, actualPageSize) {
		try {
			let pageInfo = {};
			pageInfo.pageLimit = parseInt(pageLimit);
			pageInfo.totalCount = totalCount;
			pageInfo.totalPages = Math.ceil((totalCount / pageLimit));
			pageInfo.pageNumber = parseInt(pageNumber);
			pageInfo.pageSize = actualPageSize;
			return pageInfo;
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Data Mapping for array pagination info
	 * @param {Object} array - DB result
	 * @param {Object} pageSize - page size
	 * @param {Object} pageNumber - Current page number
	 * @return {Object} paginated response
	 */
	paginateArray: function (array, pageSize, pageNumber) {
		return array.slice(pageNumber * pageSize, (pageNumber + 1) * pageSize);
	},

	/**
	 * Function to handle any error reponse of the webservice
	 * @param {object} req - Request Object
	 * @param {object} res - Response Object
	 * @param {string} reason - Reason for developers
	 * @param {string} message - Message for end users
	 * @param {number} code - Code to return (default is 1)
	 * @returns {boolean}
	 * @returns {object} Error Message (Json result)
	 */
	handleErrorData: function (req, res, reason, message, code = 1, data) {
		try {
			if (!res.headersSent) {
				var response = {
					"message": message,
					"errorCode": code,
					"data": data
				};

				res.status(200).json(response);

				if (process.env.ERROR_LOG == 'yes') { //logging
					this.wsLogger(req, response, [reason, message], 'wsError');
				}
				if (process.env.LOG_ERROR_SHOW_IN_CONSOLE == 'yes') { //show error in the console
					console.log(message);
					console.log(reason);
				}
				return false;
			}
		} catch (e) {
			//this.handleError(req, res, e.stack, _t.technicalError);
			console.log(e);
		}
	},


	/**
	 * Function to get the logged-in userId.
	 * @param {object} req - Object1
	 */
	getLoggedUser: async function (req) {
		try {
			var user = await UserModel.aggregate([{
				$match: {
					'sessions.sessionToken': req.headers['session-key'],
					'userStatus': 1
				}
			}, {
					"$unwind": "$sessions"
				}, {
					"$match": {
						"sessions.sessionToken": req.headers['session-key'],
					}
				}, {
					"$project": {
						"_id": "$_id",
						"userId": "$userId"
					}
				}]);
				return await user[0].userId;
		} catch (e) {
			this.handleError(req, res, e.stack, _t.technicalError);
		}
	},
};