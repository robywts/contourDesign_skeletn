/**
 * Bcrypt Helper
 * @exports General/Helper/Bcrypt
 */

var bcrypt = require('bcrypt');
const saltRounds = 10;

module.exports = {
	/**
	 * Function to generate bcrypted password
	 * @param {string} password - Plain password
	 * @returns {string} encrypted password
	 */
	encrypt: function (password) {
		try {
			var salt = bcrypt.genSaltSync(saltRounds);
			return bcrypt.hashSync(password, salt);
		} catch (e) {
			throw e;
		}
	},


	/**
	 * Function to compare bcrypted password
	 * @param {string} password - Plain password
	 * @param {string} encPassword - Encrypted password
	 * @returns {boolean}
	 */
	compare: function (password, encPassword) {
		try {
			return bcrypt.compareSync(password, encPassword);
		} catch (e) {
			throw e;
		}
	}
};