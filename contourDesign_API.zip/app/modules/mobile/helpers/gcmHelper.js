/**
 * GCM Related Functions
 * @exports General/Helper/GCM
 */

var gcm = require('node-gcm');
const apiKey = "AAAAs1-CEH4:APA91bEwAmLsfKWjuOvujTSLyoDVj7mvT0iLysOSFGl0SuILY5G0BH3W46KJ_IYTUCv74cQiAx7rcm4yPFr0EHk-3cW13PzQhRMjheCUvld-ckCszm0aSbpQORA0WG0KgVZtNRC-J0l5";
var sender = new gcm.Sender(apiKey);

module.exports = {
	/**
	 * Function to send push notification
	 * @param {array} tokens - Array of Tokens
	 * @param {string} msg - Message
	 */
	sendPushNotification: async function (tokens, msg) {
		try {
			var message = new gcm.Message({
				data: {
					key1: msg
				}
			});

			sender.send(message, { registrationTokens: tokens }, function (err, response) {
				if (err) console.error(err);
				else console.log(response);
			});
		} catch (e) {
			throw e;
		}
	},
};