/**
 * Email Helper
 * @exports General/Helper/Email
 */
const nodemailer = require('nodemailer');
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/generalTrans.json');
var fs = require('fs');

module.exports = {
	/**
	 * Function to send email
	 * @param {string} to - To Email
	 * @param {string} subject - Subject of the email
	 * @param {string} content - Email content
	 * @returns {bool}
	 */
	sendMail: function (to, subject, contentFile, templateData, fromEmail = '') {
		try {
			let transporter = nodemailer.createTransport({
				host: process.env.MAIL_HOST,
				port: process.env.MAIL_PORT,
				//secure: ((process.env.MAIL_SECURE == 'false') ? false : true), // true for 465, false for other ports
				auth: {
					user: process.env.MAIL_USER,
					pass: process.env.MAIL_PASS
				}
			});

			fs.readFile(contentFile, 'utf8', function (err, fileContent) { //read the template file
				try {
					if (err) {
						generalHelper.errorLogger('', '', err, 'fileError');
						return false;
					} else {
						for (var i in templateData) {
							fileContent = fileContent.replace(new RegExp('{{' + i + '}}', "g"), templateData[i]);
						}

						if (fileContent != '') { //if content present
							fromEmail = (fromEmail == '') ? process.env.MAIL_FROM : fromEmail;
							let mailOptions = {
								from: fromEmail,
								to: to,
								subject: _t[subject],
								//text: 'Hello world?', // plain text body
								html: fileContent
							};

							transporter.sendMail(mailOptions, (err) => {
								if (err) {
									generalHelper.errorLogger({
										'to': to,
										'subject': _t[subject],
										'content': fileContent
									}, '', err, 'emailSendError');
									return false;
								} else {
									return true;
								}
							});
						} else {
							generalHelper.errorLogger({
								'to': to,
								'subject': _t[subject],
								'content': fileContent
							}, '', err, 'emailContentError');
							return false;
						}
					}
				} catch (err) {
					generalHelper.errorLogger({
						'to': to,
						'subject': _t[subject],
						'content': fileContent
					}, '', err.stack, 'emailContentError');
					return false;
				}
			});
		} catch (e) {
			throw e;
		}
	}
};