/**
 * @swagger
 * definitions:
 *   UserRegistration:
 *     type: object
 *     required:
 *       - userName
 *       - email
 *       - pwd
 *       - dob
 *     properties:
 *       userName:
 *         type: string
 *       email:
 *         type: string
 *       pwd:
 *         type: string
 *       dob:
 *         type: string
 *       deviceToken:
 *         type: string
 *       deviceType:
 *         type: integer
 *       promoCode:
 *         type: string
 *       referrer:
 *         type: string
 */

/**
 * @swagger
 * definitions:
 *   FbMerge:
 *     type: object
 *     required:
 *       - fbToken
 *     properties:
 *       fbToken:
 *         type: string
 */

/**
 * @swagger
 * definitions:
 *   FbLoginRegister:
 *     type: object
 *     required:
 *       - fbToken
 *       - email
 *       - userName
 *       - pwd
 *       - dob
 *     properties:
 *       fbToken:
 *         type: string
 *       deviceToken:
 *         type: string
 *       deviceType:
 *         type: integer
 *       email:
 *         type: string
 *       userName:
 *         type: string
 *       pwd:
 *         type: string
 *       dob:
 *         type: string
 *       promoCode:
 *         type: string
 *       referrer:
 *         type: string
 */

/**
 * @swagger
 * definitions:
 *   UserLogin:
 *     type: object
 *     required:
 *       - email
 *       - pwd
 *     properties:
 *       email:
 *         type: string
 *       pwd:
 *         type: string
 *       deviceToken:
 *         type: string
 *       deviceType:
 *         type: integer
 */


/**
 * @swagger
 * definitions:
 *   UserForgot:
 *     type: object
 *     required:
 *       - email
 *     properties:
 *       email:
 *         type: string
 */


/**
 * @swagger
 * definitions:
 *   UserReset:
 *     type: object
 *     required:
 *       - email
 *       - resetCode
 *       - pwd
 *     properties:
 *       email:
 *         type: string
 *       resetCode:
 *         type: string
 *       pwd:
 *         type: string
 *       deviceToken:
 *         type: string
 *       deviceType:
 *         type: integer
 */

/**
 * @swagger
 * definitions:
 *   UserChangePassword:
 *     type: object
 *     required:
 *       - oldPwd
 *       - pwd
 *       - confirmPwd
 *     properties:
 *       oldPwd:
 *         type: string
 *       pwd:
 *         type: string
 *       confirmPwd:
 *         type: string
 */

/**
 * @swagger
 * definitions:
 *   UpdateDeviceToken:
 *     type: object
 *     required:
 *       - deviceToken
 *       - deviceType
 *     properties:
 *       deviceToken:
 *         type: string
 *       deviceType:
 *         type: integer
 */

/**
 * @swagger
 * definitions:
 *   geoToken:
 *     type: object
 *     required:
 *       - lat
 *       - lng
 *     properties:
 *       lat:
 *         type: string
 *         default: "40.714224"
 *       lng:
 *         type: string
 *         default: "-73.961452"
 */

/**
 * @swagger
 * /api/user/auth/register:
 *   post:
 *     tags:
 *       - UserAuth
 *     description: User Registration (Device Token, 1 - IOS, 2 - Android) (Dob, yyyy-mm-dd format)
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/UserRegistration'
 *     responses:
 *       200:
 *         description: Registration Successfull
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 */

/**
 * @swagger
 * /api/user/auth/fbMerge:
 *   post:
 *     tags:
 *       - UserAuth
 *     description: FB Merge (Only for the login user)
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/FbMerge'
 *     responses:
 *       200:
 *         description: MErge Successfull
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/user/auth/fb:
 *   post:
 *     tags:
 *       - UserAuth
 *     description: FB Login/Registration (Device Token, 1 - IOS, 2 - Android)
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/FbLoginRegister'
 *     responses:
 *       200:
 *         description: Registration Successfull
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 */

/**
 * @swagger
 * /api/user/auth/updateDeviceToken:
 *   put:
 *     tags:
 *       - UserAuth
 *     description: User Device Token Update (Device Token, 1 - IOS, 2 - Android)
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/UpdateDeviceToken'
 *     responses:
 *       200:
 *         description: Device Token Updated Successfully
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/user/auth/login:
 *   post:
 *     tags:
 *       - UserAuth
 *     description: User Login (Device Token, 1 - IOS, 2 - Android)
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/UserLogin'
 *     responses:
 *       200:
 *         description: Login Successfull/Failed
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 */


/**
 * @swagger
 * /api/user/auth/forgot:
 *   put:
 *     tags:
 *       - UserAuth
 *     description: User Forgot Password
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/UserForgot'
 *     responses:
 *       200:
 *         description: Reset code sent to email
 *     security:
 *       - ApiKey: []
 */


/**
 * @swagger
 * /api/user/auth/reset:
 *   put:
 *     tags:
 *       - UserAuth
 *     description: User Reset Password
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/UserReset'
 *     responses:
 *       200:
 *         description: Password Reset Successfully
 *     security:
 *       - ApiKey: []
 */

/**
 * @swagger
 * /api/user/auth/changePassword:
 *   put:
 *     tags:
 *       - UserAuth
 *     description: User Change Password
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/UserChangePassword'
 *     responses:
 *       200:
 *         description: Password Changed Successfully
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */


/**
 * @swagger
 * /api/user/auth/logout:
 *   delete:
 *     tags:
 *       - UserAuth
 *     description: Logout a user
 *     produces:
 *       - application/json
 *     responses:
 *       200:
 *         description: Logout Successfully
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/user/auth/geoToken:
 *   post:
 *     tags:
 *       - UserAuth
 *     description: Returns Geo Token
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: user
 *         description: User object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/geoToken'
 *     responses:
 *       200:
 *         description: Returns Geo token
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */