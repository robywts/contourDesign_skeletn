/**
 * @swagger
 * definitions:
 *   DraftGroupDetails:
 *     type: object
 *     properties:
 *       _id:
 *         type: string
 *       email:
 *         type: string
 */

/**
 * @swagger
 * definitions:
 *   DraftGroupContestList:
 *     type: object
 *     properties:
 *       _id:
 *         type: string
 *       email:
 *         type: string
 */

/**
 * @swagger
 * definitions:
 *   DraftGroupPlayerList:
 *     type: object
 *     properties:
 *       _id:
 *         type: string
 */

/**
 * @swagger
 * /api/draftgroups/list:
 *   get:
 *     tags:
 *       - DraftGroup
 *     description: Returns Live and Upcoming draftgroup list 
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: status
 *         description: 1-Completed, 2-Live, 3-Upcoming
 *         in: query
 *         required: false
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns Live and Upcoming draftgroup list
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /api/draftgroups/{id}:
 *   get:
 *     tags:
 *       - DraftGroup
 *     description: Returns a single draftgroup
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: draftgroup's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Get single record
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /api/draftgroups/getContests/{id}:
 *   get:
 *     tags:
 *       - DraftGroup
 *     description: Returns all contests in a draftgroup
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: draftgroup's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns contests in draftgroups
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

/**
 * @swagger
 * /api/draftgroups/getPlayers/{id}:
 *   get:
 *     tags:
 *       - DraftGroup
 *     description: Returns all players in a draftgroup
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5
 *       - name: id
 *         description: draftgroup's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns players in draftgroups
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/draftgroups/getLineUps/{id}:
 *   get:
 *     tags:
 *       - DraftGroup
 *     description: Returns all lineups in a draftgroup
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: draftgroup's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns lineups in draftgroups
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/draftgroups/getAllMyLineups:
 *   get:
 *     tags:
 *       - DraftGroup
 *     description: Returns all user lineups 
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: status
 *         description: 1-Completed, 2-Live, 3-Upcoming, 4-Cancelled
 *         in: query
 *         required: false
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns all user lineups
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */