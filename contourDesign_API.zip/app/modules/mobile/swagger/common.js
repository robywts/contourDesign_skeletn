/**
 * @swagger
 * tags:
 *   - name: Contest
 *     description: Web services of contests
 *   - name: DraftGroup
 *     description: Web services of draftgroups related functionalities
 *   - name: General
 *     description: General web services
 *   - name: UserAuth
 *     description: Web services of users authentication
 *   - name: User
 *     description: Web services of users profile related functionalities
 * securityDefinitions:
 *   ApiKey:
 *     type: apiKey
 *     in: header
 *     name: API-KEY
 *   SessionKey:
 *     type: apiKey
 *     in: header
 *     name: SESSION-KEY
 *   GeoToken:
 *     type: apiKey
 *     in: header
 *     name: GEO-TOKEN
 * definitions:
 *   ApiResponse:
 *     type: object
 *     properties:
 *       code:
 *         type: integer
 *         format: int32
 *       message:
 *         type: string
 */

 /**
 * @swagger
 * definitions:
 *   GeneralResult:
 *     type: object
 *     properties:
 *       message:
 *         type: string
 *       errorCode:
 *         type: integer
 *         format: int32
 *       data:
 *         type: object
 *       info:
 *         type: object
 */