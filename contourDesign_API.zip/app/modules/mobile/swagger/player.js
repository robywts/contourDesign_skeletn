 /**
  * @swagger
  * /api/player/playerNews/{id}:
  *   get:
  *     tags:
  *       - Player
  *     description: Returns a single player's News
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: id
  *         description: player's id
  *         in: path
  *         required: true
  *         type: integer
  *         format: int64
  *     responses:
  *       200:
  *         description: Get single record
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/player/playerScores:
  *   get:
  *     tags:
  *       - Player
  *     description: Returns player scores by event id
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: id
  *         description: event ids (comma seperated)
  *         in: query
  *         required: true
  *       - name: final
  *         description: Is final or not or both (true/false/both)
  *         in: query
  *         required: true
  *     responses:
  *       200:
  *         description: Get player scores records
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/player/playerGames/{id}/{sid}:
  *   get:
  *     tags:
  *       - Player
  *     description: Returns a single player's Games (in json format)
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: id
  *         description: player's id
  *         in: path
  *         required: true
  *         type: integer
  *         format: int64
  *       - name: sid
  *         description: sport's id (1 - NFL, 2 - MLB, 3 - NHL, 4 - NBA, 5 - GOLF)
  *         in: path
  *         required: true
  *         type: integer
  *         format: int64
  *     responses:
  *       200:
  *         description: Get game Json
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */