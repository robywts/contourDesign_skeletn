 /**
  * @swagger
  * definitions:
  *   Log:
  *     type: object
  */

 /**
  * @swagger
  * definitions:
  *   Push:
  *     type: object
  *     required:
  *       - channelName
  *       - eventName
  *       - message
  *     properties:
  *       channelName:
  *         type: string
  *       eventName:
  *         type: string   
  *       message:
  *         type: string   
  */

 /**
  * @swagger
  * definitions:
  *   Sms:
  *     type: object
  *     required:
  *       - phoneNumber
  *       - message
  *     properties:
  *       phoneNumber:
  *         type: string
  *       message:
  *         type: string   
  */

 /**
  * @swagger
  * definitions:
  *   pushNotification:
  *     type: object
  *     required:
  *       - tokens
  *       - message
  *     properties:
  *       tokens:
  *         type: array
  *         items:
  *             type: string
  *       message:
  *         type: string   
  */

 /**
  * @swagger
  * /api/general/ping:
  *   get:
  *     tags:
  *       - General
  *     description: Ping the server to check availability, api key and session key
  *     produces:
  *       - application/json
  *     responses:
  *       200:
  *         description: Returns a message
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/general/log:
  *   post:
  *     tags:
  *       - General
  *     description: Log the error from the client side
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: log
  *         description: Log object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/Log'
  *     responses:
  *       200:
  *         description: Returns a error
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/general/push:
  *   post:
  *     tags:
  *       - General
  *     description: Send push
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: push
  *         description: Push object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/Push'
  *     responses:
  *       200:
  *         description: Returns a error
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/general/sms:
  *   post:
  *     tags:
  *       - General
  *     description: Send sms
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: sms
  *         description: Sms object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/Sms'
  *     responses:
  *       200:
  *         description: Returns a error
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/general/gcm/push:
  *   post:
  *     tags:
  *       - General
  *     description: Send push notification
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: pushNotification
  *         description: Push object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/pushNotification'
  *     responses:
  *       200:
  *         description: Returns a error
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/general/test:
  *   post:
  *     tags:
  *       - General
  *     description: Test Webservice
  *     produces:
  *       - application/json
  *     responses:
  *       200:
  *         description: Returns a result
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */