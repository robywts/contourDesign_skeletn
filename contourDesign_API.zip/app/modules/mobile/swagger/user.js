 /**
  * @swagger
  * definitions:
  *   Profile:
  *     type: object
  *     required:
  *       - fName
  *       - lName
  *     properties:
  *       fName:
  *         type: string
  *       lName:
  *         type: string    
  */

 /**
  * @swagger
  * definitions:
  *   TicketToMoney:
  *     type: object
  *     required:
  *       - tickets
  *     properties:
  *       tickets:
  *         type: integer
  */

 /**
  * @swagger
  * definitions:
  *   RewardToTicket:
  *     type: object
  *     required:
  *       - rewards       
  *     properties:
  *       rewards:
  *         type: integer
  */

 /**
  * @swagger
  * definitions:
  *   Deposit:
  *     type: object
  *     required:
  *       - amount       
  *     properties:
  *       amount:
  *         type: integer
  *       nonce:
  *         type: string
  */

 /**
  * @swagger
  * definitions:
  *   withdrawals:
  *     type: object
  *     required:
  *       - amount       
  *     properties:
  *       amount:
  *         type: integer
  */

 /**
  * @swagger
  * definitions:
  *   settings:
  *     type: object 
  *     properties:
  *       spendLimits:
  *         $ref: "#/definitions/spendingLimits"
  *       depositLimits:
  *         $ref: "#/definitions/depositLimits"
  */

 /**
  * @swagger
  * definitions:
  *   spendingLimits:
  *     type: object
  *     properties:
  *       daily:
  *         type: integer
  *       weekly:
  *         type: integer
  *       monthly:
  *         type: integer
  *       maxEntryFee:
  *         type: integer
  */

 /**
  * @swagger
  * definitions:
  *   depositLimits:
  *     type: object
  *     properties:
  *       daily:
  *         type: integer
  *       weekly:
  *         type: integer
  *       monthly:
  *         type: integer
  */

 /**
  * @swagger
  * definitions:
  *   feedback:
  *     type: object
  *     required:
  *       - feedback       
  *     properties:
  *       feedback:
  *         type: string
  */
 /**
  * @swagger
  * definitions:
  *   support:
  *     type: object
  *     required:
  *       - message       
  *     properties:
  *       message:
  *         type: string
  */
 /**
  * @swagger
  * definitions:
  *   friendrequest:
  *     type: object
  *     properties:
  *       toUserId:
  *         type: integer       
  */

 /**
  * @swagger
  * definitions:
  *   respondfriendrequest:
  *     type: object
  *     properties:
  *       fromUserId:
  *         type: integer   
  *       response:
  *         type: integer     
  */

 /**
  * @swagger
  * definitions:
  *   unfriendrequest:
  *     type: object
  *     properties:
  *       friendId:
  *         type: integer       
  */

 /**
 * @swagger
 * definitions:
 *   AddTicketRequest:
 *     type: object
 *     required:       
 *       - ticketAmount
 *       - ticketStatus
 *     properties:
 *       ticketAmount:
 *         type: integer 
 *       ticketStatus:
 *         type: string        
 */

/**
 * @swagger
 * definitions:
 *   TicketStoreRequest:
 *     type: object
 *     required: 
 *       - ticketStore        
 *     properties:
 *       ticketStore:
 *         type: array   
 *         items:        
 *           $ref: "#/definitions/TicketStoreItems"
 */

 /**
 * @swagger
 * definitions:
 *   TicketStoreItems:
 *     type: object
 *     required: 
 *       - ticketId      
 *       - ticketAmount
 *       - ticketStatus
 *     properties:       
 *       ticketId:
 *         type: integer
 *       ticketAmount:
 *         type: integer 
 *       totalRewards:
 *         type: integer    
 */


 /**
  * @swagger
  * /api/users/profile:
  *   get:
  *     tags:
  *       - User
  *     description: Returns a User's profile
  *     produces:
  *       - application/json
  *     responses:
  *       200:
  *         description: Returns a User's profile
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */
 /**
  * @swagger
  *  /api/users/profile:
  *   put:
  *     tags:
  *       - User
  *     description: User profile update
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: user
  *         description: User object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/Profile'
  *     responses:
  *       200:
  *         description: Profile Update successfully completed.
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/users/updateprofileImage:
  *   put:
  *     tags:
  *       - User
  *     description: User Profile Image Update
  *     consumes:
  *       - multipart/form-data
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: profileImage
  *         description: User Profile Picture
  *         in: formData
  *         required: true
  *         type: file
  *     responses:
  *       200:
  *         description: Profile Picture Update Successfull
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  *  /api/users/client_token:
  *   get:
  *     tags:
  *       - User
  *     description: Get client token
  *     produces:
  *       - application/json
  *     responses:
  *       200:
  *         description: Get client token
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  *  /api/users/get_nonce:
  *   get:
  *     tags:
  *       - User
  *     description: Get nonce
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: token
  *         description: Payment token of the customer
  *         in: query
  *         required: true
  *         type: string
  *     responses:
  *       200:
  *         description: Get Nonce
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger2
  *  /api/users/ticketToMoney:
  *   put:
  *     tags:
  *       - User
  *     description: Ticket To Money Conversion
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: user
  *         description: User object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/TicketToMoney'
  *     responses:
  *       200:
  *         description: Ticket To Money Conversion
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  *  /api/users/rewardToTicket:
  *   put:
  *     tags:
  *       - User
  *     description: Reward To Ticket Conversion
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: user
  *         description: User object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/RewardToTicket'
  *     responses:
  *       200:
  *         description: Reward To Ticket Conversion
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  *  /api/users/depositMoney:
  *   put:
  *     tags:
  *       - User
  *     description: Deposit Money (Pass empty nonce for the repeated user)
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: user
  *         description: User object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/Deposit'
  *     responses:
  *       200:
  *         description: Deposit Money
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/users/balanceMoney:
  *   get:
  *     tags:
  *       - User
  *     description: Returns a User's balance amount
  *     produces:
  *       - application/json
  *     responses:
  *       200:
  *         description: User's balance amount listed successfully.
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */
 /**
  * @swagger
  *  /api/users/withdrawalRequest:
  *   put:
  *     tags:
  *       - User
  *     description: Withdrawal Money
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: user
  *         description: User object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/withdrawals'
  *     responses:
  *       200:
  *         description: Withdrawal Money requested successfully.
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */
 /**
  * @swagger2
  * /api/users/withdrawalStatus:
  *   get:
  *     tags:
  *       - User
  *     description: Returns a User's withdrawal status
  *     produces:
  *       - application/json
  *     responses:
  *       200:
  *         description: User's withdrawal status listed successfully.
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/users/getwithdrawalrequests:
  *   get:
  *     tags:
  *       - User
  *     description: Returns withdrawal requests
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: status
  *         description:  P - Pending, C - Closed, R - Rejected, I - In progress
  *         in: query
  *         required: false
  *         type: string
  *       - name: page_number
  *         description: Page Number
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 0
  *       - name: page_limit
  *         description: Number of records in a page
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 5 
  *     responses:
  *       200:
  *         description: All records retrieved successfully.
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/users/transactions:
  *   get:
  *     tags:
  *       - User
  *     description: Returns transactions
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: transaction_type
  *         description:  D - Deposit, W - Withdrawal
  *         in: query
  *         required: false
  *         type: string
  *       - name: page_number
  *         description: Page Number
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 0
  *       - name: page_limit
  *         description: Number of records in a page
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 5
  *     responses:
  *       200:
  *         description: All records retrieved successfully.
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/users/notifications:
  *   get:
  *     tags:
  *       - User
  *     description: Returns User's Notification
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: page_number
  *         description: Page Number
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 0
  *       - name: page_limit
  *         description: Number of records in a page
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 5   
  *     responses:
  *       200:
  *         description: User's Notifications retrieved successfully.
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */
 /**
  * @swagger
  * /api/users/updateNotification:
  *   put:
  *     tags:
  *       - User
  *     description: Update notification- Mark all notifications as read
  *     produces:
  *       - application/json
  *     responses:
  *       200:
  *         description: Update notification successfully completed.
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */
 /**
  * @swagger
  *  /api/users/settings:
  *   put:
  *     tags:
  *       - User
  *     description: User settings update
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: user
  *         description: User object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/settings'
  *     responses:
  *       200:
  *         description: Profile settings update successfully completed.
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/users/settings:
  *   get:
  *     tags:
  *       - User
  *     description: Returns a User's settings
  *     produces:
  *       - application/json
  *     responses:
  *       200:
  *         description: Returns a User's settings
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  *  /api/users/feedback:
  *   post:
  *     tags:
  *       - User
  *     description: Send feedback details to Admin via email.
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: user
  *         description: User object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/feedback'
  *     responses:
  *       200:
  *         description: Send feedback details to Admin via email.
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  *  /api/users/support:
  *   post:
  *     tags:
  *       - User
  *     description: send support details to Admin via email.
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: user
  *         description: User object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/support'
  *     responses:
  *       200:
  *         description: Send feedback details to Admin via email.
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/users/listusers:
  *   get:
  *     tags:
  *       - User
  *     description: Returns all Users
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: page_number
  *         description: Page Number
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 0
  *       - name: page_limit
  *         description: Number of records in a page
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 5   
  *       - name: search_text
  *         description: Search String
  *         in: query      
  *         type: string
  *     responses:
  *       200:
  *         description: All records retrieved successfully.
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/users/listFBFriends:
  *   get:
  *     tags:
  *       - User
  *     description: Returns all matching FB friends (users)
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: page_number
  *         description: Page Number
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 0
  *       - name: page_limit
  *         description: Number of records in a page
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 5   
  *       - name: search_text
  *         description: Search String
  *         in: query      
  *         type: string
  *     responses:
  *       200:
  *         description: Records retrieved successfully.
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  *  /api/users/friendrequest:
  *   post:
  *     tags:
  *       - User
  *     description: Send friend request
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: user
  *         description: User object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/friendrequest'
  *     responses:
  *       200:
  *         description: Sent friend request successfully completed.
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */
 /**
  * @swagger
  *  /api/users/respondfriendrequest:
  *   put:
  *     tags:
  *       - User
  *     description: Respond to  friend request- 1- Accept, 2- Decline
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: user
  *         description: User object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/respondfriendrequest'
  *     responses:
  *       200:
  *         description: Respond to friend request successfully completed.
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/users/getfriendrequest:
  *   get:
  *     tags:
  *       - User
  *     description: Returns friend requests
  *     produces:
  *       - application/json  
  *     responses:
  *       200:
  *         description: Friend requests retrieved successfully.
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  * /api/users/listFriends:
  *   get:
  *     tags:
  *       - User
  *     description: Returns all friends
  *     produces:
  *       - application/json 
  *     parameters:
  *       - name: page_number
  *         description: Page Number
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 0
  *       - name: page_limit
  *         description: Number of records in a page
  *         in: query
  *         required: true
  *         type: integer
  *         format: int64
  *         default: 5   
  *       - name: search_text
  *         description: Search String
  *         in: query      
  *         type: string
  *     responses:
  *       200:
  *         description: Friends retrieved successfully.
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
  * @swagger
  *  /api/users/unfriend:
  *   delete:
  *     tags:
  *       - User
  *     description: Unfriend request
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: user
  *         description: User object
  *         in: body
  *         required: true
  *         schema:
  *           $ref: '#/definitions/unfriendrequest'
  *     responses:
  *       200:
  *         description: Unfriend request successfully completed.
  *     security:
  *       - ApiKey: []
  *       - SessionKey: []
  *       - GeoToken: []
  */

 /**
 * @swagger2
 * /api/users/addUserTicket:
 *   post:
 *     tags:
 *       - User
 *     description: Add ticket (Ticket status, N - New, U - Used)
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userTicket
 *         description: Ticket object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/AddTicketRequest'
 *     responses:
 *       200:
 *         description: Ticket has been added successfully.
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

  /**
 * @swagger2
 * /api/users/addTicketToStore:
 *   post:
 *     tags:
 *       - User
 *     description: Add ticket to store
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: ticketStore
 *         description: Ticket store object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/TicketStoreRequest'
 *     responses:
 *       200:
 *         description: Ticket has been added successfully.
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 */

  /**
  * @swagger
  * /api/users/getStoreTickets:
  *   get:
  *     tags:
  *       - User
  *     description: Returns ticket store
  *     produces:
  *       - application/json
  *     responses:
  *       200:
  *         description: Returns ticket store
  *         schema:
  *           $ref: '#/definitions/GeneralResult'
  *     security:
  *       - ApiKey: []
  *       - SessionKey: [] 
  */
