/**
 * @swagger
 * definitions:
 *   Contest:
 *     type: object
 *     required:
 *       - entryFee
 *       - contestTypeId
 *       - gameTypeId
 *       - draftgroupId
 *     properties:
 *       entryFee:
 *         type: integer
 *         format: int64
 *       visibilityStatus:
 *         type: string
 *         enum:
 *         - Public
 *         - Private
 *       contestTypeId:
 *         type: integer
 *         format: int64
 *       gameTypeId:
 *         type: integer
 *         format: int64
 *       draftgroupId:
 *         type: integer
 *         format: int64
 *       participantSize:
 *         type: integer
 *         format: int64
 *       maxEntriesPerUser:
 *         type: integer
 *         format: int64
 *       sportId:
 *         type: integer
 *         format: int64
 *       prizetypeId:
 *         type: integer
 *         format: int64
 *       numToCreate:
 *         type: integer
 *         format: int64
 */

/**
 * @swagger
 * definitions:
 *   ContestUpdate:
 *     type: object
 *     required:
 *       - entryFee
 *       - contestTypeId
 *       - gameTypeId
 *       - draftgroupId
 *     properties:
 *       entryFee:
 *         type: integer
 *         format: int64
 *       visibilityStatus:
 *         type: string
 *         enum:
 *         - Public
 *         - Private
 *       contestTypeId:
 *         type: integer
 *         format: int64
 *       gameTypeId:
 *         type: integer
 *         format: int64
 *       draftgroupId:
 *         type: integer
 *         format: int64
 *       participantSize:
 *         type: integer
 *         format: int64
 *       maxEntriesPerUser:
 *         type: integer
 *         format: int64
 *       sportId:
 *         type: integer
 *         format: int64
 *       prizetypeId:
 *         type: integer
 *         format: int64
 */

/**
 * @swagger
 * definitions:
 *   ContestUsers:
 *     type: object
 *     properties:
 *       _id:
 *         type: string
 *       email:
 *         type: string
 */

/**
 * @swagger
 * definitions:
 *   JoinContest:
 *     type: object
 *     required:
 *       - contestId
 *       - draftgroupId
 *       - sportId
 *     properties:
 *       contestId:
 *         type: integer
 *         format: int64
 *       draftgroupId:
 *         type: integer
 *         format: int64
 *       sportId:
 *         type: integer
 *         format: int64
 *       sName:
 *         type: string
 *       ticketId:
 *         type: string
 *       players:
 *         type: array
 *         items:        
 *           $ref: "#/definitions/LineupPlayers"
 */

/**
 * @swagger
 * definitions:
 *   LineupPlayers:
 *     type: object
 *     required:
 *       - eventId
 *       - playerId
 *     properties:
 *       eventId:
 *         type: integer
 *         format: int64
 *       tmpPosId:
 *         type: integer
 *         format: int64
 *       tmpPosAbbr:
 *         type: string
 *       tmpPosName:
 *         type: string
 *       tmpId:
 *         type: integer
 *         format: int64
 *       playerId:
 *         type: integer
 *         format: int64
 */

/**
 * @swagger
 * definitions:
 *   AllLineups:
 *     type: object
 *     required:
 *       - draftgroupId
 *       - sportId
 *       - lineupIds
 *     properties:
 *       lineupIds:
 *         type: array
 *       draftgroupId:
 *         type: integer
 *         format: int64
 *       sportId:
 *         type: integer
 *         format: int64
 *       sName:
 *         type: string
 *       players:
 *         type: array
 *         items:        
 *           $ref: "#/definitions/LineupPlayers"
 */

/**
 * @swagger
 * definitions:
 *   joinMultipleContest:
 *     type: object
 *     required:
 *       - contestId
 *       - draftgroupId
 *       - sportId
 *     properties:
 *       contestId:
 *         type: array       
 *       draftgroupId:
 *         type: integer
 *         format: int64
 *       sportId:
 *         type: integer
 *         format: int64
 *       sName:
 *         type: string
 *       players:
 *         type: array
 *         items:        
 *           $ref: "#/definitions/LineupPlayers"
 */
/**
 * @swagger
 * definitions:
 *   JoinContestLineupId:
 *     type: object
 *     required:
 *       - contestId
 *       - lineupId  
 *     properties:
 *       contestId:
 *         type: integer
 *         format: int64
 *       lineupId:
 *         type: integer
 *         format: int64
 *       ticketId:
 *         type: string
 * 
 */

/**
 * @swagger
 * /api/contests:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns all ongoing contests
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sort_order
 *         description: Sort Order (asc or desc)
 *         in: query
 *         required: true
 *         type: string
 *         default: asc
 *       - name: sort_field
 *         description: Sort field name
 *         in: query
 *         required: false
 *         type: string
 *       - name: search_text
 *         description: Search String
 *         in: query
 *         required: false
 *         type: string
 *       - name: visibility
 *         description: Private or Public, by default Public
 *         in: query
 *         required: false
 *         type: string
 *         default: Public
 *       - name: sportId
 *         description: 1-NFL, 2-MLB, 3-NHL, 4-NBA 5-GOLF
 *         in: query
 *         required: false
 *         type: integer
 *         format: int64
 *       - name: contestTypeId
 *         description: 1-Multiplayer, 2-H2H
 *         in: query
 *         required: false
 *         type: integer
 *         format: int64
 *       - name: status
 *         description: 1-Completed, 2-Live, 3-Upcoming, 4-Cancelled
 *         in: query
 *         required: false
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Get all records
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */


/**
 * @swagger
 * /api/contests/getGames/{id}:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns a single contest's games
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5
 *       - name: id
 *         description: contest's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Get single record
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */


/**
 * @swagger
 * /api/contests:
 *   post:
 *     tags:
 *       - Contest
 *     description: Creates a new contest
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: contest
 *         description: Contest object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Contest'
 *     responses:
 *       200:
 *         description: Successfully created
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */



/**
 * @swagger
 * /api/contests/{id}:
 *   put:
 *     tags: 
 *       - Contest
 *     description: Updates a single contest
 *     produces: 
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: contest's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *       - name: contest
 *         description: Fields for the contest resource
 *         in: body
 *         schema:
 *           $ref: '#/definitions/ContestUpdate'
 *     responses:
 *       200:
 *         description: Successfully updated
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */


/**
 * @swagger
 * /api/contests/{id}:
 *   delete:
 *     tags:
 *       - Contest
 *     description: Deletes a single contest
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: Contest's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Successfully deleted
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/contests/getStandings/{id}:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns all standings in a contest
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5
 *       - name: sort_order
 *         description: Position Sort Order (asc or desc)
 *         in: query
 *         required: true
 *         type: string
 *         default: asc
 *       - name: id
 *         description: contest's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns all standings in a contest
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/contests/joinContest:
 *   post:
 *     tags:
 *       - Contest
 *     description: Join to a multiplayer contest
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: contest
 *         description: Contest object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/JoinContest'
 *     responses:
 *       200:
 *         description: Successfully created
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/contests/getLineUps/{id}:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns all lineups in a contest
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: Contest's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns lineups in Contest
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/contests/getMyContests:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns all contests by userId
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sort_field
 *         description: Sort field name
 *         in: query
 *         required: false
 *         type: string
 *       - name: sort_order
 *         description: Sort Order (asc or desc by contest name)
 *         in: query
 *         required: true
 *         type: string
 *         default: asc
 *       - name: sportId
 *         description: 1-NFL, 2-MLB, 3-NHL, 4-NBA 5-GOLF
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *       - name: contestTypeId
 *         description: 1-Multiplayer, 2-H2H
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns all contest by UserId
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/contests/lineUp/{id}:
 *   put:
 *     tags:
 *       - Contest
 *     description: Update a multiplayer contest Lineup
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: Lineup's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *       - name: lineup
 *         description: Lineup object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/JoinContest'
 *     responses:
 *       200:
 *         description: Successfully updated
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/contests/lineUp/{id}:
 *   get:
 *     tags:
 *       - Contest
 *     description: Get a multiplayer contest Lineup
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: Lineup's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns all contest by UserId
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/contests/getFeatured:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns all live and upcoming Featured contests
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: page_number
 *         description: Page Number
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 0
 *       - name: page_limit
 *         description: Number of records in a page
 *         in: query
 *         required: true
 *         type: integer
 *         format: int64
 *         default: 5
 *       - name: sort_order
 *         description: Sort Order (asc or desc)
 *         in: query
 *         required: true
 *         type: string
 *         default: asc
 *       - name: sort_field
 *         description: Sort field name
 *         in: query
 *         required: false
 *         type: string
 *       - name: search_text
 *         description: Search String
 *         in: query
 *         required: false
 *         type: string
 *       - name: visibility
 *         description: Private or Public, by default Public
 *         in: query
 *         required: false
 *         type: string
 *         default: Public
 *     responses:
 *       200:
 *         description: Get all records
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/contests/getLineUpTemplate:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns a sport's lineup Template based on game type
 *     produces:
 *       - application/json
 *     responses:
 *       200:
 *         description: Get all records
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/contests/getAllMyContests:
 *   get:
 *     tags:
 *       - Contest
 *     description: Returns all contests by userId
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: sort_field
 *         description: Sort field name
 *         in: query
 *         required: false
 *         type: string
 *       - name: sort_order
 *         description: Sort Order (asc or desc by contest name)
 *         in: query
 *         required: true
 *         type: string
 *         default: asc
 *       - name: sportId
 *         description: 1-NFL, 2-MLB, 3-NHL, 4-NBA 5-GOLF
 *         in: query
 *         required: false
 *         type: integer
 *         format: int64
 *       - name: status
 *         description: 1-Completed, 2-Live, 3-Upcoming, 4-Cancelled
 *         in: query
 *         required: false
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns all contest by UserId
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 *  /api/contests/createContestTemplate:
 *   get:
 *     tags:
 *       - Contest
 *     description: Get Contest Prize Template
 *     produces:
 *       - application/json
 *     responses:
 *       200:
 *         description: Template listed successfully.
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/contests/{id}:
 *   get:
 *     tags:
 *       - Contest
 *     description: Get a contest detail
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: id
 *         description: Contest's id
 *         in: path
 *         required: true
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Returns contest by contestId
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/contests/lineupUpdateAll:
 *   put:
 *     tags:
 *       - Contest
 *     description: Update Lineups All
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: lineup
 *         description: Lineup object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/AllLineups'
 *     responses:
 *       200:
 *         description: Successfully updated
 *         schema:
 *           $ref: '#/definitions/GeneralResult'
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */

/**
 * @swagger
 * /api/contests/unjoinlineup:
 *   delete:
 *     tags:
 *       - Contest
 *     description: Deletes a Lineup by lineupId
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: contestId
 *         description: contestId
 *         in: query       
 *         type: integer        
 *         format: int64
 *       - name: lineupId
 *         description: lineupId
 *         in: query        
 *         type: integer
 *         format: int64
 *     responses:
 *       200:
 *         description: Successfully deleted
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */
/**
 * @swagger
 * /api/contests/joinMultipleContest:
 *   post:
 *     tags:
 *       - Contest
 *     description: Join to mutiple H2H contests(only H2H)
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: contest
 *         description: Contest object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/joinMultipleContest'
 *     responses:
 *       200:
 *         description: Successfully created
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */
/**
 * @swagger
 * /api/contests/joinWithLineUpId:
 *   post:
 *     tags:
 *       - Contest
 *     description: Join to a  contest with lineupId
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: contest
 *         description: Contest object
 *         in: body
 *         required: true
 *         schema:
 *           $ref: '#/definitions/JoinContestLineupId'
 *     responses:
 *       200:
 *         description: Successfully created
 *     security:
 *       - ApiKey: []
 *       - SessionKey: []
 *       - GeoToken: []
 */