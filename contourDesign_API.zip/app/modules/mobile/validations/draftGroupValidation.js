/**
 * DraftGroup Validation
 * @exports DraftGroup/Validation
 */
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/draftGroupTrans.json');
const numberRegEx = /^\d+(\.\d{1,2})?$/;


module.exports = {

	/**
	 * Validation for the data - get draftgroups
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	listDraftValidation: function (req, res) {
		try {
			/*if (!req.query.week || req.query.week == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in week", _t.weekRequired);
			}
			if (!req.query.season || req.query.season == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in season", _t.seasonRequired);
			}*/
			if (!req.query.sportId || req.query.sportId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in sportId", _t.sportIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},


	/**
	 * Validation for the data - get draftgroups details/players by id
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	DraftgroupIdValidation: function (req, res) {
		try {
			if (!req.params.id || req.params.id == 0) {
				return generalHelper.handleError(req, res, "Record not found", _t.draftgroupIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},
};