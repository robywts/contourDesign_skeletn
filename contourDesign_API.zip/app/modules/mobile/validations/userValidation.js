/**
 * User Validation
 * @exports User/Validation
 */
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/userTrans.json');
const numberRegEx = /^\d+(\.\d{1,2})?$/;
const allNumberRegEx = /^\d+(\.\d{1,2})?$/;


module.exports = {

	/**
	 *  * Validation for the data - update Profile
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	updateProfileValidation: function (req, res) {
		if (!req.body.fName) {
			return generalHelper.handleError(req, res, "Invalid Input in fname", _t.fnameRequired);
		}
		if (!req.body.lName) {
			return generalHelper.handleError(req, res, "Invalid Input in lname", _t.lnameRequired);
		}
	},

	/**
	 * Validation for the data - Ticket To Money Conversion
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	// ticketToMoney: function (req, res) {
	// 	if (!req.body.tickets) {
	// 		return generalHelper.handleError(req, res, "Invalid Input in ticket", _t.ticketsRequired);
	// 	} else {
	// 		if (!numberRegEx.test(req.body.tickets)) {
	// 			return generalHelper.handleError(req, res, "Invalid tickets", _t.ticketsInvalid);
	// 		}
	// 	}
	// },

	/**
	 * Validation for the data - Reward To Money Conversion
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	// rewardToMoney: function (req, res) {
	// 	if (!req.body.rewards) {
	// 		return generalHelper.handleError(req, res, "Invalid Input in rewards", _t.rewardsRequired);
	// 	} else {
	// 		if (!numberRegEx.test(req.body.rewards)) {
	// 			return generalHelper.handleError(req, res, "Invalid rewards", _t.rewardsInvalid);
	// 		}
	// 	}
	// },

	/**
	 * Validation for the data - Reward To Ticket Conversion
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	rewardToTicket: function (req, res) {
		if (!req.body.rewards) {
			return generalHelper.handleError(req, res, "Invalid Input in rewards", _t.rewardsRequired);
		} else {
			if (!numberRegEx.test(req.body.rewards)) {
				return generalHelper.handleError(req, res, "Invalid rewards", _t.rewardsInvalid);
			}
		}
	},

	/**
	 * Validation for the data - deposit Money
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	depositMoneyValidation: function (req, res) {
		// if (!req.body.nonce) {
		// 	return generalHelper.handleError(req, res, "Invalid Input in nonce", _t.nonceRequired);
		// }
		if (!req.body.amount) {
			return generalHelper.handleError(req, res, "Invalid Input in amount", _t.amountRequired);
		} else {
			if (!numberRegEx.test(req.body.amount)) {
				return generalHelper.handleError(req, res, "Invalid amount", _t.amountInvalid);
			}
		}
	},

	/**
	 * Validation for the data - withdrawal Amount
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	withdrawalValidation: function (req, res) {
		if (!req.body.amount) {
			return generalHelper.handleError(req, res, "Invalid Input in amount", _t.amountRequired);
		} else {
			if (!numberRegEx.test(req.body.amount)) {
				return generalHelper.handleError(req, res, "Invalid amount", _t.amountInvalid);
			}
		}
	},

	/**
	 *  * Validation for the data - update Settings
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	updateSettingsValidation: function (req, res) {

		if (req.body.spendLimits.daily === '') {
			return generalHelper.handleError(req, res, "Invalid Input in spending daily", _t.dailySpendingRequired);
		}
		if (req.body.spendLimits.weekly === '') {
			return generalHelper.handleError(req, res, "Invalid Input in spending weekly", _t.weeklySpendingRequired);
		} else if (req.body.spendLimits.weekly < req.body.spendLimits.daily && req.body.spendLimits.weekly != -1 && req.body.spendLimits.daily != -1) {
			return generalHelper.handleError(req, res, "weekly less than daily spending", _t.weeklySpendingGreater);
		}
		if (req.body.spendLimits.monthly === '') {
			return generalHelper.handleError(req, res, "Invalid Input in spending monthly", _t.monthlySpendingRequired);
		} else if (req.body.spendLimits.monthly < req.body.spendLimits.weekly && req.body.spendLimits.monthly != -1 && req.body.spendLimits.weekly != -1) {
			return generalHelper.handleError(req, res, "Monthly less than weekly spending", _t.monthlySpendingGreater);
		}
		if (req.body.spendLimits.maxEntryFee === '') {
			return generalHelper.handleError(req, res, "Invalid Input in max entry fee", _t.maxEntryFeeRequired);
		}
		if (!allNumberRegEx.test(req.body.spendLimits.daily) || !allNumberRegEx.test(req.body.spendLimits.weekly) || !allNumberRegEx.test(req.body.spendLimits.monthly) || !allNumberRegEx.test(req.body.spendLimits.maxEntryFee)) {
			return generalHelper.handleError(req, res, "Invalid amount in spending", _t.amountInvalid);
		}

		if (req.body.depositLimits.daily === '') {
			return generalHelper.handleError(req, res, "Invalid Input in deposit daily", _t.dailyDepositRequired);
		}
		if (req.body.depositLimits.weekly === '') {
			return generalHelper.handleError(req, res, "Invalid Input in deposit weekly", _t.weeklyDepositRequired);
		} else if (req.body.depositLimits.weekly < req.body.depositLimits.daily && req.body.depositLimits.weekly != -1 && req.body.depositLimits.daily != -1) {
			return generalHelper.handleError(req, res, "weekly less than daily deposit", _t.weeklyDepositGreater);
		}
		if (req.body.depositLimits.monthly === '') {
			return generalHelper.handleError(req, res, "Invalid Input in deposit monthly", _t.monthlyDepositRequired);
		} else if (req.body.depositLimits.monthly < req.body.depositLimits.weekly && req.body.depositLimits.monthly != -1 && req.body.depositLimits.weekly != -1) {
			return generalHelper.handleError(req, res, "Monthly less than weekly deposit", _t.monthlyDepositGreater);
		}
		if (!allNumberRegEx.test(req.body.depositLimits.daily) || !allNumberRegEx.test(req.body.depositLimits.weekly) || !allNumberRegEx.test(req.body.depositLimits.monthly)) {
			return generalHelper.handleError(req, res, "Invalid amount in deposit", _t.amountInvalid);
		}
	},

	/**
	 *   Validation for the data - send Feedback
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	sendFeedbackValidation: function (req, res) {
		if (!req.body.feedback) {
			return generalHelper.handleError(req, res, "Invalid Input in feedback", _t.feedbackRequired);
		}
	},
	/**
	 *  Validation for the data - contact Support
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	contactSupportValidation: function (req, res) {
		if (!req.body.message) {
			return generalHelper.handleError(req, res, "Invalid Input in mesage", _t.supportmesageRequired);
		}
	},
	/**
	 *  Validation for the data - send Friend request
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	friendRequestValidation: function (req, res) {
		if (!req.body.toUserId) {
			return generalHelper.handleError(req, res, "Invalid Input in toUserId", _t.toUserIdRequired);
		}

		if (req.body.toUserId == global.userId) {
			return generalHelper.handleError(req, res, "Invalid Input in toUserId", _t.invalidToUserId);
		}
	},
	/**
	 *  Validation for the data - respond to Friendrequest
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	friendValidation: function (req, res) {
		if (!req.body.response) {
			return generalHelper.handleError(req, res, "Invalid Input in response", _t.responseRequired);
		}
		if (req.body.response != 1 && req.body.response != 2) {
			return generalHelper.handleError(req, res, "Invalid request", _t.invalidRequest);
		}
		if (!req.body.fromUserId) {
			return generalHelper.handleError(req, res, "Invalid Input in fromUserId", _t.fromUserIdRequired);
		}
	},

	/**
	 *  Validation for the data - Unfriend a friend
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	unFriendValidation: function (req, res) {
		if (!req.body.friendId) {
			return generalHelper.handleError(req, res, "Invalid Input in friendId", _t.friendidRequired);
		}

	},

	/**
	 * Validation for the data - Search for FB friends in the database
	 * @param {Array} fbFriends - Fb Id Array
	 * @return {boolean} False 
	 */
	facebookIdsValidation: function (req, res, fbFriends) {
		if (fbFriends.length == 0) {
			return generalHelper.handleError(req, res, "Invalid Input in Facebook Id", _t.fbidRequired);
		}
	},

		/**
	 * Validation for the data - User ticket
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	ticketValidation: function (req, res) {
		if (!req.body.ticketAmount) {
			return generalHelper.handleError(req, res, "Invalid Input in ticket amount", _t.ticketAmountRequired);
		} else {			
			if (!numberRegEx.test(req.body.ticketAmount)) {
				return generalHelper.handleError(req, res, "Invalid ticket amount", _t.ticketAmountInvalid);
			}
		}
		if (!req.body.ticketStatus) {
			return generalHelper.handleError(req, res, "Invalid Input in ticket status", _t.ticketStatusRequired);
		}
		else
		{
			if(req.body.ticketStatus.toUpperCase() != "N" && req.body.ticketStatus.toUpperCase() != "U")
			{
				return generalHelper.handleError(req, res, "Invalid ticket status", _t.ticketStatusInvalid);
			}
		}
	},

	/**
	 * Validation for the data - Ticket store
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	ticketStoreValidation: function (req, res) {
		if (!req.body.ticketAmount) {
			return generalHelper.handleError(req, res, "Invalid Input in ticket amount", _t.ticketAmountRequired);
		} else {			
			if (!numberRegEx.test(req.body.ticketAmount)) {
				return generalHelper.handleError(req, res, "Invalid ticket amount", _t.ticketAmountInvalid);
			}
		}
		if (!req.body.totalRewards) {
			return generalHelper.handleError(req, res, "Invalid Input in ticket status", _t.ticketStatusRequired);
		}
		else {			
			if (!numberRegEx.test(req.body.totalRewards)) {
				return generalHelper.handleError(req, res, "Invalid ticket amount", _t.ticketAmountInvalid);
			}
		}
	},

};