/**
 * User Auth Validation
 * @exports UserAuth/Validation
 */
var generalHelper = require('../helpers/generalHelper');
var moment = require('moment');
var _t = require('../translations/' + process.env.LANGUAGE + '/userAuthTrans.json');
const emailRegEx = /\S+@\S+\.\S+/;
// const dateRegEx = /^\d+(\.\d{1,2})?$/;

module.exports = {
	/**
	 * Validation for the data to be registered with
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False
	 */
	registerValidation: function (req, res) {
		try {
			if (!req.body.userName) {
				return generalHelper.handleError(req, res, "Invalid Input in user name", _t.userNameRequired);
			}
			if (!req.body.email) {
				return generalHelper.handleError(req, res, "Invalid Input in email", _t.emailRequired);
			} else {
				if (!emailRegEx.test(req.body.email)) {
					return generalHelper.handleError(req, res, "Invalid email", _t.emailInvalid);
				}
			}
			if (!req.body.pwd) {
				return generalHelper.handleError(req, res, "Invalid Input in password", _t.passwordRequired);
			}
			if (!req.body.dob) {
				return generalHelper.handleError(req, res, "Invalid Input in dob", _t.dobRequired);
			} else if (moment().diff(moment(req.body.dob, 'YYYY-MM-DD'), 'years') < 18) {
				return generalHelper.handleError(req, res, "Invalid Age in dob", _t.dobAgeRestricted);
			}
			return this.deviceTokenValidation(req, res);
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the fb data to be merged with (only for login users)
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False
	 */
	fbMergeValidation: function (req, res) {
		try {
			if (!req.body.fbToken) {
				return generalHelper.handleError(req, res, "Invalid Input in fbToken", _t.fbTokenRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the fb data to be registered with
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False
	 */
	fbRegisterValidation: function (req, res) {
		try {
			// if (!req.body.userName) {
			// 	return generalHelper.handleError(req, res, "Invalid Input in user name", _t.userNameRequired);
			// }
			if (!req.body.fbToken) {
				return generalHelper.handleError(req, res, "Invalid Input in fbToken", _t.fbTokenRequired);
			}
			// if (!req.body.fbId) {
			// 	return generalHelper.handleError(req, res, "Invalid Input in fbId", _t.fbIdRequired);
			// }
			if (!req.body.email) {
				// return generalHelper.handleError(req, res, "Invalid Input in email", _t.emailRequired);
			} else {
				if (!emailRegEx.test(req.body.email)) {
					return generalHelper.handleError(req, res, "Invalid email", _t.emailInvalid);
				}
			}
			// if (!req.body.dob) {
			// 	return generalHelper.handleError(req, res, "Invalid Input in dob", _t.dobRequired);
			// }
			return this.deviceTokenValidation(req, res);
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data to be login with
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	loginValidation: function (req, res) {
		try {
			if (!req.body.email) {
				return generalHelper.handleError(req, res, "Invalid Input in email", _t.emailRequired);
			}
			if (!req.body.pwd) {
				return generalHelper.handleError(req, res, "Invalid Input in password", _t.passwordRequired);
			}
			return this.deviceTokenValidation(req, res);
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - forgot password
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	forgotValidation: function (req, res) {
		try {
			if (!req.body.email) {
				return generalHelper.handleError(req, res, "Invalid Input in email", _t.emailRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - reset password
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	resetValidation: function (req, res) {
		try {
			if (!req.body.email) {
				return generalHelper.handleError(req, res, "Invalid Input in email", _t.emailRequired);
			}
			if (!req.body.resetCode) {
				return generalHelper.handleError(req, res, "Invalid reset code", _t.resetCodeRequired);
			}
			if (!req.body.pwd) {
				return generalHelper.handleError(req, res, "Invalid Input in password", _t.passwordRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - change password
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	changePasswordValidation: function (req, res) {
		try {
			if (!req.body.oldPwd) {
				return generalHelper.handleError(req, res, "Invalid Input in old password", _t.oldPasswordRequired);
			}
			if (!req.body.pwd) {
				return generalHelper.handleError(req, res, "Invalid Input in new password", _t.newPasswordRequired);
			}
			if (req.body.confirmPwd != req.body.pwd) {
				return generalHelper.handleError(req, res, "Passwords are not same", _t.confirmPasswordNotMatching);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the device token to be updated
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False
	 */
	deviceTokenValidation: function (req, res) {
		try {
			if (!req.body.deviceToken) {
				return generalHelper.handleError(req, res, "Invalid Input in deviceToken", _t.deviceTokenRequired);
			}
			if (req.body.deviceType === '') {
				return generalHelper.handleError(req, res, "Invalid Input in deviceType", _t.deviceTypeRequired);
			} else if (![0, 1, 2].includes(req.body.deviceType)) {
				return generalHelper.handleError(req, res, "Invalid Input value in deviceType", _t.deviceTypeInvalid);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation of lat and lng data
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	geoTokenValidation: function (req, res) {
		if (!req.body.lat) {
			return generalHelper.handleError(req, res, "Invalid Input in Latitude", _t.latRequired);
		}
		if (!req.body.lng) {
			return generalHelper.handleError(req, res, "Invalid Input in Longitude", _t.latRequired);
		}
	},
};