/**
 * Contest Validation
 * @exports Contest/Validation
 */
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/contestTrans.json');

module.exports = {
	/**
	 * Validation for the data to be added
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	addValidation: function (req, res, prizeTemplate) {
		try {
			if (req.body.entryFee == undefined || req.body.entryFee < 0) {
				return generalHelper.handleError(req, res, "Invalid Input in entry fees", _t.entryFeesRequired);
			}
			if (!req.body.contestTypeId || req.body.contestTypeId < 1 || req.body.contestTypeId > 2) {
				return generalHelper.handleError(req, res, "Invalid Input in contest type Id", _t.contestTypeIdRequired);
			}
			if (!req.body.gameTypeId || req.body.gameTypeId < 1) {
				return generalHelper.handleError(req, res, "Invalid Input in game type Id", _t.gameTypeIdRequired);
			}
			if (!req.body.draftgroupId || req.body.draftgroupId < 1) {
				return generalHelper.handleError(req, res, "Invalid Input in draftgroup Id", _t.draftgroupIdRequired);
			}
			if (!req.body.sportId || req.body.sportId < 1 || req.body.sportId > 5) {
				return generalHelper.handleError(req, res, "Invalid Input in sport Id", _t.sportIdRequired);
			}
			if (!req.body.participantSize || req.body.participantSize < 1) {
				return generalHelper.handleError(req, res, "Invalid Input in participantSize", _t.participantSizeRequired);
			}
			if (!req.body.prizetypeId || req.body.prizetypeId < 1) {
				return generalHelper.handleError(req, res, "Invalid Input in prizetypeId", _t.prizetypeIdRequired);
			}
			if (req.body.participantSize < prizeTemplate.minLimit && req.body.contestTypeId != 2) {
				return generalHelper.handleError(req, res, "Invalid Input in participantSize", _t.participantSizeGTTemplatePrize);
			}
			if (req.body.gameTypeIdDB.indexOf(req.body.gameTypeId) == -1) {
				return generalHelper.handleError(req, res, "Invalid Input in game type Id", _t.gameTypeIdMissmatch);
			}
			/*if (!req.body.numToCreate && req.body.numToCreate < 1) {
				return generalHelper.handleError(req, res, "Invalid Input in numToCreate", _t.numToCreateRequired);
			}*/
			if (!req.body.maxEntriesPerUser) {
				return generalHelper.handleError(req, res, "Invalid Input in maxEntriesPerUser", _t.maxEntriesPerUserRequired);
			} else if (req.body.maxEntriesPerUser > req.body.participantSize) {
				return generalHelper.handleError(req, res, "Invalid Input in maxEntriesPerUser", _t.maxEntriesPerUserGreater);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data to be edited
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	editValidation: function (req, res) {
		try {
			if (!req.body.contestName) {
				return generalHelper.handleError(req, res, "Invalid Input in name", _t.nameRequired);
			}
			if (!req.body.entryFees) {
				return generalHelper.handleError(req, res, "Invalid Input in entry fees", _t.entryFeesRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - get contests by visibility
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	getAllValidation: function (req, res) {
		try {
			if (!req.query.sportId || req.query.sportId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in visibility", _t.contestSportIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - get contest's games and standings by contestId
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	getValidation: function (req, res) {
		try {
			if (!req.params.id || req.params.id == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in contestId", _t.contestIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data to be added for join contest
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	joinContestValidation: function (req, res) {
		try {
			if (!req.body.contestId || req.body.contestId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in contestId", _t.contestIdRequired);
			}
			if (!req.body.draftgroupId || req.body.draftgroupId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in draftgroupId", _t.draftgroupIdRequired);
			}
			if (!req.body.sportId || req.body.sportId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in sportId", _t.sportIdRequired);
			}
			if ((req.body.players).length == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in players", _t.playerDetailsRequired);
			}
			for (var i in req.body.players) {
				if (!req.body.players[i].eventId || req.body.players[i].eventId == 0) {
					return generalHelper.handleError(req, res, "Invalid Input in eventId", _t.eventIdRequired);
				}
				if (!req.body.players[i].playerId || req.body.players[i].playerId == 0) {
					return generalHelper.handleError(req, res, "Invalid Input in playerId", _t.playerIdRequired);
				}
			}

		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data to be updated for contest lineup
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	updateContestLineupValidation: function (req, res) {
		try {
			if (!req.params.id || req.params.id == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in lineupId", _t.lineupIdRequired);
			}
			if (!req.body.contestId || req.body.contestId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in contestId", _t.contestIdRequired);
			}
			if (!req.body.draftgroupId || req.body.draftgroupId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in draftgroupId", _t.draftgroupIdRequired);
			}
			if (!req.body.sportId || req.body.sportId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in sportId", _t.sportIdRequired);
			}
			if ((req.body.players).length == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in players", _t.playerDetailsRequired);
			}
			for (var i in req.body.players) {
				if (!req.body.players[i].eventId || req.body.players[i].eventId == 0) {
					return generalHelper.handleError(req, res, "Invalid Input in eventId", _t.eventIdRequired);
				}
				if (!req.body.players[i].playerId || req.body.players[i].playerId == 0) {
					return generalHelper.handleError(req, res, "Invalid Input in playerId", _t.playerIdRequired);
				}
			}

		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data - get lineup by lineUpId
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	getLineUpValidation: function (req, res) {
		try {
			if (!req.params.id || req.params.id == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in lineupId", _t.lineupIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data to get User's Contests
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	getMyContestValidation: function (req, res) {
		try {
			if (!req.query.sportId || req.query.sportId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in sportId", _t.sportIdRequired);
			}
			if (!req.query.contestTypeId || req.query.contestTypeId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in contestTypeId", _t.contestTypeIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data to get lineup Template
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	getTemplateValidation: function (req, res) {
		try {
			if (!req.query.sportId || req.query.sportId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in sportId", _t.sportIdRequired);
			}
			if (!req.query.gameTypeId || req.query.gameTypeId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in gameTypeId", _t.gameTypeIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for the data to be updated for contests lineup
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	updateContestLineupAllValidation: function (req, res) {
		try {
			/*if (!(((req.query.lineups).split(',')).some(isNaN)) && ((req.query.lineups).split(',')).length == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in lineupIds", _t.lineupIdsRequired);
			}*/
			if ((req.body.lineupIds).length == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in lineupIds", _t.lineupIdsRequired);
			}
			if (!req.body.draftgroupId || req.body.draftgroupId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in draftgroupId", _t.draftgroupIdRequired);
			}
			if (!req.body.sportId || req.body.sportId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in sportId", _t.sportIdRequired);
			}
			if ((req.body.players).length == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in players", _t.playerDetailsRequired);
			}
			for (var i in req.body.players) {
				if (!req.body.players[i].eventId || req.body.players[i].eventId == 0) {
					return generalHelper.handleError(req, res, "Invalid Input in eventId", _t.eventIdRequired);
				}
				if (!req.body.players[i].playerId || req.body.players[i].playerId == 0) {
					return generalHelper.handleError(req, res, "Invalid Input in playerId", _t.playerIdRequired);
				}
			}

		} catch (e) {
			throw e;
		}
	},

	/**
	 * Validation for unjoin a lineup
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	unjoinLineupValidation: function (req, res) {
		try {
			if (!req.query.contestId || req.query.contestId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in contestId", _t.contestIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},
	
	/**
	 * Validation for the data to be added for join contest with lineupId
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	joinContestWithLineUpIdValidation: function (req, res) {
		try {
			if (!req.body.contestId || req.body.contestId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in contestId", _t.contestIdRequired);
			}
			if (!req.body.lineupId || req.body.lineupId == 0) {
				return generalHelper.handleError(req, res, "Invalid Input in lineupId", _t.lineupIdRequired);
			}

		} catch (e) {
			throw e;
		}
	},
};