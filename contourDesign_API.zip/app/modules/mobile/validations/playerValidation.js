/**
 * Player Validation
 * @exports Player/Validation
 */
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/playerTrans.json');
const numberRegEx = /^\d+(\.\d{1,2})?$/;


module.exports = {

	/**
	 * Validation for the data
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	PlayerIdValidation: function (req, res) {
		try {
			if (!req.params.id || req.params.id == 0) {
				return generalHelper.handleError(req, res, "Record not found", _t.playerIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},
	
	/**
	 * Validation for the data
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	PlayerRequestValidation: function (req, res) {
		try {
			if (!req.params.id || req.params.id == 0) {
				return generalHelper.handleError(req, res, "Player id not found", _t.playerIdRequired);
			}
			if (!req.params.sid || req.params.sid == 0) {
				return generalHelper.handleError(req, res, "Sports id not found", _t.sportsIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},
	
	/**
	 * Validation for the data - event ids
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	EventIdValidation: function (req, res) {
		try {
			if (!req.query.id || req.query.id == 0) {
				return generalHelper.handleError(req, res, "Record not found", _t.eventIdRequired);
			}
		} catch (e) {
			throw e;
		}
	},
};