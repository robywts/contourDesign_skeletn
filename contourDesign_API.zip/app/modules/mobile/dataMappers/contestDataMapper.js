/**
 * Contest Data Mapper
 * @exports Contest/DataMapper
 */
var fbHelper = require('../helpers/fbHelper');

module.exports = {
    /**
     * Data Mapping for Search
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : requestData.page_limit;
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.sort = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            search.sort_field = (!requestData.sort_field) ? 'name' : requestData.sort_field;
            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
       * Data Mapping for Search
       * @param {Object} requestData - Request Query Object
       * @return {Object} Array of data
       */
    searchDataCustom: function (requestData) {
        try {
            var search = {};
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.sort = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            search.sort_field = (!requestData.sort_field) ? 'name' : requestData.sort_field;
            return search;
        } catch (e) {
            throw e;
        }
    },


    /**
     * Data Mapping for Add functionality
     * @param {Object} contest - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @param {Object} userDetails - User Object
     * @return {Object} Updated contest object
     */
    addData: function (contest, requestData, prizeTemplate, userDetails, userId = global.userId) {
        try {
            contest.entryFees = requestData.entryFee;
            contest.contestStartTime = requestData.startTimeUTC;
            contest.contestTypeId = requestData.contestTypeId;
            contest.contestType = (contest.contestTypeId == 1) ? 'Multiplayer' : 'H2H';
            contest.gameTypeId = requestData.gameTypeId;
            contest.gameType = (contest.gameTypeId < 6) ? 'Multiplier' : 'Salary Cap';
            contest.draftgroupId = requestData.draftgroupId;
            contest.visibility = requestData.visibilityStatus;
            contest.createdBy = userId;
            contest.sportId = requestData.sportId;
            contest.contestStatus = requestData.contestStatus ? requestData.contestStatus : 3;
            // contest.maxLimit = (contest.contestTypeId == 2) ? 2 : requestData.participantSize;
            contest.prizeTmpId = requestData.prizetypeId;
            var entrants = [];
            var entrantsObj = {};
            entrantsObj.userId = userId;
            entrantsObj.joinDate = new Date().toISOString();
            (typeof requestData.entrantsEntry !== 'undefined') ? (entrantsObj.totalentry = requestData.entrantsEntry) : '';
            entrants.push(entrantsObj);
            contest.entrants = entrants;
            //contest.prizePool = (contest.contestTypeId == 2) ? ((requestData.entryFee * 2) - (requestData.entryFee * 2) * (10 / 100)) : 0; //prizepool calculation for H2H only(for multiplayer prizepool cron is used) 
            contest.prizePool = (contest.contestTypeId == 2) ? ((requestData.entryFee * 2) - (requestData.entryFee * 2) * (10 / 100)) : ((requestData.entryFee * requestData.participantSize) - (requestData.entryFee * requestData.participantSize) * (10 / 100)); //prizepool calculation for H2H and multiplayer contest --- changed on 6 Aug 18
            contest.maxLimit = (contest.contestTypeId == 2) ? 2 : (requestData.participantSize);
            contest.maxEntriesPerUser = (contest.contestTypeId == 2) ? 1 : requestData.maxEntriesPerUser;
            contest.userName = userDetails.userName;
            contest.userEmail = userDetails.email;
            contest.minLimit = (contest.contestTypeId == 2) ? 2 : (prizeTemplate.minLimit);
            contest.prizeMode = 'C';
            contest.summary = (contest.contestTypeId == 1) ? 'Multiplayer Contest' : 'H2H Contest';
            contest.labels = [];
            contest.prizes = [];
            contest.prizeTickets = 0;
            contest.isVideoAvailable = false;
            contest.isAdminRow = false;
            contest.isGuaranteed = false;
            /*if (requestData.users && requestData.users.length > 0) {
                for (var i in requestData.users) {
                    contest.users.push(requestData.users[i]);
                }
            }*/
            return contest;
        } catch (e) {
            throw e;
        }
    },

    /**
    * Data Mapping for Add functionality
    * @param {Object} contest - Data Schema Object
    * @param {Object} requestData - Request Body Object
    * @param {Object} userDetails - User Object
    * @return {Object} Updated contest object
    */
    addDataAutoContest: function (requestData) {
        try {
            contest = {};
            contest.entryFees = requestData.entryFees;
            contest.contestStartTime = requestData.contestStartTime;
            contest.contestName = requestData.contestName;
            contest.contestTypeId = requestData.contestTypeId;
            contest.contestType = (requestData.contestTypeId == 1) ? 'Multiplayer' : 'H2H';
            contest.gameTypeId = requestData.gameTypeId;
            contest.gameType = (requestData.gameTypeId < 6) ? 'Multiplier' : 'Salary Cap';
            contest.draftgroupId = requestData.draftgroupId;
            contest.visibility = requestData.visibility;
            contest.sportId = requestData.sportId;
            contest.contestStatus = requestData.contestStatus ? requestData.contestStatus : 3;
            contest.prizeTmpId = requestData.prizeTmpId;
            contest.prizePool = requestData.prizePool;
            contest.minLimit = requestData.minLimit;
            contest.maxLimit = requestData.maxLimit;
            contest.maxEntriesPerUser = requestData.maxEntriesPerUser;
            contest.prizeMode = 'C';
            contest.summary = (requestData.contestTypeId == 1) ? 'Multiplayer Contest' : 'H2H Contest';
            contest.labels = [];
            contest.prizes = [];
            contest.prizeTickets = 0;
            contest.isVideoAvailable = false;
            contest.isAdminRow = false;
            contest.isGuaranteed = false;
            return contest;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Edit functionality
     * @param {Object} contest - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated contest object
     */
    editData: function (contest, requestData) {
        try {
            contest.contestName = requestData.contestName;
            contest.entryFees = requestData.entryFees;
            contest.description = requestData.description;
            contest.visibility = requestData.visibility;

            //sub document object
            if (contest.author) {
                contest.author._id = requestData.author._id;
                contest.author.email = requestData.author.email;
            }

            //sub document array
            var subSetMode = 'edit';
            if (subSetMode == 'add') {
                contest.users = []; //emptying the whole array
                if (requestData.users && requestData.users.length > 0) { //add it fresh
                    for (var i in requestData.users) {
                        contest.users.push(requestData.users[i]);
                    }
                }
            } else { //edit only
                if (requestData.users && requestData.users.length > 0) {
                    for (var j in requestData.users) {
                        contest.users.pull(requestData.users[j]._id);
                        contest.users.push(requestData.users[j]);
                    }

                }
            }
            return contest;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get All functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getAllData: function (resultSet, getAllParticipantsH2H) {
        try {
            var result = {};
            var multiplayer = [];
            var h2h = [];
            for (var i in resultSet) {
                if (resultSet[i].contestTypeId == 1) {

                    var myEntryN = (resultSet[i].entrants).find(function (obj) {
                        return obj.userId === global.userId;
                    });

                    var totalEntry = (resultSet[i].entrants).reduce(function (a, b) {
                        return a + b.totalentry;
                    }, 0);

                    var creatorEntry = resultSet[i].entrants.find(function (obj) {
                        return obj.userId === resultSet[i].createdBy;
                    });

                    //var contestIds = [];
                    //contestIds.push(resultSet[i].contestId);

                    var myEntry = myEntryN ? myEntryN.totalentry : 0;
                    //totalEntry = (creatorEntry && (creatorEntry.totalentry == 0 && resultSet[i].createdBy != global.userId)) ? totalEntry + 1 : totalEntry;
                    totalEntry = (creatorEntry && creatorEntry.totalentry == 0) ? totalEntry + 1 : totalEntry;

                    if (myEntry < resultSet[i].maxEntriesPerUser && totalEntry < resultSet[i].maxLimit) {

                        var multiplayerObj = {};
                        multiplayerObj.type = resultSet[i].contestType;
                        // multiplayerObj.id = resultSet[i]._id;
                        multiplayerObj.contestTypeId = resultSet[i].contestTypeId;
                        multiplayerObj.gameTypeId = resultSet[i].gameTypeId;
                        multiplayerObj.me = resultSet[i].maxEntriesPerUser ? resultSet[i].maxEntriesPerUser : '';
                        multiplayerObj.rewards = resultSet[i].rewards ? resultSet[i].rewards : '';
                        multiplayerObj.contestId = resultSet[i].contestId;
                        multiplayerObj.contestName = resultSet[i].contestName;
                        multiplayerObj.entryFees = resultSet[i].entryFees;
                        multiplayerObj.po = resultSet[i].prizePool ? resultSet[i].prizePool : '';
                        // multiplayerObj.description = resultSet[i].description;
                        multiplayerObj.visibility = resultSet[i].visibility;
                        multiplayerObj.draftgroupId = resultSet[i].draftgroupId;
                        multiplayerObj.sportId = resultSet[i].sportId;
                        //multiplayerObj.en = resultSet[i].entrants ? resultSet[i].entrants.length : 0;
                        multiplayerObj.en = totalEntry;
                        multiplayerObj.t = resultSet[i].maxLimit ? resultSet[i].maxLimit : '';
                        multiplayerObj.sd = resultSet[i].contestStartTime ? resultSet[i].contestStartTime : '';
                        multiplayerObj.isOwner = (resultSet[i].createdBy == global.userId) ? true : false;
                        multiplayerObj.guarenteed = resultSet[i].isGuaranteed ? true : false;
                        attr = {};
                        sponsor = {};
                        sponsor.sponsorName = resultSet[i].attributes.sponsor.sponsorName;
                        sponsor.imgURL = resultSet[i].attributes.sponsor.imgUrl;
                        attr.isVideo = resultSet[i].isVideoAvailable ? true : false;
                        attr.tags = resultSet[i].labels;
                        attr.sponsor = sponsor
                        multiplayerObj.attributes = attr;
                        if (totalEntry > 0) {
                            multiplayerObj.hasLineup = totalEntry > 0 ? true : false;
                        }
                        multiplayerObj.status = (resultSet[i].contestStatus == 1) ? 'completed' : ((resultSet[i].contestStatus == 2) ? 'live' : ((resultSet[i].contestStatus == 3) ? 'upcoming' : 'cancelled'));//1-Completed, 2- live, 3- Yet To happen, 4- cancelled
                        multiplayerObj.sort = resultSet[i].sort;
                        multiplayerObj.autoId = resultSet[i].autoId ? resultSet[i].autoId : '';
                        multiplayer.push(multiplayerObj);

                    }

                }
                if (resultSet[i].contestTypeId == 2) {

                    var myEntryCount = 0;
                    var myEntryCountt = 0;
                    var count = 0;
                    var totalEntry = (resultSet[i].entrants).reduce(function (a, b) {
                        return a + b.totalentry;
                    }, 0);
                    var myEntryN = (resultSet[i].entrants).find(function (obj) {
                        return obj.userId === global.userId;
                    });
                    var h2hC = {};
                    contestIds = [];
                    var contestHasLineupArr = [];
                    var contestHasLineupObj = {};

                    var sportRanking = [];

                    var enArr = [];
                    var enObj = {};
                    enObj.contest = resultSet[i].contestId;
                    enObj.en = resultSet[i].entrants ? resultSet[i].entrants.length : 0;
                    enArr.push(enObj);

                    if (myEntryN && myEntryN.totalentry > 0) { myEntryCount = 1; }

                    // if(myEntryN && myEntryN.totalentry < 1)  {  
                    //  if (totalEntry < 2 && myEntryCount == 0) {

                    contestHasLineupObj.contest = resultSet[i].contestId;
                    contestHasLineupObj.hasLineup = totalEntry > 0 ? true : false;
                    contestHasLineupArr.push(contestHasLineupObj);
                    contestIds.push(resultSet[i].contestId);
                    count++;

                    //for sport ranking objects to H2H object---start
                    if (resultSet[i].participantsH2H) {
                        for (var z = 0; z < (resultSet[i].participantsH2H).length; z++) {
                            if (resultSet[i].participantsH2H[z] != global.userId) {
                                var sportRankingObj = {};
                                var sportRankUser = (getAllParticipantsH2H).find(function (obj) {
                                    return obj.userId == resultSet[i].participantsH2H[z];
                                });
                                if ((sportRankUser.sportsRanking).length > 0) {
                                    var sportRankingDB = (sportRankUser.sportsRanking).find(function (obj) {
                                        return obj.sportId == resultSet[i].sportId;
                                    });
                                    if (sportRankingDB) {
                                        sportRankingObj.userId = sportRankUser.userId;
                                        sportRankingObj.sportRank = sportRankingDB.rank ? sportRankingDB.rank : 0;
                                        sportRankingObj.sportSubRank = sportRankingDB.subRank ? sportRankingDB.subRank : 0;
                                        sportRankingObj.sportPoints = sportRankingDB.points ? sportRankingDB.points : 0;
                                        sportRankingObj.sportIconUrl = process.env.SPORT_RANK_IMAGE + sportRankingDB.imageName + '.png';
                                        sportRanking.push(sportRankingObj);
                                    }
                                }
                            }
                        }
                    }
                    //for sport ranking objects to H2H object---end

                    //   }
                    if (resultSet[i].contestGroupId) {
                        var kArr = [];
                        // var count = 1;
                        //contestIds.push(resultSet[i].contestId);
                        for (var k in resultSet) {
                            var myEntryCountt = 0;
                            var totalEntryy = (resultSet[k].entrants).reduce(function (a, b) {
                                return a + b.totalentry;
                            }, 0);

                            var myEntryNN = (resultSet[k].entrants).find(function (obj) {
                                return obj.userId === global.userId;
                            });
                            if (myEntryNN && myEntryNN.totalentry > 0) { myEntryCountt = 1; }

                            //if(myEntryNN && myEntryNN.totalentry < 1)  {  
                            // if (totalEntryy < 2 && myEntryCountt == 0) {

                            if ((resultSet[k].contestGroupId == resultSet[i].contestGroupId) && (resultSet[k].contestId != resultSet[i].contestId) && resultSet[k].contestId > resultSet[i].contestId) {
                                count++;
                                kArr.push(k);
                                contestIds.push(resultSet[k].contestId);
                                var totalEntry = (resultSet[k].entrants).reduce(function (a, b) {
                                    return a + b.totalentry;
                                }, 0);
                                var contestHasLineupObj = {};
                                contestHasLineupObj.contest = resultSet[k].contestId;
                                contestHasLineupObj.hasLineup = totalEntry > 0 ? true : false;
                                contestHasLineupArr.push(contestHasLineupObj);
                                //resultSet.splice(k, 1);

                                var enObj = {};
                                enObj.contest = resultSet[k].contestId;
                                enObj.en = resultSet[k].entrants ? resultSet[k].entrants.length : 0;
                                enArr.push(enObj);

                                //for sport ranking objects to H2H object---start
                                if (resultSet[k].participantsH2H) {
                                    for (var z = 0; z < (resultSet[k].participantsH2H).length; z++) {
                                        if (resultSet[k].participantsH2H[z] != global.userId) {
                                            var sportRankingObj = {};
                                            var sportRankUser = (getAllParticipantsH2H).find(function (obj) {
                                                return obj.userId == resultSet[k].participantsH2H[z];
                                            });
                                            if ((sportRankUser.sportsRanking).length > 0) {
                                                var sportRankingDB = (sportRankUser.sportsRanking).find(function (obj) {
                                                    return obj.sportId == resultSet[k].sportId;
                                                });
                                                if (sportRankingDB) {
                                                    sportRankingObj.userId = sportRankUser.userId;
                                                    sportRankingObj.sportRank = sportRankingDB.rank ? sportRankingDB.rank : 0;
                                                    sportRankingObj.sportSubRank = sportRankingDB.subRank ? sportRankingDB.subRank : 0;
                                                    sportRankingObj.sportPoints = sportRankingDB.points ? sportRankingDB.points : 0;
                                                    sportRankingObj.sportIconUrl = process.env.SPORT_RANK_IMAGE + sportRankingDB.imageName + '.png';
                                                    sportRanking.push(sportRankingObj);
                                                }
                                            }
                                        }
                                    }
                                }
                                //for sport ranking objects to H2H object---end

                            }
                            //  }
                        }

                        h2hC.contestCount = count;
                        /*for (var c in kArr) {
                            resultSet.splice(c, 1);
                        }*/
                        for (var g = 0; g < kArr.length; g++) {
                            resultSet.splice(kArr[g] - g, 1);
                        }
                    }



                    if (contestIds.length > 0) {

                        //(contestIds.length > 1) ? (h2hC.contestIds = contestIds) : (h2hC.contestId = resultSet[i].contestId);
                        h2hC.contestIds = contestIds;
                        // h2hC.id = resultSet[i]._id;
                        h2hC.contestGroupId = resultSet[i].contestGroupId;
                        h2hC.contestName = resultSet[i].contestName;
                        h2hC.draftgroupId = resultSet[i].draftgroupId;
                        if (!resultSet[i].autoId) {
                            h2hC.username = resultSet[i].userName;
                        }
                        h2hC.displayName = (resultSet[i].fName && resultSet[i].lName) ? resultSet[i].fName + ' ' + resultSet[i].lName : '';
                        h2hC.entryFees = resultSet[i].entryFees;
                        h2hC.po = resultSet[i].prizePool ? resultSet[i].prizePool : '';
                        // h2hC.description = resultSet[i].description;
                        h2hC.visibility = resultSet[i].visibility;
                        h2hC.type = resultSet[i].contestType;
                        h2hC.contestTypeId = resultSet[i].contestTypeId;
                        h2hC.me = resultSet[i].maxEntriesPerUser ? resultSet[i].maxEntriesPerUser : '';
                        h2hC.sportId = resultSet[i].sportId;
                        h2hC.sport = resultSet[i].sName;
                        h2hC.en = enArr;
                        h2hC.t = resultSet[i].maxLimit ? resultSet[i].maxLimit : '';
                        h2hC.pid = resultSet[i].createdBy ? resultSet[i].createdBy : '';
                        h2hC.cid = '';
                        h2hC.sd = resultSet[i].contestStartTime ? resultSet[i].contestStartTime : '';
                        h2hC.isRival = resultSet[i].rival ? true : false;
                        h2hC.gameType = resultSet[i].gameType.split(" ")[0];
                        h2hC.gameTypeId = resultSet[i].gameTypeId;
                        h2hC.records = {};
                        if (totalEntry > 0) {
                            h2hC.hasLineup = contestHasLineupArr;
                        }
                        h2hC.status = (resultSet[i].contestStatus == 1) ? 'completed' : ((resultSet[i].contestStatus == 2) ? 'live' : ((resultSet[i].contestStatus == 3) ? 'upcoming' : 'cancelled'));//1-Completed, 2- live, 3- Yet To happen, 4- cancelled
                        h2hC.sort = resultSet[i].sort;
                        h2hC.imageName = resultSet[i].imageName ? resultSet[i].imageName : '';
                        h2hC.autoId = resultSet[i].autoId ? resultSet[i].autoId : '';
                        h2hC.sportRanking = sportRanking;
                        h2h.push(h2hC);

                    }

                }
            }
            result.multiplayer = multiplayer;
            result.h2h = h2h;
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get One functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getOneData: function (contestGames, contest) {
        try {
            var row = {};
            //row.id = resultSet._id;
            row.contestId = contest.contestId;
            row.contestName = contest.contestName;
            row.entryFees = contest.entryFees;
            row.games = [];
            if (contestGames.length > 0) {
                games = contestGames[0].gameList;
                /* for (var i in games) {
                     if (games[i].eventId) {
                         var rowGame = {};
                         rowGame.eventId = games[i].eventId;
                         rowGame.startTimeUTC = games[i].startTimeUTC;
                         rowGame.gameStatus = games[i].gameStatus ? games[i].gameStatus : '';
                         rowGame.startTimeUTC = games[i].startTimeUTC;
                         if (games[i].players != null) {
                             rowGame.homeTeam = games[i].players[0].competition.nameDisplay[0].htName;
                             rowGame.awayTeam = games[i].players[0].competition.nameDisplay[0].atName;
                         }
                         row.games.push(rowGame);
                     }
                 }*/

                for (var j = 0, len = games.length; j < len; j++) {
                    //event Set start
                    event = {};
                    event.eventId = games[j].eventId;
                    event.sport = contestGames[0].league[0].abbr;
                    homeTeam = {};
                    if (games[j].players.length > 0) {
                        homeTeam.teamId = games[j].players[0].competition.nameDisplay[0].htId;
                        homeTeam.teamName = games[j].players[0].competition.nameDisplay[0].htName;
                        homeTeam.abbreviation = games[j].players[0].competition.nameDisplay[0].htAbbr;
                        homeTeam.city = games[j].players[0].competition.nameDisplay[0].htCity;
                        homeTeam.wins = games[j].players[0].competition.nameDisplay[0].htRecord.wins;
                        homeTeam.losses = games[j].players[0].competition.nameDisplay[0].htRecord.losses;
                        event.homeTeam = homeTeam;
                        awayTeam = {};
                        awayTeam.teamId = games[j].players[0].competition.nameDisplay[0].atId;
                        awayTeam.teamName = games[j].players[0].competition.nameDisplay[0].atName;
                        awayTeam.abbreviation = games[j].players[0].competition.nameDisplay[0].atAbbr;
                        awayTeam.city = games[j].players[0].competition.nameDisplay[0].atCity;
                        awayTeam.wins = games[j].players[0].competition.nameDisplay[0].atRecord.wins;
                        awayTeam.losses = games[j].players[0].competition.nameDisplay[0].atRecord.losses;
                        event.awayTeam = awayTeam;
                        event.startTime = games[j].startTimeUTC;
                        event.name = games[j].players[0].competition.nameDisplay[0].value;
                    }
                    event.venue = games[j].venueName;
                    weather = {};
                    weather.type = games[j].weather.conditionDesc;
                    event.weather = weather;
                    event.startingLineupReady = games[j].startingLineupReady;
                    event.competitionState = games[j].gameStatus;
                    row.games.push(event);
                    //event Set end
                }
            }
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get Contest's Games and Standings
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    contestData: function (contestId) {
        try {
            contestId = parseInt(contestId);
            return contestId;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get all contest
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    contestDataMap: function (contest, requestData) {
        try {
            contest.visibility = (!requestData.query.visibility) ? 'Public' : requestData.query.visibility;
            //  contest.contestStatus = 2; //live contest
            contest.contestTypeId = (!requestData.query.contestTypeId) ? '' : requestData.query.contestTypeId;
            contest.sportId = (!requestData.query.sportId) ? '' : requestData.query.sportId;
            contest.status = (!requestData.query.status) ? '' : requestData.query.status;
            return contest;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get Contest Standings
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getStandingData: function (resultSet, contestId, usersDb) {
        try {
            /* var result = [];
             for (var i in resultSet) {
                 var row = {};
                 row.userId = resultSet[i].userId;
                 row.userName = resultSet[i].userName;
                 row.userImgName = resultSet[i].userImgName ? resultSet[i].userImgName : '';
                 row.position = resultSet[i].position;
                 row.points = resultSet[i].points ? resultSet[i].points : '';
                 result.push(row);
             }
             return result;*/

            var result = [];
            var users = {};
            for (var i in usersDb) {
                users[usersDb[i].userId] = {
                    'userName': usersDb[i].userName,
                    'img': usersDb[i].imageName,
                    'currentLoginType': usersDb[i].currentLoginType,
                    'fbId': usersDb[i].loginTypes.FB.fbId
                };
            }
            for (var i in resultSet) {
                var row = {};
                row.contestId = contestId;
                row.userId = resultSet[i].userId;
                row.userName = users[row.userId].userName ? users[row.userId].userName : '';

                if (users[row.userId].currentLoginType == 'FB' && users[row.userId].fbId) {
                    row.userImgName = fbHelper.getFbPicture(users[row.userId].fbId);
                } else {
                    row.userImgName = (users[row.userId].img != '') ? process.env.PROFILE_IMAGE_URL + users[row.userId].img : '';
                }
                // row.participantImage = resultSet[i].userImgName ? resultSet[i].userImgName : '';

                row.position = resultSet[i].position ? resultSet[i].position : null;
                row.score = resultSet[i].points ? resultSet[i].points : '0';
                row.winningAmount = resultSet[i].winning ? resultSet[i].winning : '0';
                //row.entryCount = resultSet[i].entryCount ? resultSet[i].entryCount : '';
                row.lineupId = (resultSet[i].lineupId && resultSet[i].isReserved != 1) ? resultSet[i].lineupId : '';
                row.rem = resultSet[i].avgRemTimePerc ? resultSet[i].avgRemTimePerc : '';
                result.push(row);
            }
            //added on 2 Aug 2018 - for reserved entries --- start
            /* if (resEntryId) {
                 const maxPosLineup = resultSet.reduce((prev, current) => (prev.position > current.position) ? prev : current);
                 res = {};
                 res.contestId = contestId;
                 res.userId = resEntryId;
                 res.userName = users[resEntryId].userName ? users[resEntryId].userName : '';
 
                 if (users[resEntryId].currentLoginType == 'FB' && users[resEntryId].fbId) {
                     res.userImgName = fbHelper.getFbPicture(users[resEntryId].fbId);
                 } else {
                     res.userImgName = (users[resEntryId].img != '') ? process.env.PROFILE_IMAGE_URL + users[resEntryId].img : '';
                 }
                 if (maxPosLineup.points == 0) {
                     res.position = maxPosLineup.position;
                 }
                 else {
                     res.position = maxPosLineup.position + 1;
                 }
                 res.score = '0';
                 res.winningAmount = '0';
                 res.lineupId = null;
                 res.rem = maxPosLineup.avgRemTimePerc ? maxPosLineup.avgRemTimePerc : '';
                 result.push(res);
             }*/
            //added on 2 Aug 2018 - for reserved entries --- end
            return result;

        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Add/Update User Lineup
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    playerLinupData: function (lineUpModel, playerArrayDB, request, minSalary, referralM = 0, usedTicketId = "N", appUserId = global.userId) {
        try {
            lineUpModel.contestId = request.contestId;
            lineUpModel.userId = appUserId;
            lineUpModel.draftgroupId = request.draftgroupId;
            lineUpModel.dgName = request.dgName;
            lineUpModel.startTimeUTC = request.startTimeUTC;
            lineUpModel.gameTypeId = request.gameTypeId;
            lineUpModel.sportId = request.sportId;
            lineUpModel.sName = request.sName ? request.sName : '';
            lineUpModel.referralMoney = referralM ? referralM : 0;
            lineUpModel.ticketId = usedTicketId ? usedTicketId : "N";
            lineUpModel.points = 0;
            var playersList = [];
            for (var i in playerArrayDB) {
                var player = {};
                player.eventId = request.players[i].eventId;
                player.eventST = playerArrayDB[i].st;
                player.tmpPosId = request.players[i].tmpPosId;
                player.tmpPosAbbr = playerArrayDB[i].players.posAbbr;
                player.tmpPosName = playerArrayDB[i].players.posName;
                player.tmpId = request.players[i].tmpId;
                player.playerId = playerArrayDB[i].players.playerId;
                player.isInjured = playerArrayDB[i].players.isInjured;
                player.fName = playerArrayDB[i].players.fName;
                player.lName = playerArrayDB[i].players.lName;
                player.mValue = playerArrayDB[i].players.mValue;
                player.fanProjSalary = playerArrayDB[i].players.fanProjSalary;
                //added for starting pitching probables lineup MLB -- start
                if (request.sportId == 2) {
                    player.starting = playerArrayDB[i].players.starting ? (playerArrayDB[i].players.starting).toString() : '';
                    player.probable = (playerArrayDB[i].players.probable) ? playerArrayDB[i].players.probable : false;
                }
                //added for starting pitching probables lineup MLB -- end
                //min salary setting
                if ((playerArrayDB[i].players.fanProjSalary == 0) && (request.sportId == 4 || request.sportId == 3 || request.sportId == 2)) {
                    for (var h in minSalary) {
                        if (minSalary[h]._id == playerArrayDB[i].players.posGen) {
                            player.fanProjSalary = minSalary[h].min;
                        }
                    }
                }
                else if ((playerArrayDB[i].players.fanProjSalary == 0) && (request.sportId != 4 || request.sportId != 3 || request.sportId != 2)) {
                    for (var h in minSalary) {
                        if (minSalary[h]._id == playerArrayDB[i].players.posAbbr) {
                            player.fanProjSalary = minSalary[h].min;
                        }
                    }
                }
                player.competition = playerArrayDB[i].players.competition;
                player.teamId = playerArrayDB[i].players.teamId;
                player.teamAbbr = playerArrayDB[i].players.teamAbbr;
                player.fanProjScore = playerArrayDB[i].players.fanProjScore;
                player.draftAtt = playerArrayDB[i].players.draftAtt;
                player.playerAttributes = playerArrayDB[i].players.playerAttributes;
                player.gameAttributes = playerArrayDB[i].players.gameAttributes;
                player.scoreInfo = playerArrayDB[i].players.scoreInfo;
                player.info = playerArrayDB[i].players.info ? playerArrayDB[i].players.info : '';
                playersList.push(player);
            }
            lineUpModel.players = playersList;
            return lineUpModel;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get contest lineups as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    contestLineUpsResultMap: function (resultSet) {
        try {
            var lineups = [];
            for (var i in resultSet) {
                var rowLineup = {};
                rowLineup.lineupId = resultSet[i].lineupId;
                rowLineup.contestId = resultSet[i].contestId;
                rowLineup.userId = resultSet[i].userId;
                rowLineup.draftgroupId = resultSet[i].draftgroupId;
                rowLineup.draftgroupName = resultSet[i].dgName;
                rowLineup.st = resultSet[i].startTimeUTC;
                rowLineup.sportId = resultSet[i].sportId;
                playersList = [];
                players = resultSet[i].players;
                for (var j = 0; j < players.length; j++) {
                    rowPlayer = {};
                    rowPlayer.eventId = players[j].eventId;
                    rowPlayer.startTimeUTC = players[j].eventST;
                    rowPlayer.tmpPosId = players[j].tmpPosId;
                    rowPlayer.tmpPosAbbr = players[j].tmpPosAbbr;
                    rowPlayer.tmpPosName = players[j].tmpPosName;
                    rowPlayer.tmpId = players[j].tmpId;
                    rowPlayer.playerId = players[j].playerId;
                    rowPlayer.fName = players[j].fName;
                    rowPlayer.lName = players[j].lName;
                    rowPlayer.multiplier = players[j].mValue;
                    rowPlayer.playerName = players[j].playerName;
                    rowPlayer.imgUrl = players[j].imgUrl;
                    rowPlayer.injuryDetail = players[j].isInjured ? players[j].isInjured : '';
                    rowPlayer.injuryStatus = (players[j].isInjured != null) ? (("'" + players[j].isInjured + "'").match(/\b\w/g).join('')).toUpperCase() : '';
                    if (resultSet[i].sportId == 2 && players[j].isInjured != 'Day-to-Day' && players[j].isInjured != null) {
                        rowPlayer.injuryStatus = ("" + players[j].isInjured + "").split(' ')[0] + ("" + players[j].isInjured + "").split(" ").splice(-1);
                    }
                    competitionObj = {};
                    competitionObj.compId = (players[j].competition.compId) ? (players[j].competition.compId) : '';
                    nameDisplayList = [];
                    nameDisplayObj = {};
                    nameDisplayObj.htName = players[j].competition.nameDisplay[0].htName;
                    nameDisplayObj.htAbbr = players[j].competition.nameDisplay[0].htAbbr ? players[j].competition.nameDisplay[0].htAbbr : '';
                    nameDisplayObj.htScore = (players[j].competition.nameDisplay[0].htScore) ? players[j].competition.nameDisplay[0].htScore : '';
                    nameDisplayObj.value = (players[j].competition.nameDisplay[0].value) ? players[j].competition.nameDisplay[0].value : '';
                    nameDisplayObj.atName = (players[j].competition.nameDisplay[0].atName) ? players[j].competition.nameDisplay[0].atName : '';
                    nameDisplayObj.atAbbr = players[j].competition.nameDisplay[0].atAbbr ? players[j].competition.nameDisplay[0].atAbbr : '';
                    nameDisplayObj.atScore = (players[j].competition.nameDisplay[0].atScore) ? players[j].competition.nameDisplay[0].atScore : '';
                    nameDisplayList.push(nameDisplayObj);
                    competitionObj.nameDisplay = nameDisplayList;
                    rowPlayer.competition = competitionObj;
                    rowPlayer.teamId = players[j].teamId;
                    rowPlayer.teamAbbr = players[j].teamAbbr;
                    rowPlayer.fanProjScore = players[j].fanProjScore;
                    //added for starting pitching probables lineup MLB -- start
                    if (resultSet[i].sportId == 2) {
                        rowPlayer.starting = players[j].starting ? (players[j].starting).toString() : '';
                        //rowPlayer.probable = (players[j].starting && players[j].starting == 'p') ? true : false;
                        rowPlayer.probable = (players[j].probable) ? players[j].probable : false;
                    }
                    //added for starting pitching probables lineup MLB -- end
                    playersList.push(rowPlayer);
                }
                rowLineup.players = playersList;
                lineups.push(rowLineup);
            }
            //console.log(lineups);process.exit();
            return lineups;
        } catch (e) {
            throw e;
        }
    },


    /**
     * Data Mapping for Update User Lineup for single/bulk update
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    updatePlayerLinupData: function (lineUpModel, playerArrayDB, request, minSalary) {
        try {
            var playersList = [];
            for (var i in playerArrayDB) {
                var player = {};
                player.eventId = request.players[i].eventId;
                player.eventST = playerArrayDB[i].st;
                player.tmpPosId = request.players[i].tmpPosId;
                player.tmpPosAbbr = playerArrayDB[i].players.posAbbr;
                player.tmpPosName = playerArrayDB[i].players.posName;
                player.tmpId = request.players[i].tmpId;
                player.playerId = playerArrayDB[i].players.playerId;
                player.isInjured = playerArrayDB[i].players.isInjured;
                player.fName = playerArrayDB[i].players.fName;
                player.lName = playerArrayDB[i].players.lName;
                player.mValue = playerArrayDB[i].players.mValue;
                player.fanProjSalary = playerArrayDB[i].players.fanProjSalary;
                //added for starting pitching probables lineup MLB -- start
                if (request.sportId == 2) {
                    player.starting = playerArrayDB[i].players.starting ? (playerArrayDB[i].players.starting).toString() : '';
                    //player.probable = (playerArrayDB[i].players.starting && playerArrayDB[i].players.starting == 'p') ? true : false;
                    player.probable = playerArrayDB[i].players.probable ? (playerArrayDB[i].players.probable) : false;
                }
                //added for starting pitching probables lineup MLB -- end
                //min salary setting
                if ((playerArrayDB[i].players.fanProjSalary == 0) && (request.sportId == 4 || request.sportId == 3 || request.sportId == 2)) {
                    for (var h in minSalary) {
                        if (minSalary[h]._id == playerArrayDB[i].players.posGen) {
                            player.fanProjSalary = minSalary[h].min;
                        }
                    }
                }
                else if ((playerArrayDB[i].players.fanProjSalary == 0) && (request.sportId != 4 || request.sportId != 3 || request.sportId != 2)) {
                    for (var h in minSalary) {
                        if (minSalary[h]._id == playerArrayDB[i].players.posAbbr) {
                            player.fanProjSalary = minSalary[h].min;
                        }
                    }
                }
                player.competition = playerArrayDB[i].players.competition;
                player.teamId = playerArrayDB[i].players.teamId;
                player.teamAbbr = playerArrayDB[i].players.teamAbbr;
                player.fanProjScore = playerArrayDB[i].players.fanProjScore;
                player.draftAtt = playerArrayDB[i].players.draftAtt;
                player.playerAttributes = playerArrayDB[i].players.playerAttributes;
                player.gameAttributes = playerArrayDB[i].players.gameAttributes;
                player.scoreInfo = playerArrayDB[i].players.scoreInfo;
                player.info = playerArrayDB[i].players.info ? playerArrayDB[i].players.info : '';
                playersList.push(player);
            }
            lineUpModel.players = playersList;
            return lineUpModel;
        } catch (e) {
            throw e;
        }
    },



    /**
     * Data Mapping for get contest list as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getUserContestsData: function (resultSet, myLineups, opponentLineups) {
        try {
            var result = {};
            var multiplayer = [];
            var h2h = [];
            for (var i in resultSet) {
                var lineupIds = [];
                if (resultSet[i].contestTypeId == 1) {
                    var totalEntry = (resultSet[i].entrants).reduce(function (a, b) {
                        return a + b.totalentry;
                    }, 0);
                    //added for reserved entry count -- start
                    var creatorEntry = resultSet[i].entrants.find(function (obj) {
                        return obj.userId === resultSet[i].createdBy;
                    });
                    totalEntry = (creatorEntry && creatorEntry.totalentry == 0) ? totalEntry + 1 : totalEntry;
                    //added for reserved entry count -- end
                    var multiplayerObj = {};
                    multiplayerObj.type = resultSet[i].contestType;
                    // multiplayerObj.id = resultSet[i]._id;
                    multiplayerObj.contestTypeId = resultSet[i].contestTypeId;
                    multiplayerObj.gameTypeId = resultSet[i].gameTypeId;
                    multiplayerObj.me = resultSet[i].maxEntriesPerUser ? resultSet[i].maxEntriesPerUser : '';
                    multiplayerObj.rewards = resultSet[i].rewards ? resultSet[i].rewards : '';
                    multiplayerObj.contestId = resultSet[i].contestId;
                    multiplayerObj.contestName = resultSet[i].contestName;
                    //lineup section
                    var myEntryN = (resultSet[i].entrants).find(function (obj) { return obj.userId === global.userId; });
                    if (myEntryN) {
                        //if ((resultSet[i].createdBy == global.userId) && (myEntryN.totalentry == 0 || typeof myEntryN.totalentry != 'undefined')) {
                        /* if ((resultSet[i].createdBy == global.userId) && (myEntryN.totalentry == 0)) {
                             lineupIds.push(null);
                         }
                         else { */   //console.log(resultSet[i].contestId);console.log("*****");console.log(myLineups);
                        for (var h in myLineups) {
                            // if (myLineups[h].contestId == resultSet[i].contestId && myLineups[h].userId == resultSet[i].createdBy) {
                            if (myLineups[h].contestId == resultSet[i].contestId) {
                                //live lineups details start --added on 18 July 2018
                                var lineupDetails = {};
                                lineupDetails.lineupId = myLineups[h].lineupId;
                                if (resultSet[i].contestStatus == 2 || resultSet[i].contestStatus == 1) {
                                    lineupDetails.pos = myLineups[h].position;
                                    lineupDetails.w = myLineups[h].winning ? myLineups[h].winning : 0;
                                    lineupDetails.score = myLineups[h].points;
                                    lineupDetails.rem = myLineups[h].avgRemTimePerc ? myLineups[h].avgRemTimePerc : '';
                                }
                                lineupIds.push(lineupDetails);
                                //live lineups details end --added on 18 July 2018
                                //lineupIds.push(myLineups[h].lineupId);
                            }
                        }
                        //  }
                    }
                    multiplayerObj.lineupIds = lineupIds;
                    multiplayerObj.entryFees = resultSet[i].entryFees;
                    multiplayerObj.po = resultSet[i].prizePool ? resultSet[i].prizePool : '';
                    // multiplayerObj.description = resultSet[i].description;
                    multiplayerObj.visibility = resultSet[i].visibility;
                    multiplayerObj.draftgroupId = resultSet[i].draftgroupId;
                    multiplayerObj.sportId = resultSet[i].sportId;
                    //multiplayerObj.en = resultSet[i].entrants ? resultSet[i].entrants.length : 0;
                    multiplayerObj.en = totalEntry;
                    multiplayerObj.t = resultSet[i].maxLimit ? resultSet[i].maxLimit : '';
                    multiplayerObj.sd = resultSet[i].contestStartTime ? resultSet[i].contestStartTime : '';
                    multiplayerObj.isOwner = (resultSet[i].createdBy == global.userId) ? true : false;
                    multiplayerObj.guarenteed = resultSet[i].isGuaranteed ? true : false;
                    multiplayerObj.userEntryCount = myEntryN ? myEntryN.totalentry : 0
                    attr = {};
                    sponsor = {};
                    sponsor.sponsorName = resultSet[i].attributes.sponsor.sponsorName;
                    sponsor.imgURL = resultSet[i].attributes.sponsor.imgUrl;
                    attr.isVideo = resultSet[i].isVideoAvailable ? true : false;
                    attr.tags = resultSet[i].labels;
                    attr.sponsor = sponsor
                    multiplayerObj.attributes = attr;
                    multiplayerObj.sort = resultSet[i].sort;
                    multiplayerObj.minPosPO = resultSet[i].minPosPO ? resultSet[i].minPosPO:'';
                    multiplayerObj.autoId = resultSet[i].autoId ? resultSet[i].autoId : '';
                    if (totalEntry > 0) {
                        multiplayerObj.hasLineup = totalEntry > 0 ? true : false;
                    }
                    multiplayerObj.status = (resultSet[i].contestStatus == 1) ? 'completed' : ((resultSet[i].contestStatus == 2) ? 'live' : ((resultSet[i].contestStatus == 3) ? 'upcoming' : 'cancelled'));//1-Completed, 2- live, 3- Yet To happen, 4- cancelled
                    multiplayer.push(multiplayerObj);
                }
                if (resultSet[i].contestTypeId == 2) {
                    var h2hC = {};
                    contestIds = [];
                    contestIds.push(resultSet[i].contestId);
                    //lineup section start
                    var myEntryN = (resultSet[i].entrants).find(function (obj) { return obj.userId === global.userId; });
                    var lineupContestObj = {};

                    var totalEntry = (resultSet[i].entrants).reduce(function (a, b) {
                        return a + b.totalentry;
                    }, 0);

                    var opponentArr = [];
                    var opponentObj = {};
                    var contestHasLineupArr = [];
                    var contestHasLineupObj = {};
                    var userEntryCountArr = [];
                    var userEntryCountObj = {};
                    var enArr = [];
                    contestHasLineupObj.contest = resultSet[i].contestId;
                    contestHasLineupObj.hasLineup = totalEntry > 0 ? true : false;
                    contestHasLineupArr.push(contestHasLineupObj);


                    /* var opponentId=0;
                     if(resultSet[i].entrants.length>1) {
                     if (resultSet[i].entrants[1] != null) {
                         if (resultSet[i].entrants[1].userId != global.userId) {
                             opponentId = resultSet[i].entrants[1].userId;
                         } else {
                             opponentId = resultSet[i].entrants[0].userId;
                         }
                     }
                 }
                     var opponentIds= opponentId ? opponentId:'0';
                     opponentObj.contest = resultSet[i].contestId;
                     opponentObj.opponentUserId = opponentIds;
                     opponentArr.push(opponentObj);*/

                    //added on 31July18 for H2H opponests score---start
                    if (opponentLineups) {
                        for (var x = 0; x < opponentLineups.length; x++) {
                            if ((opponentLineups[x].userId == resultSet[i].opponentUserId) && (opponentLineups[x].contestId == resultSet[i].contestId)) {
                                opponentObj.score = opponentLineups[x].points ? opponentLineups[x].points : '';
                                opponentObj.rem = opponentLineups[x].avgRemTimePerc ? opponentLineups[x].avgRemTimePerc : '';
                                break;
                            }
                        }
                    }
                    //added on 31July18 for H2H opponests score---end
                    opponentObj.contest = resultSet[i].contestId;
                    opponentObj.opponentUserId = resultSet[i].opponentUserId ? resultSet[i].opponentUserId : 0;
                    opponentObj.opponentuserName = resultSet[i].opponentuserName ? resultSet[i].opponentuserName : '';
                    opponentObj.opponentimageName = resultSet[i].opponentimageName ? resultSet[i].opponentimageName : '';
                    opponentObj.sportRank = resultSet[i].sportRank;
                    opponentObj.rank = resultSet[i].rank;
                    opponentObj.isRival = resultSet[i].rival ? true : false;
                    opponentArr.push(opponentObj);

                    var userEntryCountObj = {};
                    userEntryCountObj.contest = resultSet[i].contestId;
                    userEntryCountObj.userEntryCount = myEntryN ? (myEntryN.totalentry ? myEntryN.totalentry : 0) : 0;
                    userEntryCountArr.push(userEntryCountObj);

                    var enObj = {};
                    enObj.contest = resultSet[i].contestId;
                    enObj.en = resultSet[i].entrants ? resultSet[i].entrants.length : 0;
                    enArr.push(enObj);

                    if (myEntryN) {
                        var lineupContest = [];
                        //var lineupContestObj = {};
                        /*  if ((resultSet[i].createdBy == global.userId) && (myEntryN.totalentry == 0)) {
                              lineupContestObj.lineUp = null;
                              lineupContestObj.contest = resultSet[i].contestId;
                              lineupContestObj.userEntryCount = 0;
                              lineupContest.push(lineupContestObj);
                          }
                          else {*/
                        for (var h in myLineups) {
                            if (myLineups[h].contestId == resultSet[i].contestId) {
                                var lineupContestObj = {};
                                lineupContestObj.lineUp = myLineups[h].lineupId;
                                lineupContestObj.contest = resultSet[i].contestId;
                                //live lineups details start --added on 18 July 2018
                                if (resultSet[i].contestStatus == 2 || resultSet[i].contestStatus == 1) {
                                    lineupContestObj.pos = myLineups[h].position;
                                    lineupContestObj.w = myLineups[h].winning ? myLineups[h].winning : 0;
                                    lineupContestObj.score = myLineups[h].points;
                                    lineupContestObj.rem = myLineups[h].avgRemTimePerc ? myLineups[h].avgRemTimePerc : '';
                                }
                                //live lineups details end --added on 18 July 2018
                                lineupContestObj.userEntryCount = myEntryN ? (myEntryN.totalentry ? myEntryN.totalentry : 0) : 0;
                                lineupContest.push(lineupContestObj);
                            }
                        }
                        //}
                    }
                    //lineup section end
                    if (resultSet[i].contestGroupId) {
                        var count = 1;
                        var kArr = [];
                        //contestIds.push(resultSet[i].contestId);
                        for (var k in resultSet) {
                            if ((resultSet[k].contestGroupId == resultSet[i].contestGroupId) && (resultSet[k].contestId != resultSet[i].contestId)) {
                                count++;
                                kArr.push(k);
                                contestIds.push(resultSet[k].contestId);
                                var totalEntry = (resultSet[k].entrants).reduce(function (a, b) {
                                    return a + b.totalentry;
                                }, 0);
                                //lineup section start
                                var myEntryN = (resultSet[k].entrants).find(function (obj) { return obj.userId === global.userId; });
                                var lineupContestObj = {};
                                if (myEntryN) {
                                    //  var lineupContestObj = {};
                                    /* if ((resultSet[k].createdBy == global.userId) && (myEntryN.totalentry == 0)) {
                                         lineupContestObj.lineUp = null;
                                         lineupContestObj.contest = resultSet[k].contestId;
                                         lineupContestObj.userEntryCount = 0;
                                         lineupContest.push(lineupContestObj);
                                     }
                                     else {*/
                                    for (var g in myLineups) {
                                        if (myLineups[g].contestId == resultSet[k].contestId) {
                                            var lineupContestObj = {};
                                            lineupContestObj.lineUp = myLineups[g].lineupId;
                                            lineupContestObj.contest = resultSet[k].contestId;
                                            //live lineups details start --added on 18 July 2018
                                            if (resultSet[k].contestStatus == 2 || resultSet[k].contestStatus == 1) {
                                                lineupContestObj.pos = myLineups[g].position;
                                                lineupContestObj.w = myLineups[g].winning ? myLineups[g].winning : 0;
                                                lineupContestObj.score = myLineups[g].points;
                                                lineupContestObj.rem = myLineups[g].avgRemTimePerc ? myLineups[g].avgRemTimePerc : '';
                                            }
                                            //live lineups details end --added on 18 July 2018
                                            lineupContestObj.userEntryCount = myEntryN ? (myEntryN.totalentry ? myEntryN.totalentry : 0) : 0;
                                            lineupContest.push(lineupContestObj);
                                        }
                                    }
                                    //}
                                }
                                //lineup section end
                                var totalEntry = (resultSet[k].entrants).reduce(function (a, b) {
                                    return a + b.totalentry;
                                }, 0);
                                var contestHasLineupObj = {};
                                contestHasLineupObj.contest = resultSet[k].contestId;
                                contestHasLineupObj.hasLineup = totalEntry > 0 ? true : false;
                                contestHasLineupArr.push(contestHasLineupObj);


                                /* var opponentId=0;
                                 if(resultSet[k].entrants.length>1) {
                                  if (resultSet[k].entrants[1] != null) {
                                      if (resultSet[k].entrants[1].userId != global.userId) {
                                          opponentId = resultSet[k].entrants[1].userId;
                                      } else {
                                          opponentId = resultSet[k].entrants[0].userId;
                                      }
                                  }
                              }
                                  var opponentIds= opponentId ? opponentId:'0';
                                      //opponent
                                      var opponentObj = {};
                                      opponentObj.contest = resultSet[k].contestId;
                                      opponentObj.opponentUserId =opponentIds;
                                      opponentArr.push(opponentObj); */

                                var opponentObj = {};
                                opponentObj.contest = resultSet[k].contestId;
                                opponentObj.opponentUserId = resultSet[k].opponentUserId ? resultSet[k].opponentUserId : 0;
                                opponentObj.opponentuserName = resultSet[k].opponentuserName ? resultSet[k].opponentuserName : '';
                                opponentObj.opponentimageName = resultSet[k].opponentimageName ? resultSet[k].opponentimageName : '';
                                opponentObj.sportRank = resultSet[k].sportRank ? resultSet[k].sportRank : 0;
                                opponentObj.rank = resultSet[k].rank ? resultSet[k].rank : 0;
                                opponentObj.isRival = resultSet[k].rival ? true : false;
                                opponentArr.push(opponentObj);


                                var userEntryCountObj = {};
                                userEntryCountObj.contest = resultSet[k].contestId;
                                userEntryCountObj.userEntryCount = myEntryN ? (myEntryN.totalentry ? myEntryN.totalentry : 0) : 0;
                                userEntryCountArr.push(userEntryCountObj);
                                var enObj = {};
                                enObj.contest = resultSet[k].contestId;
                                enObj.en = resultSet[k].entrants ? resultSet[k].entrants.length : 0;
                                enArr.push(enObj);
                            }
                        }
                        h2hC.contestCount = count;
                        /* for (var c in kArr) {
                             resultSet.splice(c, 1);
                         }*/
                        for (var g = 0; g < kArr.length; g++) {
                            resultSet.splice(kArr[g] - g, 1);
                        }
                    }

                    //(contestIds.length > 1) ? (h2hC.contestIds = contestIds) : (h2hC.contestId = resultSet[i].contestId);
                    h2hC.contestIds = contestIds;
                    // h2hC.id = resultSet[i]._id;
                    h2hC.contestGroupId = resultSet[i].contestGroupId;
                    h2hC.contestName = resultSet[i].contestName ? resultSet[i].contestName : '';
                    h2hC.lineupIds = lineupContest;
                    h2hC.draftgroupId = resultSet[i].draftgroupId;
                    if (!resultSet[i].autoId) {
                        h2hC.username = resultSet[i].userName;
                    }
                    h2hC.displayName = (resultSet[i].fName && resultSet[i].lName) ? resultSet[i].fName + ' ' + resultSet[i].lName : '';
                    h2hC.entryFees = resultSet[i].entryFees;
                    h2hC.po = resultSet[i].prizePool ? resultSet[i].prizePool : '';
                    // h2hC.description = resultSet[i].description;
                    h2hC.visibility = resultSet[i].visibility;
                    h2hC.type = resultSet[i].contestType;
                    h2hC.contestTypeId = resultSet[i].contestTypeId;
                    h2hC.me = resultSet[i].maxEntriesPerUser ? resultSet[i].maxEntriesPerUser : '';
                    h2hC.sportId = resultSet[i].sportId;
                    h2hC.sport = resultSet[i].sName;
                    h2hC.en = enArr;
                    h2hC.t = resultSet[i].maxLimit ? resultSet[i].maxLimit : '';
                    h2hC.pid = resultSet[i].createdBy ? resultSet[i].createdBy : '';
                    h2hC.cid = '';
                    h2hC.sd = resultSet[i].contestStartTime ? resultSet[i].contestStartTime : '';
                    h2hC.gameType = resultSet[i].gameType.split(" ")[0];
                    h2hC.gameTypeId = resultSet[i].gameTypeId;
                    h2hC.records = {};
                    if (totalEntry > 0) {
                        h2hC.hasLineup = contestHasLineupArr;
                    }
                    h2hC.opponent = opponentArr;
                    h2hC.status = (resultSet[i].contestStatus == 1) ? 'completed' : ((resultSet[i].contestStatus == 2) ? 'live' : ((resultSet[i].contestStatus == 3) ? 'upcoming' : 'cancelled'));//1-Completed, 2- live, 3- Yet To happen, 4- cancelled
                    h2hC.sort = resultSet[i].sort;
                    h2hC.imageName = resultSet[i].imageName ? resultSet[i].imageName : '';
                    h2hC.userEntryCount = userEntryCountArr;
                    //h2hC.minPosPO = 1;
                    h2hC.autoId = resultSet[i].autoId ? resultSet[i].autoId : '';
                    h2h.push(h2hC);

                }
            }
            result.multiplayer = multiplayer;
            result.h2h = h2h;
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get Contest's Games and Standings
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    LineUpData: function (contestId) {
        try {
            contestId = parseInt(contestId);
            return contestId;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get lineup by Id as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    lineUpResultMap: function (resultSet, appUserId = global.userId) {
        try {
            var dt = new Date();
            var lineups = {};
            for (var i in resultSet) {
                var rowLineup = {};
                rowLineup.lineupId = resultSet[i].lineupId;
                rowLineup.contestId = resultSet[i].contestId;
                rowLineup.userId = resultSet[i].userId;
                rowLineup.draftgroupId = resultSet[i].draftgroupId;
                rowLineup.draftgroupName = resultSet[i].dgName;
                rowLineup.st = resultSet[i].startTimeUTC;
                rowLineup.sportId = resultSet[i].sportId;
                playersList = [];
                players = resultSet[i].players;
                for (var j = 0; j < players.length; j++) {
                    rowPlayer = {};
                    rowPlayer.eventId = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].eventId;
                    rowPlayer.startTimeUTC = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].eventST;
                    rowPlayer.tmpPosId = players[j].tmpPosId;
                    rowPlayer.tmpPosAbbr = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].tmpPosAbbr;
                    rowPlayer.tmpPosName = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].tmpPosName;
                    rowPlayer.tmpId = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].tmpId;
                    rowPlayer.playerId = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].playerId;
                    rowPlayer.fName = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].fName;
                    rowPlayer.lName = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].lName;
                    rowPlayer.multiplier = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].mValue;
                    rowPlayer.playerName = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].playerName;
                    rowPlayer.imgUrl = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].imgUrl;
                    rowPlayer.injuryDetail = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].isInjured ? players[j].isInjured : '';
                    if (appUserId != resultSet[i].userId && dt < players[j].eventST) { rowPlayer.injuryStatus = null; } else {
                        rowPlayer.injuryStatus = (players[j].isInjured != null) ? (("'" + players[j].isInjured + "'").match(/\b\w/g).join('')).toUpperCase() : '';
                        if (resultSet[i].sportId == 2 && players[j].isInjured != 'Day-to-Day' && players[j].isInjured != null) {
                            rowPlayer.injuryStatus = ("" + players[j].isInjured + "").split(' ')[0] + ("" + players[j].isInjured + "").split(" ").splice(-1);
                        }
                    }

                    competitionObj = {};
                    competitionObj.compId = (players[j].competition.compId) ? (players[j].competition.compId) : '';
                    nameDisplayList = [];
                    nameDisplayObj = {};
                    nameDisplayObj.htName = players[j].competition.nameDisplay[0].htName;
                    nameDisplayObj.htAbbr = players[j].competition.nameDisplay[0].htAbbr ? players[j].competition.nameDisplay[0].htAbbr : '';
                    nameDisplayObj.htScore = (players[j].competition.nameDisplay[0].htScore) ? players[j].competition.nameDisplay[0].htScore : '';
                    nameDisplayObj.value = (players[j].competition.nameDisplay[0].value) ? players[j].competition.nameDisplay[0].value : '';
                    nameDisplayObj.atName = (players[j].competition.nameDisplay[0].atName) ? players[j].competition.nameDisplay[0].atName : '';
                    nameDisplayObj.atAbbr = players[j].competition.nameDisplay[0].atAbbr ? players[j].competition.nameDisplay[0].atAbbr : '';
                    nameDisplayObj.atScore = (players[j].competition.nameDisplay[0].atScore) ? players[j].competition.nameDisplay[0].atScore : '';
                    nameDisplayList.push(nameDisplayObj);
                    competitionObj.nameDisplay = nameDisplayList;
                    rowPlayer.competition = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : competitionObj;
                    rowPlayer.teamId = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].teamId;
                    rowPlayer.teamAbbr = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].teamAbbr;
                    rowPlayer.fanProjScore = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].fanProjScore;
                    rowPlayer.info = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : players[j].info;
                    //added for starting pitching probables lineup MLB -- start
                    if (resultSet[i].sportId == 2) {
                        rowPlayer.starting = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : (players[j].starting ? (players[j].starting).toString() : '');
                        //rowPlayer.probable = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : ((players[j].starting && players[j].starting == 'p') ? true : false);
                        rowPlayer.probable = (appUserId != resultSet[i].userId && dt < players[j].eventST) ? null : (players[j].probable ? (players[j].probable) : false);
                    }
                    //added for starting pitching probables lineup MLB -- end
                    playersList.push(rowPlayer);
                }
                rowLineup.players = playersList;
            }
            lineups = rowLineup;
            //console.log(lineups);process.exit();
            return lineups;
        } catch (e) {
            throw e;
        }
    },


    /**
     * Data Mapping for get all featured contest
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    contestFeaturedDataMap: function (contest, requestData) {
        try {
            contest.visibility = (!requestData.query.visibility) ? 'Public' : requestData.query.visibility;
            return contest;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get lineuptemplate
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    lineUpTemplateResultMap: function (resultSet) {
        try {
            var lineuptemplateArr = [];
            for (var j = 0; j < resultSet.length; j++) {
                var lineuptemplate = {};
                lineuptemplate.sportId = resultSet[j].sportId;
                lineuptemplate.sName = resultSet[j].sName;
                lineuptemplate.sortOrder = resultSet[j].sortOrder;
                lineuptemplate.isAvailable = resultSet[j].isAvailable;
                var Game = [];
                if (resultSet[j].gameTypes.length != 0) {
                    for (var k = 0; k < (resultSet[j].gameTypes).length; k++) {
                        var rowGame = {};
                        rowGame.lptemplateId = resultSet[j].gameTypes[k].lptemplateid;
                        rowGame.gameType = resultSet[j].gameTypes[k].gameType;
                        rowGame.gameTypeId = resultSet[j].gameTypes[k].gameTypeId;
                        rowGame.capLimit = resultSet[j].gameTypes[k].capLimit;
                        var Template = [];
                        templates = resultSet[j].gameTypes[k].template;
                        for (var h = 0; h < templates.length; h++) {
                            var rowTemp = {};
                            rowTemp.id = templates[h].id;
                            rowTemp.PositionID = templates[h].posId;
                            if (resultSet[j].sportId == 3 || resultSet[j].sportId == 4) {
                                var posGName = (templates[h].posName).split(" ").splice(-1)[0];
                                rowTemp.Position = (templates[h].posAbbr)[(templates[h].posAbbr).length - 1];
                                rowTemp.PositionName = posGName;
                            }
                            else {
                                rowTemp.Position = templates[h].posAbbr;
                                rowTemp.PositionName = templates[h].posName;
                            }
                            rowTemp.playerId = '';
                            rowTemp.playerName = '';
                            Template.push(rowTemp);
                        }
                        rowGame.template = Template;
                        Game.push(rowGame);
                    }
                }
                lineuptemplate.gameTypes = Game;
                lineuptemplateArr.push(lineuptemplate);
            }
            return lineuptemplateArr;
        } catch (e) {
            throw e;
        }
    },


    /**
      * Data Mapping for get all my contest
      * @param {Object} requestData - Request Query Object
      * @return {Object} Array of data
      */
    myContestDataMap: function (requestData) {
        try {
            sportId = (!requestData.query.sportId) ? [1, 2, 3, 4, 5] : requestData.query.sportId;
            status = (!requestData.query.status) ? '' : requestData.query.status;
            return sportId;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get All prize templates
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getPrizeTemplateMapping: function (resultSet) {
        try {
            var createTemplate = {};
            createTemplate.entryFees = [0, 1, 2, 3, 5, 10, 15, 20, 25, 50, 100, 150, 200, 250, 500, 1000];
            createTemplate.maxParticipantSize = 20;
            createTemplate.maxCreateCount = 100;
            var result = [];
            for (var i in resultSet) {
                var row = {};
                row.prizeTypeId = resultSet[i].prizeTmpId;
                row.name = resultSet[i].tmpName;
                row.participantsReq = resultSet[i].minLimit;
                row.prizes = resultSet[i].prizes;
                result.push(row);
            }
            createTemplate.payoutStruction = result;
            return createTemplate;
        } catch (e) {
            throw e;
        }
    },

    /**
    * Data Mapping for created contest list as response
    * @param {Object} resultSet - Resultset
    * @return {Object} Updated result object
    */
    getUserCreatedContest: function (resultSet, appUserId = global.userId) {
        try {

            var result = {};
            var multiplayer = [];
            var h2h = [];
            for (var i in resultSet) {
                var lineupIds = [];

                var totalEntry = 0;
                if (resultSet[i].entrants) {
                    totalEntry = (resultSet[i].entrants).reduce(function (a, b) {
                        return a + b.totalentry;
                    }, 0);

                    //added for reserved entry count -- start
                    var creatorEntry = resultSet[i].entrants.find(function (obj) {
                        return obj.userId === resultSet[i].createdBy;
                    });
                }
                totalEntry = (creatorEntry && creatorEntry.totalentry == 0) ? totalEntry + 1 : totalEntry;
                //added for reserved entry count -- end
                if (resultSet[i].contestTypeId == 1) {
                    // var contestIds = [];
                    //contestIds.push(resultSet[i].contestId);
                    var multiplayerObj = {};
                    multiplayerObj.type = resultSet[i].contestType;
                    // multiplayerObj.id = resultSet[i]._id;
                    multiplayerObj.contestTypeId = resultSet[i].contestTypeId;
                    multiplayerObj.gameTypeId = resultSet[i].gameTypeId;
                    multiplayerObj.me = resultSet[i].maxEntriesPerUser ? resultSet[i].maxEntriesPerUser : '';
                    multiplayerObj.rewards = resultSet[i].rewards ? resultSet[i].rewards : '';
                    multiplayerObj.contestId = resultSet[i].contestId;
                    multiplayerObj.contestName = resultSet[i].contestName;
                    multiplayerObj.username = resultSet[i].userName;
                    multiplayerObj.imageName = resultSet[i].imageName ? resultSet[i].imageName : '';
                    multiplayerObj.isRival = false;
                    //lineup section start
                    lineupIds.push(null);
                    multiplayerObj.lineupIds = resultSet[i].lineupId ? resultSet[i].lineupId : lineupIds;
                    //lineupsection end
                    multiplayerObj.entryFees = resultSet[i].entryFees;
                    multiplayerObj.po = resultSet[i].prizePool ? resultSet[i].prizePool : '';
                    // multiplayerObj.description = resultSet[i].description;
                    multiplayerObj.visibility = resultSet[i].visibility;
                    multiplayerObj.draftgroupId = resultSet[i].draftgroupId;
                    multiplayerObj.sportId = resultSet[i].sportId;
                    //multiplayerObj.en = resultSet[i].entrants ? resultSet[i].entrants.length : 0;
                    multiplayerObj.en = totalEntry;
                    multiplayerObj.t = resultSet[i].maxLimit ? resultSet[i].maxLimit : '';
                    multiplayerObj.sd = resultSet[i].contestStartTime ? resultSet[i].contestStartTime : '';
                    multiplayerObj.isOwner = (resultSet[i].createdBy == appUserId) ? true : false;
                    multiplayerObj.guarenteed = resultSet[i].isGuaranteed ? true : false;
                    attr = {};
                    sponsor = {};
                    if (resultSet[i].attributes) {
                        sponsor.sponsorName = resultSet[i].attributes.sponsor.sponsorName;
                        sponsor.imgURL = resultSet[i].attributes.sponsor.imgUrl;
                    }
                    attr.isVideo = resultSet[i].isVideoAvailable ? true : false;
                    attr.tags = resultSet[i].labels;
                    attr.sponsor = sponsor
                    multiplayerObj.attributes = attr;
                    multiplayerObj.sort = resultSet[i].sort;
                    //multiplayer.push(multiplayerObj);
                }
                if (resultSet[i].contestTypeId == 2) {
                    var h2hC = {};
                    contestIds = [];
                    var lineupContest = [];
                    contestIds.push(resultSet[i].contestId);
                    //lineup section start
                    var lineupContestObj = {};
                    if ((resultSet[i].createdBy == appUserId)) {
                        lineupContestObj.lineUp = null;
                        lineupContestObj.contest = resultSet[i].contestId;
                        lineupContest.push(lineupContestObj);
                    }
                    //lineup section end
                    var enArr = [];
                    var enObj = {};
                    enObj.contest = resultSet[i].contestId;
                    enObj.en = resultSet[i].entrants ? resultSet[i].entrants.length : 0;
                    enArr.push(enObj);
                    if (resultSet[i].contestGroupId) {
                        var count = 1;
                        var kArr = [];
                        //contestIds.push(resultSet[i].contestId);
                        for (var k in resultSet) {
                            if ((resultSet[k].contestGroupId == resultSet[i].contestGroupId) && (resultSet[k].contestId != resultSet[i].contestId)) {
                                count++;
                                kArr.push(k);
                                contestIds.push(resultSet[k].contestId);
                                //lineup section start
                                var lineupContestObj = {};
                                if ((resultSet[k].createdBy == appUserId)) {
                                    lineupContestObj.lineUp = null;
                                    lineupContestObj.contest = resultSet[k].contestId;
                                    lineupContest.push(lineupContestObj);
                                }
                                //lineup section end
                                var enObj = {};
                                enObj.contest = resultSet[k].contestId;
                                enObj.en = resultSet[k].entrants ? resultSet[k].entrants.length : 0;
                                enArr.push(enObj);
                            }
                        }
                        h2hC.contestCount = count;
                        for (var g = 0; g < kArr.length; g++) {
                            resultSet.splice(kArr[g] - g, 1);
                        }
                    }
                    //(contestIds.length > 1) ? (h2hC.contestIds = contestIds) : (h2hC.contestId = resultSet[i].contestId);
                    h2hC.contestIds = contestIds;
                    // h2hC.id = resultSet[i]._id;
                    h2hC.contestGroupId = resultSet[i].contestGroupId;
                    h2hC.contestName = resultSet[i].contestName ? resultSet[i].contestName : '';
                    h2hC.lineupIds = lineupContest;
                    h2hC.draftgroupId = resultSet[i].draftgroupId;
                    h2hC.username = resultSet[i].userName;
                    h2hC.imageName = resultSet[i].imageName ? resultSet[i].imageName : '';
                    h2hC.isRival = false;
                    h2hC.displayName = (resultSet[i].fName && resultSet[i].lName) ? resultSet[i].fName + ' ' + resultSet[i].lName : '';
                    h2hC.entryFees = resultSet[i].entryFees;
                    h2hC.po = resultSet[i].prizePool ? resultSet[i].prizePool : '';
                    // h2hC.description = resultSet[i].description;
                    h2hC.visibility = resultSet[i].visibility;
                    h2hC.type = resultSet[i].contestType;
                    h2hC.contestTypeId = resultSet[i].contestTypeId;
                    h2hC.me = resultSet[i].maxEntriesPerUser ? resultSet[i].maxEntriesPerUser : '';
                    h2hC.sportId = resultSet[i].sportId;
                    h2hC.sport = resultSet[i].sName;
                    h2hC.en = enArr;
                    h2hC.t = resultSet[i].maxLimit ? resultSet[i].maxLimit : '';
                    h2hC.pid = resultSet[i].createdBy ? resultSet[i].createdBy : '';
                    h2hC.cid = '';
                    h2hC.sd = resultSet[i].contestStartTime ? resultSet[i].contestStartTime : '';
                    h2hC.gameType = resultSet[i].gameType.split(" ")[0];
                    h2hC.gameTypeId = resultSet[i].gameTypeId;
                    h2hC.records = {};
                    h2hC.sort = resultSet[i].sort;
                    // h2h.push(h2hC);
                }
            }
            result = (multiplayerObj != null) ? multiplayerObj : h2hC;
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
    * Data Mapping for contest as response
    * @param {Object} resultSet - Resultset
    * @return {Object} Updated result object
    */
    getContestDetail: function (resultSet, myLineups) {
        try {

            var result = {};
            var multiplayer = [];
            var h2h = [];
            var totalEntry = (resultSet.entrants).reduce(function (a, b) {
                return a + b.totalentry;
            }, 0);
            //added for reserved entry count -- start
            var creatorEntry = resultSet.entrants.find(function (obj) {
                return obj.userId === resultSet.createdBy;
            });
            totalEntry = (creatorEntry && creatorEntry.totalentry == 0) ? totalEntry + 1 : totalEntry;
            //added for reserved entry count -- end
            //lineup details start --added on 30-07-2018
            var lineupIds = [];
            for (var h in myLineups) {
                //live lineups details start --added on 18 July 2018
                var lineupDetails = {};
                if (!myLineups[h].isReserved || (myLineups[h].isReserved && myLineups[h].isReserved == 0) || (myLineups[h].isReserved && myLineups[h].isReserved == 1 && (resultSet.contestStatus == 2 || resultSet.contestStatus == 1))) {
                    lineupDetails.lineupId = myLineups[h].lineupId;
                }
                if (resultSet.contestStatus == 2 || resultSet.contestStatus == 1) {
                    lineupDetails.pos = myLineups[h].position;
                    lineupDetails.w = myLineups[h].winning ? myLineups[h].winning : 0;
                    lineupDetails.score = myLineups[h].points;
                    lineupDetails.rem = myLineups[h].avgRemTimePerc ? myLineups[h].avgRemTimePerc : '';
                }
                lineupIds.push(lineupDetails);
            }
            //lineup details end --added on 30-07-2018
            if (resultSet.contestTypeId == 1) {
                // var contestIds = [];
                // contestIds.push(resultSet.contestId);
                var multiplayerObj = {};
                multiplayerObj.type = resultSet.contestType;
                // multiplayerObj.id = resultSet[i]._id;
                multiplayerObj.contestTypeId = resultSet.contestTypeId;
                multiplayerObj.gameTypeId = resultSet.gameTypeId;
                multiplayerObj.me = resultSet.maxEntriesPerUser ? resultSet.maxEntriesPerUser : '';
                multiplayerObj.rewards = resultSet.rewards ? resultSet.rewards : '';
                multiplayerObj.contestId = resultSet.contestId;
                multiplayerObj.contestName = resultSet.contestName;
                multiplayerObj.entryFees = resultSet.entryFees;
                multiplayerObj.po = resultSet.prizePool ? resultSet.prizePool : '';
                // multiplayerObj.description = resultSet[i].description;
                multiplayerObj.visibility = resultSet.visibility;
                multiplayerObj.draftgroupId = resultSet.draftgroupId;
                multiplayerObj.sportId = resultSet.sportId;
                //multiplayerObj.en = resultSet.entrants ? resultSet.entrants.length : 0;
                multiplayerObj.en = totalEntry;
                multiplayerObj.t = resultSet.maxLimit ? resultSet.maxLimit : '';
                multiplayerObj.sd = resultSet.contestStartTime ? resultSet.contestStartTime : '';
                multiplayerObj.isOwner = (resultSet.createdBy == global.userId) ? true : false;
                multiplayerObj.guarenteed = resultSet.isGuaranteed ? true : false;
                attr = {};
                sponsor = {};
                sponsor.sponsorName = resultSet.attributes.sponsor.sponsorName;
                sponsor.imgURL = resultSet.attributes.sponsor.imgUrl;
                attr.isVideo = resultSet.isVideoAvailable ? true : false;
                attr.tags = resultSet.labels;
                attr.sponsor = sponsor
                multiplayerObj.attributes = attr;
                multiplayerObj.sort = resultSet.sort;
                multiplayerObj.hasLineup = totalEntry > 0 ? true : false;
                multiplayerObj.status = (resultSet.contestStatus == 1) ? 'completed' : ((resultSet.contestStatus == 2) ? 'live' : ((resultSet.contestStatus == 3) ? 'upcoming' : 'cancelled'));
                //multiplayer.push(multiplayerObj);
                multiplayerObj.lineupIds = lineupIds;
            }
            if (resultSet.contestTypeId == 2) {
                var h2hC = {};
                contestIds = [];
                contestIds.push(resultSet.contestId);
                //(contestIds.length > 1) ? (h2hC.contestIds = contestIds) : (h2hC.contestId = resultSet[i].contestId);
                h2hC.contestIds = contestIds;
                // h2hC.id = resultSet[i]._id;
                h2hC.contestGroupId = resultSet.contestGroupId;
                h2hC.contestName = resultSet.contestName ? resultSet.contestName : '';
                h2hC.draftgroupId = resultSet.draftgroupId;
                h2hC.username = resultSet.userName;
                h2hC.displayName = (resultSet.fName && resultSet.lName) ? resultSet.fName + ' ' + resultSet.lName : '';
                h2hC.entryFees = resultSet.entryFees;
                h2hC.po = resultSet.prizePool ? resultSet.prizePool : '';
                // h2hC.description = resultSet.description;
                h2hC.visibility = resultSet.visibility;
                h2hC.type = resultSet.contestType;
                h2hC.contestTypeId = resultSet.contestTypeId;
                h2hC.me = resultSet.maxEntriesPerUser ? resultSet.maxEntriesPerUser : '';
                h2hC.sportId = resultSet.sportId;
                h2hC.sport = resultSet.sName;
                h2hC.en = resultSet.entrants ? resultSet.entrants.length : 0;
                h2hC.t = resultSet.maxLimit ? resultSet.maxLimit : '';
                h2hC.pid = resultSet.createdBy ? resultSet.createdBy : '';
                h2hC.cid = '';
                h2hC.sd = resultSet.contestStartTime ? resultSet.contestStartTime : '';
                h2hC.gameType = resultSet.gameType.split(" ")[0];
                h2hC.gameTypeId = resultSet.gameTypeId;
                h2hC.records = {};
                h2hC.sort = resultSet.sort;
                h2hC.imageName = resultSet.imageName ? resultSet.imageName : '';
                h2hC.hasLineup = totalEntry > 0 ? true : false;
                h2hC.status = (resultSet.contestStatus == 1) ? 'completed' : ((resultSet.contestStatus == 2) ? 'live' : ((resultSet.contestStatus == 3) ? 'upcoming' : 'cancelled'));
                // h2h.push(h2hC);
                h2hC.lineupIds = lineupIds;

            }
            result = (multiplayerObj != null) ? multiplayerObj : h2hC;
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
  * Data Mapping for Add/Update Usermultiple  Lineup
  * @param {Object} resultSet - Resultset
  * @return {Object} Updated result object
  */
    MultipleplayerLinupData: function (lineUpModel, playerArrayDB, request, contestId, referralM = 0) {
        try {
            lineUpModel.contestId = contestId;
            lineUpModel.userId = global.userId;
            lineUpModel.draftgroupId = request.draftgroupId;
            lineUpModel.dgName = request.dgName;
            lineUpModel.startTimeUTC = request.startTimeUTC;
            lineUpModel.gameTypeId = request.gameTypeId;
            lineUpModel.sportId = request.sportId;
            lineUpModel.sName = request.sName ? request.sName : '';
            lineUpModel.referralMoney = referralM ? referralM : 0;
            lineUpModel.points = 0;
            var playersList = [];
            for (var i in playerArrayDB) {
                var player = {};
                player.eventId = request.players[i].eventId;
                player.eventST = playerArrayDB[i].st;
                player.tmpPosId = request.players[i].tmpPosId;
                player.tmpPosAbbr = playerArrayDB[i].players.posAbbr;
                player.tmpPosName = playerArrayDB[i].players.posName;
                player.tmpId = request.players[i].tmpId;
                player.playerId = playerArrayDB[i].players.playerId;
                player.isInjured = playerArrayDB[i].players.isInjured;
                player.fName = playerArrayDB[i].players.fName;
                player.lName = playerArrayDB[i].players.lName;
                player.mValue = playerArrayDB[i].players.mValue;
                player.fanProjSalary = playerArrayDB[i].players.fanProjSalary;
                player.competition = playerArrayDB[i].players.competition;
                player.teamId = playerArrayDB[i].players.teamId;
                player.teamAbbr = playerArrayDB[i].players.teamAbbr;
                player.fanProjScore = playerArrayDB[i].players.fanProjScore;
                player.draftAtt = playerArrayDB[i].players.draftAtt;
                player.playerAttributes = playerArrayDB[i].players.playerAttributes;
                player.gameAttributes = playerArrayDB[i].players.gameAttributes;
                player.scoreInfo = playerArrayDB[i].players.scoreInfo;
                //added for starting pitching probables lineup MLB -- start
                if (request.sportId == 2) {
                    player.starting = playerArrayDB[i].players.starting ? (playerArrayDB[i].players.starting).toString() : '';
                    player.probable = (playerArrayDB[i].players.starting && playerArrayDB[i].players.starting == 'p') ? true : false;
                }
                //added for starting pitching probables lineup MLB -- end
                playersList.push(player);
            }
            lineUpModel.players = playersList;
            return lineUpModel;
        } catch (e) {
            throw e;
        }
    },


    /**
     * Data Mapping for join conest with linwupId
     * @param {Object} request - request set
     * @return {Object} Updated result object
     */
    joinWithLineUpId: function (request) {
        try {
            var row = {};
            row.contestId = request.contestId;
            row.lineupId = request.lineupId;
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
    * Data Mapping for linup Data Resevered
    * @param {Object} contest - Data Schema Object
    * @param {Object} requestData - Request Body Object
    * @param {Object} userDetails - User Object
    * @return {Object} Updated contest object
    */
    linupDataResevered: function (contestId, userId, lineupId, draftgroupId, startTimeUTC, sportId, gameTypeId) {
        try {
            lineUp = {};
            lineUp.lineupId = lineupId;
            lineUp.contestId = contestId;
            lineUp.draftgroupId = draftgroupId;
            lineUp.userId = userId;
            lineUp.points = 0;
            lineUp.isReserved = 1;
            lineUp.startTimeUTC = startTimeUTC;
            lineUp.sportId = sportId;
            lineUp.gameTypeId = gameTypeId;
            return lineUp;
        } catch (e) {
            throw e;
        }
    },

    /**
       * Data Mapping for join contest wih ticket
       * @param {string} ticketId - Request Query Object
       * @return {Object} Array of data
       */
    joinContestTicket: function (ticketId, entryFees, userId) {
        try {
            var ticket = {};
            ticket.ticketId = ticketId;
            ticket.userId = userId;
            ticket.ticketAmount = entryFees;
            return ticket;
        } catch (e) {
            throw e;
        }
    },

    /**
   * Data Mapping for update ticket
   * @param {string} ticketId - Request Query Object
   * @return {Object} Array of data
   */
    updateTicketData: function (ticketId, userId, status = "U") {
        try {
            var ticket = {};
            ticket.ticketId = ticketId;
            ticket.userId = userId;
            ticket.ticketStatus = status;
            return ticket;
        } catch (e) {
            throw e;
        }
    },

    /**
   * Data Mapping for transaction functionality
   * @param {Object} transaction - Data Schema Object
   * @param {Object} userData - User Object
   * @param {String} transactionType - Transaction Type
   * @return {Object} Updated object
   */
    transactionData: function (transaction, userData, amount, transactionType) {
        try {
            transaction.amount = amount;
            transaction.tranStatus = 1;
            transaction.tranType = transactionType;
            transaction.userId = userData.userId;
            transaction.userName = userData.userName;
            transaction.userImg = userData.imageName;
            transaction.fName = userData.fName;
            transaction.lName = userData.lName;
            return transaction;
        } catch (e) {
            throw e;
        }
    },

    /**
   * Data Mapping for update lineup
   * @param {string} transactionId - Request Query Object
   * @return {Object} Array of data
   */
    updateLineupData: function (transactionId) {
        try {
            var lineup = {};
            lineup.transactionId = transactionId;
            return lineup;
        } catch (e) {
            throw e;
        }
    },
    /**
     * Data Mapping for update lineup with Refferal money
     * @param {string} transactionId - Request Query Object
     * @return {Object} Array of data
     */
    updateLineupDataRefferal: function (referralMoney) {
        try {
            var lineup = {};
            lineup.referralMoney = referralMoney;
            return lineup;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for update Transaction Statu
     * @param {string} transactionId - Request Query Object
     * @return {Object} Array of data
     */
    updateTransactionStatus: function () {
        try {
            var transaction = {};
            //transaction.amount = 0; 
            transaction.tranType = "UC";
            return transaction;
        } catch (e) {
            throw e;
        }
    },

    /**
   * Data Mapping for update Transaction amount
   * @param {string} transactionId - Request Query Object
   * @return {Object} Array of data
   */
    updateTransactionamount: function (amount) {
        try {
            var transaction = {};
            transaction.amount = amount;
            return transaction;
        } catch (e) {
            throw e;
        }
    },

};