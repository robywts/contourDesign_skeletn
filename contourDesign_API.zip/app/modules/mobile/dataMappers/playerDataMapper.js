/**
 * Player  Data Mapper
 * @exports Player/DataMapper
 */
module.exports = {

    /**
     * Data Mapping for get Player News Details
     * @param {Object} playerId - playerId
     * @return {Object} Updated result object
     */
    playerNewsData: function (playerId) {
        try {
            playerId = parseInt(playerId);
            return playerId;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get Player Games
     * @param {Object} req - Request parameters
     * @return {Object} Updated result object
     */
    playerGamesData: function (req) {
        try {
            var res = {};
            res.playerId = parseInt(req.id);
            res.sportsId = parseInt(req.sid);
            return res;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get player scores
     * @param {Object} query - Query values
     * @return {Object} Updated response object
     */
    playerScoresData: function (query) {
        try {
            var dataSet = {};
            dataSet['idArr'] = query.id.split(',');
            dataSet['final'] = (query.final) ? query.final : 'both';
            return dataSet;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get player news details as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    playerNewsResultMap: function (resultSet) {
        try {
            var newsArr = [];
            for (var j = 0; j < resultSet.length; j++) {
                var playerNews = {};

                playerNews.sportId = resultSet[j].sportId;
                League = {};
                League.leagueId = resultSet[j].league.leagueId;
                League.abbr = resultSet[j].league.abbr;
                playerNews.league = League;
                playerNews.season = resultSet[j].season;
                playerNews.playerId = resultSet[j].playerId;
                playerNews.fName = resultSet[j].fName;
                playerNews.lName = resultSet[j].lName;
                playerNews.newsText = resultSet[j].newsText;
                playerNews.adviceText = resultSet[j].adviceText;
                playerNews.lName = resultSet[j].lName;

                Team = {};
                Team.teamId = resultSet[j].team.teamId;
                Team.abbr = resultSet[j].team.tAbbr;
                playerNews.team = Team;
                Positions = resultSet[j].positions;
                positions = [];
                for (var i = 0; i < Positions.length; i++) {
                    position = {}
                    position.sequence = Positions[i].sequence;
                    position.posName = Positions[i].posName;
                    position.posAbbr = Positions[i].posAbbr;
                    position.posId = Positions[i].posId;
                    positions.push(position);
                }
                playerNews.positions = positions;
                playerNews.originalDateUtc = resultSet[j].originalDateUtc;
                newsArr.push(playerNews);
            }
            return newsArr;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get player games details as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    playerGamesResultMap: function (resultSet) {
        try {
            var playerGames = resultSet.gamesJson;

            return playerGames;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get player score as response
     * @param {Object} result - Resultset
     * @return {Object} Updated result object
     */
    playerScoresResultMap: function (result) {
        try {
            var game = {};
            var gIndx = 0;
            // var pIndx = 0;
            // var prevEventId = '';
            for (var i in result) { // looping player records
                // if (prevEventId != result[i].eventId || pIndx == 5) {
                //     gIndx++;
                //     pIndx = 0;
                // }
                // pIndx++;
                // prevEventId = result[i].eventId;
                gIndx = result[i].eventId;

                if (!game[gIndx]) {
                    game[gIndx] = {};
                }
                game[gIndx]['sportId'] = result[i].sportId;
                game[gIndx]['gameId'] = result[i].eventId;
                game[gIndx]['isFinal'] = (result[i].eventStatus == 'Final') ? true : false;

                game[gIndx]['liveGameInfo'] = result[i].liveGameInfo;
                game[gIndx]['liveGameInfo2'] = result[i].liveGameInfo2;
                // if (result[i].possTeam) {
                game[gIndx]['possTeam'] = result[i].possTeam;
                // }
                // if (!game[gIndx]['possTeam']) {
                //     game[gIndx]['possTeam'] = '';
                // }
                game[gIndx]['homeScore'] = result[i].homeScore;
                game[gIndx]['awayScore'] = result[i].awayScore;
                game[gIndx]['homeAbbr'] = result[i].homeAbbr;
                game[gIndx]['awayAbbr'] = result[i].awayAbbr;
                game[gIndx]['clock'] = result[i].clock;
                game[gIndx]['fieldPos'] = result[i].fieldPos ? result[i].fieldPos : 0;

                if (!game[gIndx]['players']) {
                    game[gIndx]['players'] = [];
                }
                // if (!game[gIndx]['players'][result[i].playerId]) {
                //     game[gIndx]['players'][result[i].playerId] = {};
                // }
                var player = {};

                player['playerId'] = result[i].playerId;
                player['isAtBat'] = (result[i].isAtBat == 'true') ? true : false;
                player['playerName'] = result[i].playerName;
                player['posId'] = result[i].playerPositionId;
                player['pos'] = result[i].playerPosition;
                player['team'] = result[i].teamName;
                player['teamAlias'] = result[i].teamAlias;
                player['xmlFile'] = result[i].fileName;

                player['scoring'] = [];

                if (result[i].sportId == 2) {
                    for (var param in result[i]['playerStats']['battingStats']) {
                        var playerParamScore = result[i]['playerStats']['battingStats'][param]['val'] * result[i]['playerStats']['battingStats'][param]['pts'];
                        player['scoring'].push({
                            't': param,
                            'abr': result[i]['playerStats']['battingStats'][param]['abr'],
                            'n': result[i]['playerStats']['battingStats'][param]['val'] * 1,
                            'v': playerParamScore,
                            's': 'pts'
                        });
                    }
                    for (var param in result[i]['playerStats']['pitchingStats']) {
                        var playerParamScore = result[i]['playerStats']['pitchingStats'][param]['val'] * result[i]['playerStats']['pitchingStats'][param]['pts'];
                        player['scoring'].push({
                            't': param,
                            'abr': result[i]['playerStats']['pitchingStats'][param]['abr'],
                            'n': result[i]['playerStats']['pitchingStats'][param]['val'] * 1,
                            'v': playerParamScore,
                            's': 'pts'
                        });
                    }
                }
                else if (result[i].sportId == 1) {
                    if (result[i]['playerStats']) {
                        for (var param in result[i]['playerStats']['passing']) {
                            var playerParamScore = Math.round((result[i]['playerStats']['passing'][param]['val'] * result[i]['playerStats']['passing'][param]['pts']) * 100) / 100;
                            player['scoring'].push({
                                't': param,
                                'abr': result[i]['playerStats']['passing'][param]['abr'],
                                'n': result[i]['playerStats']['passing'][param]['val'] * 1,
                                'v': playerParamScore,
                                's': 'pts'
                            });
                        }
                    }
                    if (result[i]['playerStats']) {
                        for (var param in result[i]['playerStats']['rushing']) {
                            var playerParamScore = Math.round((result[i]['playerStats']['rushing'][param]['val'] * result[i]['playerStats']['rushing'][param]['pts']) * 100) / 100;
                            player['scoring'].push({
                                't': param,
                                'abr': result[i]['playerStats']['rushing'][param]['abr'],
                                'n': result[i]['playerStats']['rushing'][param]['val'] * 1,
                                'v': playerParamScore,
                                's': 'pts'
                            });
                        }
                    }
                    if (result[i]['playerStats']) {
                        for (var param in result[i]['playerStats']['receiving']) {
                            var playerParamScore = Math.round((result[i]['playerStats']['receiving'][param]['val'] * result[i]['playerStats']['receiving'][param]['pts']) * 100) / 100;
                            player['scoring'].push({
                                't': param,
                                'abr': result[i]['playerStats']['receiving'][param]['abr'],
                                'n': result[i]['playerStats']['receiving'][param]['val'] * 1,
                                'v': playerParamScore,
                                's': 'pts'
                            });
                        }
                    }
                    if (result[i]['playerStats']) {
                        for (var param in result[i]['playerStats']['scoring']) {
                            var playerParamScore = Math.round((result[i]['playerStats']['scoring'][param]['val'] * result[i]['playerStats']['scoring'][param]['pts']) * 100) / 100;
                            player['scoring'].push({
                                't': param,
                                'abr': result[i]['playerStats']['scoring'][param]['abr'],
                                'n': result[i]['playerStats']['scoring'][param]['val'] * 1,
                                'v': playerParamScore,
                                's': 'pts'
                            });
                        }
                    }
                    if (result[i]['playerStats']) {
                        for (var param in result[i]['playerStats']['fumbles']) {
                            var playerParamScore = Math.round((result[i]['playerStats']['fumbles'][param]['val'] * result[i]['playerStats']['fumbles'][param]['pts']) * 100) / 100;
                            player['scoring'].push({
                                't': param,
                                'abr': result[i]['playerStats']['fumbles'][param]['abr'],
                                'n': result[i]['playerStats']['fumbles'][param]['val'] * 1,
                                'v': playerParamScore,
                                's': 'pts'
                            });
                        }
                    }
                }
                player['playerScore'] = Math.round(result[i]['playerScore'] * 100) / 100;
                /*player['multiPlayerScore'] = {};
                  for (var dgId in result[i]['multiPlayerScore']) {
                      player['multiPlayerScore'][dgId] = Math.round(result[i]['multiPlayerScore'][dgId] * 100) / 100;
                  }*/
                player['multiPlayerScore'] = Math.round(result[i]['multiPlayerScore'] * 100) / 100;
                game[gIndx]['players'].push(player);
            }

            var gameArr = new Array();
            for (oneGame in game) {
                gameArr.push(game[oneGame]);
            }
            return gameArr;
        } catch (e) {
            throw e;
        }
    },

};