/**
 * DraftGroup  Data Mapper
 * @exports DraftGroup/DataMapper
 */
module.exports = {
    /**
     * Data Mapping for get DraftGroups
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftListData: function ({ }, requestData) {
        try {
            var draftgroup = {};
            //draftgroup.dgWeek = parseInt(requestData.week);
            draftgroup.sportId = parseInt(requestData.sportId);
            // draftgroup.dgSeason = parseInt(requestData.season);
            return draftgroup;
        } catch (e) {
            throw e;
        }
    },

    /**
    * Data Mapping for get DraftGroups as response
    * @param {Object} resultSet - Resultset
    * @return {Object} Updated result object
    */
    draftGroupResultMap: function (resultSetDraft, resultSetLineup) {
        try {
            //draftgroups
            var drafts = {};
            var draftGroups = [];
            var eventSets = [];
            for (var i in resultSetDraft) {
                var row = {};
                row.eventIds = [];
                row.draftgroupId = resultSetDraft[i].draftgroupId;
                row.name = resultSetDraft[i].dgName;
                row.gamesCount = (resultSetDraft[i].gameList).length;
                row.status = resultSetDraft[i].dgState;
                row.sportId = resultSetDraft[i].sportId;
                row.st = resultSetDraft[i].startTimeUTC;
                row.draftGroupState = resultSetDraft[i].dgState;
                row.sortOrder = resultSetDraft[i].sortOrder;
                League = [];
                rowLeague = {};
                rowLeague.leagueId = resultSetDraft[i].league[0].leagueId;
                rowLeague.leagueAbbreviation = resultSetDraft[i].league[0].abbr;
                rowLeague.leagueName = resultSetDraft[i].league[0].name;
                League.push(rowLeague);
                row.leagues = League;
                //event set 
                eventSet = {};
                eventSet.sportId = resultSetDraft[i].sportId;
                eventSet.draftgroupId = resultSetDraft[i].draftgroupId;
                events = [];
                for (var j = 0, len = resultSetDraft[i].gameList.length; j < len; j++) {
                    //event Set start
                    event = {};
                    event.eventId = resultSetDraft[i].gameList[j].eventId;
                    event.sport = resultSetDraft[i].league[0].abbr;
                    homeTeam = {};
                    if (resultSetDraft[i].gameList[j].players.length > 0) {
                        homeTeam.teamId = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].htId;
                        homeTeam.teamName = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].htName;
                        homeTeam.abbreviation = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].htAbbr;
                        homeTeam.city = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].htCity;
                        homeTeam.wins = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].htRecord.wins;
                        homeTeam.losses = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].htRecord.losses;
                        event.homeTeam = homeTeam;
                        awayTeam = {};
                        awayTeam.teamId = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].atId;
                        awayTeam.teamName = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].atName;
                        awayTeam.abbreviation = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].atAbbr;
                        awayTeam.city = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].atCity;
                        awayTeam.wins = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].atRecord.wins;
                        awayTeam.losses = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].atRecord.losses;
                        event.awayTeam = awayTeam;
                        event.startTime = resultSetDraft[i].gameList[j].startTimeUTC;
                        event.name = resultSetDraft[i].gameList[j].players[0].competition.nameDisplay[0].value;
                    }
                    event.venue = resultSetDraft[i].gameList[j].venueName;
                    weather = {};
                    weather.type = resultSetDraft[i].gameList[j].weather.conditionDesc;
                    event.weather = weather;
                    event.startingLineupReady = resultSetDraft[i].gameList[j].startingLineupReady;
                    event.competitionState = resultSetDraft[i].gameList[j].gameStatus;
                    events.push(event);
                    //event Set end
                    row.eventIds.push(resultSetDraft[i].gameList[j].eventId);
                }
                eventSet.events = events;
                eventSets.push(eventSet);
                draftGroups.push(row);
            }
            drafts.draftGroups = draftGroups;
            //lineuptemplates
            var lineuptemp = [];
            for (var j in resultSetLineup) {
                var lineuptemplate = {};
                lineuptemplate.sportId = resultSetLineup[j].sportId;
                lineuptemplate.name = resultSetLineup[j].sName;
                lineuptemplate.sortOrder = resultSetLineup[j].sortOrder;
                lineuptemplate.available = resultSetLineup[j].isAvailable;
                var Game = [];
                if (resultSetLineup[j].gameTypes.length != 0) {
                    var gameType = [];
                    var len = resultSetLineup[j].gameTypes.length;
                    for (var k = 0; k < len; k++) {
                        var rowGame = {};
                        rowGame.lptemplateId = resultSetLineup[j].gameTypes[k].lptemplateid;
                        rowGame.type = resultSetLineup[j].gameTypes[k].gameType;
                        rowGame.gameTypeId = resultSetLineup[j].gameTypes[k].gameTypeId;
                        rowGame.cap = resultSetLineup[j].gameTypes[k].capLimit;
                        var Template = [];
                        templates = resultSetLineup[j].gameTypes[k].template;
                        for (var l = 0; l < templates.length; l++) {
                            rowTemp = {};
                            rowTemp.id = templates[l].id;
                            rowTemp.PositionID = templates[l].posId;
                            if (lineuptemplate.sportId == 3 || lineuptemplate.sportId == 4) {
                                var posGName = (templates[l].posName).split(" ").splice(-1)[0];
                                rowTemp.Position = (templates[l].posAbbr)[(templates[l].posAbbr).length - 1];
                                rowTemp.PositionName = posGName;
                            }
                            else {
                                rowTemp.Position = templates[l].posAbbr;
                                rowTemp.PositionName = templates[l].posName;
                            }
                            rowTemp.playerId = '';
                            rowTemp.playerName = '';
                            Template.push(rowTemp);
                        }
                        rowGame.template = Template;
                        gameType.push(rowGame);
                    }
                }
                lineuptemplate.gameTypes = gameType;
                lineuptemp.push(lineuptemplate);
            }
            drafts.sports = lineuptemp;
            drafts.eventSets = eventSets;
            return drafts;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get DraftGroup Details
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftDetailsData: function (darftGroupId) {
        try {
            draftgroupId = parseInt(darftGroupId);
            return draftgroupId;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get DraftGroup details as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftGroupDetailsResultMap: function (resultSet) {
        try {
            var draftGroup = {};
            draftGroup.draftgroupId = resultSet.draftgroupId;
            draftGroup.dgName = resultSet.dgName;
            draftGroup.dgState = resultSet.dgState ? resultSet.dgState : '';
            draftGroup.dgWeek = resultSet.week;
            draftGroup.dgSeason = resultSet.season;
            draftGroup.startTimeSuffix = resultSet.startTimeSuffix ? resultSet.startTimeSuffix : '';
            draftGroup.sportId = resultSet.sportId;
            draftGroup.sName = resultSet.sName;
            draftGroup.contestList = resultSet.contestList;
            draftGroup.sortOrder = resultSet.sortOrder ? resultSet.sortOrder : '';

            draftGroup.gameList = [];

            games = resultSet.gameList;
            for (var i in games) {
                if (games[i].eventId) {
                    var rowGame = {};
                    rowGame.eventId = games[i].eventId;
                    rowGame.startTimeUTC = games[i].startTimeUTC;
                    rowGame.gameStatus = games[i].gameStatus ? games[i].gameStatus : '';
                    playersList = [];
                    players = resultSet.gameList[i].players;
                    for (var j in players) {
                        if (players[j].competition) {
                            rowPlayer = {};
                            rowPlayer.fName = players[j].fName;
                            rowPlayer.lName = players[j].lName;
                            rowPlayer.playerId = players[j].playerId;
                            rowPlayer.uniform = players[j].uniform;
                            // rowPlayer.posId = players[j].posId;
                            rowPlayer.posAbbr = players[j].posAbbr;
                            rowPlayer.CapValue = players[j].CapValue;
                            rowPlayer.injuryDetail = players[j].isInjured;
                            rowPlayer.injuryStatus = (players[j].isInjured != null) ? (("'" + players[j].isInjured + "'").match(/\b\w/g).join('')).toUpperCase() : '';
                            if (resultSet.sportId == 2 && players[j].isInjured != 'Day-to-Day' && players[j].isInjured != null) {
                                rowPlayer.injuryStatus = ("" + players[j].isInjured + "").split(' ')[0] + ("" + players[j].isInjured + "").split(" ").splice(-1);
                            }
                            competitionObj = {};
                            competitionObj.compId = (players[j].competition.compId) ? (players[j].competition.compId) : '';
                            nameDisplayList = [];
                            nameDisplayObj = {};
                            nameDisplayObj.htName = players[j].competition.nameDisplay[0].htName;
                            nameDisplayObj.htAbbr = (players[j].competition.nameDisplay[0].htAbbr) ? players[j].competition.nameDisplay[0].htAbbr : '';
                            nameDisplayObj.htScore = (players[j].competition.nameDisplay[0].htScore) ? players[j].competition.nameDisplay[0].htScore : '';
                            nameDisplayObj.value = (players[j].competition.nameDisplay[0].value) ? players[j].competition.nameDisplay[0].value : '';
                            nameDisplayObj.atName = (players[j].competition.nameDisplay[0].atName) ? players[j].competition.nameDisplay[0].atName : '';
                            nameDisplayObj.atAbbr = (players[j].competition.nameDisplay[0].atAbbr) ? players[j].competition.nameDisplay[0].atAbbr : '';
                            nameDisplayObj.atScore = (players[j].competition.nameDisplay[0].atScore) ? players[j].competition.nameDisplay[0].atScore : '';
                            nameDisplayList.push(nameDisplayObj);
                            competitionObj.nameDisplay = nameDisplayList;
                            rowPlayer.competition = competitionObj;
                            rowPlayer.teamId = players[j].teamId;
                            rowPlayer.teamAbbr = players[j].teamAbbr;
                            rowPlayer.fanProjScore = players[j].fanProjScore;
                            playersList.push(rowPlayer);
                        }
                    }
                    rowGame.players = playersList;
                    draftGroup.gameList.push(rowGame);
                }
            }
            //draftGroup.gameList = gameList;
            return draftGroup;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get DraftGroup's contest as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftGroupContestResultMap: function (resultSet) {
        try {
            var contests = [];
            for (var i in resultSet) {
                var row = {};
                row.id = resultSet[i].contestId;
                row.name = resultSet[i].contestName;
                row.entryFee = resultSet[i].entryFees;
                row.contestTypeId = resultSet[i].contestTypeId;
                row.contestType = resultSet[i].contestType;
                row.gameTypeId = resultSet[i].gameTypeId;
                row.gameType = resultSet[i].gameType;
                contests.push(row);
            }
            return contests;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get DraftGroup's players as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftGroupPlayersResultMap: function (resultSet, playerTemplate, minSalary) {
        try {
            games = resultSet.gameList;
            playersList = [];
            for (var i in games) {
                if (games[i].eventId) {
                    players = games[i].players;
                    for (var j in players) {
                        // if (players[j].isDisabled == 0) {
                        if (players[j].competition) {
                            rowPlayer = {};
                            pId = players[j].playerId
                            rowPlayer.eventId = games[i].eventId;
                            rowPlayer.startTimeUTC = games[i].startTimeUTC;
                            rowPlayer.fName = players[j].fName;
                            rowPlayer.lName = players[j].lName;
                            rowPlayer.playerId = pId;
                            rowPlayer.uniform = players[j].uniform;
                            rowPlayer.canDraft = (games[i].gameStatus == 'Upcoming') ? 'true' : false;
                            rowPlayer.posAbbr = players[j].posAbbr;
                            rowPlayer.info = players[j].info?players[j].info: '';
                            if (resultSet.sportId != 2) {
                                var posIdTemp = playerTemplate.find(o => o.posAbbr == players[j].posAbbr);
                                rowPlayer.posId = (posIdTemp) ? posIdTemp.posId : '';
                            }
                            else {
                                var posIdTemp = playerTemplate.find(o => o.posName == players[j].posGen);
                                rowPlayer.posId = (posIdTemp) ? posIdTemp.posId : '';
                            }
                            rowPlayer.injuryDetail = players[j].isInjured;
                            rowPlayer.injuryStatus = (players[j].isInjured != null) ? (("'" + players[j].isInjured + "'").match(/\b\w/g).join('')).toUpperCase() : '';
                            if (resultSet.sportId == 2 && players[j].isInjured != 'Day-to-Day' && players[j].isInjured != null) {
                                rowPlayer.injuryStatus = ("" + players[j].isInjured + "").split(' ')[0] + ("" + players[j].isInjured + "").split(" ").splice(-1);
                            }
                            // rowPlayer.htName = players[j].competition.nameDisplay[0].htName ? players[j].competition.nameDisplay[0].htName : '';
                            //  rowPlayer.atName = (players[j].competition.nameDisplay[0].atName) ? players[j].competition.nameDisplay[0].atName : '';
                            rowPlayer.fanProjSalary = players[j].fanProjSalary;
                            //min salary setting
                            if ((players[j].fanProjSalary == 0 || isNaN(players[j].fanProjSalary)) && (resultSet.sportId == 4 || resultSet.sportId == 3 || resultSet.sportId == 2)) {
                                for (var h in minSalary) {
                                    if (minSalary[h]._id == players[j].posGen) {
                                        rowPlayer.fanProjSalary = minSalary[h].min;
                                    }
                                }
                            }
                            else if ((players[j].fanProjSalary == 0 || isNaN(players[j].fanProjSalary)) && (resultSet.sportId != 4 || resultSet.sportId != 3 || resultSet.sportId != 2)) {
                                for (var h in minSalary) {
                                    if (minSalary[h]._id == players[j].posAbbr) {
                                        rowPlayer.fanProjSalary = minSalary[h].min;
                                    }
                                }
                            }

                            rowPlayer.multiplier = players[j].mValue;
                            competitionObj = {};
                            competitionObj.compId = (players[j].competition.compId) ? (players[j].competition.compId) : '';
                            nameDisplayList = [];
                            nameDisplayObj = {};
                            nameDisplayObj.htName = players[j].competition.nameDisplay[0].htName ? players[j].competition.nameDisplay[0].htName : '';
                            nameDisplayObj.htAbbr = (players[j].competition.nameDisplay[0].htAbbr) ? players[j].competition.nameDisplay[0].htAbbr : '';
                            nameDisplayObj.htScore = (players[j].competition.nameDisplay[0].htScore) ? players[j].competition.nameDisplay[0].htScore : '';
                            nameDisplayObj.value = (players[j].competition.nameDisplay[0].value) ? players[j].competition.nameDisplay[0].value : '';
                            nameDisplayObj.atName = (players[j].competition.nameDisplay[0].atName) ? players[j].competition.nameDisplay[0].atName : '';
                            nameDisplayObj.atAbbr = (players[j].competition.nameDisplay[0].atAbbr) ? players[j].competition.nameDisplay[0].atAbbr : '';
                            nameDisplayObj.atScore = (players[j].competition.nameDisplay[0].atScore) ? players[j].competition.nameDisplay[0].atScore : '';
                            nameDisplayList.push(nameDisplayObj);
                            competitionObj.nameDisplay = nameDisplayList;
                            rowPlayer.competition = competitionObj;
                            rowPlayer.teamId = players[j].teamId;
                            rowPlayer.teamAbbr = players[j].teamAbbr;
                            rowPlayer.fanProjScore = players[j].fanProjScore;
                            //added for starting pitching probables lineup MLB -- start
                            if (resultSet.sportId == 2) {
                                rowPlayer.starting = players[j].starting ? (players[j].starting).toString() : '';
                                //rowPlayer.probable = (players[j].starting && players[j].starting == 'P') ? true : false;
                                rowPlayer.probable = players[j].probable ? players[j].probable:false;
                            }
                            //added for starting pitching probables lineup MLB -- end
                            // found = this.checkAndAdd(pId, playersList);
                            var found = false;
                            for (var y = 0; y < playersList.length; y++) {
                                if (playersList[y].playerId == pId) {
                                    found = true;
                                    (resultSet.sportId == 2) ? (playersList[y] = rowPlayer) : '';  //added for considering MLB postponed game
                                    break;
                                }
                            }
                            if (!found) {
                                playersList.push(rowPlayer);
                                if (resultSet.sportId == 1 && (players[j].posAbbr == 'TE' || players[j].posAbbr == 'RB' || players[j].posAbbr == 'WR')) {
                                    var posIdTemp = playerTemplate.find(o => o.posAbbr == 'Flex');
                                    var player2 = Object.assign({}, rowPlayer);
                                    player2.posId = (posIdTemp) ? posIdTemp.posId : '';
                                    player2.posAbbr = 'Flex';
                                    playersList.push(player2);
                                }
                            }

                        }
                        // }
                    }
                }
            }
            return playersList;
        } catch (e) {
            throw e;
        }
    },
    /**
     * Data Mapping for Search
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : requestData.page_limit;
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            search.sort = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            search.sort_field = (!requestData.sort_field) ? 'name' : requestData.sort_field;
            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Function to check player exist
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    checkAndAdd: function (pId, playersList) {
        playersList.some(function (el) {
            return el.playerId === pId;
        });
    },

    /**
     * Data Mapping for get DraftGroup lineups as response
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    draftGroupLineUpsResultMap: function (resultSet, allMyContestDB, status = 0) {
        try {
            var lineups = [];
            for (var i in resultSet) {
                //for getting lineup status
                var matchedContest = (allMyContestDB).find(function (obj) {
                    return obj.contestId === resultSet[i].contestId;
                });

                if (status ? ((matchedContest && matchedContest.contestStatus == status) || (resultSet[i].contestId == 0 && status == 3)) : '1==1') {
                    var rowLineup = {};
                    // rowLineup.lineupId = resultSet[i].lineupId;
                    //contest grouping check start
                    resultSet2 = resultSet;
                    //  var contestIds = [];
                    //  var lineupIds = [];
                    var remArr = [];
                    //   contestIds.push(resultSet[i].contestId);
                    //   lineupIds.push(resultSet[i].lineupId);
                    //lineup-contest combination
                    var lineupContest = [];
                    var lineupContestObj = {};
                    lineupContestObj.lineUp = resultSet[i].lineupId;
                    lineupContestObj.contest = resultSet[i].contestId;
                    if (matchedContest)
                        lineupContestObj.status = (matchedContest.contestStatus == 1) ? 'completed' : ((matchedContest.contestStatus == 2) ? 'live' : ((matchedContest.contestStatus == 3) ? 'upcoming' : 'cancelled'));//1-Completed, 2- live, 3- Yet To happen, 4- cancelled
                    else
                        lineupContestObj.status = 'upcoming';
                    lineupContest.push(lineupContestObj);

                    for (var n = 0; n < resultSet2.length; n++) {
                        if ((resultSet2[n].draftgroupId == resultSet[i].draftgroupId) && (resultSet2[n].players.length == resultSet[i].players.length) && (resultSet2[n].lineupId != resultSet[i].lineupId) && (resultSet[i].gameTypeId == resultSet2[n].gameTypeId)) {
                            var resultSet2players = resultSet2[n].players.slice();
                            var resultSet1players = resultSet[i].players.slice();
                            var count = 0;
                            for (var k = 0; k < resultSet1players.length; k++) {
                                for (var v = 0; v < resultSet2players.length; v++) {
                                    if (resultSet2players[v].playerId == resultSet1players[k].playerId && resultSet2players[v].tmpPosId == resultSet1players[k].tmpPosId) {
                                        count = count + 1;
                                        resultSet2players.splice(v, 1);
                                    }
                                }
                            }
                            if (count == resultSet2[n].players.length) {
                                //lineup status start
                                var matchedContest2 = (allMyContestDB).find(function (obj) {
                                    return obj.contestId === resultSet2[n].contestId;
                                });
                                if (status ? ((matchedContest2 && matchedContest2.contestStatus == status) || (resultSet2[n].contestId == 0 && status == 3)) : '1==1') {
                                    //  contestIds.push(resultSet2[n].contestId);//console.log(resultSet2[n].contestId);
                                    //  lineupIds.push(resultSet2[n].lineupId);
                                    //lineup-contest combination
                                    var lineupContestObj = {};
                                    lineupContestObj.lineUp = resultSet2[n].lineupId;
                                    lineupContestObj.contest = resultSet2[n].contestId;
                                    if (matchedContest2)
                                        lineupContestObj.status = (matchedContest2.contestStatus == 1) ? 'completed' : ((matchedContest2.contestStatus == 2) ? 'live' : ((matchedContest2.contestStatus == 3) ? 'upcoming' : 'cancelled'));//1-Completed, 2- live, 3- Yet To happen, 4- cancelled
                                    else
                                        lineupContestObj.status = 'upcoming';
                                    //lineup status end
                                    lineupContest.push(lineupContestObj);
                                    remArr.push(n);
                                }
                                // resultSet.splice(n, 1);
                            }
                        }
                    }
                    for (var g = 0; g < remArr.length; g++) {
                        resultSet.splice(remArr[g] - g, 1);
                    }
                    //contest grouping check end
                    //contestIds.length > 1 ? (rowLineup.contestIds = contestIds) : (rowLineup.contestId = resultSet[i].contestId);
                    if (resultSet[i]) {
                        /* rowLineup.contestIds = contestIds.filter(function (elem, index, self) {
                             return index === self.indexOf(elem);
                         });
                         rowLineup.lineupIds = lineupIds;*/
                        rowLineup.lineupContest = lineupContest;
                        rowLineup.userId = resultSet[i].userId;
                        rowLineup.draftgroupId = resultSet[i].draftgroupId;
                        rowLineup.draftgroupName = resultSet[i].dgName;
                        rowLineup.st = resultSet[i].startTimeUTC;
                        rowLineup.gameTypeId = resultSet[i].gameTypeId;
                        rowLineup.sportId = resultSet[i].sportId;
                        //lineup status start
                        var matchedContest = (allMyContestDB).find(function (obj) {
                            return obj.draftgroupId === resultSet[i].draftgroupId;
                        });
                        //rowLineup.status = (matchedContest.contestStatus == 1) ? 'completed' : ((matchedContest.contestStatus == 2) ? 'live' : ((matchedContest.contestStatus == 3) ? 'upcoming' : 'cancelled'));//1-Completed, 2- live, 3- Yet To happen, 4- cancelled
                        //lineup status end
                        playersList = [];
                        players = resultSet[i].players;
                        for (var j = 0; j < players.length; j++) {
                            rowPlayer = {};
                            rowPlayer.eventId = players[j].eventId;
                            rowPlayer.startTimeUTC = players[j].eventST;
                            rowPlayer.posId = players[j].tmpPosId;
                            rowPlayer.posAbbr = players[j].tmpPosAbbr;
                            rowPlayer.posName = players[j].tmpPosName;
                            /*  if (resultSet[i].sportId == 3 || resultSet[i].sportId == 4) {
                                  var posGName = (players[j].tmpPosName).split(" ").splice(-1)[0];
                                  rowPlayer.posAbbr =  (players[j].tmpPosAbbr)[(players[j].tmpPosAbbr).length -1];
                                  rowPlayer.posName = posGName;
                              }*/
                            rowPlayer.tmpId = players[j].tmpId;
                            rowPlayer.playerId = players[j].playerId;
                            rowPlayer.fName = players[j].fName;
                            rowPlayer.lName = players[j].lName;
                            rowPlayer.multiplier = players[j].mValue;
                            rowPlayer.playerName = players[j].playerName;
                            rowPlayer.imgUrl = players[j].imgUrl;
                            rowPlayer.injuryDetail = players[j].isInjured ? players[j].isInjured : '';
                            rowPlayer.injuryStatus = (players[j].isInjured != null) ? (("'" + players[j].isInjured + "'").match(/\b\w/g).join('')).toUpperCase() : '';
                            if (resultSet[i].sportId == 2 && players[j].isInjured != 'Day-to-Day' && players[j].isInjured != null) {
                                rowPlayer.injuryStatus = ("" + players[j].isInjured + "").split(' ')[0] + ("" + players[j].isInjured + "").split(" ").splice(-1);
                            }
                            competitionObj = {};
                            competitionObj.compId = (players[j].competition.compId) ? (players[j].competition.compId) : '';
                            nameDisplayList = [];
                            nameDisplayObj = {};
                            nameDisplayObj.htName = players[j].competition.nameDisplay[0].htName;
                            nameDisplayObj.htAbbr = players[j].competition.nameDisplay[0].htAbbr ? players[j].competition.nameDisplay[0].htAbbr : '';
                            nameDisplayObj.htScore = (players[j].competition.nameDisplay[0].htScore) ? players[j].competition.nameDisplay[0].htScore : '';
                            nameDisplayObj.value = (players[j].competition.nameDisplay[0].value) ? players[j].competition.nameDisplay[0].value : '';
                            nameDisplayObj.atName = (players[j].competition.nameDisplay[0].atName) ? players[j].competition.nameDisplay[0].atName : '';
                            nameDisplayObj.atAbbr = players[j].competition.nameDisplay[0].atAbbr ? players[j].competition.nameDisplay[0].atAbbr : '';
                            nameDisplayObj.atScore = (players[j].competition.nameDisplay[0].atScore) ? players[j].competition.nameDisplay[0].atScore : '';
                            nameDisplayList.push(nameDisplayObj);
                            competitionObj.nameDisplay = nameDisplayList;
                            rowPlayer.competition = competitionObj;
                            rowPlayer.teamId = players[j].teamId;
                            rowPlayer.teamAbbr = players[j].teamAbbr;
                            rowPlayer.fanProjScore = players[j].fanProjScore;
                            rowPlayer.info = players[j].info ? players[j].info: '';
                            //rowPlayer.fanProjSalary = players[j].fanProjSalary; 
                            rowPlayer.multiplier = players[j].mValue;
                            //added for starting pitching probables lineup MLB -- start
                            if (resultSet[i].sportId == 2) {
                                rowPlayer.starting = players[j].starting ? (players[j].starting).toString() : '';
                                //rowPlayer.probable = (players[j].starting && players[j].starting == 'P') ? true : false;
                                rowPlayer.probable = players[j].probable ? players[j].probable : false;
                            }
                            //added for starting pitching probables lineup MLB -- end
                            playersList.push(rowPlayer);
                        }
                        rowLineup.players = playersList;
                        lineups.push(rowLineup);
                    }
                }
            }
            //console.log(lineups);process.exit();
            return lineups;
        } catch (e) {
            throw e;
        }
    },

    /**
    * Data Mapping for get All lineUp
    * @param {Object} resultSet - Resultset     
    */
    lineUpMappData: function (requestData) {
        try {
            var lineUp = {};
            lineUp.status = (requestData.status) ? parseInt(requestData.status) : '';
            return lineUp;
        } catch (e) {
            throw e;
        }
    },
};