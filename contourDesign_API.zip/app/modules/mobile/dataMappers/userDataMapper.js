/**
 * user  Data Mapper
 * @exports User/DataMapper
 */
var moment = require('moment');
var fbHelper = require('../helpers/fbHelper');
var crypto = require('crypto');
var timeStamp = Math.round((new Date()).getTime() / 1000);

module.exports = {
    /**
     * Data Mapping for get Profile functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getProfileData: function (resultSet, ticketDataArr=[]) {
        try {
                 
             ticketData= [];
            if(ticketDataArr.length > 0) {
            for (var i in ticketDataArr) {
                var ticketRow = {};
                ticketRow.ticketId = ticketDataArr[i].ticketId;                
                ticketRow.ticketAmount = ticketDataArr[i].ticketAmount;
                ticketData.push(ticketRow);
            } }
            var row = {};
            row.userId = resultSet.userId;
            row.email = resultSet.email;
            row.userName = resultSet.userName;
            row.dob = resultSet.dob?resultSet.dob.toISOString().slice(0, 10):'';
            row.btId = resultSet.btId;
            row.fName = resultSet.fName;
            row.lName = resultSet.lName;
            row.referralMoney = resultSet.referralMoney;
            row.balance = resultSet.balance;
            row.depositCount = resultSet.depositCnt;
            row.totalDeposited = resultSet.totalDeposited;
            row.spendLimits = resultSet.spendLimits;
            row.depositLimits = resultSet.depositLimits;
            row.referrer = resultSet.referrer;
            row.balanceTickets  = resultSet.balanceTickets;
            row.tickets  = ticketData;
            row.balanceRewards = resultSet.balanceRewards;
            if (resultSet.currentLoginType == 'Normal') {
                row.imageName = resultSet.imageName ? process.env.PROFILE_IMAGE_URL + resultSet.imageName : '';
            } else if (resultSet.currentLoginType == 'FB') {
                row.imageName = process.env.FB_IMAGE_URL.replace(new RegExp('{fbId}', "g"), resultSet.loginTypes.FB.fbId);
            }
            row.currentLoginType = resultSet.currentLoginType;
            var sportsRankings = [];
            if(resultSet.sportsRanking != null) {                
                for (var i = 0; i < resultSet.sportsRanking.length; i++ ){
                    var sports = {};
                    sports.sportId = resultSet.sportsRanking[i].sportId;
                    sports.sportRank = resultSet.sportsRanking[i].rank;
                    sports.sportSubRank = resultSet.sportsRanking[i].subRank;
                    sports.sportPoints = resultSet.sportsRanking[i].points;
                    sports.pointsForNextRank = resultSet.sportsRanking[i].pointsForNextRank;
                    sports.pointsForNextSubRank = resultSet.sportsRanking[i].pointsForNextSubRank;
                    sports.pointsForCurrentRank = resultSet.sportsRanking[i].pointsForCurrentRank;
                    sports.pointsForCurrentSubRank = resultSet.sportsRanking[i].pointsForCurrentSubRank;
                    sports.sportIconUrl = process.env.SPORT_RANK_IMAGE + (resultSet.sportsRanking[i].imageName != '' ? resultSet.sportsRanking[i].imageName :
                                             (userInfo[i].sportsRanking[j].sportId == 1 ? "empty_nfl" : 
                                                (userInfo[i].sportsRanking[j].sportId == 2 ? "empty_mlb" :
                                                    (userInfo[i].sportsRanking[j].sportId == 3 ? "empty_nhl" :
                                                        (userInfo[i].sportsRanking[j].sportId == 4 ? "empty_nba" :
                                                            (userInfo[i].sportsRanking[j].sportId == 5 ? "empty_golf" :
                                                                "")))))) + ".png";  
                    sportsRankings.push(sports); 
                }
            }
            row.sportsRankings = sportsRankings;
            row.rank = resultSet.rank;
            row.subRank = resultSet.subRank;
            row.rankName = resultSet.rankName;
            row.rankImageUrl = process.env.USER_RANK_IMAGE + (resultSet.rankImageName != '' ? resultSet.rankImageName : "empty") + ".png";                       
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for update profile functionality
     * @param {Object} userProfile - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    updateProfileData: function (userProfile, requestData) {
        try {
            userProfile.fName = requestData.fName;
            userProfile.lName = requestData.lName;
            return userProfile;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for deposit money functionality
     * @param {Object} userDB - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    // depositMoneyData: function (userDB, requestData) {
    //     try {
    //         userDB.balance += requestData.amount;
    //         userDB.totalDeposited += requestData.amount;
    //         userDB.depositCnt += 1;
    //         return userDB;
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     * Data Mapping for get balance amount functionality
     * @param {Object} resultSet - Resultset of user bal
     * @param {Object} withdrawableBal - withdrawal balance
     * @return {Object} Updated result object
     */
    getBalanceData: function (resultSet, withdrawableBal) {
        try {
            var row = {};
            row.balance = resultSet.balance;
            row.withdrawableBalance = withdrawableBal;
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for withdrawal money functionality
     * @param {Object} withdrawal - Data Schema Object
     * @param {Object} inputtData - Input Object
     * @return {Object} Updated user object
     */
    withdrawalMoneyData: function (withdrawal, inputtData, request) {
        try {
            withdrawal.amount = request.amount;
            withdrawal.requestStatus = 'P';
            withdrawal.userId = inputtData.userId;
            withdrawal.userName = inputtData.userName;
            // withdrawal.fName = inputtData.fName;
            // withdrawal.lName = inputtData.lName;
            withdrawal.userEmail = inputtData.email;
            return withdrawal;
        } catch (e) {
            throw e;
        }
    },
    /**
     * Data Mapping for get withdrawal status functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    // getWithdrawalStatus: function (resultSet) {
    //     try {
    //         var row = {};
    //         row.withdrawalStatus = (resultSet.withdrawalStatus == 'R') ? 'Rejected' : (resultSet.withdrawalStatus == 'C') ? 'Closed' : (resultSet.withdrawalStatus == 'I') ? 'In Progress' : 'Pending';
    //         return row;
    //     } catch (e) {
    //         throw e;
    //     }
    // },


    /**
     * Data Mapping for search withdrawal requests
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchWithdrawalData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.withdrawalStatus = (!requestData.status) ? '' : requestData.status;
            // search.multipleStatus = [];
            // search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            // search.request_status = (!requestData.request_status) ? '' : requestData.request_status;
            // search.from_date = (!requestData.from_date) ? '' : requestData.from_date;
            // search.to_date = (!requestData.to_date) ? '' : requestData.to_date;

            // search.sort_field = (!requestData.sort_field) ? 'userName' : requestData.sort_field;
            // search.sort_order = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            // switch (search.sort_field){
            //     case 'userName': search.sort_field = 'userName'; break;
            //     case 'requestDate': search.sort_field = 'createdAt'; break;
            //     case 'email': search.sort_field = 'userEmail'; break;
            //     case 'amount': search.sort_field = 'amount'; break;
            //     case 'paymentType': search.sort_field = 'paymentType'; break;
            //     case 'status': search.sort_field = 'requestStatus'; break;
            //     default: search.sort_field = 'userName'; break;
            // }
            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for search transaction
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchTransactionData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.tranType = (!requestData.transaction_type) ? '' : requestData.transaction_type;
            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get Withdrawal request functionality
     * @param {Object} resultSet - Resultset
     * @param {Number} userBalance - User Balance 
     * @return {Object} Updated result object
     */
    getWithdrawalData: function (resultSet) { // , userBalance
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                // row.requestId = resultSet[i]._id;
                // row.userId = resultSet[i].userId;
                // row.userName = resultSet[i].userName;
                // row.email = resultSet[i].userEmail;
                row.status = (resultSet[i].requestStatus == 'R') ? 'Rejected' : (resultSet[i].requestStatus == 'C') ? 'Closed' : (resultSet[i].requestStatus == 'I') ? 'In Progress' : 'Pending';
                row.amount = resultSet[i].amount;
                // row.balance = userBalance;
                row.paymentType = resultSet[i].paymentType;
                row.requestDate = moment(resultSet[i].createdAt).format('MM/DD/YYYY hh:mm A');
                // row.updatedAt = moment(resultSet[i].updatedAt).format('MM/DD/YYYY');
                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get transaction functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getTransactionData: function (resultSet) {
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                switch(resultSet[i].tranType){
                  case 'D':
                    row.transactionType = 'Deposit';
                    break;
                  case 'W':
                    row.transactionType = 'Withdrawal';
                    break;
                  case 'TM':
                    row.transactionType = 'Ticket to Money Conversion';
                    break;
                  case 'RT':
                    row.transactionType = 'Reward to Ticket';
                    break;
                  case 'T':
                    row.transactionType = 'Tickets';
                    break;
                  case 'R':
                    row.transactionType = 'Reward';
                    break;
                  case 'JC':
                    row.transactionType = 'Join Contest';
                    break;
                  case 'WA':
                    row.transactionType = 'Winning Amount';
                    break;
                  case 'UC':
                    row.transactionType = 'UnJoin Contest';
                    break;
                  default:                      
                    row.transactionType = 'Unknown';
                    break;
                }
                //row.transactionType = (resultSet[i].tranType == 'D') ? 'Deposit' : 'Withdrawal';
                row.amount = resultSet[i].amount;
                row.transactionDate = moment(resultSet[i].entryDate).format('MM/DD/YYYY hh:mm A');
                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for transaction functionality
     * @param {Object} transaction - Data Schema Object
     * @param {Object} userData - User Object
     * @param {String} transactionType - Transaction Type
     * @return {Object} Updated object
     */
    transactionData: function (transaction, userData, amount, transactionType) {
        try {
            transaction.amount = amount;
            transaction.tranStatus = 1;
            transaction.tranType = transactionType;
            transaction.userId = userData.userId;
            transaction.userName = userData.userName;
            transaction.userImg = userData.imageName;
            transaction.fName = userData.fName;
            transaction.lName = userData.lName;
            return transaction;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get All notifications functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getnotificationsData: function (resultSet) {
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                row.id = resultSet[i]._id;
                row.message = resultSet[i].message;
                row.createdAt = resultSet[i].createdAt;
                row.isRead = resultSet[i].isRead;
                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for notification pagination
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    paginationData: function (requestData) {
        try {
            var pagination = {};
            pagination.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            pagination.page = (!requestData.page_number) ? 0 : requestData.page_number;
            return pagination;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for update settings functionality
     * @param {Object} userSettings - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    updateSettingsData: function (userSettings, requestData) {
        try {
            userSettings.spendLimits.daily = requestData.spendLimits.daily;
            userSettings.spendLimits.weekly = requestData.spendLimits.weekly;
            userSettings.spendLimits.monthly = requestData.spendLimits.monthly;
            userSettings.spendLimits.maxEntryFee = requestData.spendLimits.maxEntryFee;

            userSettings.depositLimits.daily = requestData.depositLimits.daily;
            userSettings.depositLimits.weekly = requestData.depositLimits.weekly;
            userSettings.depositLimits.monthly = requestData.depositLimits.monthly;
            return userSettings;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for get Settings functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getSettingsData: function (resultSet) {
        try {
            var row = {};
            row.spendLimits = {};
            row.spendLimits.daily = resultSet.spendLimits.daily;
            row.spendLimits.weekly = resultSet.spendLimits.weekly;
            row.spendLimits.monthly = resultSet.spendLimits.monthly;
            row.spendLimits.maxEntryFee = resultSet.spendLimits.maxEntryFee;

            row.depositLimits = {};
            row.depositLimits.daily = resultSet.depositLimits.daily;
            row.depositLimits.weekly = resultSet.depositLimits.weekly;
            row.depositLimits.monthly = resultSet.depositLimits.monthly;
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Search
     * @param {Object} requestData - Request Query Object
     * @return {Object} Array of data
     */
    searchData: function (requestData) {
        try {
            var search = {};
            search.limit = (!requestData.page_limit) ? 10 : parseInt(requestData.page_limit);
            search.page = (!requestData.page_number) ? 0 : requestData.page_number;
            search.search_text = (!requestData.search_text) ? '' : requestData.search_text;
            //search.sort = (!requestData.sort_order) ? 'asc' : requestData.sort_order;
            //search.sort_field = (!requestData.sort_field) ? 'name' : requestData.sort_field;
            return search;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get users functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    // getUsersData: function (resultSet) {
    //     try {
    //         var result = [];
    //         for (var i in resultSet) {
    //             var row = {};
    //             row.userId = resultSet[i].userId;
    //             row.name = resultSet[i].userName;
    //             row.btId = resultSet[i].btId;
    //             row.fName = (!resultSet[i].fName) ? '' : resultSet[i].fName;
    //             row.lName = (!resultSet[i].lName) ? '' : resultSet[i].lName;
    //             // row.email = resultSet[i].email;

    //             if (resultSet[i].currentLoginType == 'FB' && resultSet[i].loginTypes.FB.fbId) {
    //                 row.imageName = fbHelper.getFbPicture(resultSet[i].loginTypes.FB.fbId);
    //             } else {
    //                 row.imageName = (resultSet[i].imageName != '') ? process.env.PROFILE_IMAGE_URL + resultSet[i].imageName : '';
    //             }
    //             // row.imageName = resultSet[i].imageName ? process.env.PROFILE_IMAGE_URL + resultSet[i].imageName : '';

    //             if (resultSet[i].friends) {
    //                 row.isFriend = resultSet[i].friends.includes(global.userId) ? 1 : 0;
    //             }
    //             result.push(row);
    //         }
    //         return result;
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     * Data Mapping for send friendrequest functionality
     * @param {Object} friendRequestData - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    friendRequestDataAdd: function (friendRequestData, friendRequest, toUserData, fromUserData) {
        try {
            friendRequestData.fromUserId = global.userId;
            friendRequestData.toUserId = friendRequest.toUserId;
            friendRequestData.requestStatus = 0;
            friendRequestData.toUserName = toUserData.userName;
            friendRequestData.toUserImg = toUserData.imageName;
            friendRequestData.fromUserName = fromUserData.userName;
            friendRequestData.fromUserImg = fromUserData.imageName;
            friendRequestData.fName = fromUserData.fName;
            friendRequestData.lName = fromUserData.lName;
            return friendRequestData;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for respond friendrequest functionality    
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    friendData: function ({}, requestData) {
        try {
            var userdata = parseInt(requestData.fromUserId);
            return userdata;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for respond friendrequest functionality(reponse)
     * @param {Object} userdata - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    friendDataResponse: function (userdata, requestData) {
        try {
            userdata.requestStatus = requestData.response;
            return userdata;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get friend request functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getFriendRequestData: function (resultSet) {
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                row.fromUserId = resultSet[i].fromUserId;
                row.fromUserName = resultSet[i].fromUserName;
                row.fName = resultSet[i].fName;
                row.lName = resultSet[i].lName;
                row.fromUserImg = resultSet[i].fromUserImg ? process.env.PROFILE_IMAGE_URL + resultSet[i].fromUserImg : '';
                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for feedback functionality    
     * @param {Object} inputtData - Input Object
     * @return {Object} Updated user object
     */
    feedbackData: function (request, inputData) {
        try {
            var row = {};
            row.Name = inputData.userName;
            row.Email = inputData.email;
            row.Feedback = request.feedback;
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for support functionality    
     * @param {Object} inputtData - Input Object
     * @return {Object} Updated user object
     */
    supportData: function (request, inputData) {
        try {
            var row = {};
            row.Name = inputData.userName;
            row.Email = inputData.email;
            row.Message = request.message;
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for respond friendrequest functionality    
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    friendRequestData: function ({}, requestData) {
        try {
            var row = {};
            row.toUserId = parseInt(requestData.toUserId);
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for friendrequest response functionality   
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    friendRequestResponsData: function ({}, requestData) {
        try {
            var row = {};
            row.fromUserId = parseInt(requestData.fromUserId);
            row.response = requestData.response;
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for unfriend functionality   
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    unfriendData: function ({}, requestData) {
        try {
            var row = {};
            row.friendId = parseInt(requestData.friendId);
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get friends functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    // getFriendsData: function (resultSet) {
    //     try {
    //         var result = [];
    //         for (var i in resultSet) {
    //             var row = {};
    //             row.userId = resultSet[i].userId;
    //             row.name = resultSet[i].userName;
    //             row.btId = resultSet[i].btId;
    //             row.fName = (!resultSet[i].fName) ? '' : resultSet[i].fName;
    //             row.lName = (!resultSet[i].lName) ? '' : resultSet[i].lName;
    //             // row.email = resultSet[i].email;

    //             if (resultSet[i].currentLoginType == 'FB' && resultSet[i].loginTypes.FB.fbId) {
    //                 row.imageName = fbHelper.getFbPicture(resultSet[i].loginTypes.FB.fbId);
    //             } else {
    //                 row.imageName = resultSet[i].imageName ? process.env.PROFILE_IMAGE_URL + resultSet[i].imageName : '';
    //             }
    //             // row.imageName = resultSet[i].imageName ? process.env.PROFILE_IMAGE_URL + resultSet[i].imageName : '';

    //             if (resultSet[i].friends) {
    //                 row.isFriend = resultSet[i].friends.includes(global.userId) ? 1 : 0;
    //             }
    //             result.push(row);
    //         }
    //         return result;
    //     } catch (e) {
    //         throw e;
    //     }
    // },


    /**
     * Data Mapping for get sent friend request ids functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    sentFriendRequestData: function (sentResultSet, sentResultSet1) {
        try {
            var row = {};
            var result = [];
            for (var j in sentResultSet) {
                result[j] = parseInt(sentResultSet[j].fromUserId);
            }
            var result1 = [];
            for (var i in sentResultSet1) {
                result1[i] = parseInt(sentResultSet1[i].toUserId);
            }
            row.sentResult = result;
            row.sentResult1 = result1;
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Get users functionality
     * @param {Object} resultSet - Resultset
     * @param {Object} sentFriendRequestresult - Friend request resultset
     * @param {Array} fbids - Array of FB friends id
     * @return {Object} Updated result object
     */
    getUsersDatas: function (resultSet, sentFriendRequestresult, fbids) {
        try {
            var result = [];
            for (var i in resultSet) {
                var row = {};
                row.userId = resultSet[i].userId;
                row.name = resultSet[i].userName;
                row.btId = resultSet[i].btId;
                row.fName = (!resultSet[i].fName) ? '' : resultSet[i].fName;
                row.lName = (!resultSet[i].lName) ? '' : resultSet[i].lName;
                // row.email = resultSet[i].email;
                if (resultSet[i].currentLoginType == 'FB' && resultSet[i].loginTypes.FB.fbId) {
                    row.imageName = fbHelper.getFbPicture(resultSet[i].loginTypes.FB.fbId);
                } else {
                    row.imageName = resultSet[i].imageName ? process.env.PROFILE_IMAGE_URL + resultSet[i].imageName : '';
                }

                row.isFriend = 0;
                if (resultSet[i].friends) {
                    row.isFriend = resultSet[i].friends.includes(global.userId) ? 1 : 0;
                }
                row.isFollowing = 0;
                if (sentFriendRequestresult.isFollowing) {
                    row.isFollowing = sentFriendRequestresult.isFollowing.includes(resultSet[i].userId) ? 1 : 0;
                }
                row.isFollows = 0;
                if (sentFriendRequestresult.isFollows) {
                    row.isFollows = sentFriendRequestresult.isFollows.includes(resultSet[i].userId) ? 1 : 0;
                }

                row.isFbFriend = 'N';
                if (resultSet[i].loginTypes) {
                    row.isFbFriend = (fbids.indexOf(resultSet[i].loginTypes.FB.fbId) > -1) ? 'Y' : 'N';
                }
                /*if (sentFriendRequestresult.sentResult1) {
                    row.isFollows = (sentFriendRequestresult.sentResult1.includes(resultSet[i].userId) || row.isFriend == 1) ? 1 : 0;
                }*/
                /*if (resultSet[i].isFollows) {
                    row.isFollows = resultSet[i].isFollows.includes(global.userId) ? 1 : 0;
                }*/

                result.push(row);
            }
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for add ticket functionality
     * @param {Object} ticketInfo - Data Schema Object
     * @param {Object} requestData - Ticket Object    
     * @return {Object} Updated object
     */
    ticketData: function (ticketInfo, requestData) {
        try {
            ticketInfo.ticketId = crypto.randomBytes(4).toString('hex') + timeStamp;
            ticketInfo.ticketAmount = requestData.ticketAmount;
            ticketInfo.ticketStatus = requestData.ticketStatus;
            return ticketInfo;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for store ticket functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    ticketStoreData: function (ticketStore, req) {
        try {            
            for (var i in req.ticketStore) {
                var row = {};
                row.ticketId = req.ticketStore[i].ticketId;
                row.ticketAmount = req.ticketStore[i].ticketAmount;
                row.totalRewards = req.ticketStore[i].totalRewards;
                ticketStore.push(row);
            }
            return ticketStore;
        } catch (e) {
            throw e;
        }
    },

        /**
     * Data Mapping for Get all tickets from the store
     * @param {Object} resultSet - Resultset     
     * @return {Object} Updated result object
     */
    getStoreTicketData: function (resultSet) {
        try {
            var result = {};
            result.ticketStore = [];
            for (var i in resultSet) {
                var row = {};
                row.id = resultSet[i].ticketId;
                row.v = resultSet[i].ticketAmount;
                row.cost = resultSet[i].totalRewards;
                result.ticketStore.push(row);
            }            
            return result;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for sport points calculation functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    sportPointData: function (pointsModel) {
        try {                 
            pointsModel.pointId = 1;
            pointsModel.rank = 1;
            pointsModel.subRank = 1;
            pointsModel.points = 1;
            pointsModel.iValue = 0;
            pointsModel.jValue = 0;
            pointsModel.kValue = 0;
            pointsModel.lValue = 0;                
            return pointsModel;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for setup rank images functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    rankImageData: function (rankImages) {
        try {                 
            rankImages.rankImageId = 1;
            rankImages.rank = 1;            
            rankImages.sportRankImage = 'white_nfl';            
            rankImages.userRankImage = 'recruit';                
            return rankImages;
        } catch (e) {
            throw e;
        }
    },

    

};