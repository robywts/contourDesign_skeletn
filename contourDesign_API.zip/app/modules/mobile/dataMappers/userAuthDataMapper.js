/**
 * user Auth Data Mapper
 * @exports UserAuth/DataMapper
 */
var crypto = require('crypto');
var timeStamp = Math.round((new Date()).getTime() / 1000);

module.exports = {
    /**
     * Data Mapping for Register functionality
     * @param {Object} userAuth - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    registerData: function (userAuth, requestData) {
        try {
            userAuth.userName = requestData.userName;
            userAuth.email = requestData.email;
            userAuth.pwd = requestData.pwd;
            userAuth.dob = requestData.dob;
            userAuth.btId = crypto.randomBytes(4).toString('hex') + timeStamp;
            userAuth.sessions = [{
                'sessionToken': crypto.randomBytes(8).toString('hex') + timeStamp,
                'deviceToken': requestData.deviceToken,
                'deviceType': requestData.deviceType
            }];
            // userAuth.sessions.sessionToken = crypto.randomBytes(8).toString('hex') + timeStamp;
            // userAuth.sessions.deviceToken = requestData.deviceToken;
            // userAuth.sessions.deviceType = requestData.deviceType;
            userAuth.currentLoginType = 'Normal';
            userAuth.userStatus = 1;
            userAuth.promoCode = requestData.promoCode;
            userAuth.referrer = requestData.referrer;
            userAuth.spendLimits = {
                'daily': 0,
                'weekly': 0,
                'monthly': 0,
                'maxEntryFee': 0,
            };
            userAuth.depositLimits = {
                'daily': 0,
                'weekly': 0,
                'monthly': 0,
            };
            return userAuth;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for FB Merge functionality (only for login users)
     * @param {Object} userAuth - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    fbMergeData: function (userAuth, requestData) {
        try {
            userAuth.loginTypes = {
                "FB": {
                    "fbToken": requestData.fbToken
                }
            };
            // userAuth.loginTypes.FB.fbId = requestData.fbId;
            userAuth.userStatus = 1;
            userAuth.currentLoginType = 'FB';
            return userAuth;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for FB Register functionality
     * @param {Object} userAuth - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    fbLoginRegisterData: function (userAuth, requestData) {
        try {
            userAuth.loginTypes.FB.fbToken = requestData.fbToken;
            // userAuth.loginTypes.FB.fbId = requestData.fbId;
            userAuth.email = requestData.email;
            userAuth.userName = requestData.userName;
            userAuth.pwd = requestData.pwd;
            userAuth.dob = requestData.dob;
            userAuth.btId = crypto.randomBytes(4).toString('hex') + timeStamp;
            userAuth.sessions = [{
                'sessionToken': crypto.randomBytes(8).toString('hex') + timeStamp,
                'deviceToken': requestData.deviceToken,
                'deviceType': requestData.deviceType
            }];
            // userAuth.sessions.sessionToken = crypto.randomBytes(8).toString('hex') + timeStamp;
            // userAuth.sessions.deviceToken = requestData.deviceToken;
            // userAuth.sessions.deviceType = requestData.deviceType;            
            userAuth.userStatus = 1;
            userAuth.currentLoginType = 'FB';
            userAuth.promoCode = requestData.promoCode;
            userAuth.referrer = requestData.referrer;
            return userAuth;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Login functionality
     * @param {Object} userAuth - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    loginData: function (userAuth, requestData) {
        try {
            userAuth.email = requestData.email;
            userAuth.pwd = requestData.pwd;
            userAuth.sessions = {
                'sessionToken': crypto.randomBytes(8).toString('hex') + timeStamp,
                'deviceToken': requestData.deviceToken,
                'deviceType': requestData.deviceType
            };
            // userAuth.sessions.sessionToken = crypto.randomBytes(8).toString('hex') + timeStamp;
            // userAuth.sessions.deviceToken = requestData.deviceToken;
            // userAuth.sessions.deviceType = requestData.deviceType;
            userAuth.currentLoginType = 'Normal';
            return userAuth;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Forgot functionality
     * @param {Object} userAuth - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    forgotData: function (userAuth, requestData) {
        try {
            userAuth.email = requestData.email;
            userAuth.resetCode = crypto.randomBytes(3).toString('hex').toUpperCase();
            return userAuth;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for reset functionality
     * @param {Object} userAuth - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    resetData: function (userAuth, requestData) {
        try {
            userAuth.email = requestData.email;
            userAuth.pwd = requestData.pwd;
            userAuth.resetCode = requestData.resetCode;
            // userAuth.sessions.sessionToken = crypto.randomBytes(8).toString('hex') + timeStamp;
            userAuth.sessions = {
                'sessionToken': crypto.randomBytes(8).toString('hex') + timeStamp,
                'deviceToken': requestData.deviceToken,
                'deviceType': requestData.deviceType
            };
            return userAuth;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for change password functionality
     * @param {Object} userAuth - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    changePasswordData: function (userAuth, requestData) {
        try {
            userAuth.pwd = requestData.pwd;
            userAuth.oldPwd = requestData.oldPwd;
            return userAuth;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for Update Device Token functionality
     * @param {Object} userDevice - Data Schema Object
     * @param {Object} requestData - Request Body Object
     * @return {Object} Updated user object
     */
    updateDeviceTokenData: function (userDevice, requestData) {
        try {
            userDevice.sessions = {
                'deviceToken': requestData.deviceToken,
                'deviceType': requestData.deviceType
            };
            // userDevice.sessions.deviceToken = requestData.deviceToken;
            // userDevice.sessions.deviceType = requestData.deviceType;
            return userDevice;
        } catch (e) {
            throw e;
        }
    },


    /**
     * Data Mapping for Register/Login functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getOneUserData: function (resultSet) {
        try {
            var row = {};
            row.userId = resultSet.userId;
            row.email = resultSet.email;
            row.userName = resultSet.userName;
            if (resultSet.dob != null) {
                row.dob = resultSet.dob.toISOString().slice(0, 10);
            }
            row.btId = resultSet.btId;
            row.fName = resultSet.fName;
            row.lName = resultSet.lName;
            row.balance = resultSet.balance;
            row.depositCount = resultSet.depositCnt;
            if (resultSet.sessions != null) {
                row.sessionToken = resultSet.sessions.sessionToken;
            }
            row.currentLoginType = resultSet.currentLoginType;
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for forgot functionality
     * @param {Object} resultSet - Resultset
     * @return {Object} Updated result object
     */
    getUserForgotData: function (resultSet) {
        try {
            var row = {};
            row.resetCode = resultSet.resetCode;
            return row;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Data Mapping for geoToken functionality
     * @param {Object} geoAuth - Data Object
     * @param {Object} requestData - Request Body Object
     * @param {Object} resultData - Result Object
     * @return {Object} Updated object
     */
    geoData: function (geoAuth, requestData, resultData) {
        try {
            geoAuth = {
                'geoToken': 'geo' + crypto.randomBytes(8).toString('hex') + timeStamp,
                'allowed': resultData.allowed,
                'state': resultData.state,
                'country': resultData.country,
                'lat': requestData.lat,
                'lng': requestData.lng,
                'createdAt': Date.now()
            };
            return geoAuth;
        } catch (e) {
            throw e;
        }
    },

};