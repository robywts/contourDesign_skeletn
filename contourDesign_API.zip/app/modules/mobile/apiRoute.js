/**
 * Api Route
 * @exports General/Route
 */
var express = require('express');
var router = express.Router();

process.setMaxListeners(Infinity);
/**
 * Middleware
 */
var middleware = require('./apiMiddleware');
router.use(middleware.authentication);

/**
 * Contest Routes
 */
router.use('/contests', function (req, res, next) {
	var contestController = require('./controllers/contestController');
	router.route('/contests')
		.post(contestController.add) //add
		.get(contestController.getAll); //getall
    router.route('/contests/getFeatured').get(contestController.getFeatured); //get featured contests
    router.route('/contests/getGames/:id').get(contestController.getOne); //get contest's games by id
	router.route('/contests/getStandings/:id').get(contestController.getContestStandings); //get contest's participants standings by id
	router.route('/contests/joinContest').post(contestController.joinContest); //join to a contest
	router.route('/contests/joinMultipleContest').post(contestController.joinMultipleContest); //join to multiple contests
	router.route('/contests/getLineUps/:id')
		.get(contestController.getLineUp); //get all lineups in a contest by id
	router.route('/contests/lineUp/:id')
		.put(contestController.updateLineUp) //update Lineups in a contest by lineup id
		.get(contestController.getLineUpById); //get Lineup details by lineup id
	router.route('/contests/getMyContests').get(contestController.getMyContests); //get all contests by user id
	router.route('/contests/getLineUpTemplate').get(contestController.getLineUpTemplate); //get sport lineup template
	router.route('/contests/getAllMyContests').get(contestController.getAllMyContests); //get all contests by user id
	router.route('/contests/createContestTemplate').get(contestController.getContestPrizeTemplate); //get all prize template
	router.route('/contests/lineupUpdateAll').put(contestController.updateAllLineUps) //update Lineups in a contest by lineup id
	router.route('/contests/unjoinlineup').delete(contestController.unjoinLineUp); //unjoin lineup
	router.route('/contests/joinWithLineUpId').post(contestController.joinContestWithLineUpId); //join to a contest
	router.route('/contests/:id')
		.get(contestController.getOneContest) //getone
		.put(contestController.update) //update
		.delete(contestController.delete); //delete
	next();
});

/**
 * General Routes
 */
router.use('/general', function (req, res, next) {
	var generalController = require('./controllers/generalController');
	router.route('/general/ping').get(generalController.ping); // ping
	router.route('/general/log').post(generalController.log); // log
	router.route('/general/test').post(generalController.test); // test
	router.route('/general/push').post(generalController.push); // pusher test
	router.route('/general/sms').post(generalController.sms); // sms test
	router.route('/general/gcm/push').post(generalController.pushNotification); // sms test
	next();
});


/**
 * UserAuth Routes
 */
router.use('/user/auth', function (req, res, next) {
	var userAuthController = require('./controllers/userAuthController');

	router.route('/user/auth/register').post(userAuthController.register);
	router.route('/user/auth/login').post(userAuthController.login);
	router.route('/user/auth/forgot').put(userAuthController.forgot);
	router.route('/user/auth/reset').put(userAuthController.reset);
	router.route('/user/auth/changePassword').put(userAuthController.changePassword);
	router.route('/user/auth/logout').delete(userAuthController.logout);
	router.route('/user/auth/updateDeviceToken').put(userAuthController.updateDeviceToken); //update Device Token
	router.route('/user/auth/fb').post(userAuthController.fbLogin);
	router.route('/user/auth/fbMerge').post(userAuthController.fbMerge); // only for login user
	router.route('/user/auth/geoToken').post(userAuthController.getGeoToken); //Get geo token
	next();
});

/**
 * User Routes
 */
router.use('/users', function (req, res, next) {
	var userController = require('./controllers/userController');

	router.route('/users/profile')
		.get(userController.getProfile) //get profile
		.put(userController.updateProfile); //update profile
	router.route('/users/updateprofileImage').put(userController.updateprofileImage);
	router.route('/users/client_token').get(userController.getClientToken); //Get client token
	router.route('/users/get_nonce').get(userController.getNonce); //Get Nonce
	// router.route('/users/ticketToMoney').put(userController.ticketToMoney); //Ticket to money conversion
	// router.route('/users/rewardToMoney').put(userController.rewardToMoney); //Reward to money conversion
	router.route('/users/rewardToTicket').put(userController.rewardToTicket); //Reward to ticket conversion
	router.route('/users/depositMoney').put(userController.depositMoney); //depost amount	 
	router.route('/users/balanceMoney').get(userController.getBalanceMoney); //get balance amount
	router.route('/users/withdrawalRequest').put(userController.withdrawalRequest); // Request for withdrawal amount
	// router.route('/users/withdrawalStatus').get(userController.withdrawalStatus); // get  withdrawal status
	router.route('/users/getwithdrawalrequests').get(userController.getWithdrawalRequests); //Get Withdrawal Requests
	router.route('/users/transactions').get(userController.getTransactions); //Get Transactions

	router.route('/users/notifications').get(userController.getNotifications); // get  withdrawal status
	router.route('/users/updateNotification').put(userController.updateNotification); //update notification
	router.route('/users/settings')
		.put(userController.updateSettings) //update Settings
		.get(userController.getSettings); //get Settings  
	router.route('/users/feedback').post(userController.sendFeedback); //send feedback 
	router.route('/users/support').post(userController.contactSupport); //conatct support
	router.route('/users/listusers').get(userController.listUsers); //list users
	router.route('/users/listFBFriends').get(userController.listFBUsers); //list FB users (friends)
	router.route('/users/friendrequest').post(userController.sendFriendrequest) //send friend request
	router.route('/users/respondfriendrequest').put(userController.respondFriendRequest) //respond to friend request
	router.route('/users/getfriendrequest').get(userController.getFriendRequest); //get friend request 
	router.route('/users/listfriends').get(userController.listFriends); //list friends
	router.route('/users/unfriend').delete(userController.unfriendRequest); //Unfriend a friend 
	router.route('/users/addUserTicket').post(userController.addUserTicket); //Add user ticket
	router.route('/users/addTicketToStore').post(userController.addTicketToStore); //Add ticket to store
	router.route('/users/getStoreTickets').get(userController.getStoreTickets); //list tickets from store
	next();
});

/**
 * DraftGroup Routes
 */
router.use('/draftgroups', function (req, res, next) {
	var draftGroupController = require('./controllers/draftGroupController');
	router.route('/draftgroups/list').get(draftGroupController.getDraftGroupList); //get draftGroups for dropdown
	router.route('/draftgroups/getAllMyLineups').get(draftGroupController.getAllLineUp); //get all user lineups 
	router.route('/draftgroups/:id').get(draftGroupController.getDraftGroupDetails); //get draftgroup details by id
	router.route('/draftgroups/getContests/:id').get(draftGroupController.getDraftGroupContestDetails); //get draftgroup's contest list by id
	router.route('/draftgroups/getPlayers/:id').get(draftGroupController.getAllPlayer); //get all players in a draftgroup by id
	router.route('/draftgroups/getLineUps/:id').get(draftGroupController.getLineUp); //get all lineups in a draftgroup by id
	next();
});

/**
 * Player Routes
 */
router.use('/player', function (req, res, next) {
	var playerController = require('./controllers/playerController');
	router.route('/player/playerNews/:id').get(playerController.getPlayerNews); //get player news by player id
	router.route('/player/playerScores').get(playerController.getPlayerScores); //get Player scores by event ids
	router.route('/player/playerGames/:id/:sid').get(playerController.getPlayerGames); //get player games by player id
	next();
});

module.exports = router;