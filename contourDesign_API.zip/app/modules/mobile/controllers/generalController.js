/**
 * General Module
 * @exports General/Controller
 */

var generalHelper = require('../helpers/generalHelper');
var pusherHelper = require('../helpers/pusherHelper');
var smsHelper = require('../helpers/teleSignHelper');
var pushNotificationHelper = require('../helpers/gcmHelper');

var _t = require('../translations/' + process.env.LANGUAGE + '/generalTrans.json');

var FB = require('fb');
var fbHelper = require('../helpers/fbHelper');

module.exports = {
	/**
	 * Ping
	 * @param {object} req - Request object
	 * @param {object} res - Response object
	 */
	ping: function (req, res) {
		try {
			generalHelper.handleSuccess(req, res, _t.authSuccess, {});
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Logger
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	log: function (req, res) {
		try {
			generalHelper.wsLogger(req, '', [req.body], 'ClientError');
			generalHelper.handleSuccess(req, res, _t.logSuccess, {});
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Pusher Test
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	push: function (req, res) {
		try {
			pusherHelper.sendPush(req.body.channelName, req.body.eventName, req.body.message);
			// generalHelper.wsLogger(req, '', [req.body], 'ClientError');
			generalHelper.handleSuccess(req, res, _t.pushSentSuccess, {});
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Sms Test
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	sms: function (req, res) {
		try {
			smsHelper.sendSMS(req.body.phoneNumber, req.body.message, 'ARN');
			generalHelper.handleSuccess(req, res, _t.smsSentSuccess, {});
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Push Notification (GCM) Test
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	pushNotification: function (req, res) {
		try {
			pushNotificationHelper.sendPushNotification(req.body.tokens, req.body.message);
			generalHelper.handleSuccess(req, res, _t.pushNotificationSentSuccess, {});
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Test
	 * @param {object} req - Request object
	 * @param {object} res - Response object
	 */
	test: async function (req, res) {
		try {
			FB.options({
				version: 'v2.11'
			});
			// var fbToken = await FB.api('oauth/access_token', {
			// 	client_id: '178551595582630',
			// 	client_secret: 'fb22ce89473e94a0ee5934b7aad3b06f',
			// 	grant_type: 'client_credentials'
			// });
			var fbToken = await FB.api('oauth/access_token', {
				client_id: process.env.FB_APP_ID,
				client_secret: process.env.FB_APP_SECRET,
				grant_type: 'client_credentials'
			});
			FB.setAccessToken(fbToken.access_token);

			// var fbResponse = await FB.api(
			// 	'/100734674069485',
			// 	'GET', {
			// 		// access_token: fbToken.access_token,
			// 		fields: 'id, name, first_name, last_name, picture.type(large), friends, installed'
			// 	}
			// );
			var fbResponse = await FB.api(
				'/me',
				'GET', {
					access_token: 'EAAZA92YEZAwKABAJmrmCBbwH9E78btb6PhRQPuGa5wnZBAE5Ja39TZAcOfCSkNdDOn7tJcUvJRsU7C4JZC5Sz6HJVtHOjpbhNsn9RW2pZBplZBmjiov1GeT0Kaq0WSbBdzB8HWRLmdkWhrt45yGzRZByi88ZBd5XxKN8Qij0D4oZAyde5AelgcZBO8n6oeoTNSorHFtHTksYlEFqb4b3BVKPdQXYtbeOCCF3kr8QhrYTbEnCcckitUCdq0y',
					fields: 'id, name, email, first_name, last_name, picture.type(large), friends, installed'
				}
			);

			// var fbResponse = await FB.api(
			// 	'/'+process.env.FB_APP_ID+'/accounts'
			// );

			// var fbResponse = await FB.api(
			// 	'/100734674069485/friends?limit=1000&fields=id,name,first_name,last_name,picture,installed'
			// );

			// FB.api('/1303834107/friends?limit=50');
			// FB.api('/'+process.env.FB_APP_ID+'/accounts');
			//550812996
			//100000710922030

			//104364580313771
			//110618673020142
			//100734674069485

			// fbResponse = await fbHelper.getFbFriendsInstalled('EAAZA92YEZAwKABAIFdUQgFWw3lPvKQBc9J1gCmjsaPvNvNLtMwOZA3k00MYmQb3ko6Wf453E6CbSNbERLZAVZCZA9Lh6wfrVQmflsB7UaBLmXU6e3h4NgSIhjCwTWMGsuPrhKuQbR73ZCRtGFowLmi9z5aWMXbK2LmTaiI8ykBg96pdEr2aTuZBnHeXNXBS2dCBKCF2vkQWuXAAtt1bEofPBgwDiZAcWKHLGFrp35TIVjsAEeKQngCwd8');

			generalHelper.handleSuccess(req, res, '', {
				'result': fbResponse
			});



		} catch (e) {
			console.log(e);
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},
};