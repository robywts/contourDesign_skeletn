/**
 * Player Module
 * @exports Player/Controller
 */
var playerService = require('../services/playerService');
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/playerTrans.json');
var playerValidation = require('../validations/playerValidation');
var playerDataMapper = require('../dataMappers/playerDataMapper');
var async = require('async');

module.exports = {

	/**
	 * Get player news by player id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getPlayerNews: async function (req, res) {
		try {
			if (playerValidation.PlayerIdValidation(req, res) != false) {
				playerMapData = playerDataMapper.playerNewsData(req.params.id);
				var playerNewsDB = await playerService.getPlayerNewsDetails(playerMapData);
				if (playerNewsDB != null) {
					result = playerDataMapper.playerNewsResultMap(playerNewsDB);
					generalHelper.handleSuccess(req, res, _t.playerNewsDetailsRetrieved, result, {});

				} else {
					generalHelper.handleError(req, res, {}, _t.playerNewsDetailsEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get players score by event id
	 * @param {string} req Request object
	 * @param {object} res - Response object
	 */
	getPlayerScores: async function (req, res) {
		try {
			if (playerValidation.EventIdValidation(req, res) != false) {
				playerMapData = playerDataMapper.playerScoresData(req.query);
				var playerGamesDB = await playerService.getPlayerScores(playerMapData);
				if (playerGamesDB.length != 0) {
					result = playerDataMapper.playerScoresResultMap(playerGamesDB);
					generalHelper.handleSuccess(req, res, _t.playerScoresRetrieved, result, {});

				} else {
					generalHelper.handleError(req, res, {}, _t.playerScoresEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get player games by player id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getPlayerGames: async function (req, res) {
		try {
			if (playerValidation.PlayerRequestValidation(req, res) != false) {
				playerMapData = playerDataMapper.playerGamesData(req.params);
				var playerGamesDB = await playerService.getPlayerGamesDetails(playerMapData);
				if (playerGamesDB != null) {
					result = playerDataMapper.playerGamesResultMap(playerGamesDB);
					generalHelper.handleSuccess(req, res, _t.playerGamesDetailsRetrieved, result, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.playerGamesDetailsEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

};