/**
 * User Module
 * @exports User/Controller
 */
var userService = require('../services/userService');
var ticketService = require('../services/ticketService');
var WithdrawalModel = require('../../../models/withdrawal');
var FriendrequestModel = require('../../../models/friendrequest');
var TransactionModel = require('../../../models/transaction');
var TicketStoreModel = require('../../../models/ticketStore');
var UserTicketModel = require('../../../models/userTicket');
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/userTrans.json');
var userValidation = require('../validations/userValidation');
var userDataMapper = require('../dataMappers/userDataMapper');
var emailHelper = require('../helpers/emailHelper');
var async = require('async');
var fbHelper = require('../helpers/fbHelper');
var braintreeHelper = require('../helpers/brainTreeHelper');

var SportPointModel = require('../../../models/sportPoint');
var RankImagesModel = require('../../../models/rankImage');

module.exports = {
	/**
	 * Get user profile by session_key
	 * @param {object} req.header - Request object (session data)
	 * @param {object} res - Response object
	 */
	getProfile: async function (req, res) {
		try {
			var appUserId = global.userId;
			var profile = await userService.getProfile(appUserId);
			if (profile == null) { //error
				generalHelper.handleError(req, res, {}, _t.failedGetProfile);
			} else {
				var ticketData = await ticketService.getUserTickets(appUserId); 
				var result = userDataMapper.getProfileData(profile, ticketData);
			}
			generalHelper.handleSuccess(req, res, _t.profileRetrieved, result);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Update User profile
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	updateProfile: async function (req, res) {
		try {
			if (userValidation.updateProfileValidation(req, res) != false) {
				var userProfile = userDataMapper.updateProfileData({}, req.body);
				var profileUpdate = await userService.updateProfile(userProfile, global.userId);
				if (profileUpdate) {
					//Braintree customer updation
					braintreeHelper.updateClient(profileUpdate, async function (err, response) {
						generalHelper.wsLogger(req, {}, {
							err,
							response
						}, 'BTUpdateClient');
					});
					generalHelper.handleSuccess(req, res, _t.userProfileUpdate, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.invalidRequest);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get Client Token
	 * @param {object} req - Request object
	 * @param {object} res - Response object
	 */
	getClientToken: async function (req, res) {
		try {
			userData = {};
			var profile = await userService.getProfile(global.userId);
			if (profile == null) { //error
				generalHelper.handleError(req, res, {}, _t.failedGetProfile);
			} else {
				var userData = userDataMapper.getProfileData(profile);

				// Get Client
				var customerId = (userData.btId) ? userData.btId : ''; // 'bente';
				braintreeHelper.getClient(customerId, async function (err, response) {
					generalHelper.wsLogger(req, {}, {
						err,
						response
					}, 'BTGetClient');
					if (err) { // if error create a client
						// braintreeHelper.createClient(userData, async function (err, response) {
						// 	generalHelper.wsLogger(req, {}, {
						// 		err,
						// 		response
						// 	}, 'BTCreateClient');
						// 	var btCustomer = response.customer;
						// 	if (response) {
						// 		await userService.updateBtId(response.customer.id, global.userId);
						// 		customerId = response.customer.id;
						// 	}
						// });
						var response = await braintreeHelper.createClient(userData);
						generalHelper.wsLogger(req, {}, response, 'BTCreateClient');
						var btCustomer = response.customer;
						if (response) {
							await userService.updateBtId(response.customer.id, global.userId);
							customerId = response.customer.id;
						}
					} else {
						var btCustomer = response;
					}
					//Braintree Get Client Token
					braintreeHelper.getClientToken(customerId, async function (err, response) {
						generalHelper.wsLogger(req, {}, {
							err,
							response
						}, 'BTGetClientToken');

						if (response) {
							var result = {
								'btId': customerId,
								'clientToken': response.clientToken,
								'customer': btCustomer
							};
							generalHelper.handleSuccess(req, res, _t.clientTokenSuccess, result);
						} else {
							generalHelper.handleError(req, res, response, _t.invalidRequest);
						}
						// response.clientToken
					});
				});
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get Nonce (Input should be a BrainTree paymentToken)
	 * @param {object} req - Request object
	 * @param {object} res - Response object
	 */
	getNonce: async function (req, res) {
		try {
			if (req.query.token != '') {
				// Get Nonce
				// braintreeHelper.getNonce(req.query.token, function (err, response) { // getting nonce from an already existing user
				// 	generalHelper.wsLogger(req, {}, {
				// 		err,
				// 		response
				// 	}, 'BTGetNonce');
				// 	if (err) {
				// 		generalHelper.handleError(req, res, response, _t.invalidRequest);
				// 	} else if (response.success != true) {
				// 		generalHelper.handleError(req, res, response, response.message);
				// 	} else {
				// 		// console.log(response.paymentMethodNonce.nonce);
				// 		var result = {
				// 			'nonce': response.paymentMethodNonce.nonce
				// 		};
				// 		generalHelper.handleSuccess(req, res, _t.nonceSuccess, result);
				// 	}
				// });
				var response = await braintreeHelper.getNonce(req.query.token);
				generalHelper.wsLogger(req, {}, response, 'BTGetNonce');
				if (response) {
					var result = {
						'nonce': response.paymentMethodNonce.nonce
					};
					generalHelper.handleSuccess(req, res, _t.nonceSuccess, result);
				} else {
					generalHelper.handleError(req, res, response, _t.invalidRequest);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Deposit Money
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	depositMoney: async function (req, res) {
		try {
			if (userValidation.depositMoneyValidation(req, res) != false) {
				userData = {};
				var profile = await userService.getProfile(global.userId);
				if (profile == null) { //error
					generalHelper.handleError(req, res, {}, _t.failedGetProfile);
				} else {
					var userData = userDataMapper.getProfileData(profile);

					var transactionAmountMonthly = await userService.getTransactionAmounts('D', global.userId, 'monthly');
					var transactionAmountWeekly = await userService.getTransactionAmounts('D', global.userId, 'weekly');
					var transactionAmountDaily = await userService.getTransactionAmounts('D', global.userId, 'daily');

					if ((transactionAmountDaily[0].amount + req.body.amount) > userData.depositLimits.daily && userData.depositLimits.daily != 0) {
						generalHelper.handleError(req, res, {}, _t.dailyDepositLimitExceeded);
					} else if ((transactionAmountWeekly[0].amount + req.body.amount) > userData.depositLimits.weekly && userData.depositLimits.weekly != 0) {
						generalHelper.handleError(req, res, {}, _t.weeklyDepositLimitExceeded);
					} else if ((transactionAmountMonthly[0].amount + req.body.amount) > userData.depositLimits.monthly && userData.depositLimits.monthly != 0) {
						generalHelper.handleError(req, res, {}, _t.monthlyDepositLimitExceeded);
					} else {

						// Get Client
						var customerId = (userData.btId) ? userData.btId : ''; // 'bente';
						var nonce = req.body.nonce;
						braintreeHelper.getClient(customerId, async function (err, response) {
							generalHelper.wsLogger(req, {}, {
								err,
								response
							}, 'BTGetClient');
							if (err) { // if error create a client
								// braintreeHelper.createClient(userData, async function (err, response) {
								// 	generalHelper.wsLogger(req, {}, {
								// 		err,
								// 		response
								// 	}, 'BTCreateClient');
								// 	if (response) {
								// 		await userService.updateBtId(response.customer.id, global.userId);
								// 		customerId = response.customer.id;
								// 	}
								// });
								var response = await braintreeHelper.createClient(userData);
								generalHelper.wsLogger(req, {}, response, 'BTCreateClient');
								if (response) {
									await userService.updateBtId(response.customer.id, global.userId);
									customerId = response.customer.id;
								}
							} else {
								if (nonce == '') {
									var paymentToken = (response.paymentMethods[0]) ? response.paymentMethods[0].token : '';
									var responseNonce = await braintreeHelper.getNonce(paymentToken);
									if (responseNonce) {
										nonce = responseNonce.paymentMethodNonce.nonce;
									}
								}
								// response.id
							}

							// Payment
							braintreeHelper.paymentSubmit(req.body.amount, nonce, userData, customerId, async function (err, response) {
								generalHelper.wsLogger(req, {}, {
									err,
									response
								}, 'BTPayment');
								if (err) {
									generalHelper.handleError(req, res, response, _t.invalidRequest);
								} else if (response.success != true) {
									generalHelper.handleError(req, res, {}, response.message);
								} else { // success
									// var userDB = await userService.getBalance(global.userId); //get existing balance.
									// var depositMoneyData = userDataMapper.depositMoneyData(userDB, req.body);
									var userData = await userService.depositMoney(req.body.amount, global.userId);
									if (userData) {
										if (userData.depositCnt == 1) { //if first deposit

											// Credit $3 tickets
											var ticketAmount = 3;
											var ticket = new UserTicketModel();
											ticket.userId = global.userId;
											ticket = userDataMapper.ticketData(ticket, {
												ticketAmount: ticketAmount,
												ticketStatus: 'N'
											});
											var ticketData = await ticketService.addUserTicket(ticket);

											var userTicketData = await userService.addTicket(ticketAmount, global.userId);
											if (userTicketData && ticketData) {
												var transactionModel = new TransactionModel();
												transactionModel = userDataMapper.transactionData(transactionModel, userData, ticketAmount, 'T');
												await userService.transactionEntry(transactionModel);
												userData = userTicketData;
											}

											// Credit $10 to both the user and the referrer
											if (userData.referrer != '') {
												var creditAmount = 10;
												var referrerUserData = await userService.getProfileByUserName(userData.referrer);
												if (referrerUserData != null) { // if referrer found
													var referrerCredit = await userService.depositReferralMoney(creditAmount, referrerUserData.userId); // deposit to the referrer
													if (referrerCredit) {
														var transactionModel = new TransactionModel();
														transactionModel = userDataMapper.transactionData(transactionModel, referrerCredit, creditAmount, 'D');
														await userService.transactionEntry(transactionModel);
													}

													var userCredit = await userService.depositReferralMoney(creditAmount, global.userId); // deposit to the new user
													if (userCredit) {
														var transactionModel = new TransactionModel();
														transactionModel = userDataMapper.transactionData(transactionModel, userCredit, creditAmount, 'D');
														await userService.transactionEntry(transactionModel);
														userData = userCredit;
													}
												}
											}
										}
										var transactionModel = new TransactionModel();
										transactionModel = userDataMapper.transactionData(transactionModel, userData, req.body.amount, 'D');
										var transactionResult = await userService.transactionEntry(transactionModel);
										if (transactionResult) {
											var result = userDataMapper.getProfileData(userData);
											generalHelper.handleSuccess(req, res, _t.depositSuccess.replace('{{amount}}', req.body.amount), result);
										} else {
											generalHelper.handleError(req, res, {}, _t.invalidRequest);
										}
									} else {
										generalHelper.handleError(req, res, {}, _t.invalidRequest);
									}
								}
							});
							// }
						});
					}
				}

				// Get Client token
				// braintreeHelper.getClientToken('bente', async function (err, response) {
				// 	if (err) {
				// 		generalHelper.handleError(req, res, response, _t.invalidRequest);
				// 	} else if (response.success == true) {
				// 		console.log(response.clientToken);
				// 		generalHelper.handleSuccess(req, res, _t.depositSuccess, response);
				// 	} else {
				// 		generalHelper.handleError(req, res, response, response.message);
				// 	}
				// });

				// if (req.body.nonce == '') { //when u comment this uncomment the validation for nounce
				// 	// Get Nonce
				// 	braintreeHelper.getNonce("gvkr8x", function (err, response) { // getting nonce from an already existing user
				// 		if (err) {
				// 			generalHelper.handleError(req, res, response, _t.invalidRequest);
				// 		} else if (response.success == true) {
				// 			console.log(response.paymentMethodNonce.nonce);
				// 			generalHelper.handleSuccess(req, res, _t.depositSuccess, response);
				// 		} else {
				// 			generalHelper.handleError(req, res, response, response.message);
				// 		}
				// 	});
				// } else {
				// 	// Payment
				// 	userData = {};
				// 	var profile = await userService.getProfile(global.userId);
				// 	if (profile == null) { //error
				// 		generalHelper.handleError(req, res, {}, _t.failedGetProfile);
				// 	} else {
				// 		var userData = userDataMapper.getProfileData(profile);
				// 	}
				// 	braintreeHelper.paymentSubmit(req.body.amount, req.body.nonce, userData, async function (err, response) {
				// 		if (err) {
				// 			generalHelper.handleError(req, res, response, _t.invalidRequest);
				// 		} else if (response.success == true) {
				// 			var userDB = await userService.getBalance(global.userId); //get existing balance.
				// 			var depositMoneyData = userDataMapper.depositMoneyData(userDB, req.body);
				// 			var depositMoney = await userService.depositMoney(depositMoneyData, global.userId);
				// 			if (depositMoney) {
				// 				var transactionModel = new TransactionModel();
				// 				var transactionModel = userDataMapper.transactionData(transactionModel, userData, req.body.amount, 'D');
				// 				transactionResult = await userService.transactionEntry(transactionModel);
				// 				if (transactionResult) {
				// 					generalHelper.handleSuccess(req, res, _t.depositSuccess, {
				// 						response
				// 					});
				// 				} else {
				// 					generalHelper.handleError(req, res, {}, _t.invalidRequest);
				// 				}
				// 			} else {
				// 				generalHelper.handleError(req, res, {}, _t.invalidRequest);
				// 			}
				// 		} else {
				// 			generalHelper.handleError(req, res, {}, response.message);
				// 		}
				// 	});
				// }
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Ticket to money conversion
	 * Info: The users can earn tickets by winning contests
	 * Info: The users can earn tickets by converting rewards to tickets
	 * @param {object} req.header - Request object (session data)
	 * @param {object} res - Response object
	 */
	// ticketToMoney: async function (req, res) {
	// 	try {
	// 		if (userValidation.ticketToMoney(req, res) != false) {
	// 			var settings = await userService.getAdminSettings();
	// 			var amount = Math.floor(req.body.tickets / settings.ticketToDollar);
	// 			if (amount <= 0) { // if ticket is too low for $1 conversion
	// 				generalHelper.handleError(req, res, {}, _t.ticketsTooLess);
	// 			} else {
	// 				var userBalance = await userService.getBalance(global.userId);
	// 				var remainingTickets = userBalance.balanceTickets - req.body.tickets + (req.body.tickets % settings.ticketToDollar);
	// 				if (userBalance.balanceTickets < req.body.tickets) { // if given ticket is more than the balanceTickets
	// 					generalHelper.handleError(req, res, {}, _t.ticketsNotAvailable);
	// 				} else {
	// 					var userData = await userService.transferTicketToMoney(amount, remainingTickets, global.userId);
	// 					if (userData) {
	// 						var transactionModel = new TransactionModel();
	// 						transactionModel = userDataMapper.transactionData(transactionModel, userData, amount, 'TM');
	// 						var transactionResult = await userService.transactionEntry(transactionModel);
	// 						if (transactionResult) {
	// 							generalHelper.handleSuccess(req, res, _t.ticketConvertedSuccess.replace('{{tickets}}', (req.body.tickets - (req.body.tickets % settings.ticketToDollar))).replace('{{amount}}', amount), userData);
	// 						} else {
	// 							generalHelper.handleError(req, res, {}, _t.invalidRequest);
	// 						}
	// 					} else {
	// 						generalHelper.handleError(req, res, {}, _t.invalidRequest);
	// 					}
	// 				}
	// 			}
	// 		}
	// 	} catch (e) {
	// 		generalHelper.handleError(req, res, e.stack, _t.technicalError);
	// 	}
	// },

	/**
	 * Reward to money conversion
	 * Info: The users can earn rewards by ........................
	 * Info: The users can earn rewards by ........................
	 * @param {object} req.header - Request object (session data)
	 * @param {object} res - Response object
	 */
	// rewardToMoney: async function (req, res) {
	// 	try {
	// 		if (userValidation.rewardToMoney(req, res) != false) {
	// 			var settings = await userService.getAdminSettings();
	// 			var amount = Math.floor(req.body.rewards / settings.rewardToDollar);
	// 			if (amount <= 0) { // if reward is too low for $1 conversion
	// 				generalHelper.handleError(req, res, {}, _t.rewardsTooLess);
	// 			} else {
	// 				var userBalance = await userService.getBalance(global.userId);
	// 				var remainingRewards = userBalance.balanceRewards - req.body.rewards + (req.body.rewards % settings.rewardToDollar);
	// 				if (userBalance.balanceRewards < req.body.rewards) { // if given rewards is more than the balanceRewards
	// 					generalHelper.handleError(req, res, {}, _t.rewardsNotAvailable);
	// 				} else {
	// 					var userData = await userService.transferRewardToMoney(amount, remainingRewards, global.userId);
	// 					if (userData) {
	// 						var transactionModel = new TransactionModel();
	// 						transactionModel = userDataMapper.transactionData(transactionModel, userData, amount, 'RM');
	// 						var transactionResult = await userService.transactionEntry(transactionModel);
	// 						if (transactionResult) {
	// 							generalHelper.handleSuccess(req, res, _t.rewardConvertedSuccess.replace('{{rewards}}', (req.body.rewards - (req.body.rewards % settings.rewardToDollar))).replace('{{amount}}', amount), userData);
	// 						} else {
	// 							generalHelper.handleError(req, res, {}, _t.invalidRequest);
	// 						}
	// 					} else {
	// 						generalHelper.handleError(req, res, {}, _t.invalidRequest);
	// 					}
	// 				}
	// 			}
	// 		}
	// 	} catch (e) {
	// 		generalHelper.handleError(req, res, e.stack, _t.technicalError);
	// 	}
	// },

	/**
	 * Reward to ticket conversion
	 * Info: The users can earn rewards by ........................
	 * Info: The users can earn rewards by ........................
	 * @param {object} req.header - Request object (session data)
	 * @param {object} res - Response object
	 */
	rewardToTicket: async function (req, res) {
		try {
			if (userValidation.rewardToTicket(req, res) != false) {
				var settings = await userService.getAdminSettings();
				var tickets = Math.floor(req.body.rewards / settings.rewardToTicket);
				if (tickets <= 0) { // if reward is too low for 1 ticket conversion
					generalHelper.handleError(req, res, {}, _t.rewardsTooLessTicket);
				} else {
					var userBalance = await userService.getBalance(global.userId);
					var remainingRewards = userBalance.balanceRewards - req.body.rewards + (req.body.rewards % settings.rewardToTicket);
					if (userBalance.balanceRewards < req.body.rewards) { // if given rewards is more than the balanceRewards
						generalHelper.handleError(req, res, {}, _t.rewardsNotAvailable);
					} else {
						var ticket = new UserTicketModel();
						ticket.userId = global.userId;
						ticket = userDataMapper.ticketData(ticket, {
							ticketAmount: tickets,
							ticketStatus: 'N'
						});
						var ticketData = await ticketService.addUserTicket(ticket);

						var userData = await userService.transferRewardToTicket(tickets, remainingRewards, global.userId);
						if (userData && ticketData) {
							var transactionModel = new TransactionModel();
							transactionModel = userDataMapper.transactionData(transactionModel, userData, tickets, 'RT');
							var transactionResult = await userService.transactionEntry(transactionModel);
							if (transactionResult) {
								generalHelper.handleSuccess(req, res, _t.rewardConvertedSuccessTicket.replace('{{rewards}}', (req.body.rewards - (req.body.rewards % settings.rewardToTicket))).replace('{{tickets}}', tickets), userData);
							} else {
								generalHelper.handleError(req, res, {}, _t.invalidRequest);
							}
						} else {
							generalHelper.handleError(req, res, {}, _t.invalidRequest);
						}
					}
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get user balance amount by session_key
	 * @param {object} req.header - Request object (session data)
	 * @param {object} res - Response object
	 */
	getBalanceMoney: async function (req, res) {
		try {
			var userDB = await userService.getBalance(global.userId);
			var withdrawRequestAmt = await userService.withdrawRequestAmount(global.userId);
			var withdrawAmt = (withdrawRequestAmt[0]) ? withdrawRequestAmt[0].amount : 0;
			var realBal = userDB.balance - withdrawAmt - userDB.referralMoney;

			var result = userDataMapper.getBalanceData(userDB, realBal); //get existing balance.
			generalHelper.handleSuccess(req, res, _t.balanceRetrieved, result);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Reuqest for withdrawal Money
	 * @param {object} req.body - Request object 
	 * @param {object} res - Response object
	 */
	withdrawalRequest: async function (req, res) {
		try {
			if (userValidation.withdrawalValidation(req, res) != false) {
				var userDB = await userService.getBalance(global.userId);
				var withdrawRequestAmt = await userService.withdrawRequestAmount(global.userId);
				var withdrawAmt = (withdrawRequestAmt[0]) ? withdrawRequestAmt[0].amount : 0;
				var realBal = userDB.balance - withdrawAmt - userDB.referralMoney;

				if (realBal < req.body.amount) {
					generalHelper.handleError(req, res, '', _t.requestAmountExceeded);
				} else {
					var withdrawalModel = new WithdrawalModel();
					withdrawalModel = userDataMapper.withdrawalMoneyData(withdrawalModel, userDB, req.body);
					withdrawalStatus = await userService.addWithdrawalRequest(withdrawalModel);
					if (withdrawalStatus != null) {
						generalHelper.handleSuccess(req, res, _t.withdrawalSent, {});
						// userWithDrawStatus = await userService.updateUserWithdrawStatus(global.userId, 'P');
						// if (userWithDrawStatus) {
						// 	generalHelper.handleSuccess(req, res, _t.withdrawalSent, {});
						// } else {
						// 	generalHelper.handleError(req, res, {}, _t.invalidRequest);
						// }
					} else {
						generalHelper.handleError(req, res, {}, _t.invalidRequest);
					}
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get user withdrawal Status
	 * @param {object} req.header - Request object (session data)
	 * @param {object} res - Response object
	 */
	// withdrawalStatus: async function (req, res) {
	// 	try {
	// 		var userDB = await userService.withdrawalStatus(global.userId);
	// 		if (userDB == null) { //error
	// 			generalHelper.handleError(req, res, {}, _t.failedGetWithdrawalStatus);
	// 		} else {
	// 			var result = userDataMapper.getWithdrawalStatus(userDB);
	// 			generalHelper.handleSuccess(req, res, _t.withdrawalStatusRetrieved, result);
	// 		}
	// 	} catch (e) {
	// 		generalHelper.handleError(req, res, e.stack, _t.technicalError);
	// 	}
	// },

	/**
	 * Get Withdrawal Requests
	 * @param {object} req - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getWithdrawalRequests: async function (req, res) {
		try {
			var userId = global.userId;
			var search = userDataMapper.searchWithdrawalData(req.query);
			var withdrawalDB = await userService.withdrawalRequests(search, userId);
			var totalCount = await userService.withdrawalRequestsCount(search, userId);

			// var userDB = await userService.getUserBalance(userId);
			var result = userDataMapper.getWithdrawalData(withdrawalDB); // , userDB.balance
			var additionalData = {};
			additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, withdrawalDB.length);
			generalHelper.handleSuccess(req, res, _t.withdrawalRequestsRetrieved, result, additionalData);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get transactions
	 * @param {object} req - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getTransactions: async function (req, res) {
		try {
			var userId = global.userId;
			var search = userDataMapper.searchTransactionData(req.query);
			var tranDB = await userService.getTransactions(search, userId);
			var totalCount = await userService.getTransactionsCount(search, userId);

			var result = userDataMapper.getTransactionData(tranDB);
			var additionalData = {};
			additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, tranDB.length);
			generalHelper.handleSuccess(req, res, _t.transactionsRetrieved, result, additionalData);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get all notifications
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getNotifications: async function (req, res) {
		try {
			var pagination = userDataMapper.paginationData(req.query);
			var notificationsDB = await userService.getNotifications(pagination, global.userId);
			var totalCount = await userService.getNotificationsCount(global.userId); //get rocords count
			var result = userDataMapper.getnotificationsData(notificationsDB);
			var additionalData = {};
			additionalData = generalHelper.paginationInfo(pagination.limit, totalCount, pagination.page, notificationsDB.length);
			generalHelper.handleSuccess(req, res, _t.notificationsRetrieved, result, additionalData);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Reuqest for update notification
	 * @param {object} req.body - Request object 
	 * @param {object} res - Response object
	 */
	updateNotification: async function (req, res) {
		try {
			var notificationsDB = await userService.updateNotification(global.userId); //Marking all unread notifications as read
			if (notificationsDB) {
				generalHelper.handleSuccess(req, res, _t.notificationUpdate, {});
			} else {
				generalHelper.handleError(req, res, {}, _t.invalidRequest);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Update User Settings
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	updateSettings: async function (req, res) {
		try {
			if (userValidation.updateSettingsValidation(req, res) != false) {
				var userDB = await userService.getProfile(global.userId);

				var remainingTime = 0;
				if (global.geoSession.country == 'US' && global.geoSession.state == 'MA') {
					var nintyPlus = new Date(userDB.createdAt);
					nintyPlus.setDate(nintyPlus.getDate() + 90);
					remainingTime = nintyPlus.getTime() - new Date().getTime();
				} else {
					var twentyFourPlus = new Date(userDB.createdAt);
					twentyFourPlus.setDate(twentyFourPlus.getDate() + 1);
					remainingTime = twentyFourPlus.getTime() - new Date().getTime();
				}

				if (remainingTime > 0) {
					remainingTime = remainingTime / (1000 * 60 * 60); // convert it to hours					
					if (remainingTime >= 24) {
						remainingTime = remainingTime / 24;
						generalHelper.handleError(req, res, {}, _t.settingsUpdateDayNotReached.replace('{days}', parseInt(remainingTime)));
					} else {
						generalHelper.handleError(req, res, {}, _t.settingsUpdateTimeNotReached.replace('{hrs}', parseInt(remainingTime)));
					}
				} else {
					var settingsData = userDataMapper.updateSettingsData(userDB, req.body);
					var settingsDB = await userService.updateSettings(settingsData);
					if (settingsDB) {
						generalHelper.handleSuccess(req, res, _t.userSettingsUpdate, {});
					} else {
						generalHelper.handleError(req, res, {}, _t.failedUpdateSettings);
					}
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get user settings by userid
	 * @param {object} req.header - Request object (session data)
	 * @param {object} res - Response object
	 */
	getSettings: async function (req, res) {
		try {
			var settings = await userService.getSettings(global.userId);
			var result = userDataMapper.getSettingsData(settings);
			generalHelper.handleSuccess(req, res, _t.settingsRetrieved, result);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Send feedback
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	sendFeedback: async function (req, res) {
		try {
			if (userValidation.sendFeedbackValidation(req, res) != false) {
				var userDB = await userService.getProfile();
				var result = userDataMapper.feedbackData(req.body, userDB);
				var sendMail = emailHelper.sendMail(process.env.MAIL_FROM, 'feddbackSubject', './app/modules/mobile/emailTemplates/feedback.html', {
					Name: result.Name ? result.Name : '',
					Email: result.Email,
					Feedback: result.Feedback
				});
				generalHelper.handleSuccess(req, res, _t.feedbackSuccess, {});
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Contact support
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	contactSupport: async function (req, res) {
		try {
			if (userValidation.contactSupportValidation(req, res) != false) {
				var userDB = await userService.getProfile();
				var result = userDataMapper.supportData(req.body, userDB);
				var sendMail = emailHelper.sendMail(process.env.MAIL_FROM, 'supportSubject', './app/modules/mobile/emailTemplates/support.html', {
					Name: result.Name ? result.Name : '',
					Email: result.Email,
					Message: result.Message
				});
				generalHelper.handleSuccess(req, res, _t.supportSuccess, {});
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get all Users
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	listUsers: async function (req, res) {
		try {
			var search = userDataMapper.searchData(req.query);
			var userDB = await userService.listUsers(search, global.userId);
			var totalCount = await userService.listUsersCount(search, global.userId);
			//var sentFriendRequestDB = await userService.getSentFriendRequest(global.userId);
			//var sentFriendRequestDB1 = await userService.getSentFriendRequest1(global.userId);
			//var sentFriendRequestresult = userDataMapper.sentFriendRequestData(sentFriendRequestDB, sentFriendRequestDB1);	
			var getIsFollowing = await userService.getIsFollowing(global.userId);
			var fbids = await fbHelper.getFbFriendsInstalled(global.fbUserToken); // get fb friends
			if (fbids.error) { // if fb token issue
				fbids = [];
			}
			var result = userDataMapper.getUsersDatas(userDB, getIsFollowing, fbids);
			var additionalData = {};
			additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, userDB.length);
			generalHelper.handleSuccess(req, res, _t.usersListRetrieved, result, additionalData);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get all Users with matching FBID
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	listFBUsers: async function (req, res) {
		try {
			var fbids = await fbHelper.getFbFriendsInstalled(global.fbUserToken);
			if (fbids.error) { // if fb token issue
				generalHelper.handleError(req, res, {}, fbids.error.message);
			} else if (userValidation.facebookIdsValidation(req, res, fbids) != false) {
				var search = userDataMapper.searchData(req.query);
				// var fbids = req.query.fbids.split(',');
				var userDB = await userService.listFBUsers(search, global.userId, fbids);
				var totalCount = await userService.listFBUsersCount(search, global.userId, fbids);

				var getIsFollowing = await userService.getIsFollowing(global.userId);
				var fbids = await fbHelper.getFbFriendsInstalled(global.fbUserToken); // get fb friends
				if (fbids.error) { // if fb token issue
					fbids = [];
				}

				// var result = userDataMapper.getUsersData(userDB);
				var result = userDataMapper.getUsersDatas(userDB, getIsFollowing, fbids);
				var additionalData = {};
				additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, userDB.length);
				generalHelper.handleSuccess(req, res, _t.fbFriendsListRetrieved, result, additionalData);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Send Friend Request
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	sendFriendrequest: async function (req, res) {
		try {
			if (userValidation.friendRequestValidation(req, res) != false) {
				friendRequest = userDataMapper.friendRequestData({}, req.body);
				//var friendRequestDB = await userService.checkFriendrequest(friendRequest, global.userId); //check request sent status 

				var getIsFollowing = await userService.getIsFollowing(global.userId);

				if (!getIsFollowing.isFollowing.includes(friendRequest.toUserId)) {
					//	if (friendRequestDB == null) {
					var fromUserData = await userService.getProfile(global.userId);
					var toUserData = await userService.getProfile(friendRequest.toUserId);
					if (toUserData == null) {
						generalHelper.handleError(req, res, {}, _t.failedGetUser);
					} else {
						var friendRequestModel = new FriendrequestModel();
						friendRequestModel = userDataMapper.friendRequestDataAdd(friendRequestModel, friendRequest, toUserData, fromUserData);
						var sendRequest = await userService.sendFriendrequest(friendRequestModel);
						if (sendRequest) {
							var sendRequestFollowing = await userService.setFriendrequestFollowing(friendRequest.toUserId, global.userId);
							var sendRequestFollows = await userService.setFriendrequestFollows(friendRequest.toUserId, global.userId);

							var friendRequesBothtDB = await userService.checkFriendrequestBoth(friendRequest, global.userId); //check request sent status 
							if (friendRequesBothtDB != null) {
								var friendDB = await userService.updateFriendrequestStatusBoth(friendRequest.toUserId, global.userId);
								var friendDB1 = await userService.updateFriendrequestStatusBoth(global.userId, friendRequest.toUserId);

								var friendDB = await userService.setFriends(friendRequest.toUserId, global.userId); //add to user in from user's list
								var friendDB = await userService.setFriends(global.userId, friendRequest.toUserId); //add from  user in to user's list
							}

							generalHelper.handleSuccess(req, res, _t.friendRequestSentSuccess, {});
						} else {
							generalHelper.handleError(req, res, {}, _t.failedToSentFriendRequest);
						}
					}
				} else {
					generalHelper.handleError(req, res, {}, _t.friendRequestSentAlready);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Respond to a Friend Request
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	respondFriendRequest: async function (req, res) {
		try {
			if (userValidation.friendValidation(req, res) != false) {
				friendRequestResponse = userDataMapper.friendRequestResponsData({}, req.body);
				var friendDB = await userService.checkFriendrequestStatus(friendRequestResponse, global.userId);
				if (friendDB == null) {
					generalHelper.handleError(req, res, {}, _t.friendRequestNotExist);
				} else {
					if (friendDB.requestStatus == 0) { //checking the already responded or not
						var userDataResponse = userDataMapper.friendDataResponse(friendDB, req.body);
						var friendDB = await userService.updateFriendrequestStatus(userDataResponse, global.userId, friendRequestResponse);
						if (friendRequestResponse.response == 1) { //User accapted the request
							var userdata = userDataMapper.friendData({}, req.body);
							var friendDB = await userService.setFriends(userdata, global.userId); //add to user in from user's list
							var friendDB = await userService.setFriends(global.userId, userdata); //add from  user in to user's list

							var sendRequestFollowing = await userService.setFriendrequestFollowing(userdata, global.userId);
							var sendRequestFollows = await userService.setFriendrequestFollows(userdata, global.userId);

							generalHelper.handleSuccess(req, res, _t.friendRequestAccepted, {});
						} else if (friendRequestResponse.response == 2) { //User declined the request
							generalHelper.handleSuccess(req, res, _t.friendRequestDeclined, {});
						}
					} else {
						generalHelper.handleError(req, res, {}, _t.friendRequestAlreadyRespond);
					}
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get Friend Requests
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getFriendRequest: async function (req, res) {
		try {
			var friendRequestDB = await userService.getFriendRequest(global.userId);
			var result = userDataMapper.getFriendRequestData(friendRequestDB);
			generalHelper.handleSuccess(req, res, _t.friendRequestRetrieved, result, {});
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * List Friends
	 * @param {object} req.header - Request object (session data)
	 * @param {object} res - Response object
	 */
	listFriends: async function (req, res) {
		try {
			var search = userDataMapper.searchData(req.query);
			var friendsID = await userService.getFriendsIds(global.userId);
			if (friendsID == null) {
				generalHelper.handleError(req, res, {}, _t.failedGetFriendsList);
			} else {
				var userDB = await userService.listFriends(search, friendsID.friends);
				var totalCount = await userService.listFriendsCount(search, friendsID.friends);

				var getIsFollowing = await userService.getIsFollowing(global.userId);
				var fbids = await fbHelper.getFbFriendsInstalled(global.fbUserToken); // get fb friends
				if (fbids.error) { // if fb token issue
					fbids = [];
				}

				// var result = userDataMapper.getFriendsData(userDB);
				var result = userDataMapper.getUsersDatas(userDB, getIsFollowing, fbids);
				var additionalData = {};
				additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, userDB.length);
				generalHelper.handleSuccess(req, res, _t.freindsListRetrieved, result, additionalData);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Unfriend a Friend 
	 * @param {object} req.body - Request object
	 * @param {object} res - Response object
	 */
	unfriendRequest: async function (req, res) {
		try {
			if (userValidation.unFriendValidation(req, res) != false) {
				unfriend = userDataMapper.unfriendData({}, req.body);
				var userDB = await userService.checkFriendStatus(unfriend, global.userId);
				/*if (userDB[0] == null) {
					generalHelper.handleError(req, res, '', _t.friendNotExist);
				} else {*/
				var unfriendFromUserId = await userService.unfriendRequest(unfriend.friendId, global.userId);
				var unfriendToUserId = await userService.unfriendRequest(global.userId, unfriend.friendId);

				var unfriendIsFollowing = await userService.removeIsFollowing(global.userId, unfriend.friendId);
				var unfriendIsFollows = await userService.removeIsFollows(global.userId, unfriend.friendId);

				var removeFriendRequest = await userService.removeFriend(unfriend, global.userId);
				generalHelper.handleSuccess(req, res, _t.unfriendSuccess, {});
				//}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Update Profile Image
	 * @param {object} req - Request object (record's data)
	 * @param {object} res - Response object
	 */
	updateprofileImage: async function (req, res) {
		try {
			var userAuthDB = await userService.getProfile(global.userId); //find the account
			if (userAuthDB == null) {
				generalHelper.handleError(req, res, {}, _t.invalidRequest);
			} else {
				var imageUploadHelper = require('../helpers/imageUploadHelper');
				await imageUploadHelper.imageUpload(req, res, 'profileImage', async function (imageName) {
					if (imageName != '') {

						await imageUploadHelper.resize(req.file, 'profileImage', 120);
						await imageUploadHelper.uploadS3(req.file, 'profileImage', '');
						await imageUploadHelper.uploadS3(req.file, 'profileImage', 120);

						await imageUploadHelper.deleteLocalImage('profileImage', imageName, '');
						await imageUploadHelper.deleteLocalImage('profileImage', imageName, 120);

						await userService.updateprofileImage(imageName, userAuthDB);

						await imageUploadHelper.deleteOldImage('profileImage', userAuthDB.imageName, '');
						await imageUploadHelper.deleteOldImage('profileImage', userAuthDB.imageName, 120);
						generalHelper.handleSuccess(req, res, _t.profileImageUploaded, {});
					} else {
						generalHelper.handleError(req, res, 'Image name not found', _t.invalidRequest);
					}
				});
			}

		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Add new ticket
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	addUserTicket: async function (req, res) {
		try {
			if (userValidation.ticketValidation(req, res) != false) {
				var ticket = new UserTicketModel();
				ticket.userId = global.userId;
				ticket = userDataMapper.ticketData(ticket, req.body);
				var response = await ticketService.addUserTicket(ticket);
				if (response._id != null) {
					generalHelper.handleSuccess(req, res, _t.ticketAddedSuccess, response);
				} else {
					generalHelper.handleError(req, res, 'Failed to add Ticket', _t.ticketAddFailed);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Add ticket to store
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	addTicketToStore: async function (req, res) {
		try {
			var ticketStore = [];
			ticketStore = userDataMapper.ticketStoreData(ticketStore, req.body);
			var response = await ticketService.addTicketToStore(ticketStore);
			if (response != null) {
				generalHelper.handleSuccess(req, res, _t.ticketAddedSuccess, response);
			} else {
				generalHelper.handleError(req, res, 'Failed to add Ticket', _t.ticketAddFailed);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get ticket store data using session_key
	 * @param {object} req.header - Request object (session data)
	 * @param {object} res - Response object
	 */
	getStoreTickets: async function (req, res) {
		try {
			var tickets = await ticketService.getStoreTickets();			
			if (tickets == null) { //error
				generalHelper.handleError(req, res, {}, _t.failedToGetTicketStore);
			} else {
				var result = userDataMapper.getStoreTicketData(tickets);
			}
			generalHelper.handleSuccess(req, res, _t.ticketsRetrieved, result);
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},
};