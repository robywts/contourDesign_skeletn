/**
 * User Authentication Module
 * @exports UserAuth/Controller
 */
var UserModel = require('../../../models/user');
var moment = require('moment');
var userAuthService = require('../services/userAuthService');
var generalHelper = require('../helpers/generalHelper');
var fbHelper = require('../helpers/fbHelper');
var bcryptHelper = require('../helpers/bcryptHelper');
var emailHelper = require('../helpers/emailHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/userAuthTrans.json');
var userAuthValidation = require('../validations/userAuthValidation');
var userAuthDataMapper = require('../dataMappers/userAuthDataMapper');
var braintreeHelper = require('../helpers/brainTreeHelper');
var geoCodingHelper = require('../helpers/geoCodingHelper');

module.exports = {
	/**
	 * User Registration
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	register: async function (req, res) {
		try {
			if (userAuthValidation.registerValidation(req, res) != false) {
				var userAuth = userAuthDataMapper.registerData({}, req.body);
				var user = await userAuthService.findUser(userAuth);
				if (user == null) { //can create account
					var userAuthDBNew = new UserModel();
					userAuthDBNew.userId = await generalHelper.updateCounter('userId'); // unique key
					if (userAuthDBNew.userId != null) {
						userAuthDBNew = userAuthDataMapper.registerData(userAuthDBNew, req.body);
						userAuthDBNew.pwd = bcryptHelper.encrypt(userAuthDBNew.pwd); // encryption
						var response = await userAuthService.addUser(userAuthDBNew);
						if (response._id != null) {
							// console.log(response);
							response.sessions.sessionToken = response.sessions.pop().sessionToken; // gets the last session
							var result = userAuthDataMapper.getOneUserData(response);

							//Braintree customer adding
							// braintreeHelper.createClient(userAuthDBNew, async function (err, response) {
							// 	generalHelper.wsLogger(req, {}, {
							// 		err,
							// 		response
							// 	}, 'BTCreateClient');
							// });
							var response = await braintreeHelper.createClient(userAuthDBNew);
							generalHelper.wsLogger(req, {}, response, 'BTCreateClient');

							generalHelper.handleSuccess(req, res, _t.userRegistered, result);
						} else {
							generalHelper.handleError(req, res, 'Registration failed', _t.failedRegistration);
						}
					} else {
						generalHelper.handleError(req, res, 'Id generation failed', _t.failedRegistration);
					}
				} else { // account existing
					if (user.email == userAuth.email) {
						generalHelper.handleError(req, res, 'Email exists', _t.emailExists);
					} else if (user.userName == userAuth.userName) {
						generalHelper.handleError(req, res, 'User name exists', _t.userNameExists);
					}
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * User FB Login
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	fbLogin: async function (req, res) {
		try {
			if (userAuthValidation.fbRegisterValidation(req, res) != false) { //validation
				var userAuth = new UserModel();
				var userAuth = userAuthDataMapper.fbLoginRegisterData(userAuth, req.body); //data mapping
				var response = {};
				var fbProfile = await fbHelper.getFbProfile(req.body.fbToken); //get fb profile
				userAuth.loginTypes.FB.fbId = fbProfile.id;
				// if (!fbProfile.email && !userAuth.email) { //if email didn't appear in the fb get
				// 	generalHelper.handleError(req, res, 'FB Login failed', _t.emailRequired);
				// } else {
				var userSM = await userAuthService.findUserSocialMedia('FB', userAuth); //fbId matching
				var user = await userAuthService.findUserByEmail(userAuth.email); //email matching

				if (userSM != null && userSM.userStatus != 1) { // userSM inactive
					response.userId = null;
				} else if (userSM != null) { // login only (fbId is mandatory)
					response = await userAuthService.SMLogin('FB', userAuth);
				} else if (user != null && user.userStatus != 1) { // user inactive
					response.userId = null;
				} else if (user != null) { // existing but merge required (email and password are mandatory)
					if (userAuth.email === '') { // email not provided in input
						generalHelper.handleError(req, res, "Invalid Input in email", _t.emailRequired);
					} else if (userAuth.pwd === '') { // password not provided in input
						generalHelper.handleError(req, res, "Invalid Input in password", _t.passwordRequired);
					} else if (!bcryptHelper.compare(userAuth.pwd, user.pwd)) { // password comparison
						generalHelper.handleError(req, res, 'Invalid password', _t.invalidCredentials);
					} else {
						userAuth.fName = fbProfile.firstName;
						userAuth.lName = fbProfile.lastName;
						response = await userAuthService.SMMerge('FB', userAuth);
					}
				} else { // new record  (all are mandatory and user should be unique)
					var userNameValidity = await userAuthService.findUserByUserName(userAuth); //username not null and not duplicate
					// console.log(userAuth);
					if (userAuth.email === '') { // email not provided in input
						generalHelper.handleError(req, res, "Invalid Input in email", _t.emailRequired);
					} else if (userAuth.pwd === '') { // password not provided in input
						generalHelper.handleError(req, res, "Invalid Input in password", _t.passwordRequired);
					} else if (userAuth.dob === '' || userAuth.dob === null) { // date of birth not provided in input
						generalHelper.handleError(req, res, "Invalid Input in dob", _t.dobRequired);
					} else if (moment().diff(moment(userAuth.dob, 'YYYY-MM-DD'), 'years') < 18) {
						return generalHelper.handleError(req, res, "Invalid Age in dob", _t.dobAgeRestricted);
					} else if (userNameValidity == false) { // userName not provided in input
						generalHelper.handleError(req, res, "Invalid Input in user name", _t.userNameRequired);
					} else if (userNameValidity != null) { // userName exists
						generalHelper.handleError(req, res, 'User name exists', _t.userNameExists);
					} else {
						userAuth.userId = await generalHelper.updateCounter('userId'); // unique key
						if (userAuth.userId != null) {
							// userAuth.email = fbProfile.email;
							userAuth.fName = fbProfile.firstName;
							userAuth.lName = fbProfile.lastName;
							userAuth.pwd = bcryptHelper.encrypt(userAuth.pwd); // encryption
							userAuth.spendLimits = {
								'daily': 0,
								'weekly': 0,
								'monthly': 0,
								'maxEntryFee': 0,
							};
							userAuth.depositLimits = {
								'daily': 0,
								'weekly': 0,
								'monthly': 0,
							};
							response = await userAuthService.addUser(userAuth);
							//Braintree customer adding
							// braintreeHelper.createClient(userAuth, async function (err, response) {
							// 	generalHelper.wsLogger(req, {}, {
							// 		err,
							// 		response
							// 	}, 'BTCreateClientFB');
							// });
							var responseBT = await braintreeHelper.createClient(userAuth);
							generalHelper.wsLogger(req, {}, responseBT, 'BTCreateClientFB');
						} else {
							generalHelper.handleError(req, res, 'Id generation failed', _t.invalidRequest);
						}
					}
				}

				if (response == null) { //fix for the next condition
					response = {};
					response.userId = null;
				}
				if (response.userId != null) {
					response.sessions.sessionToken = response.sessions.pop().sessionToken; // gets the last session
					var result = userAuthDataMapper.getOneUserData(response);
					generalHelper.handleSuccess(req, res, _t.userLogin, result);
				} else {
					generalHelper.handleError(req, res, 'FB Login failed', _t.invalidCredentials);
				}
			}
			// }
		} catch (e) {
			if (e.name == 'FacebookApiException') {
				generalHelper.handleError(req, res, e.stack, e.response.error.message);
			} else {
				generalHelper.handleError(req, res, e.stack, _t.technicalError);
			}
		}
	},

	/**
	 * User FB Merge (only for login users)
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	fbMerge: async function (req, res) {
		try {
			if (userAuthValidation.fbMergeValidation(req, res) != false) { //validation
				var userAuth = userAuthDataMapper.fbMergeData({}, req.body); //data mapping
				var fbProfile = await fbHelper.getFbProfile(req.body.fbToken); //get fb profile
				userAuth.loginTypes.FB.fbId = fbProfile.id;

				var userSM = await userAuthService.findUserSocialMedia('FB', userAuth); //fbId matching
				if (userSM != null && userSM.userId != global.userId) { // fbId is already attached with another account
					generalHelper.handleError(req, res, 'FB Merge failed', _t.fbAlreadyMerged);
				} else {
					userAuth.loginTypes.FB.fbId = fbProfile.id;
					userAuth.fName = fbProfile.firstName;
					userAuth.lName = fbProfile.lastName;
					response = await userAuthService.SMMergeUser('FB', userAuth);
					if (response.userId != null) {
						var result = userAuthDataMapper.getOneUserData(response);
						generalHelper.handleSuccess(req, res, _t.userFBMerge, result);
					} else {
						generalHelper.handleError(req, res, 'FB Merge failed', _t.invalidRequest);
					}
				}
			}
		} catch (e) {
			if (e.name == 'FacebookApiException') {
				generalHelper.handleError(req, res, e.stack, e.response.error.message);
			} else {
				generalHelper.handleError(req, res, e.stack, _t.technicalError);
			}
		}
	},

	/**
	 * User Login
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	login: async function (req, res) {
		try {
			if (userAuthValidation.loginValidation(req, res) != false) {
				var userAuth = userAuthDataMapper.loginData({}, req.body);
				var user = await userAuthService.findUserByEmail(userAuth.email, 1);
				if (user != null) {
					if (!bcryptHelper.compare(userAuth.pwd, user.pwd)) { // password comparison
						generalHelper.handleError(req, res, 'Invalid password', _t.invalidCredentials);
					} else {
						var response = await userAuthService.updateUserSession(user.userId, userAuth);
						if (response.sessions != null) {
							response.sessions.sessionToken = response.sessions.pop().sessionToken; // get the last session
							var result = userAuthDataMapper.getOneUserData(response);
							generalHelper.handleSuccess(req, res, _t.userLogin, result);
						} else {
							generalHelper.handleError(req, res, 'Session not updated', _t.invalidRequest);
						}
					}
				} else {
					generalHelper.handleError(req, res, 'Invalid user', _t.invalidCredentials);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * User Forgot Password
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	forgot: async function (req, res) {
		try {
			if (userAuthValidation.forgotValidation(req, res) != false) {
				var userAuth = userAuthDataMapper.forgotData({}, req.body);
				var user = await userAuthService.findUserByEmail(userAuth.email, 1);
				if (user != null) {
					var response = await userAuthService.updateResetCode(user.userId, userAuth);
					if (response.resetCode != null) {
						emailHelper.sendMail(response.email, 'emailResetCodeSubject', './app/modules/mobile/emailTemplates/resetCode.html', {
							resetCode: response.resetCode,
							name: response.userName.charAt(0).toUpperCase() + response.userName.slice(1).toLowerCase()
						}, ''); // email
						var result = userAuthDataMapper.getUserForgotData(response);
						generalHelper.handleSuccess(req, res, _t.userResetCode, result);
					} else {
						generalHelper.handleError(req, res, 'Reset code not updated', _t.invalidRequest);
					}
				} else {
					generalHelper.handleError(req, res, 'Email not exists', _t.invalidEmail);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * User Reset Password
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	reset: async function (req, res) {
		try {
			if (userAuthValidation.resetValidation(req, res) != false) {
				var userAuth = userAuthDataMapper.resetData({}, req.body);
				var user = await userAuthService.findActiveUserByResetCode(userAuth);
				if (user != null) {
					userAuth.pwd = bcryptHelper.encrypt(userAuth.pwd); //encryption
					var response = await userAuthService.resetPassword(user.userId, userAuth);
					if (response.sessions != null) {
						response.sessions.sessionToken = response.sessions.pop().sessionToken; // get the last session
						var result = userAuthDataMapper.getOneUserData(response);
						generalHelper.handleSuccess(req, res, _t.passwordReset, result);
					} else {
						generalHelper.handleError(req, res, 'password not updated', _t.invalidRequest);
					}
				} else {
					generalHelper.handleError(req, res, 'Invalid email or reset code', _t.invalidEmailOrResetCode);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * User Change Password
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	changePassword: async function (req, res) {
		try {
			if (userAuthValidation.changePasswordValidation(req, res) != false) {
				var user = await userAuthService.findActiveUserById(global.userId);
				if (user != null) {
					var userAuth = userAuthDataMapper.changePasswordData({}, req.body);
					if (!bcryptHelper.compare(userAuth.oldPwd, user.pwd)) { // password comparison
						generalHelper.handleError(req, res, 'Current password is wrong', _t.invalidOldPassword);
					} else {
						userAuth.pwd = bcryptHelper.encrypt(userAuth.pwd); // encryption
						var response = await userAuthService.changePassword(user.userId, userAuth);
						if (response.userId != null) {
							var result = userAuthDataMapper.getOneUserData(response);
							generalHelper.handleSuccess(req, res, _t.passwordChange, result);
						} else {
							generalHelper.handleError(req, res, 'password not updated', _t.invalidRequest);
						}
					}
				} else {
					generalHelper.handleError(req, res, 'Invalid user id', _t.invalidSessionKey);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * User Logout
	 * @param {object} req.headers - Request object
	 * @param {object} res - Response object
	 */
	logout: async function (req, res) {
		try {
			var response = await userAuthService.logout(global.userId, global.sessionToken);
			if (response != null) {
				generalHelper.handleSuccess(req, res, _t.userLogout, {});
			} else {
				generalHelper.handleError(req, res, 'Logout not successfull', _t.invalidRequest);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Update Device Token
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	updateDeviceToken: async function (req, res) {
		try {
			if (userAuthValidation.deviceTokenValidation(req, res) != false) {
				var userAuth = userAuthDataMapper.updateDeviceTokenData({}, req.body);
				var response = await userAuthService.updateDeviceToken(global.userId, global.sessionToken, userAuth);
				if (response != null) {
					generalHelper.handleSuccess(req, res, _t.userDeviceUpdate, {});
				} else {
					generalHelper.handleError(req, res, 'Device info not updated', _t.invalidRequest);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get Geo Token
	 * @param {object} req - Request object
	 * @param {object} res - Response object
	 */
	getGeoToken: async function (req, res) {
		try {
			if (userAuthValidation.geoTokenValidation(req, res) != false) {
				var createNewToken = false;
				if (global.geoToken.createdAt) {
					var dbDt = new Date(global.geoToken.createdAt);
					dbDt.setDate(dbDt.getDate() + 1);
					var currDt = new Date();

					if (dbDt.getTime() < currDt.getTime()) { // token expired
						createNewToken = true;
						// console.log('expired token');
					} else if (global.geoToken.lat != req.body.lat || global.geoToken.lng != req.body.lng) {
						createNewToken = true;
						// console.log('Lat lang different in token');
					} else {
						// console.log('all conditions solved success');
					}
				} else { // first time creation
					createNewToken = true;
					// console.log('first time creation token');
				}

				if (createNewToken == true) { // create new token
					// console.log('new token');
					var BFstates = require('../../../static/blockedFreeStates.json');
					var allowed = false;
					var result = await geoCodingHelper.getStateCode(req.body.lat, req.body.lng);
					// console.log(result);

					if (result.country == 'CA') { // if country is Canada
						allowed = true;
					} else if (result.country == 'US') { // if country is United States
						if (BFstates.allowed.indexOf(result.state) > -1) { // if it is in allowed states
							allowed = true;
						}
					}

					result.allowed = allowed;
					var geoAuth = userAuthDataMapper.geoData({}, req.body, result);
					var response = await userAuthService.updateGeoToken(global.userId, global.sessionToken, geoAuth);
					if (response != null) {
						generalHelper.handleSuccess(req, res, _t.geoTokenGenerated, geoAuth);
					} else {
						generalHelper.handleError(req, res, 'GeoToken not generated', _t.invalidRequest);
					}
				} else { // send the old token
					// console.log('old token');
					var dbDt = new Date(global.geoToken.createdAt);
					global.geoToken.createdAt = dbDt.getTime();
					generalHelper.handleSuccess(req, res, _t.geoTokenGenerated, global.geoToken);
				}
			}
		} catch (e) {
			if (e.stack) {
				generalHelper.handleError(req, res, e.stack, _t.technicalError);
			} else {
				generalHelper.handleError(req, res, e, _t.technicalError);
			}
		}
	},
};