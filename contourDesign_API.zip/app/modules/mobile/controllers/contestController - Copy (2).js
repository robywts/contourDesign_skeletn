/**
 * Contest Module
 * @exports Contest/Contorller
 */
var contestService = require('../services/contestService');
var draftGroupService = require('../services/draftGroupService');
var lineUpService = require('../services/lineUpService');
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/contestTrans.json');
var contestValidation = require('../validations/contestValidation');
var contestDataMapper = require('../dataMappers/contestDataMapper');
var ContestModel = require('../../../models/contest');
var userService = require('../services/userService');
var lineupTemplateService = require('../services/lineUpTemplateService');
var prizeTemplateService = require('../services/prizeTemplateService');
var TransactionModel = require('../../../models/transaction');
var moment = require('moment-timezone');
var Pusher = require('../helpers/pusherHelper');

var fbHelper = require('../helpers/fbHelper');

var LockItemModel = require('../../../models/lockItem');

module.exports = {
	/**
	 * Get all contests
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 * @throws {object} e - Error
	 */
	getAll: async function (req, res) {
		try {
			//if (contestValidation.getAllValidation(req, res) != false) {
			var search = contestDataMapper.searchDataCustom(req.query);
			var contestModel = new ContestModel();
			var contestMapData = contestDataMapper.contestDataMap(contestModel, req);

			var d = new Date();
			d.setDate(d.getDate() - 14);
			//var zone = process.env.dest_zone;
			//var date = moment.utc(d).tz(zone).format('YYYY-MM-DD');
			var date = moment.utc(d).format('YYYY-MM-DD');
			var contestsDB = await contestService.getAll(search, contestMapData, date);
			var getMyContests = await contestService.getUserAllH2HContest(contestMapData);
			for (var l = 0; l < contestsDB.length; l++) {
				userDetails = await userService.getProfile(contestsDB[l].createdBy);
				if (userDetails != null) {
					contestsDB[l].userName = userDetails.userName ? userDetails.userName : '';
					contestsDB[l].fName = userDetails.fName ? userDetails.fName : '';
					contestsDB[l].lName = userDetails.lName ? userDetails.lName : '';
					if (userDetails.currentLoginType == 'Normal') {
						contestsDB[l].imageName = userDetails.imageName ? process.env.PROFILE_IMAGE_URL + userDetails.imageName : '';
					} else if (userDetails.currentLoginType == 'FB') {
						contestsDB[l].imageName = process.env.FB_IMAGE_URL.replace(new RegExp('{fbId}', "g"), userDetails.loginTypes.FB.fbId);
					}
				}
				if (contestsDB[l].contestTypeId == 2 && contestsDB[l].visibility == 'Public') {

					var opponentId = 0;
					if (contestsDB[l].entrants.length > 1) {
						if (contestsDB[l].entrants[1] != null) {
							if (contestsDB[l].entrants[1].userId != global.userId) {
								opponentId = contestsDB[l].entrants[1].userId;
							} else {
								opponentId = contestsDB[l].entrants[0].userId;
							}
						}
					}

					//for (var i = 0; i < contestsDB.length; i++) {
					var count = 0;
					for (var j = 0; j < getMyContests.length; j++) {
						for (var k = 0; k < getMyContests[j].entrants.length; k++) {
							if (getMyContests[j].entrants[k].userId == opponentId)
								count++;
						}
					}
					contestsDB[l].rival = (count > 6) ? 1 : 0;
					//}
				}
			}
			if (contestsDB == null) {
				generalHelper.handleError(req, res, 'Record not found', _t.failedGetAllContest);
			} else {
				//var totalCount = await contestService.getAllCount(search, contestMapData);
				var result = contestDataMapper.getAllData(contestsDB);
				//var additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, contestsDB.length);
				//generalHelper.handleSuccess(req, res, _t.contestRetrieved, result, additionalData);
				generalHelper.handleSuccess(req, res, _t.contestRetrieved, result, {});
			}
			//}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get one contest's games by id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getOne: async function (req, res) {
		try {
			if (contestValidation.getValidation(req, res) != false) {
				contestGamesMapData = contestDataMapper.contestData(req.params.id);
				var search = contestDataMapper.searchData(req.query);
				var contestDB = await contestService.getOne(contestGamesMapData);
				var contestGames = [];
				if (contestDB)
					contestGames = await draftGroupService.getDraftgroupGames(contestDB.draftgroupId);
				if (contestGames.length < 1 || contestDB == null) {
					generalHelper.handleError(req, res, 'Record not found', _t.failedGetContestGames);
				} else {
					var result = contestDataMapper.getOneData(contestGames, contestDB);
					//pagination after mapping
					var totalCount = result.games.length;
					gamesPaginated = generalHelper.paginateArray(result.games, +search.limit, +search.page);
					result.games = gamesPaginated;
					var additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, result.games.length);
					generalHelper.handleSuccess(req, res, _t.contestGamesRetrieved, result, additionalData);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},


	/**
	 * Add a contest
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	add: async function (req, res) {
		try {
			//getting prize template 
			var templateDet = req.body.prizetypeId ? (await prizeTemplateService.getPrizeTemplateDetail(req.body.prizetypeId)) : '';
			req.body.gameTypeIdDB = (req.body.sportId && (6 > req.body.sportId > 0)) ? ((await lineupTemplateService.getGameType(req.body))[0].gameTypes) : [];
			if (contestValidation.addValidation(req, res, templateDet) != false) {
				var ContestModel = require('../../../models/contest');
				var contestModel = {};
				var contestCreated = [];
				var referralM = 0;
				var referralMoneyBalance = 0;
				var numToCreate = (req.body.contestTypeId == 2) ? (req.body.numToCreate > 0 ? req.body.numToCreate : 1) : 1;
				if (req.body.contestTypeId == 2) {
					contestModel.contestGroupId = await generalHelper.updateCounter('contestGroupId'); //unique key
				}
				//contest name start
				var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
				contestNameDetails = await draftGroupService.getDraftGroupDetails(req.body.draftgroupId);
				if (contestNameDetails.dgState == "Upcoming") {
					var zone = process.env.dest_zone;
					var s = moment.utc(contestNameDetails.startTimeUTC).tz(zone).format('YYYY-MM-DD HH:mm:ss');
					var localDate = new Date(s).toLocaleDateString();
					var localHour = (new Date(s).getHours());
					var utcHour = (contestNameDetails.startTimeUTC).getHours();
					var localMinute = (new Date(s).getMinutes()) ? (':' + new Date(s).getMinutes()) : '';
					var hours = (utcHour + 24 - 2) % 24;
					var AM_or_PM = ' AM ';
					localHour = (localHour == 12) ? localHour : localHour % 12;
					if (hours == 0) { //At 00 hours we need to show 12 am
						hours = 12;
					} else if (hours > 12) {
						hours = hours % 12;
						AM_or_PM = " PM ";
					}
					var day = days[new Date(localDate).getDay()];
					userDetails = await userService.getProfile(global.userId);
					referralMoneyBalance = userDetails.referralMoney ? userDetails.referralMoney : 0;
					var feeContest = req.body.entryFee * req.body.numToCreate;
					if (userDetails.balance < feeContest) {
						return generalHelper.handleError(req, res, "Insufficient balance", _t.balanceInsufficient);
					} else {

						await module.exports.contestSettingsValidation(userDetails, feeContest, req.body.entryFee, req, res);

						contestModel.contestName = (req.body.contestTypeId == 2) ? (contestNameDetails.league[0].abbr + ' ' + day + ' ' + 'vs.' + userDetails.userName) : (contestNameDetails.league[0].abbr + ' ' + day + ' ' + req.body.participantSize + ' man Tournament.');
						//contest name end
						req.body.startTimeUTC = contestNameDetails.startTimeUTC;
						req.body.entrantsEntry = 0;
						contestModel = contestDataMapper.addData(contestModel, req.body, templateDet, userDetails);
						for (var i = 0; i < numToCreate; i++) {
							contestModel.contestId = await generalHelper.updateCounter('contestId'); //unique key
							if (contestModel.contestId != null) {
								var response = await contestService.add(contestModel);
								//adding contest to draftgroup
								var contestToDraft = await draftGroupService.addContest(req.body.draftgroupId, contestModel.contestId);
								//update Referral Money								
								if (referralMoneyBalance != 0) {
									if (referralMoneyBalance >= contestModel.entryFees) {
										referralM = contestModel.entryFees;
										referralMoneyBalance = referralMoneyBalance - contestModel.entryFees;
									} else {
										referralM = referralMoneyBalance;
										referralMoneyBalance = 0;
									}
									var updateReferralBalance = await userService.updateReferralMoney(referralM);
									var referralMoneyToEntrant = await contestService.addreferralMoneyToEntrants(contestModel.contestId, referralM);

								}

								//var lineupId = await generalHelper.updateCounter('lineupId'); //unique key									
								//lineUpModel = contestDataMapper.linupDataResevered(contestModel.contestId, global.userId, referralM, lineupId);
								//console.log(lineUpModel); //process.exit();
								//var responseReserved = await lineUpService.addreservedLineup(lineUpModel);

								//update user balance
								var updateBalance = await userService.updateBalance(req.body.entryFee);

								var transactionModel = new TransactionModel();
								transactionModel = contestDataMapper.transactionData(transactionModel, userDetails, req.body.entryFee, 'JC');
								var transactionResult = await userService.transactionEntry(transactionModel);
								var TransactionIdToEntrant = await contestService.addTransactionIdToEntrants(contestModel.contestId, transactionResult._id);
								//for response - created contest
								contestCreated.push((await contestService.getContestCreated(contestModel.contestId))[0]);
							} else {
								generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddContest);
							}
						}
						if (response.upserted[0]._id != null) {
							//for response - created contest
							contest = contestDataMapper.getUserCreatedContest(contestCreated);
							if (userDetails != null) {
								contest.username = userDetails.userName ? userDetails.userName : '';
								if (userDetails.currentLoginType == 'FB' && userDetails.loginTypes.FB.fbId) {
									contest.imageName = fbHelper.getFbPicture(userDetails.loginTypes.FB.fbId);
								} else {
									contest.imageName = userDetails.imageName ? process.env.PROFILE_IMAGE_URL + userDetails.imageName : '';
								}
							}
							//pushing newly created contest
							Pusher.sendPush('draftgroup-channel', 'draftgroup-' + req.body.draftgroupId, contest);
							generalHelper.handleSuccess(req, res, _t.contestAdded, contest);
						} else {
							generalHelper.handleError(req, res, 'Add record failed', _t.failedAddContest);
						}
					}
				} else {
					generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddContestLive);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},


	/**
	 * Update a contest
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	update: async function (req, res) {
		try {
			//getting prize template 
			var templateDet = req.body.prizetypeId ? (await prizeTemplateService.getPrizeTemplateDetail(req.body.prizetypeId)) : '';
			req.body.gameTypeIdDB = (req.body.sportId && (6 > req.body.sportId > 0)) ? ((await lineupTemplateService.getGameType(req.body))[0].gameTypes) : [];
			if (contestValidation.addValidation(req, res, templateDet) != false) {
				var contestDet = await contestService.getMyContestDetail(req.params.id);
				var myEntryN = (contestDet.entrants).find(function (obj) {
					return obj.userId === global.userId;
				});

				if (contestDet.contestStatus == 3) {
					contestNameDetails = await draftGroupService.getDraftGroupDetails(req.body.draftgroupId);
					var referralMoneyBalance = 0;
					var contestCreated = [];
					var oldFee = contestDet.entryFees;
					if (contestDet == null || contestNameDetails == null) {
						generalHelper.handleError(req, res, 'Record not found', _t.failedGetContest);
					} else {
						var userDetails = await userService.getProfile(global.userId);
						referralMoneyBalance = userDetails.referralMoney ? userDetails.referralMoney : 0;
						var totalBal = oldFee + userDetails.balance;
						if (totalBal < req.body.entryFee) {
							return generalHelper.handleError(req, res, "Insufficient balance", _t.balanceInsufficient);
						} else {
							//contest Details to check upcoming and entrants 
							if (contestDet.contestStatus != 3 || contestDet.entrants.length > 1) {
								generalHelper.handleError(req, res, 'contest not upcoming or user joined contest', _t.contestNotUpdate);
							} else {

								dailyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "daily");
								weeklyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "weekly");
								monthlyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "monthly");

								if ((dailyTransactionAmount[0].amount - oldFee) + req.body.entryFee >= userDB.spendLimits.daily) {
									return generalHelper.handleError(req, res, "daily Limit", _t.dailyLimitExceeded);
								}
								if ((weeklyTransactionAmount[0].amount - oldFee) + req.body.entryFee >= userDB.spendLimits.weekly) {
									return generalHelper.handleError(req, res, "weekly Limit", _t.weeklyLimitExceeded);
								}
								if ((monthlyTransactionAmount[0].amount - oldFee) + req.body.entryFee >= userDB.spendLimits.monthly) {
									return generalHelper.handleError(req, res, "monthly Limit", _t.monthlyLimitExceeded);
								}
								if (req.body.entryFee > userDB.spendLimits.maxEntryFee) {
									return generalHelper.handleError(req, res, "max entry Fee", _t.maxEntryFeeExceeded);
								}

								var contestModel = {};
								//contest name start
								var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
								var zone = process.env.dest_zone;
								var s = moment.utc(contestNameDetails.startTimeUTC).tz(zone).format('YYYY-MM-DD HH:mm:ss');
								var localDate = new Date(s).toLocaleDateString();
								var localHour = new Date(s).getHours();
								var utcHour = (contestNameDetails.startTimeUTC).getHours();
								var localMinute = (new Date(s).getMinutes()) ? (':' + new Date(s).getMinutes()) : '';
								var hours = (utcHour + 24 - 2) % 24;
								var AM_or_PM = ' AM ';
								if (hours == 0) { //At 00 hours we need to show 12 am
									hours = 12;
								} else if (hours > 12) {
									hours = hours % 12;
									AM_or_PM = " PM ";
								}
								var day = days[new Date(localDate).getDay()];
								req.body.startTimeUTC = contestNameDetails.startTimeUTC;
								req.body.entrantsEntry = 0;
								contest = contestDataMapper.addData(contestModel, req.body, templateDet, userDetails);

								var response = await contestService.update(req.params.id, contest, req.body.draftgroupId);
								if (response.n == 1) {
									//update user balance
									var updateBalance = await userService.updateBalance(req.body.entryFee);
									if (myEntryN.transactionId) {
										var transactionData = contestDataMapper.updateTransactionamount(req.body.entryFee)
										var updateTransaction = await userService.updateTransactionStatus(global.userId, myEntryN.transactionId, transactionData);
									}
									//adding old fees
									var addBalance = await userService.addBalance(oldFee);
									//update Referral Money	
									if (myEntryN.referralMoney) {
										var totalReferralMoneyBalance = referralMoneyBalance + myEntryN.referralMoney;
										var addBalance = await userService.addReferralMoney(myEntryN.referralMoney);
									} else {
										var totalReferralMoneyBalance = referralMoneyBalance;
									}
									if (totalReferralMoneyBalance != 0) {
										if (totalReferralMoneyBalance >= contestModel.entryFees) {
											referralM = contestModel.entryFees;
										} else {
											referralM = totalReferralMoneyBalance;
										}
										var updateReferralBalance = await userService.updateReferralMoney(referralM);
										var referralMoneyToEntrant = await contestService.addreferralMoneyToEntrants(contestDet.contestId, referralM);


									}
									//for response - updated contest
									contestCreated.push((await contestService.getContestCreated(req.params.id))[0]);
									contest = contestDataMapper.getUserCreatedContest(contestCreated);
									//console.log(contestCreated);
									generalHelper.handleSuccess(req, res, _t.contestUpdated, contest);
								} else {
									generalHelper.handleError(req, res, 'Update record not found', _t.failedUpdateContest);
								}
							}
						}
					}

				} else {
					if (contestDet.contestStatus == 2) {
						var lang = _t.contestLiveUpdate;
					}
					if (contestDet.contestStatus == 1) {
						var lang = _t.contesCompletedUpdate;
					}
					if (contestDet.contestStatus == 4) {
						var lang = _t.contestCancelledUpdate;
					}
					generalHelper.handleError(req, res, 'Id generation failed', lang);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Delete a contest
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	delete: async function (req, res) {
		try {
			var contestDet = await contestService.getMyContestDetail(req.params.id);
			if (contestDet == null) {
				generalHelper.handleError(req, res, 'Record not found', _t.failedGetContest);
			} else {
				var totalEntry = (contestDet.entrants).reduce(function (a, b) {
					return a + b.totalentry;
				}, 0);
				var myEntryN = (contestDet.entrants).find(function (obj) {
					return obj.userId === global.userId;
				});
				var myEntryCount = myEntryN ? myEntryN.totalentry : 0;
				var totalEntry = (contestDet.entrants).reduce(function (a, b) {
					return a + b.totalentry;
				}, 0);
				//contest Details to check upcoming and entrants 
				if (contestDet.contestStatus != 3 || ((totalEntry - myEntryCount) != 0)) {
					generalHelper.handleError(req, res, 'contest not upcoming or user joined contest', _t.contestNotDelete);
				} else {
					//adding balance back
					if (myEntryN)
						var updateBalance = await userService.addBalance(contestDet.entryFees);
					//deleting creator lineup if any
					var response = await lineUpService.delete(req.params.id);
					//deleting contest
					var response = await contestService.delete(req.params.id);
					if (response.result.n == 1) {
						generalHelper.handleSuccess(req, res, _t.contestDeleted, {});
					} else {
						generalHelper.handleError(req, res, 'Delete record not found', _t.failedDeleteContest);
					}
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get standings in a contest
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 * @throws {object} e - Error
	 */
	getContestStandings: async function (req, res) {
		try {
			if (contestValidation.getValidation(req, res) != false) {
				contestMapData = contestDataMapper.contestData(req.params.id);
				var search = contestDataMapper.searchData(req.query);
				var contestsDB = await lineUpService.getUserContestStandings(contestMapData, search);
				if (contestsDB == null) {
					generalHelper.handleError(req, res, 'Record not found', _t.failedGetContestStandings);
				} else {
					var totalCount = await lineUpService.getAllCountContUser(contestMapData);
					var userIds = [];
					for (var i in contestsDB) {
						userIds.push(contestsDB[i].userId);
					}
					var usersDb = await userService.getUsersByIds(userIds)
					var result = contestDataMapper.getStandingData(contestsDB, contestMapData, usersDb);
					var additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, contestsDB.length);
					generalHelper.handleSuccess(req, res, _t.contestStandingsRetrieved, result, additionalData);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Join to a contest
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	joinContest: async function (req, res) {
		try {
			//var lockItem = new LockItemModel();
			var newlock = new LockItemModel({
				itemId: 1,
				clientId: "SessionToken",
				itemDateTime: new Date()
			});
			newlock.save(async function (err) {
				if (err) {
					/*if (global.seconds != 0) {
						//global.seconds = Math.floor(new Date().getTime() / 1000);
					}*/
					//console.log(err);
                    console.log('Pod Inside');
					var lockItemVar = 1;
					/*var start = new Date().getTime();
					while ((new Date().getTime() - start) < 150) {
						//loop here
					}*/
					while (lockItemVar != 0) {
                        console.log('insideee');
						var checkLock = await LockItemModel.findOne({ itemId: 1 });
						if (!checkLock)
							lockItemVar = 0;
					}
					await JoinContest(req, res);

				}
				else {
					//global.seconds = 0;
					console.log('Lock acquired successfully!');
					await JoinContest(req, res);
				}
			})

			async function JoinContest(req, res) {

				var appUserId = global.userId;
				if (contestValidation.joinContestValidation(req, res) != false) {
					global.joinContestLocked = 1;
					var LineUpModel = require('../../../models/lineup');
					var lineUpModel = new LineUpModel();
					lineUpModel.lineupId = await generalHelper.updateCounter('lineupId'); //unique key
					userDB = await userService.getProfile(appUserId);
					lineUpModel.userName = userDB.userName;
					lineUpModel.imageName = userDB.imageName;
					var contestCreated = [];
					var gcontestId = 0;
					var referralM = 0;
					var isTicket = 0;
					var usedTicketId = "N";
					var checkContest = await contestService.getOne(req.body.contestId);
					if (checkContest.contestStatus == 3) {
						/*	contestModel = contestDataMapper.addDataAutoContest(checkContest);
				
							contestModel.contestId = await generalHelper.updateCounter('contestId'); //unique key
				
							console.log(contestModel); process.exit();*/

						//console.log(dailyTransactionAmount) ; console.log("****") ;  console.log(weeklyTransactionAmount) ; console.log("****") ; console.log(monthlyTransactionAmount) ;process.exit();

						if (req.body.ticketId && req.body.ticketId != '') {
							var ticketService = require('../services/ticketService');
							ticketModel = contestDataMapper.joinContestTicket(req.body.ticketId, checkContest.entryFees, appUserId);
							var checkTicket = await ticketService.validateJoinContestTicket(ticketModel);
							if (!checkTicket) {
								return generalHelper.handleError(req, res, "Ticket Invalid", _t.invalidTicket);
							} else {
								isTicket = 1;
							}
						}

						if (checkContest.contestTypeId == 2 && checkContest.entrants.length > 1 && !checkContest.autoId) {
							var groupContest = await contestService.getGroupContests(checkContest.contestGroupId);
							for (var g in groupContest) {
								var myentryCheck = groupContest[g].entrants.find(function (obj) {
									return obj.userId === appUserId;
								});
								if (groupContest[g].entrants.length < 2 && !myentryCheck) {
									gcontestId = groupContest[g].contestId;
									break;
								}
							}
						}

						//auto contest swap joining start
						var totalEntry = (checkContest.entrants).reduce(function (a, b) {
							return a + b.totalentry;
						}, 0);
						if (checkContest.autoId && totalEntry >= checkContest.maxLimit) {
							var autoContestSimilar = await contestService.getAutoContestSimilar(checkContest);
							var myentryCheckAuto = autoContestSimilar.entrants.find(function (obj) {
								return obj.userId === appUserId;
							});
							if (!myentryCheckAuto) {
								gcontestId = autoContestSimilar.contestId;
							}
						}
						////auto contest swap joining end


						if (gcontestId == 0) {
							contestIdd = req.body.contestId;
						} else {
							contestIdd = gcontestId;
						}
						req.body.contestId = contestIdd;
						//console.log(contestIdd); process.exit();
						//contest details for entryFee
						var contestDetails = await contestService.getOne(contestIdd);
						//getting all entrants
						var entrants = contestDetails.entrants;
						//user's entry
						var myentry = entrants.find(function (obj) {
							return obj.userId === appUserId;
						});
						var totalEntry = entrants.reduce(function (a, b) {
							return a + b.totalentry;
						}, 0);
						//creator entry (for reservation)
						var creatorEntry = entrants.find(function (obj) {
							return obj.userId === contestDetails.createdBy;
						});
						if (creatorEntry && !contestDetails.autoId)
							(creatorEntry.totalentry == 0 && appUserId != contestDetails.createdBy) ? (totalEntry = totalEntry + 1) : '';
						//entry limit if h2h
						if (contestDetails.contestTypeId == 2 && !contestDetails.autoId) {
							(appUserId == contestDetails.createdBy && (myentry ? myentry.totalentry != 0 : '')) ? totalEntry = totalEntry + 1 : '';
						}
						var myEntryVal = myentry ? myentry.totalentry : 0;
						if (totalEntry < contestDetails.maxLimit && myEntryVal < contestDetails.maxEntriesPerUser) {
							if (userDB.balance < contestDetails.entryFees && (myentry ? myentry.totalentry != 0 : '1=1') && isTicket == 0) {
								return generalHelper.handleError(req, res, "Insufficient balance", _t.balanceInsufficient);
							} else {
								if ((myentry && myentry.totalentry) != 0 || !myentry) {
									if (isTicket == 0) {
										/*dailyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "daily");
										weeklyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "weekly");
										monthlyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "monthly");
										//console.log(userDB.spendLimits.daily);  console.log("dailyTransactionAmount"); console.log( dailyTransactionAmount[0].amount);				
										if (dailyTransactionAmount[0].amount >= userDB.spendLimits.daily) {
											return generalHelper.handleError(req, res, "daily Limit", _t.dailyLimitExceeded);
										}
										if (weeklyTransactionAmount[0].amount >= userDB.spendLimits.weekly) {
											return generalHelper.handleError(req, res, "weekly Limit", _t.weeklyLimitExceeded);
										}
										if (monthlyTransactionAmount[0].amount >= userDB.spendLimits.monthly) {
											return generalHelper.handleError(req, res, "monthly Limit", _t.monthlyLimitExceeded);
										}
										if (checkContest.entryFees > userDB.spendLimits.maxEntryFee) {
											return generalHelper.handleError(req, res, "max entry Fee", _t.maxEntryFeeExceeded);
										}*/

										await module.exports.contestSettingsValidation(userDB, contestDetails.entryFees, contestDetails.entryFees, req, res);
									}
								}
								//additional details added on 19-march-18 start
								var draftDetails = await draftGroupService.getDraftGroupDetails(req.body.draftgroupId);
								req.body.dgName = draftDetails.dgName;
								req.body.startTimeUTC = draftDetails.startTimeUTC;
								req.body.gameTypeId = contestDetails.gameTypeId;
								//additional details added on 19-march-18 end
								if (lineUpModel.lineupId != null) {
									playerArrayDB = [];
									for (var i in req.body.players) {
										var playerDB = await draftGroupService.getPlayerDataFromDraftgroup(req.body, i);
										if (playerDB.length > 0) {
											playerArrayDB.push(playerDB[0]);
										}
									}
									if (playerArrayDB.length == req.body.players.length) {
										//draftgroups player minSalary w.r.t position
										if ((req.body.sportId == 4 || req.body.sportId == 3 || req.body.sportId == 2)) {
											var minSalary = await draftGroupService.getMinSalaryNBAMLBNHLDraftgroup(req.body.draftgroupId);
										} else {
											var minSalary = await draftGroupService.getMinSalaryNFLGOLFDraftgroup(req.body.draftgroupId);
										}

										if ((myentry && myentry.totalentry) != 0 || !myentry) {
											if (isTicket == 0) {
												if (userDB.referralMoney != 0) {
													if (userDB.referralMoney >= contestDetails.entryFees) {
														referralM = contestDetails.entryFees;
													} else {
														referralM = userDB.referralMoney;
													}
												}
											} else {
												usedTicketId = req.body.ticketId;
											}
										}

										lineUpModel = contestDataMapper.playerLinupData(lineUpModel, playerArrayDB, req.body, minSalary, referralM, usedTicketId, appUserId);
										var response = await lineUpService.addLineup(lineUpModel);
										if (response._id != null) {
											//update user balance
											//if (myentry ? myentry.totalentry != 0 : '1=1')
											if ((myentry && myentry.totalentry) != 0 || !myentry) {
												if (isTicket == 0) {
													if (userDB.referralMoney != 0) {
														var updateReferralBalance = await userService.updateReferralMoney(referralM, appUserId);
													}
													var updateBalance = await userService.updateBalance(contestDetails.entryFees, appUserId);
													var transactionModel = new TransactionModel();
													transactionModel = contestDataMapper.transactionData(transactionModel, userDB, contestDetails.entryFees, 'JC');
													var transactionResult = await userService.transactionEntry(transactionModel);
													var lineupData = contestDataMapper.updateLineupData(transactionResult._id);
													var updateLineup = await lineUpService.updateLineupData(lineUpModel.lineupId, lineupData);
													//console.log("***********");	console.log(transactionResult);
												} else {
													var updateTicketData = contestDataMapper.updateTicketData(req.body.ticketId, appUserId);
													var updateTicket = await ticketService.updateUserTicket(updateTicketData);
												}
											} else {
												if (myentry.transactionId) {
													var lineupData = contestDataMapper.updateLineupData(myentry.transactionId);
													var updateLineup = await lineUpService.updateLineupData(lineUpModel.lineupId, lineupData);
												}
											}
											//add entrants to contest
											var contestEntrants = await contestService.addEntrantsToContest(lineUpModel.contestId, appUserId);

											//contest details for entryFee
											var contestUpdated = [];
											var contestDetailsUpdated = await contestService.getOne(lineUpModel.contestId);
											contestUpdated.push(contestDetailsUpdated);
											contestUpdatedPush = contestDataMapper.getUserCreatedContest(contestUpdated, appUserId);
											//pushing updated contest
											Pusher.sendPush('draftgroup-channel', 'draftgroup-' + contestDetails.draftgroupId, contestUpdatedPush);

											var totalEntryAuto = totalEntry + 1;
											if (contestDetails.autoId && totalEntryAuto >= contestDetails.maxLimit) {
												contestModel = contestDataMapper.addDataAutoContest(contestDetails);
												contestModel.contestId = await generalHelper.updateCounter('contestId'); //unique key
												contestModel.autoId = await generalHelper.updateCounter('autoId');
												var responseAdd = await contestService.add(contestModel);
												//adding contest to draftgroup
												var contestToDraft = await draftGroupService.addContest(contestDetails.draftgroupId, contestModel.contestId);
												//console.log(contestModel); process.exit();
												contestCreated.push(contestModel);
												contest = contestDataMapper.getUserCreatedContest(contestCreated, appUserId);
												//pushing newly created contest
												Pusher.sendPush('draftgroup-channel', 'draftgroup-' + contestModel.draftgroupId, contest);
												//Pusher.sendPush('draftgroup-channel', 'draftgroup-21770', contestModel);
											}
											generalHelper.handleSuccess(req, res, _t.lineUpAdded, {
												'id': response._id,
												'lineupId': response.lineupId,
												'contestId': lineUpModel.contestId
											});
										} else {
											generalHelper.handleError(req, res, 'Add record failed', _t.failedAddLineUp);
										}
									} else {
										generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddLineUp);
									}
								} else {
									generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddLineUp);
								}
							}
						} else {

							//if reach maximm entry limit.
							var draftDetails = await draftGroupService.getDraftGroupDetails(req.body.draftgroupId);
							req.body.dgName = draftDetails.dgName;
							req.body.startTimeUTC = draftDetails.startTimeUTC;
							req.body.gameTypeId = contestDetails.gameTypeId;
							req.body.contestId = 0;
							//additional details added on 19-march-18 end
							if (lineUpModel.lineupId != null) {
								playerArrayDB = [];
								for (var i in req.body.players) {
									var playerDB = await draftGroupService.getPlayerDataFromDraftgroup(req.body, i);
									if (playerDB.length > 0) {
										playerArrayDB.push(playerDB[0]);
									}
								}
								if (playerArrayDB.length == req.body.players.length) {
									//draftgroups player minSalary w.r.t position
									if ((req.body.sportId == 4 || req.body.sportId == 3 || req.body.sportId == 2)) {
										var minSalary = await draftGroupService.getMinSalaryNBAMLBNHLDraftgroup(req.body.draftgroupId);
									} else {
										var minSalary = await draftGroupService.getMinSalaryNFLGOLFDraftgroup(req.body.draftgroupId);
									}
									lineUpModel = contestDataMapper.playerLinupData(lineUpModel, playerArrayDB, req.body, minSalary);
									var response = await lineUpService.addLineup(lineUpModel);
									if (response._id != null) { } else {
										generalHelper.handleError(req, res, 'Add record failed', _t.failedAddLineUp);
									}
								} else {
									generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddLineUp);
								}
							} else {
								generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddLineUp);
							}
							generalHelper.handleError(req, res, 'Entry Limit Reached', _t.lineupEntryLimitLineupAdded);
						}
					} else {

						if (checkContest.contestStatus == 2) {
							var lang = _t.contestLive;
						}
						if (checkContest.contestStatus == 1) {
							var lang = _t.contesCompleted;
						}
						if (checkContest.contestStatus == 4) {
							var lang = _t.contestCancelled;
						}
						generalHelper.handleError(req, res, 'Id generation failed', lang);

					}

				}
				newlock.remove({ ItemId: 1 }, function (err) { })
			}




		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get lineups list by contest id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getLineUp: async function (req, res) {
		try {
			if (contestValidation.getValidation(req, res) != false) {
				contestMapData = contestDataMapper.contestData(req.params.id);
				var contestLineUpsDB = await lineUpService.getContestLineups(contestMapData);
				if (contestLineUpsDB != null) {
					result = contestDataMapper.contestLineUpsResultMap(contestLineUpsDB);
					generalHelper.handleSuccess(req, res, _t.contestLineupsRetrieved, result, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.contestLineupsEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get contests by user id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getMyContests: async function (req, res) {
		try {
			var d = new Date();
			d.setDate(d.getDate() - 14);
			//var zone = process.env.dest_zone;
			//var date = moment.utc(d).tz(zone).format('YYYY-MM-DD');
			var date = moment.utc(d).format('YYYY-MM-DD');

			if (contestValidation.getMyContestValidation(req, res) != false) {
				var search = contestDataMapper.searchDataCustom(req.query);
				var userContestDB = await contestService.getUserContest(search, req.query);

				if (userContestDB != null) {
					for (var l = 0; l < userContestDB.length; l++) {
						userDetails = await userService.getProfile(userContestDB[l].createdBy);
						if (userDetails != null) {
							userContestDB[l].userName = userDetails.userName ? userDetails.userName : '';
							userContestDB[l].fName = userDetails.fName ? userDetails.fName : '';
							userContestDB[l].lName = userDetails.lName ? userDetails.lName : '';
							if (userDetails.currentLoginType == 'Normal') {
								userContestDB[l].imageName = userDetails.imageName ? process.env.PROFILE_IMAGE_URL + userDetails.imageName : '';
							} else if (userDetails.currentLoginType == 'FB') {
								userContestDB[l].imageName = process.env.FB_IMAGE_URL.replace(new RegExp('{fbId}', "g"), userDetails.loginTypes.FB.fbId);
							}
						}
					}
					var myLineUpsDB = await lineUpService.getAllLineups(date);
					//var totalCount = await contestService.getUserContestAll(req.query);
					var result = contestDataMapper.getUserContestsData(userContestDB, myLineUpsDB);
					//var additionalData = {};
					//additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, userContestDB.length);
					generalHelper.handleSuccess(req, res, _t.userContestsRetrieved, result, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.userContestsEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Update Contest's Lineup By lineup id
	 * @param {string} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	updateLineUp: async function (req, res) {
		try {
			if (contestValidation.updateContestLineupValidation(req, res) != false) {
				var checkContest = await contestService.getOne(req.body.contestId);
				if (checkContest.contestStatus == 3) {
					var LineUpModel = require('../../../models/lineup');
					playerArrayDB = [];
					for (var i in req.body.players) {
						var playerDB = await draftGroupService.getPlayerDataFromDraftgroup(req.body, i);
						if (playerDB.length > 0) {
							playerArrayDB.push(playerDB[0]);
						}
					}
					if (playerArrayDB.length == req.body.players.length) {
						//draftgroups player minSalary w.r.t position
						if ((req.body.sportId == 4 || req.body.sportId == 3 || req.body.sportId == 2)) {
							var minSalary = await draftGroupService.getMinSalaryNBAMLBNHLDraftgroup(req.body.draftgroupId);
						} else {
							var minSalary = await draftGroupService.getMinSalaryNFLGOLFDraftgroup(req.body.draftgroupId);
						}
						lineUpMapData = contestDataMapper.updatePlayerLinupData({}, playerArrayDB, req.body, minSalary);
						var response = await lineUpService.updateLineup(LineUpModel, lineUpMapData, req.params.id);
						if (response._id != null) {
							generalHelper.handleSuccess(req, res, _t.lineUpUpdate, {
								'id': response._id,
								'lineupId': response.lineupId
							});
						} else {
							generalHelper.handleError(req, res, 'Add record failed', _t.failedUpdateLineUp);
						}
					} else {
						generalHelper.handleError(req, res, 'Id generation failed', _t.failedUpdateLineUp);
					}

				} else {

					if (checkContest.contestStatus == 2) {
						var lang = _t.contestLiveUpdate;
					}
					if (checkContest.contestStatus == 1) {
						var lang = _t.contesCompletedUpdate;
					}
					if (checkContest.contestStatus == 4) {
						var lang = _t.contestCancelledUpdate;
					}
					generalHelper.handleError(req, res, 'Id generation failed', lang);

				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get Lineup Details By lineup id
	 * @param {string} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	getLineUpById: async function (req, res) {
		try {
			if (contestValidation.getLineUpValidation(req, res) != false) {
				LineUpMapData = contestDataMapper.LineUpData(req.params.id);
				var lineUpDB = await lineUpService.getLineup(LineUpMapData);
				if (lineUpDB.length > 0) {
					result = contestDataMapper.lineUpResultMap(lineUpDB);
					generalHelper.handleSuccess(req, res, _t.lineUpRetrieved, result, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.lineUpEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get all featured contests
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 * @throws {object} e - Error
	 */
	getFeatured: async function (req, res) {
		try {
			var search = contestDataMapper.searchData(req.query);
			var contestModel = new ContestModel();
			var contestMapData = contestDataMapper.contestFeaturedDataMap(contestModel, req);
			var contestsDB = await contestService.getAllFeatured(search, contestMapData);
			if (contestsDB == null) {
				generalHelper.handleError(req, res, 'Record not found', _t.failedGetAllContest);
			} else {
				var totalCount = await contestService.getAllFeaturedCount(search, contestMapData);
				var result = contestDataMapper.getAllData(contestsDB);
				var additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, contestsDB.length);
				generalHelper.handleSuccess(req, res, _t.contestRetrieved, result, additionalData);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get sport Lineup Template
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 * @throws {object} e - Error
	 */
	getLineUpTemplate: async function (req, res) {
		try {
			//if (contestValidation.getTemplateValidation(req, res) != false) {
			var lineUpTemplateDB = await lineupTemplateService.getLineUpTemplate(req.query);
			if (lineUpTemplateDB.length > 0) {
				result = contestDataMapper.lineUpTemplateResultMap(lineUpTemplateDB);
				generalHelper.handleSuccess(req, res, _t.lineUpTemplateRetrieved, result, {});
			} else {
				generalHelper.handleError(req, res, {}, _t.lineUpTemplateEmpty);
			}
			//}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get all contests by user id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getAllMyContests: async function (req, res) {
		try {

			var d = new Date();
			d.setDate(d.getDate() - 14);
			//var zone = process.env.dest_zone;
			//var date = moment.utc(d).tz(zone).format('YYYY-MM-DD');
			var date = moment.utc(d).format('YYYY-MM-DD');

			var search = contestDataMapper.searchDataCustom(req.query);
			var contestModel = new ContestModel();
			var contestMapData = contestDataMapper.myContestDataMap(req);
			var userContestDB = await contestService.getAllUserContest(search, contestMapData, date);
			var getMyContests = await contestService.getUserAllMyH2HContest();

			if (userContestDB != null) {
				for (var l = 0; l < userContestDB.length; l++) {
					userDetails = await userService.getProfile(userContestDB[l].createdBy);
					if (userDetails != null) {
						userContestDB[l].userName = userDetails.userName ? userDetails.userName : '';
						userContestDB[l].fName = userDetails.fName ? userDetails.fName : '';
						userContestDB[l].lName = userDetails.lName ? userDetails.lName : '';

						/*if (userDetails.currentLoginType == 'Normal') {
							userContestDB[l].imageName = userDetails.imageName ? process.env.PROFILE_IMAGE_URL + userDetails.imageName : '';
						} else if (userDetails.currentLoginType == 'FB') {
							userContestDB[l].imageName = process.env.FB_IMAGE_URL.replace(new RegExp('{fbId}', "g"), userDetails.loginTypes.FB.fbId);
						}*/

						if (userDetails.currentLoginType == 'FB' && userDetails.loginTypes.FB.fbId) {
							userContestDB[l].imageName = fbHelper.getFbPicture(userDetails.loginTypes.FB.fbId);
						} else {
							userContestDB[l].imageName = userDetails.imageName ? process.env.PROFILE_IMAGE_URL + userDetails.imageName : '';
						}
					}

					if (userContestDB[l].contestTypeId == 2) {
						var opponentId = 0;
						if (userContestDB[l].entrants.length > 1) {
							if (userContestDB[l].entrants[1] != null) {
								if (userContestDB[l].entrants[1].userId != global.userId) {
									opponentId = userContestDB[l].entrants[1].userId;
								} else {
									opponentId = userContestDB[l].entrants[0].userId;
								}
							}
							opponentDetails = await userService.getProfile(opponentId);
							userContestDB[l].opponentUserId = opponentId ? opponentId : 0;
							userContestDB[l].opponentuserName = opponentDetails.userName ? opponentDetails.userName : '';

							/*if (opponentDetails.currentLoginType == 'Normal') {
								userContestDB[l].opponentimageName = opponentDetails.imageName ? process.env.PROFILE_IMAGE_URL + opponentDetails.imageName : '';
							} else if (opponentDetails.currentLoginType == 'FB') {
								userContestDB[l].opponentimageName = process.env.FB_IMAGE_URL.replace(new RegExp('{fbId}', "g"), opponentDetails.loginTypes.FB.fbId);
							}*/

							if (opponentDetails.currentLoginType == 'FB' && opponentDetails.loginTypes.FB.fbId) {
								userContestDB[l].opponentimageName = fbHelper.getFbPicture(opponentDetails.loginTypes.FB.fbId);
							} else {
								userContestDB[l].opponentimageName = opponentDetails.imageName ? process.env.PROFILE_IMAGE_URL + opponentDetails.imageName : '';
							}


							userContestDB[l].sportRank = 0;
							userContestDB[l].rank = 0;
						}

						//for (var i = 0; i < userContestDB.length; i++) {
						var count = 0;
						for (var j = 0; j < getMyContests.length; j++) {
							for (var k = 0; k < getMyContests[j].entrants.length; k++) {
								if (getMyContests[j].entrants[k].userId == opponentId)
									count++;
							}
						}
						userContestDB[l].rival = (count > 6) ? 1 : 0;

						//console.log(userContestDB[i].rival);
						//}

					}

				}
				var myLineUpsDB = await lineUpService.getAllLineups(date);
				//var totalCount = await contestService.getAllMyUserContestAll(contestMapData);
				var result = contestDataMapper.getUserContestsData(userContestDB, myLineUpsDB);
				//var additionalData = {};
				//additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, userContestDB.length);
				generalHelper.handleSuccess(req, res, _t.userContestsRetrieved, result, {});
			} else {
				generalHelper.handleError(req, res, {}, _t.userContestsEmpty);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get contest prize templates
	 * @param {string} req.header - Request object (session data)
	 * @param {object} res - Response object
	 */
	getContestPrizeTemplate: async function (req, res) {
		try {
			var prizeTemplateDB = await prizeTemplateService.getPrizeTemplate();
			if (prizeTemplateDB.length < 1 || prizeTemplateDB == null) {
				generalHelper.handleError(req, res, 'Record not found', _t.failedGetPrizeTemplate);
			} else {
				var result = contestDataMapper.getPrizeTemplateMapping(prizeTemplateDB);
				generalHelper.handleSuccess(req, res, _t.prizeTemplateRetrieved, result, {});
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get one contest's details id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getOneContest: async function (req, res) {
		try {
			if (contestValidation.getValidation(req, res) != false) {
				var appUserId = global.userId;
				contestGamesMapData = contestDataMapper.contestData(req.params.id);
				var search = contestDataMapper.searchData(req.query);
				var contestDB = await contestService.getOne(contestGamesMapData);
				var myLineUpsDB = await lineUpService.getContestLineups(contestGamesMapData, appUserId);
				if (contestDB == null) {
					generalHelper.handleError(req, res, 'Record not found', _t.failedGetOneContestDetail);
				} else {
					var result = contestDataMapper.getContestDetail(contestDB, myLineUpsDB);
					generalHelper.handleSuccess(req, res, _t.contestRetrieved, result, {});
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},


	/**
	 * Update Contests Lineups - multiple same lineup
	 * @param {string} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	updateAllLineUps: async function (req, res) {
		try {
			if (contestValidation.updateContestLineupAllValidation(req, res) != false) {
				//	var lineupIds = ((req.query.lineups).split(','));
				var lineupIds = req.body.lineupIds;
				for (var s = 0; s < lineupIds.length; s++) {
					var LineUpModel = require('../../../models/lineup');
					playerArrayDB = [];
					for (var i in req.body.players) {
						var playerDB = await draftGroupService.getPlayerDataFromDraftgroup(req.body, i);
						if (playerDB.length > 0) {
							playerArrayDB.push(playerDB[0]);
						}
					}
					if (playerArrayDB.length == req.body.players.length) {
						lineUpMapData = contestDataMapper.updatePlayerLinupData({}, playerArrayDB, req.body);
						var response = await lineUpService.updateLineup(LineUpModel, lineUpMapData, lineupIds[s]);
						if (response._id != null) {
							generalHelper.handleSuccess(req, res, _t.lineUpUpdate, {
								'id': response._id,
								'lineupId': response.lineupId
							});
						} else {
							generalHelper.handleError(req, res, 'Add record failed', _t.failedUpdateLineUp);
						}
					} else {
						generalHelper.handleError(req, res, 'Id generation failed', _t.failedUpdateLineUp);
					}
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * unjoin LineUp
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	unjoinLineUp: async function (req, res) {
		try {
			if (contestValidation.unjoinLineupValidation(req, res) != false) {
				//get lineup details
				//var lineUpDB = await lineUpService.getLineup(req.query.lineupId); 
				//get contest details 			
				var contestDetails = await contestService.getContestDetail(req.query.contestId);
				if (contestDetails != null) {
					//var contestDetails = await contestService.getContestDetail(lineUpDB[0].contestId);
					/*if (contestDetails.contestTypeId == 2 && contestDetails.createdBy == global.userId) {
						generalHelper.handleError(req, res, 'Cannot delete h2h entry', _t.DeleteH2HLineUpPermission);
					} else {*/
					if (contestDetails.contestStatus == 3) {

						var myEntryN = (contestDetails.entrants).find(function (obj) {
							return obj.userId === global.userId;
						});
						var totalEntry = contestDetails.entrants.reduce(function (a, b) {
							return a + b.totalentry;
						}, 0);

						if (req.query.lineupId) {

							var lineUpDB = await lineUpService.getLineup(req.query.lineupId);

							if (contestDetails.contestTypeId == 2) { //H2H
								//	if (myEntryN.totalentry > 0) {

								if (totalEntry > 1 && (contestDetails.createdBy == global.userId)) {
									//chanage Contest Ownership
									/*if (contestDetails.entrants[1] != null) {
										if (contestDetails.entrants[1].userId != contestDetails.createdBy) {
											profile1Id = contestDetails.entrants[1].userId;
										} else {
											profile1Id = contestDetails.entrants[0].userId;
										}
									}
									var updateOwner = await contestService.updateContestOwnership(profile1Id, contestDetails.contestId);*/
									generalHelper.handleError(req, res, 'Delete record not permitted', _t.DeleteLineUpPermission);

								} else if (myEntryN && myEntryN.totalentry == 1 && (contestDetails.createdBy == global.userId)) {
									var response = await lineUpService.deleteById(req.query.lineupId);
									if (response.result.n == 1) {
										//deleting contest
										var response = await contestService.delete(contestDetails.contestId);
										if ((!lineUpDB[0].ticketId) || (lineUpDB[0].ticketId && lineUpDB[0].ticketId == "N")) {
											var updateBalance = await userService.addBalance(contestDetails.entryFees);
											if (lineUpDB[0].transactionId && lineUpDB[0].transactionId != "N") {
												var transactionData = contestDataMapper.updateTransactionStatus()
												var updateTransaction = await userService.updateTransactionStatus(global.userId, lineUpDB[0].transactionId, transactionData);
											}
											if (lineUpDB[0].referralMoney) {
												if (lineUpDB[0].referralMoney != 0) {
													var addBalance = await userService.addReferralMoney(lineUpDB[0].referralMoney);
												}
											}
										}
									} else {
										generalHelper.handleError(req, res, 'Delete record not found', _t.failedDeleteLineUp);
									}
								} else if (myEntryN && myEntryN.totalentry == 1 && (contestDetails.createdBy != global.userId)) {

									var response = await lineUpService.deleteById(req.query.lineupId);
									if (response.result.n == 1) {
										//remove user's entrance
										var updateEntrance = await contestService.removeUserEntrance(contestDetails.contestId);
										if ((!lineUpDB[0].ticketId) || (lineUpDB[0].ticketId && lineUpDB[0].ticketId == "N")) {
											var updateBalance = await userService.addBalance(contestDetails.entryFees);
											if (lineUpDB[0].transactionId && lineUpDB[0].transactionId != "N") {
												var transactionData = contestDataMapper.updateTransactionStatus()
												var updateTransaction = await userService.updateTransactionStatus(global.userId, lineUpDB[0].transactionId, transactionData);
											}
											if (lineUpDB[0].referralMoney) {
												if (lineUpDB[0].referralMoney != 0) {
													var addBalance = await userService.addReferralMoney(lineUpDB[0].referralMoney);
												}
											}
										}

									} else {
										generalHelper.handleError(req, res, 'Delete record not found', _t.failedDeleteLineUp);
									}

								} else {
									generalHelper.handleError(req, res, 'Delete record not found', _t.failedDeleteLineUp);
								}

								//} 
							} else { //multi player

								if (totalEntry == contestDetails.maxLimit) {
									generalHelper.handleError(req, res, 'Delete record not permitted', _t.DeleteLineUpPermission);
								} else {

									var response = await lineUpService.deleteById(req.query.lineupId);
									if (response.result.n == 1) {
										if ((!lineUpDB[0].ticketId) || (lineUpDB[0].ticketId && lineUpDB[0].ticketId == "N")) {
											var updateBalance = await userService.addBalance(contestDetails.entryFees);
											if (lineUpDB[0].transactionId && lineUpDB[0].transactionId != "N") {
												var transactionData = contestDataMapper.updateTransactionStatus()
												var updateTransaction = await userService.updateTransactionStatus(global.userId, lineUpDB[0].transactionId, transactionData);
											}
											if (lineUpDB[0].referralMoney) {
												if (lineUpDB[0].referralMoney != 0) {
													var addBalance = await userService.addReferralMoney(lineUpDB[0].referralMoney);
												}
											}
										}
										if (myEntryN.totalentry > 1) {
											//decrement user's entrance count
											var updateEntrance = await contestService.updateEntranceCount(contestDetails.contestId);
										} else {
											//remove user's entrance
											var updateEntrance = await contestService.removeUserEntrance(contestDetails.contestId);
										}
									} else {
										generalHelper.handleError(req, res, 'Delete record not found', _t.failedDeleteLineUp);
									}

								}

							}

							generalHelper.handleSuccess(req, res, _t.lineUpDeleted, {});
						} else {

							if (myEntryN && myEntryN.totalentry < 1) {

								if (contestDetails.contestTypeId == 2 && totalEntry > 0 && myEntryN.totalentry < 1) {
									//chanage Contest Ownership
									/*if (contestDetails.entrants[1] != null) {
										if (contestDetails.entrants[1].userId != contestDetails.createdBy) {
											profile1Id = contestDetails.entrants[1].userId;
										} else {
											profile1Id = contestDetails.entrants[0].userId;
										}
									}
									var updateOwner = await contestService.updateContestOwnership(profile1Id, contestDetails.contestId);*/
									generalHelper.handleError(req, res, 'Delete record not permitted', _t.DeleteLineUpPermission);
								} else {

									var updateEntrance = await contestService.removeUserEntrance(contestDetails.contestId);
									//if((lineUpDB && !lineUpDB[0].ticketId) || (lineUpDB && (lineUpDB[0].ticketId && lineUpDB[0].ticketId == "N"))) {
									var updateBalance = await userService.addBalance(contestDetails.entryFees);
									if (myEntryN.transactionId) {
										var transactionData = contestDataMapper.updateTransactionStatus()
										var updateTransaction = await userService.updateTransactionStatus(global.userId, myEntryN.transactionId, transactionData);
									}
									if (myEntryN.referralMoney) {
										if (myEntryN.referralMoney != 0) {
											var addBalance = await userService.addReferralMoney(myEntryN.referralMoney);
										}
									}
									//}
									if (contestDetails.contestTypeId == 2 && totalEntry < 1 && (contestDetails.createdBy == global.userId)) { //deleting contest
										var response = await contestService.delete(contestDetails.contestId);
									}
								}
							} else {
								generalHelper.handleError(req, res, 'lineupId required', _t.lineupIdRequired);
							}
							generalHelper.handleSuccess(req, res, _t.lineUpDeleted, {});
						}
					} else {
						generalHelper.handleError(req, res, 'Delete record not permitted', _t.DeleteLineUpPermission);
					}
					//}
				} else {
					generalHelper.handleError(req, res, 'Delete record not found', _t.failedDeleteLineUp);
				}

			}

		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},


	/**
	 * Join to multiple contest
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	joinMultipleContest_old: async function (req, res) {
		try {
			if (contestValidation.joinContestValidation(req, res) != false) {
				var LineUpModel = require('../../../models/lineup');
				var lineUpModel = {};

				userDB = await userService.getProfile(global.userId);
				lineUpModel.userName = userDB.userName;
				lineUpModel.imageName = userDB.imageName;

				var contestIds = req.body.contestId;
				var contestFee = await contestService.getContestFee(contestIds);

				var limitContestIds = [];
				var joinedContestIds = [];
				var lineupids = [];
				var _ids = [];

				var fees = [];
				for (var i in contestFee) {
					fees.push(contestFee[i].entryFees);

					var myentry = contestFee[i].entrants.find(function (obj) {
						return obj.userId === global.userId;
					});

					var totalEntry = contestFee[i].entrants.reduce(function (a, b) {
						return a + b.totalentry;
					}, 0);

					if (totalEntry > 1) {
						limitContestIds.push(contestFee[i].contestId);
					}
					if (myentry && myentry.totalentry != 0) {
						joinedContestIds.push(contestFee[i].contestId);
					}
				}
				var sum = fees.reduce(add, 0)

				function add(a, b) {
					return a + b;
				}
				if (sum < userDB.balance) { //checking user balace
					if (limitContestIds.length == 0) { //checking entry limit

						if (joinedContestIds.length == 0) { //checking already joined

							for (var j in contestIds) { //loop starts

								lineUpModel.lineupId = await generalHelper.updateCounter('lineupId'); //unique key
								//contest details for entryFee
								var contestDetails = await contestService.getOne(contestIds[j]);
								//getting all entrants
								var entrants = contestDetails.entrants;
								//user's entry
								var myentry = entrants.find(function (obj) {
									return obj.userId === global.userId;
								});
								var totalEntry = entrants.reduce(function (a, b) {
									return a + b.totalentry;
								}, 0);
								//creator entry (for reservation)
								/*var creatorEntry = entrants.find(function (obj) {
									return obj.userId === contestDetails.createdBy;
								});
								if (creatorEntry)
									(creatorEntry.totalentry == 0 && global.userId != contestDetails.createdBy) ? (totalEntry = totalEntry + 1) : '';*/
								//entry limit if h2h
								/*if (contestDetails.contestTypeId == 2) {
									(global.userId == contestDetails.createdBy && (myentry ? myentry.totalentry != 0 : '')) ? totalEntry = totalEntry + 1: '';
								}*/
								/*if (totalEntry < contestDetails.maxLimit) {
									if (userDB.balance < contestDetails.entryFees && (myentry ? myentry.totalentry != 0 : '1=1')) {
										return generalHelper.handleError(req, res, "Insufficient balance", _t.balanceInsufficient);
									} else {*/


								//additional details added on 19-march-18 start
								var draftDetails = await draftGroupService.getDraftGroupDetails(req.body.draftgroupId);
								req.body.dgName = draftDetails.dgName;
								req.body.startTimeUTC = draftDetails.startTimeUTC;
								req.body.gameTypeId = contestDetails.gameTypeId;
								//additional details added on 19-march-18 end
								if (lineUpModel.lineupId != null) {
									playerArrayDB = [];
									for (var i in req.body.players) {
										var playerDB = await draftGroupService.getPlayerDataFromDraftgroup(req.body, i);
										if (playerDB.length > 0) {
											playerArrayDB.push(playerDB[0]);
										}
									}
									if (playerArrayDB.length == req.body.players.length) {
										lineUpModel = contestDataMapper.MultipleplayerLinupData(lineUpModel, playerArrayDB, req.body, contestIds[j]);
										var response = await lineUpService.addLineupMultiple(lineUpModel);
										if (response.upserted[0]._id != null) {
											//update user balance
											if (myentry ? myentry.totalentry != 0 : '1=1')
												var updateBalance = await userService.updateBalance(contestDetails.entryFees);
											//add entrants to contest
											var contestEntrants = await contestService.addEntrantsToContest(lineUpModel.contestId);

											lineupids.push(lineUpModel.lineupId);

										} else {
											generalHelper.handleError(req, res, 'Add record failed', _t.failedAddLineUp);
										}
									} else {
										generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddLineUp);
									}
								} else {
									generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddLineUp);
								}
								/*	}
								} else {
									generalHelper.handleError(req, res, 'Entry Limit Reached', _t.lineupEntryLimit);
								}*/
							} //loop ends

							generalHelper.handleSuccess(req, res, _t.lineUpAdded, {
								'lineupId': lineupids
							});

						} else { //checking already joined
							generalHelper.handleErrorData(req, res, 'Entry Limit Reached', "Already joined.", '', joinedContestIds);
						}

					} else { //checking entry limit ends
						generalHelper.handleErrorData(req, res, 'Entry Limit Reached', _t.lineupEntryLimit, '', limitContestIds);
					}

				} else { //checking user balace ends
					return generalHelper.handleError(req, res, "Insufficient balance", _t.balanceInsufficient);
				}

			} //validation ends

		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Join to a contest
	 * @param {object} req.body - Request object (record's data)
	 * @param {object} res - Response object
	 */
	joinMultipleContest: async function (req, res) {
		try {
			if (contestValidation.joinContestValidation(req, res) != false) {
				var LineUpModel = require('../../../models/lineup');
				//var lineUpModel = new LineUpModel();
				var lineUpModel = {};

				userDB = await userService.getProfile(global.userId);
				lineUpModel.userName = userDB.userName;
				lineUpModel.imageName = userDB.imageName;

				var contestIds = req.body.contestId;


				var balanceError = [];
				var maxLimitError = [];
				var insertedContests = [];
				var lineupids = [];
				var referralMoneyBalance = 0;
				var referralM = 0;

				var referralMoneyBalance = userDB.referralMoney ? userDB.referralMoney : 0;
				var moneyBalane = userDB.balance ? userDB.balance : 0;


				for (var j in contestIds) { //loop starts
					var contestCreated = [];
					lineUpModel.lineupId = await generalHelper.updateCounter('lineupId'); //unique key

					//contest details for entryFee
					var contestDetails = await contestService.getOne(contestIds[j]);
					//getting all entrants
					var entrants = contestDetails.entrants;
					//user's entry
					var myentry = entrants.find(function (obj) {
						return obj.userId === global.userId;
					});
					var totalEntry = entrants.reduce(function (a, b) {
						return a + b.totalentry;
					}, 0);
					//creator entry (for reservation)
					var creatorEntry = entrants.find(function (obj) {
						return obj.userId === contestDetails.createdBy;
					});
					if (creatorEntry && !contestDetails.autoId)
						(creatorEntry.totalentry == 0 && global.userId != contestDetails.createdBy) ? (totalEntry = totalEntry + 1) : '';
					//entry limit if h2h
					if (contestDetails.contestTypeId == 2 && !contestDetails.autoId) {
						(global.userId == contestDetails.createdBy && (myentry ? myentry.totalentry != 0 : '')) ? totalEntry = totalEntry + 1 : '';
					}

					var myEntryVal = myentry ? myentry.totalentry : 0;
					if (totalEntry < contestDetails.maxLimit && myEntryVal < contestDetails.maxEntriesPerUser) {
						if (moneyBalane < contestDetails.entryFees && (myentry ? myentry.totalentry != 0 : '1=1')) {
							//return generalHelper.handleError(req, res, "Insufficient balance", _t.balanceInsufficient);
							balanceError.push(contestIds[j]);
						} else {

							if ((myentry && myentry.totalentry) != 0 || !myentry) {
								/*dailyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "daily");
								weeklyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "weekly");
								monthlyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "monthly");
								//console.log(userDB.spendLimits.daily);  console.log("dailyTransactionAmount"); console.log( dailyTransactionAmount[0].amount);				
								if (dailyTransactionAmount[0].amount >= userDB.spendLimits.daily) {
									return generalHelper.handleError(req, res, "daily Limit", _t.dailyLimitExceeded);
								}
								if (weeklyTransactionAmount[0].amount >= userDB.spendLimits.weekly) {
									return generalHelper.handleError(req, res, "weekly Limit", _t.weeklyLimitExceeded);
								}
								if (monthlyTransactionAmount[0].amount >= userDB.spendLimits.monthly) {
									return generalHelper.handleError(req, res, "monthly Limit", _t.monthlyLimitExceeded);
								}
								if (checkContest.entryFees > userDB.spendLimits.maxEntryFee) {
									return generalHelper.handleError(req, res, "max entry Fee", _t.maxEntryFeeExceeded);
								}*/

								await module.exports.contestSettingsValidation(userDB, contestDetails.entryFees, contestDetails.entryFees, req, res);

							}

							//additional details added on 19-march-18 start
							var draftDetails = await draftGroupService.getDraftGroupDetails(req.body.draftgroupId);
							req.body.dgName = draftDetails.dgName;
							req.body.startTimeUTC = draftDetails.startTimeUTC;
							req.body.gameTypeId = contestDetails.gameTypeId;
							//additional details added on 19-march-18 end
							if (lineUpModel.lineupId != null) {
								playerArrayDB = [];
								for (var i in req.body.players) {
									var playerDB = await draftGroupService.getPlayerDataFromDraftgroup(req.body, i);
									if (playerDB.length > 0) {
										playerArrayDB.push(playerDB[0]);
									}
								}
								if (playerArrayDB.length == req.body.players.length) {

									if (myentry ? myentry.totalentry != 0 : '1=1') {
										if (referralMoneyBalance != 0) {
											if (referralMoneyBalance >= contestDetails.entryFees) {
												referralM = contestDetails.entryFees;
												referralMoneyBalance = referralMoneyBalance - contestDetails.entryFees;
											} else {
												referralM = referralMoneyBalance;
												referralMoneyBalance = 0;
											}

										}
									}

									lineUpModel = contestDataMapper.MultipleplayerLinupData(lineUpModel, playerArrayDB, req.body, contestIds[j], referralM);
									//console.log(referralM);	console.log("*****");	console.log(lineUpModel);
									var response = await lineUpService.addLineupMultiple(lineUpModel);
									if (response.upserted[0]._id != null) {
										//update user balance
										if (myentry ? myentry.totalentry != 0 : '1=1') {
											var updateBalance = await userService.updateBalance(contestDetails.entryFees);
											moneyBalane = moneyBalane - contestDetails.entryFees;

											var transactionModel = new TransactionModel();
											transactionModel = contestDataMapper.transactionData(transactionModel, userDB, contestDetails.entryFees, 'JC');
											var transactionResult = await userService.transactionEntry(transactionModel);
											var lineupData = contestDataMapper.updateLineupData(transactionResult._id);
											var updateLineup = await lineUpService.updateLineupData(lineUpModel.lineupId, lineupData);

											if (referralM != 0) {
												var updateReferralBalance = await userService.updateReferralMoney(referralM);
											}
										}
										//add entrants to contest
										var contestEntrants = await contestService.addEntrantsToContest(lineUpModel.contestId);

										//contest details for entryFee
										var contestUpdated = [];
										var contestDetailsUpdated = await contestService.getOne(lineUpModel.contestId);
										contestUpdated.push(contestDetailsUpdated);
										contestUpdatedPush = contestDataMapper.getUserCreatedContest(contestUpdated);
										//pushing updated contest
										Pusher.sendPush('draftgroup-channel', 'draftgroup-' + contestDetails.draftgroupId, contestUpdatedPush);

										//generating auto contest start
										var totalEntryAuto = totalEntry + 1;
										if (contestDetails.autoId && totalEntryAuto >= contestDetails.maxLimit) {
											contestModel = contestDataMapper.addDataAutoContest(contestDetails);
											contestModel.contestId = await generalHelper.updateCounter('contestId'); //unique key
											contestModel.autoId = await generalHelper.updateCounter('autoId');
											var response = await contestService.add(contestModel);
											//adding contest to draftgroup
											var contestToDraft = await draftGroupService.addContest(contestDetails.draftgroupId, contestModel.contestId);
											contestCreated.push(contestModel);
											contest = contestDataMapper.getUserCreatedContest(contestCreated);
											//pushing newly created contest
											Pusher.sendPush('draftgroup-channel', 'draftgroup-' + contestModel.draftgroupId, contest);
											//Pusher.sendPush('draftgroup-channel', 'draftgroup-21770', contestModel);
										}
										//generating auto contest ends

										lineupids.push(lineUpModel.lineupId);
										insertedContests.push(contestIds[j]);

										/*	generalHelper.handleSuccess(req, res, _t.lineUpAdded, {
												'id': response._id,
												'lineupId': response.lineupId
											});*/
									} else {
										generalHelper.handleError(req, res, 'Add record failed', _t.failedAddLineUp);
									}
								} else {
									generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddLineUp);
								}
							} else {
								generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddLineUp);
							}
						}
					} else {
						//generalHelper.handleError(req, res, 'Entry Limit Reached', _t.lineupEntryLimit);
						maxLimitError.push(contestIds[j]);
					}

				} //loop ends

				generalHelper.handleSuccess(req, res, _t.lineUpAdded, {
					'lineupId': lineupids,
					'insertedContests': insertedContests,
					'maxLimitErrorContests': maxLimitError,
					'balanceErrorContests': balanceError
				});

			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Join a conest with lenup id id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	joinContestWithLineUpId1111: async function (req, res) {
		try {
			if (contestValidation.joinContestWithLineUpIdValidation(req, res) != false) {
				var contestMapData = contestDataMapper.joinWithLineUpId(req.body);
				//contest details for entryFee
				var contestDetails = await contestService.getOne(req.body.contestId);
				//getting all entrants
				var entrants = contestDetails.entrants;
				//user's entry
				var myentry = entrants.find(function (obj) {
					return obj.userId === global.userId;
				});
				var totalEntry = entrants.reduce(function (a, b) {
					return a + b.totalentry;
				}, 0);

				var contestLineUpsDB = await lineUpService.updateLineupWithContest(contestMapData);
				if (contestLineUpsDB != null) {
					//update user balance
					if (myentry ? myentry.totalentry != 0 : '1=1')
						var updateBalance = await userService.updateBalance(contestDetails.entryFees);
					//add entrants to contest
					var contestEntrants = await contestService.addEntrantsToContest(contestMapData.contestId);
					generalHelper.handleSuccess(req, res, _t.lineUpAdded, {
						'contestId': contestMapData.contestId,
						'lineupId': contestMapData.lineupId
					});
				} else {
					generalHelper.handleError(req, res, {}, _t.contestLineupsEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	joinContestWithLineUpId: async function (req, res) {
		try {
			if (contestValidation.joinContestWithLineUpIdValidation(req, res) != false) {
				/*var LineUpModel = require('../../../models/lineup');
				var lineUpModel = new LineUpModel();*/
				var lineUpModel = {};
				var contestMapData = contestDataMapper.joinWithLineUpId(req.body);
				lineUpModel.lineupId = contestMapData.lineupId;
				userDB = await userService.getProfile(global.userId);
				lineupDB = await lineUpService.getLineup(contestMapData.lineupId);

				lineUpModel.userName = userDB.userName;
				lineUpModel.imageName = userDB.imageName;
				var contestCreated = [];
				var gcontestId = 0;
				var referralM = 0;
				var isTicket = 0;
				var usedTicketId = "N";
				var checkContest = await contestService.getOne(req.body.contestId);
				if (checkContest.contestStatus == 3) {

					/*	contestModel = contestDataMapper.addDataAutoContest(checkContest);
		
						contestModel.contestId = await generalHelper.updateCounter('contestId'); //unique key
		
						console.log(contestModel); process.exit();*/

					if (req.body.ticketId && req.body.ticketId != '') {
						var ticketService = require('../services/ticketService');
						ticketModel = contestDataMapper.joinContestTicket(req.body.ticketId, checkContest.entryFees, global.userId);
						var checkTicket = await ticketService.validateJoinContestTicket(ticketModel);
						if (!checkTicket) {
							return generalHelper.handleError(req, res, "Ticket Invalid", _t.invalidTicket);
						} else {
							isTicket = 1;
						}
					}


					if (checkContest.contestTypeId == 2 && checkContest.entrants.length > 1 && !checkContest.autoId) {
						var groupContest = await contestService.getGroupContests(checkContest.contestGroupId);
						for (var g in groupContest) {
							var myentryCheck = groupContest[g].entrants.find(function (obj) {
								return obj.userId === global.userId;
							});
							if (groupContest[g].entrants.length < 2 && !myentryCheck) {
								gcontestId = groupContest[g].contestId;
								break;
							}
						}
					}

					//auto contest swap joining start
					var totalEntry = (checkContest.entrants).reduce(function (a, b) {
						return a + b.totalentry;
					}, 0);
					if (checkContest.autoId && totalEntry >= checkContest.maxLimit) {
						var autoContestSimilar = await contestService.getAutoContestSimilar(checkContest);
						var myentryCheckAuto = autoContestSimilar.entrants.find(function (obj) {
							return obj.userId === global.userId;
						});
						if (!myentryCheckAuto) {
							gcontestId = autoContestSimilar.contestId;
						}
					}
					////auto contest swap joining end


					if (gcontestId == 0) {
						contestIdd = req.body.contestId;
					} else {
						contestIdd = gcontestId;
					}
					req.body.contestId = contestIdd;

					//contest details for entryFee
					var contestDetails = await contestService.getOne(contestIdd);

					//console.log("************");	console.log(contestDetails.draftgroupId); console.log("----------"); console.log(lineupDB);

					if (contestDetails.draftgroupId == lineupDB[0].draftgroupId) {

						//getting all entrants
						var entrants = contestDetails.entrants;
						//user's entry
						var myentry = entrants.find(function (obj) {
							return obj.userId === global.userId;
						});
						var totalEntry = entrants.reduce(function (a, b) {
							return a + b.totalentry;
						}, 0);
						//creator entry (for reservation)
						var creatorEntry = entrants.find(function (obj) {
							return obj.userId === contestDetails.createdBy;
						});
						if (creatorEntry && !contestDetails.autoId)
							(creatorEntry.totalentry == 0 && global.userId != contestDetails.createdBy) ? (totalEntry = totalEntry + 1) : '';
						//entry limit if h2h
						if (contestDetails.contestTypeId == 2 && !contestDetails.autoId) {
							(global.userId == contestDetails.createdBy && (myentry ? myentry.totalentry != 0 : '')) ? totalEntry = totalEntry + 1 : '';
						}
						var myEntryVal = myentry ? myentry.totalentry : 0;
						if (totalEntry < contestDetails.maxLimit && myEntryVal < contestDetails.maxEntriesPerUser) {
							if (userDB.balance < contestDetails.entryFees && (myentry ? myentry.totalentry != 0 : '1=1') && isTicket == 0) {
								return generalHelper.handleError(req, res, "Insufficient balance", _t.balanceInsufficient);
							} else {

								if ((myentry && myentry.totalentry) != 0 || !myentry) {
									if (isTicket == 0) {
										/*	dailyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "daily");
											weeklyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "weekly");
											monthlyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "monthly");	
											if( dailyTransactionAmount[0].amount >= userDB.spendLimits.daily ) { 
											return generalHelper.handleError(req, res, "daily Limit", _t.dailyLimitExceeded);
											}
											if( weeklyTransactionAmount[0].amount >= userDB.spendLimits.weekly ) {
											return generalHelper.handleError(req, res, "weekly Limit", _t.weeklyLimitExceeded);
											}
											if( monthlyTransactionAmount[0].amount >= userDB.spendLimits.monthly  ) {
											return generalHelper.handleError(req, res, "monthly Limit", _t.monthlyLimitExceeded);
											}
											if( checkContest.entryFees > userDB.spendLimits.maxEntryFee ) {
											return generalHelper.handleError(req, res, "max entry Fee", _t.maxEntryFeeExceeded);
											}*/

										await module.exports.contestSettingsValidation(userDB, contestDetails.entryFees, contestDetails.entryFees, req, res);
									}
								}

								//additional details added on 19-march-18 start
								/*var draftDetails = await draftGroupService.getDraftGroupDetails(req.body.draftgroupId);
								req.body.dgName = draftDetails.dgName;
								req.body.startTimeUTC = draftDetails.startTimeUTC;
								req.body.gameTypeId = contestDetails.gameTypeId;
								//additional details added on 19-march-18 end
								if (lineUpModel.lineupId != null) {
									playerArrayDB = [];
									for (var i in req.body.players) {
										var playerDB = await draftGroupService.getPlayerDataFromDraftgroup(req.body, i);
										if (playerDB.length > 0) {
											playerArrayDB.push(playerDB[0]);
										}
									}
									if (playerArrayDB.length == req.body.players.length) {
										//draftgroups player minSalary w.r.t position
										if ((req.body.sportId == 4 || req.body.sportId == 3)) {
											var minSalary = await draftGroupService.getMinSalaryNBAMLBNHLDraftgroup(req.body.draftgroupId);
										}
										else {
											var minSalary = await draftGroupService.getMinSalaryNFLMLBGOLFDraftgroup(req.body.draftgroupId);
										}
										lineUpModel = contestDataMapper.playerLinupData(lineUpModel, playerArrayDB, req.body, minSalary);
										var response = await lineUpService.addLineup(lineUpModel);*/

								if ((myentry && myentry.totalentry) != 0 || !myentry) {
									//if (myentry ? myentry.totalentry != 0 : '1=1') {
									if (isTicket == 0) {
										if (userDB.referralMoney != 0) {
											if (userDB.referralMoney >= contestDetails.entryFees) {
												referralM = contestDetails.entryFees;
											} else {
												referralM = userDB.referralMoney;
											}
										}
									} else {
										usedTicketId = req.body.ticketId;
									}

								}
								var contestLineUpsDB = await lineUpService.updateLineupWithContest(contestMapData, contestDetails.draftgroupId, referralM, usedTicketId);
								if (contestLineUpsDB != null) {

									//update user balance
									if ((myentry && myentry.totalentry) != 0 || !myentry) {
										//if (myentry ? myentry.totalentry != 0 : '1=1') {

										if (isTicket == 0) {
											var updateBalance = await userService.updateBalance(contestDetails.entryFees);

											var transactionModel = new TransactionModel();
											transactionModel = contestDataMapper.transactionData(transactionModel, userDB, contestDetails.entryFees, 'JC');
											var transactionResult = await userService.transactionEntry(transactionModel);
											var lineupData = contestDataMapper.updateLineupData(transactionResult._id);
											var updateLineup = await lineUpService.updateLineupData(contestMapData.lineupId, lineupData);

											if (userDB.referralMoney != 0) {
												var updateReferralBalance = await userService.updateReferralMoney(referralM);
											}
										} else {
											var updateTicketData = contestDataMapper.updateTicketData(req.body.ticketId, global.userId);
											var updateTicket = await ticketService.updateUserTicket(updateTicketData);

										}

									}
									//add entrants to contest

									var contestEntrants = await contestService.addEntrantsToContest(contestMapData.contestId);

									//contest details for entryFee
									var contestUpdated = [];
									var contestDetailsUpdated = await contestService.getOne(contestMapData.contestId);
									contestDetailsUpdated.lineupId = contestMapData.lineupId
									contestUpdated.push(contestDetailsUpdated);
									contestUpdatedPush = contestDataMapper.getUserCreatedContest(contestUpdated);
									//pushing updated contest
									Pusher.sendPush('draftgroup-channel', 'draftgroup-' + contestDetails.draftgroupId, contestUpdatedPush);

									//generating auto contest start
									var totalEntryAuto = totalEntry + 1;
									if (contestDetails.autoId && totalEntryAuto >= contestDetails.maxLimit) {
										contestModel = contestDataMapper.addDataAutoContest(contestDetails);
										contestModel.contestId = await generalHelper.updateCounter('contestId'); //unique key
										contestModel.autoId = await generalHelper.updateCounter('autoId');
										var response = await contestService.add(contestModel);
										//adding contest to draftgroup
										var contestToDraft = await draftGroupService.addContest(contestDetails.draftgroupId, contestModel.contestId);
										contestCreated.push(contestModel);
										contest = contestDataMapper.getUserCreatedContest(contestCreated);
										//pushing newly created contest
										Pusher.sendPush('draftgroup-channel', 'draftgroup-' + contestModel.draftgroupId, contest);
										//Pusher.sendPush('draftgroup-channel', 'draftgroup-21770', contestModel);
									}
									//generating auto contest end

									generalHelper.handleSuccess(req, res, _t.lineUpAdded, {
										'contestId': contestMapData.contestId,
										'lineupId': contestMapData.lineupId
									});
								} else {
									generalHelper.handleError(req, res, 'Add record failed', _t.failedAddLineUp);
								}
								/*	} else {
										generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddLineUp);
									}
								} else {
									generalHelper.handleError(req, res, 'Id generation failed', _t.failedAddLineUp);
								}*/
							}
						} else {
							generalHelper.handleError(req, res, 'Entry Limit Reached', _t.lineupEntryLimit);
						}

					} else {
						generalHelper.handleError(req, res, 'Draft group not matching', _t.draftgroupNotMatching);
					}

				} else {
					if (checkContest.contestStatus == 2) {
						var lang = _t.contestLive;
					}
					if (checkContest.contestStatus == 1) {
						var lang = _t.contesCompleted;
					}
					if (checkContest.contestStatus == 4) {
						var lang = _t.contestCancelled;
					}
					generalHelper.handleError(req, res, 'Id generation failed', lang);
				}

			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Settings validation  while join to a contest
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @return {boolean} False 
	 */
	contestSettingsValidation: async function (userDB, feeContest, feeContestsingle, req, res) {
		try {
			dailyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "daily");
			weeklyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "weekly");
			monthlyTransactionAmount = await userService.getTransactionAmounts("JC", global.userId, "monthly");
			if (dailyTransactionAmount[0].amount + feeContest >= userDB.spendLimits.daily) {
				return generalHelper.handleError(req, res, "daily Limit", _t.dailyLimitExceeded);
			}
			if (weeklyTransactionAmount[0].amount + feeContest >= userDB.spendLimits.weekly) {
				return generalHelper.handleError(req, res, "weekly Limit", _t.weeklyLimitExceeded);
			}
			if (monthlyTransactionAmount[0].amount + feeContest >= userDB.spendLimits.monthly) {
				return generalHelper.handleError(req, res, "monthly Limit", _t.monthlyLimitExceeded);
			}
			if (feeContestsingle > userDB.spendLimits.maxEntryFee) {
				return generalHelper.handleError(req, res, "max entry Fee", _t.maxEntryFeeExceeded);
			}

		} catch (e) {
			throw e;
		}
	},

};