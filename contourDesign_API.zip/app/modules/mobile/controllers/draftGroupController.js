/**
 * DraftGroup Module
 * @exports DraftGroup/Controller
 */
var draftGroupService = require('../services/draftGroupService');
var contestService = require('../services/contestService');
var lineUpService = require('../services/lineUpService');
var generalHelper = require('../helpers/generalHelper');
var _t = require('../translations/' + process.env.LANGUAGE + '/draftGroupTrans.json');
var darftGroupValidation = require('../validations/draftGroupValidation');
var draftGroupDataMapper = require('../dataMappers/draftGroupDataMapper');
var lineupTemplateService = require('../services/lineUpTemplateService');
var async = require('async');
var moment = require('moment-timezone');

module.exports = {

	/**
	 * Get DraftGroup List
	 * @param {object} req.query - Request object with request parameters
	 * @param {object} res - Response object
	 */
	getDraftGroupList: async function (req, res) {
		try {
			//if (darftGroupValidation.listDraftValidation(req, res) != false) {
			//draftGroupMapData = draftGroupDataMapper.draftListData({}, req.query);
			var d = new Date();
			d.setDate(d.getDate() - 14);	
			var date = moment.utc(d).format('YYYY-MM-DD');
			var draftGroupDB = await draftGroupService.getDraftGroup(req.query, date);
			var lineuptemplates = await lineupTemplateService.getAllLineUpTemplate();
			if (draftGroupDB.length > 0) {
				result = draftGroupDataMapper.draftGroupResultMap(draftGroupDB, lineuptemplates);
				generalHelper.handleSuccess(req, res, _t.draftGroupRetrieved, result, {});

			} else {
				generalHelper.handleError(req, res, {}, _t.draftGroupEmpty);
			}
			//}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get one draftgroup by id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getDraftGroupDetails: async function (req, res) {
		try {
			if (darftGroupValidation.DraftgroupIdValidation(req, res) != false) {
				draftDetailsMapData = draftGroupDataMapper.draftDetailsData(req.params.id);
				var draftGroupDetailsDB = await draftGroupService.getDraftGroupDetails(draftDetailsMapData);
				if (draftGroupDetailsDB != null) {
					result = draftGroupDataMapper.draftGroupDetailsResultMap(draftGroupDetailsDB);
					generalHelper.handleSuccess(req, res, _t.draftGroupDetailsRetrieved, result, {});

				} else {
					generalHelper.handleError(req, res, {}, _t.draftGroupDetailsEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get contest list by draftgroup id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getDraftGroupContestDetails: async function (req, res) {
		try {
			if (darftGroupValidation.DraftgroupIdValidation(req, res) != false) {
				draftDetailsMapData = draftGroupDataMapper.draftDetailsData(req.params.id);
				var draftGroupDetailsDB = await draftGroupService.getDraftGroupContest(draftDetailsMapData);
				if (draftGroupDetailsDB != null) {
					var draftGroupContestDetailsDB = await contestService.getDraftGroupContestDetails(draftGroupDetailsDB);
					result = draftGroupDataMapper.draftGroupContestResultMap(draftGroupContestDetailsDB);
					generalHelper.handleSuccess(req, res, _t.draftGroupContestRetrieved, result, {});

				} else {
					generalHelper.handleError(req, res, {}, _t.draftGroupContestEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get players list by draftgroup id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getAllPlayer: async function (req, res) {
		try {
			if (darftGroupValidation.DraftgroupIdValidation(req, res) != false) {
				draftPlayersMapData = draftGroupDataMapper.draftDetailsData(req.params.id);
				var search = draftGroupDataMapper.searchData(req.query);
				var draftGroupPlayersDB = await draftGroupService.getDraftGroupPlayers(draftPlayersMapData);
				if (draftGroupPlayersDB != null) {
					var playerTemplate = (await lineupTemplateService.getSportLineup(draftGroupPlayersDB.sportId)).gameTypes[0].template;
					if ((draftGroupPlayersDB.sportId == 4 || draftGroupPlayersDB.sportId == 3 || draftGroupPlayersDB.sportId == 2)) {
						var minSalary = await draftGroupService.getMinSalaryNBAMLBNHLDraftgroup(req.params.id);
					}
					else {
						var minSalary = await draftGroupService.getMinSalaryNFLGOLFDraftgroup(req.params.id);
					}//console.log(minSalary);
					result = draftGroupDataMapper.draftGroupPlayersResultMap(draftGroupPlayersDB, playerTemplate, minSalary);
					//pagination after mapping
					resultPaginated = generalHelper.paginateArray(result, +search.limit, +search.page);
					var totalCount = result.length;
					var additionalData = generalHelper.paginationInfo(search.limit, totalCount, search.page, resultPaginated.length);
					generalHelper.handleSuccess(req, res, _t.draftGroupPlayersRetrieved, resultPaginated, additionalData);
				} else {
					generalHelper.handleError(req, res, {}, _t.draftGroupPlayersEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},


	/**
	 * Get lineups list by draftgroup id
	 * @param {string} req.param.id Request object (id of the record)
	 * @param {object} res - Response object
	 */
	getLineUp: async function (req, res) {
		try {
			if (darftGroupValidation.DraftgroupIdValidation(req, res) != false) {
				draftLineUpMapData = draftGroupDataMapper.draftDetailsData(req.params.id);
				var draftGroupLineUpsDB = await lineUpService.getDraftGroupLineups(draftLineUpMapData);
				var allMyContestDB = await contestService.getAllMyContestDraftgroup(draftLineUpMapData);
				if (draftGroupLineUpsDB != null) {
					result = draftGroupDataMapper.draftGroupLineUpsResultMap(draftGroupLineUpsDB, allMyContestDB);
					generalHelper.handleSuccess(req, res, _t.draftGroupLineupsRetrieved, result, {});
				} else {
					generalHelper.handleError(req, res, {}, _t.draftGroupLineupsEmpty);
				}
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},

	/**
	 * Get user lineups list
	 * @param {string} req.header - Request object (session data)
	 * @param {object} res - Response object
	 */
	getAllLineUp: async function (req, res) {
		try {
			var d = new Date();
			d.setDate(d.getDate() - 14);	
			var date = moment.utc(d).format('YYYY-MM-DD');
			var lineUpMapp = draftGroupDataMapper.lineUpMappData(req.query);
			var draftGroupLineUpsDB = await lineUpService.getAllLineups(date);
			var allMyContestDB = await contestService.getAllMyContest();
			if (draftGroupLineUpsDB.length > 0) {
				result = draftGroupDataMapper.draftGroupLineUpsResultMap(draftGroupLineUpsDB, allMyContestDB, lineUpMapp.status);
				generalHelper.handleSuccess(req, res, _t.allLineupsRetrieved, result, {});
			} else {
				generalHelper.handleError(req, res, {}, _t.userLineupsEmpty);
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	},
};