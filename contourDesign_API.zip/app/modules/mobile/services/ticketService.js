/**
 * Ticket Service
 * @exports Ticket/Service
 */
var UserTicketModel = require('../../../models/userTicket');
var TicketStoreModel = require('../../../models/ticketStore');



module.exports = {


/**
	 * User ticket creation
	 * @param {object} ticketDBNew - Model object
	 * @returns {object} Response model
	 * @throws {object} e - Error
	 */
	addUserTicket: async function (ticketDBNew) {
		try {
			return await ticketDBNew.save();
		} catch (e) {
			throw e;
		}
    },

    /**
     * Update User ticket status
     * @param {object} ticketData - Data required to update user ticket
     * @returns {Number} Total count of records
     * @throws {object} e - Error
     */
    updateUserTicket: async function (ticketData) {
        try {
            return await UserTicketModel.findOneAndUpdate({
                'userId': ticketData.userId,
                "ticketId": ticketData.ticketId
            }, {
                $set: { 
                    "ticketStatus": ticketData.ticketStatus
                }
            }, {
                new: true
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Refund User ticket
     * @param {object} ticketData - Data required to refund user ticket
     * @returns {Number} Total count of records
     * @throws {object} e - Error
     */
    refundUserTicket: async function (ticketData) {
        try {
            return await UserTicketModel.findOneAndUpdate({
                'userId': ticketData.userId,
                "ticketId": ticketData.ticketId
            }, {
                $set: { 
                    "ticketStatus": ticketData.ticketStatus
                }
            }, {
                new: true
            });
        } catch (e) {
            throw e;
        }
    },

     /**
     * Validate User ticket with amount
     * @param {object} ticketData - Data required to refund ticket
     * @returns {object} Ticket object
     * @throws {object} e - Error
     */
    validateUserTicket: async function (ticketData) {
        try {
            return await UserTicketModel.count({
                'userId': ticketData.userId,
                "ticketId": ticketData.ticketId,
                "ticketAmount": ticketData.ticketAmount,
                "ticketStatus": "N"
            });
        } catch (e) {
            throw e;
        }
    },
    
    /**
	 * Add Ticket to store
	 * @param {object} ticketDBNew - Model object
	 * @returns {object} Response model
	 * @throws {object} e - Error
	 */
	addTicketToStore: async function (ticketSore) {
		try {
			return TicketStoreModel.collection.insert(ticketSore);
		} catch (e) {
			throw e;
		}
    },

    /**
     * Get all tickets from store     
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getStoreTickets: async function () {
        try {
            return await TicketStoreModel.find();
        } catch (e) {
            throw e;
        }
    },

     /**
     * Validate User ticket with amount
     * @param {object} ticketData - Data required to refund ticket
     * @returns {object} Ticket object
     * @throws {object} e - Error
     */
    validateJoinContestTicket: async function (ticketData) {
        try {
            return await UserTicketModel.count({
                'userId': ticketData.userId,
                "ticketId": ticketData.ticketId,
                "ticketAmount": ticketData.ticketAmount,
                "ticketStatus": "N"
            });
        } catch (e) {
            throw e;
        }
    },

        /**
	 * Add Sport points
	 * @param {object} pointsModel - Model object
	 * @returns {object} Response model
	 * @throws {object} e - Error
	 */
	/* addSportPoints: async function (pointsModel) {
		try {
			return pointsModel.save();
		} catch (e) {
			throw e;
		}
    }, */


     /**
     * Get all user tickets
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getUserTickets: async function (userId) {
        try {
            return await UserTicketModel.find({
                'userId': userId,               
                "ticketStatus": "N"
            });
        } catch (e) {
            throw e;
        }
    },
    /**
	 * Add rank images
	 * @param {object} rankImages - Model object
	 * @returns {object} Response model
	 * @throws {object} e - Error
	 */
	/* addRankImages: async function (rankImages) {
		try {
			return rankImages.save();
		} catch (e) {
			throw e;
		}
    }, */
    

};