/**
 * User Authentication Service
 * @exports UserAuth/Service
 */
var UserModel = require('../../../models/user');

module.exports = {
	/**
	 * Find User
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	findUser: async function (userAuth) {
		try {
			return await UserModel.findOne({
					$or: [{
						'email': userAuth.email
					}, {
						'userName': userAuth.userName
					}]
				},
				'_id userId email btId userName currentLoginType userStatus');
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Find User by userName
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	findUserByUserName: async function (userAuth) {
		try {
			if (userAuth.userName == '') {
				return false;
			} else {
				return await UserModel.findOne({
						'userName': userAuth.userName
					},
					'_id userId email btId userName currentLoginType userStatus');
			}
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Find User Account (Social Media)
	 * @param {string} loginType - Login type (FB, TW, etc)
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	findUserSocialMedia: async function (loginType, userAuth) {
		try {
			var conditions = {};
			if (loginType == 'FB') {
				conditions = {
					// 'loginTypes.FB.fbToken': userAuth.loginTypes.FB.fbToken,
					'loginTypes.FB.fbId': userAuth.loginTypes.FB.fbId
				};
			}
			return await UserModel.findOne(conditions,
				'_id userId email btId userName userStatus currentLoginType');
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Find active user by Id
	 * @param {Number} userId - User id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	findActiveUserById: async function (userId) {
		try {
			return await UserModel.findOne({ //find the account
				'userId': userId,
				'userStatus': 1
			}, '_id userId pwd currentLoginType');
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Find user by email
	 * @param {string} email - User email
	 * @param {Number} status - User status
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	findUserByEmail: async function (email, status = '') {
		try {
			var conditions = {
				'email': email,
			};
			if (status != '') {
				conditions.userStatus = status;
			}
			return await UserModel.findOne(conditions, '_id userId email pwd btId userStatus currentLoginType');
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Find active user by email and reset code
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	findActiveUserByResetCode: async function (userAuth) {
		try {
			return await UserModel.findOne({ //find the account
				'email': userAuth.email,
				'resetCode': userAuth.resetCode,
				'userStatus': 1
			}, '_id userId');
		} catch (e) {
			throw e;
		}
	},

	/**
	 * User Addition
	 * @param {object} userAuthDBNew - Model object
	 * @returns {object} Response model
	 * @throws {object} e - Error
	 */
	addUser: async function (userAuthDBNew) {
		try {
			return await userAuthDBNew.save();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Social Media vs User Account Merge (only for login users)
	 * @param {string} loginType - Login type (FB, TW, etc)
	 * @param {object} userAuth - User object
	 * @returns {object} Response model
	 * @throws {object} e - Error
	 */
	SMMergeUser: async function (loginType, userAuth) {
		try {
			var conditions = {
				userId: global.userId
			};
			return await UserModel.findOneAndUpdate(conditions, {
				$set: {
					'fName': userAuth.fName,
					'lName': userAuth.lName,
					'loginTypes.FB.fbToken': userAuth.loginTypes.FB.fbToken,
					'loginTypes.FB.fbId': userAuth.loginTypes.FB.fbId,
					'currentLoginType': loginType
				}
			}, {
				new: true,
				fields: 'userId email userName dob btId currentLoginType fName lName balance depositCnt',
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Social Media vs User Account Merge
	 * @param {string} loginType - Login type (FB, TW, etc)
	 * @param {object} userAuth - User object
	 * @returns {object} Response model
	 * @throws {object} e - Error
	 */
	SMMerge: async function (loginType, userAuth) {
		try {
			var conditions = {
				email: userAuth.email
			};
			return await UserModel.findOneAndUpdate(conditions, {
				$set: {
					'fName': userAuth.fName,
					'lName': userAuth.lName,
					'loginTypes.FB.fbToken': userAuth.loginTypes.FB.fbToken,
					'loginTypes.FB.fbId': userAuth.loginTypes.FB.fbId,
					// 'sessions.sessionToken': userAuth.sessions.sessionToken,
					// 'sessions.deviceToken': userAuth.sessions.deviceToken,
					// 'sessions.deviceType': userAuth.sessions.deviceType,
					'currentLoginType': loginType,
					'promoCode': userAuth.promoCode
				},
				$push: {
					'sessions': userAuth.sessions[0]
				}
			}, {
				new: true,
				fields: 'userId email userName dob btId sessions.sessionToken currentLoginType fName lName balance depositCnt',
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Social Media Login
	 * @param {string} loginType - Login type (FB, TW, etc)
	 * @param {object} userAuth - User object
	 * @returns {object} Response model
	 * @throws {object} e - Error
	 */
	SMLogin: async function (loginType, userAuth) {
		try {
			var conditions = {};
			if (loginType == 'FB') {
				conditions = {
					// 'loginTypes.FB.fbToken': userAuth.loginTypes.FB.fbToken,
					'loginTypes.FB.fbId': userAuth.loginTypes.FB.fbId,
					// 'email': userAuth.email
				};
			}
			return await UserModel.findOneAndUpdate(conditions, {
				$set: {
					// 'sessions.sessionToken': userAuth.sessions.sessionToken,
					// 'sessions.deviceToken': userAuth.sessions.deviceToken,
					// 'sessions.deviceType': userAuth.sessions.deviceType,
					'loginTypes.FB.fbToken': userAuth.loginTypes.FB.fbToken,
					'currentLoginType': loginType
				},
				$push: {
					'sessions': userAuth.sessions[0]
				}
			}, {
				new: true,
				fields: 'userId email userName dob btId sessions.sessionToken currentLoginType fName lName balance depositCnt',
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * User Login - Update session
	 * @param {number} userId - User id
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	updateUserSession: async function (userId, userAuth) {
		try {
			return await UserModel.findOneAndUpdate({ //update and get the session token
				'userId': userId
			}, {
				$set: {
					'currentLoginType': userAuth.currentLoginType
				},
				$push: {
					'sessions': userAuth.sessions
				}
			}, {
				new: true,
				fields: 'userId email userName dob btId sessions.sessionToken currentLoginType fName lName balance depositCnt',
			});
		} catch (e) {
			throw e;
		}

		// {
		// 	'sessionToken': userAuth.sessions.sessionToken,
		// 	'deviceToken': userAuth.sessions.deviceToken,
		// 	'deviceType': userAuth.sessions.deviceType
		// }
	},

	/**
	 * User Forgot - Update reset code
	 * @param {number} userId - User id
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	updateResetCode: async function (userId, userAuth) {
		try {
			return await UserModel.findOneAndUpdate({ // update and get the reset password code
				'userId': userId
			}, {
				$set: {
					'resetCode': userAuth.resetCode
				}
			}, {
				new: true,
				fields: 'userId email userName resetCode',
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * User Reset Password
	 * @param {number} userId - User id
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	resetPassword: async function (userId, userAuth) {
		try {
			return await UserModel.findOneAndUpdate({ //update and get the reset session token
				'userId': userId
			}, {
				$set: {
					'resetCode': '',
					'pwd': userAuth.pwd
					// 'sessions.sessionToken': userAuth.sessions.sessionToken
				},
				$push: {
					'sessions': userAuth.sessions
				}
			}, {
				new: true,
				fields: 'userId email userName dob btId sessions.sessionToken currentLoginType fName lName balance depositCnt',
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * User Change Password
	 * @param {number} userId - User id
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	changePassword: async function (userId, userAuth) {
		try {
			return await UserModel.findOneAndUpdate({ // update and get the data
				'userId': userId
			}, {
				$set: {
					'pwd': userAuth.pwd
				}
			}, {
				new: true,
				fields: 'userId email userName dob btId currentLoginType fName lName balance depositCnt',
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * User Logout
	 * @param {number} userId - User id
	 * @param {string} sessionToken - Session Token
	 * @returns {object}  Modal object
	 * @throws {object} e - Error
	 */
	logout: async function (userId, sessionToken) {
		try {
			return await UserModel.findOneAndUpdate({
				'userId': userId
			}, {
				$pull: {
					'sessions': {
						'sessionToken': sessionToken
					}
				}
			}, {
				new: true, // to get the updated record
				fields: 'sessions.sessionToken',
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Update Device Token
	 * @param {number} userId - User id
	 * @param {string} sessionToken - Session Token
	 * @param {object} userAuth - User object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	updateDeviceToken: async function (userId, sessionToken, userAuth) {
		try {
			return await UserModel.findOneAndUpdate({
				'userId': userId,
				'sessions.sessionToken': sessionToken
			}, {
				$set: {
					'sessions.$.deviceToken': userAuth.sessions.deviceToken,
					'sessions.$.deviceType': userAuth.sessions.deviceType,
					'sessions.$.createdAt': Date.now()
				}
			}, {
				new: true,
				fields: 'sessions.deviceToken',
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Update Geo Token
	 * @param {number} userId - User id
	 * @param {string} sessionToken - Session Token
	 * @param {object} geoAuth - Geo object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	updateGeoToken: async function (userId, sessionToken, geoAuth) {
		try {
			return await UserModel.findOneAndUpdate({
				'userId': userId,
				// 'sessions.sessionToken': sessionToken
				'sessions': {
					$elemMatch: {
						'sessionToken': sessionToken
					}
				}
			}, {
				$set: {
					'sessions.$.geoSession': geoAuth
				}
			}, {
				new: true,
				fields: 'userId',
				// fields: 'sessions.sessionToken sessions.geoSession',
			});
		} catch (e) {
			throw e;
		}
	},

};