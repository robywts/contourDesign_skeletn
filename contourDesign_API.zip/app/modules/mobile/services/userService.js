/**
 * User Service
 * @exports User/Service
 */
var UserModel = require('../../../models/user');
var FriendrequestModel = require('../../../models/friendrequest');
var NotificationsModel = require('../../../models/notification');
var WithdrawalModel = require('../../../models/withdrawal');
var TransactionModel = require('../../../models/transaction');
var SettingModel = require('../../../models/setting');

module.exports = {

    /**
     * Get user profile from DB
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getProfile: async function (userId = '') {
        try {
            var userId = userId ? userId : global.userId;
            return await UserModel.findOne({
                'userId': userId
            }, 'userId email btId userName dob fName lName imageName currentLoginType loginTypes.FB.fbId balance depositCnt balanceTickets balanceRewards spendLimits depositLimits referralMoney referrer createdAt sportsRanking rank subRank rankName rankImageName pointsForNextRank pointsForNextSubRank pointsForCurrentRank pointsForCurrentSubRank');
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get user profile from DB by userName
     * @param {integer} userName - user name
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getProfileByUserName: async function (userName = '') {
        try {
            return await UserModel.findOne({
                'userName': userName
            }, 'userId email btId userName dob fName lName imageName currentLoginType loginTypes.FB.fbId balance depositCnt spendLimits depositLimits');
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get users by the array of ids
     * @param {array} userId - user ids
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getUsersByIds: async function (userIds) {
        try {
            return await UserModel.find({
                "userId": {
                    $in: userIds
                }
            })
                .select('userId userName fName lName email btId imageName userStatus loginTypes currentLoginType')
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Update User profile
     * @param {object} userProfile - Data required for update profile
     * @param {integer} userId - user id
     * @returns {Number} Total count of records
     * @throws {object} e - Error
     */
    updateProfile: async function (userProfile, userId) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userId
            }, {
                    $set: userProfile
                }, {
                    new: true
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Update BT Payment Id
     * @param {string} btId - BT Id
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    updateBtId: async function (btId, userId) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userId
            }, {
                    $set: {
                        'btId': btId
                    }
                }, {
                    new: false
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Deposit Money
     * @param {Number} amount - Amount
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    depositMoney: async function (amount, userId) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userId
            }, {
                    $inc: {
                        'totalDeposited': amount,
                        'balance': amount,
                        'depositCnt': 1
                    }
                }, {
                    new: true,
                    fields: 'userId email userName fName lName imageName balance depositCnt totalDeposited balanceTickets balanceRewards referralMoney referrer'
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Deposit Referral Money
     * @param {Number} amount - Amount
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    depositReferralMoney: async function (amount, userId) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userId
            }, {
                    $inc: {
                        'referralMoney': amount,
                        'totalDeposited': amount,
                        'balance': amount,
                        'depositCnt': 1
                    }
                }, {
                    new: true,
                    fields: 'userId email userName fName lName imageName balance depositCnt totalDeposited balanceTickets balanceRewards referralMoney referrer'
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Transefer Tickets to Money
     * @param {Number} amount - Amount
     * @param {Number} remainingTickets - Remaining Tickets
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    // transferTicketToMoney: async function (amount, remainingTickets, userId) {
    //     try {
    //         return await UserModel.findOneAndUpdate({
    //             'userId': userId
    //         }, {
    //             $set: {
    //                 'balanceTickets': remainingTickets
    //             },
    //             $inc: {
    //                 'totalDeposited': amount,
    //                 'balance': amount,
    //                 'depositCnt': 1
    //             }
    //         }, {
    //             new: true,
    //             fields: 'userId email userName fName lName imageName balance depositCnt totalDeposited balanceTickets totalTickets'
    //         });
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     * Transefer Rewards to Money
     * @param {Number} amount - Amount
     * @param {Number} remainingRewards - Remaining Rewards
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    // transferRewardToMoney: async function (amount, remainingRewards, userId) {
    //     try {
    //         return await UserModel.findOneAndUpdate({
    //             'userId': userId
    //         }, {
    //             $set: {
    //                 'balanceRewards': remainingRewards
    //             },
    //             $inc: {
    //                 'totalDeposited': amount,
    //                 'balance': amount,
    //                 'depositCnt': 1
    //             }
    //         }, {
    //             new: true,
    //             fields: 'userId email userName fName lName imageName balance depositCnt totalDeposited balanceRewards totalRewards'
    //         });
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     * Transefer Rewards to Ticket
     * @param {Number} tickets - Tickets
     * @param {Number} remainingRewards - Remaining Rewards
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    transferRewardToTicket: async function (tickets, remainingRewards, userId) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userId
            }, {
                    $set: {
                        'balanceRewards': remainingRewards
                    },
                    $inc: {
                        'balanceTickets': tickets,
                        'totalTickets': tickets
                    }
                }, {
                    new: true,
                    fields: 'userId email userName fName lName imageName balance depositCnt totalDeposited balanceRewards totalRewards balanceTickets totalTickets'
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Add Ticket
     * @param {Number} tickets - Tickets
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    addTicket: async function (tickets, userId) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userId
            }, {
                    $inc: {
                        'balanceTickets': tickets,
                        'totalTickets': tickets
                    }
                }, {
                    new: true,
                    fields: 'userId email userName fName lName imageName balance depositCnt totalDeposited balanceRewards totalRewards balanceTickets totalTickets referralMoney referrer'
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get Admin Settings
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getAdminSettings: async function () {
        try {
            return await SettingModel.findOne({
                'settingId': 1
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get balance 
     * @param {integer} userId - user id 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getBalance: async function (userId) {
        try {
            return await UserModel.findOne({
                'userId': userId
            }, 'userId email btId userName fName lName imageName currentLoginType loginTypes.FB.fbId balance referralMoney depositCnt totalDeposited balanceTickets balanceRewards');
        } catch (e) {
            throw e;
        }
    },

    /**
     * Save/Update withdrawal balance
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    // withdrawalRequest: async function (userId) {
    //     try {
    //         return await UserModel.findOne({
    //             'userId': userId
    //         }, 'withdrawalStatus userId userName fName lName email');
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     * Add withdrawal request  
     * @param {object} withdrawalModel - Withdrawal model object 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    addWithdrawalRequest: async function (withdrawalModel) {
        try {
            return await withdrawalModel.save();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Add a transaction 
     * @param {object} transactionModel - Transaction model object 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    transactionEntry: async function (transactionModel) {
        try {
            return await transactionModel.save();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Save/Update user withdrawal balance 
     * @param {integer} userId - user id  
     * @param {string} status - status  
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    // updateUserWithdrawStatus: async function (userId, status) {
    //     try {
    //         return await UserModel.findOneAndUpdate({
    //             'userId': userId
    //         }, {
    //             $set: {
    //                 "withdrawalStatus": status
    //             }
    //         }, {
    //             new: false
    //         });
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     *  Get withdraw status
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    // withdrawalStatus: async function (userId) {
    //     try {
    //         return await UserModel.findOne({
    //             'userId': userId
    //         }, 'withdrawalStatus');
    //     } catch (e) {
    //         throw e;
    //     }
    // },

    /**
     * Get withdraw requested amount
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    withdrawRequestAmount: async function (userId) {
        try {
            return await WithdrawalModel.aggregate(
                [{
                    $match: {
                        $and: [{
                            'userId': userId
                        },
                            {
                                'requestStatus': {
                                    $in: ['P', 'I']
                                }
                            }
                        ]
                    }
                },
                    {
                        $group: {
                            _id: null,
                            "amount": {
                                $sum: "$amount"
                            }
                        }
                    }
                ]);
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get Withdrawal Requests 
     * @param {object} search - search object
     * @param {number} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    withdrawalRequests: async function (search, userId) {
        try {
            // let searchConditions = [{
            //     $or: [{
            //             'userName': new RegExp(search.search_text, 'i')
            //         },
            //         {
            //             'userEmail': new RegExp(search.search_text, 'i')
            //         }
            //     ]
            // }];
            let searchConditions = [];
            // if (userId != '') {
            searchConditions.push({
                'userId': userId
            });
            // }
            if (search.withdrawalStatus != '') {
                searchConditions.push({
                    'requestStatus': search.withdrawalStatus
                });
            }
            // if (search.multipleStatus.length > 0) {
            //     searchConditions.push({
            //         'request_status': {
            //             $in: search.multipleStatus
            //         }
            //     });
            // }
            // if (search.request_status != '') {
            //     searchConditions.push({
            //         'requestStatus': search.request_status
            //     });
            // }
            // if (search.from_date != '') {
            //     var dt = search.from_date.split('/');
            //     searchConditions.push({
            //         'createdAt': {
            //             $gte: new Date(dt[2] + '-' + dt[0] + '-' + dt[1])
            //             // $gte: new Date("2018-03")
            //         }
            //     });
            // }
            // if (search.to_date != '') {
            //     var dt = search.to_date.split('/');
            //     searchConditions.push({
            //         'createdAt': {
            //             $lte: new Date(dt[2] + '-' + dt[0] + '-' + dt[1])
            //             // $gte: new Date("2018-03")
            //         }
            //     });
            // }

            return await WithdrawalModel.find({
                $and: searchConditions
            })
                .select('requestStatus amount paymentType createdAt updatedAt')
                .limit(search.limit)
                .skip(search.limit * search.page)
                .sort({
                    // [search.sort_field]: search.sort_order
                    'createdAt': 'desc'
                })
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get Withdrawal Requests  count
     * @param {object} search - search object   
     * @param {number} userId - user id 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    withdrawalRequestsCount: async function (search, userId) {
        try {
            // let searchConditions = [{
            //     $or: [{
            //             'userName': new RegExp(search.search_text, 'i')
            //         },
            //         {
            //             'userEmail': new RegExp(search.search_text, 'i')
            //         }
            //     ]
            // }];
            let searchConditions = [];
            // if (userId != '') {
            searchConditions.push({
                'userId': userId
            });
            // }
            if (search.withdrawalStatus != '') {
                searchConditions.push({
                    'requestStatus': search.withdrawalStatus
                });
            }
            // if (search.request_status != '') {
            //     searchConditions.push({
            //         'requestStatus': search.request_status
            //     });
            // }
            // if (search.from_date != '') {
            //     var dt = search.from_date.split('/');
            //     searchConditions.push({
            //         'createdAt': {
            //             $gte: new Date(dt[2] + '-' + dt[0] + '-' + dt[1])
            //             // $gte: new Date("2018-03")
            //         }
            //     });
            // }
            // if (search.to_date != '') {
            //     var dt = search.to_date.split('/');
            //     searchConditions.push({
            //         'createdAt': {
            //             $lte: new Date(dt[2] + '-' + dt[0] + '-' + dt[1])
            //             // $gte: new Date("2018-03")
            //         }
            //     });
            // }

            return await WithdrawalModel.count({
                $and: searchConditions
            }).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get transactions
     * @param {object} search - search object
     * @param {number} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getTransactions: async function (search, userId) {
        try {
            let searchConditions = [];
            searchConditions.push({
                'userId': userId
            });
            if (search.tranType != '') {
                searchConditions.push({
                    'tranType': search.tranType
                });
            }

            return await TransactionModel.find({
                $and: searchConditions
            })
                .select('tranStatus amount tranType entryDate updatedAt')
                .limit(search.limit)
                .skip(search.limit * search.page)
                .sort({
                    'entryDate': 'desc'
                })
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get transactions amounts
     * @param {string} searchType - Deposit or some thing else (D - for deposit)
     * @param {number} userId - user id
     * @param {string} searchPeriod - daily/weekly/monthly
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getTransactionAmounts: async function (searchType, userId, searchPeriod) {
        try {
            var dt = new Date();
            var lastWeek = new Date();
            var lastMonth = new Date();
            dt.setHours(0, 0, 0, 0); // daily
            lastWeek.setDate(lastWeek.getDate() - 7);
            lastMonth.setDate(lastMonth.getDate() - 30);

            if (searchPeriod == 'monthly') {
                dt = lastMonth;
            } else if (searchPeriod == 'weekly') {
                dt = lastWeek;
            }
            var amount = await TransactionModel.aggregate(
                [{
                    $match: {
                        $and: [{
                            'userId': userId
                        },
                            {
                                'tranType': searchType
                            },
                            {
                                'entryDate': {
                                    $gte: dt
                                    // $gte: new Date('2018-06-27')
                                }
                            }
                        ]
                    }
                },
                    {
                        $group: {
                            _id: null,
                            "amount": {
                                $sum: "$amount"
                            }
                        }
                    }
                ]);
            if (amount.length == 0) {
                amount.push({
                    _id: null,
                    amount: 0
                });
            }
            return amount;
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get transactions count
     * @param {object} search - search object   
     * @param {number} userId - user id 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getTransactionsCount: async function (search, userId) {
        try {
            let searchConditions = [];
            searchConditions.push({
                'userId': userId
            });
            if (search.tranType != '') {
                searchConditions.push({
                    'tranType': search.tranType
                });
            }

            return await TransactionModel.count({
                $and: searchConditions
            }).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get user balance from DB
     * @param {Number} userId - user Id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getUserBalance: async function (userId) {
        try {
            return await UserModel.findOne({
                'userId': userId
            }, 'balance');
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get notifications
     * @param {object} pagination - pagination object 
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getNotifications: async function (pagination, userId) {
        try {
            return await NotificationsModel.find({
                'userId': parseInt(userId)
            })
                .select('_id message createdAt isRead')
                .limit(pagination.limit)
                .skip(pagination.limit * pagination.page)
                .sort({
                    createdAt: 'desc'
                })
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get notification count
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getNotificationsCount: async function (userId) {
        try {
            return await NotificationsModel.count({
                'userId': userId

            }).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     *  update notifications
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    updateNotification: async function (userId) {
        try {
            return await NotificationsModel.update({
                'userId': userId
            }, {
                    $set: {
                        "isRead": 1
                    }
                }, {
                    "multi": true,
                    new: false
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get user settings by userid
     * @param {object} userDB - settings object
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    updateSettings: async function (userDB) {
        try {
            return await userDB.save();
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get user profile from DB
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getSettings: async function (userId) {
        try {
            return await UserModel.findOne({
                'userId': userId
            }, 'spendLimits depositLimits');
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get users 
     * @param {object} search - search object 
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    listUsers: async function (search, userId) {
        try {
            return await UserModel.find({
                $and: [{
                    $or: [{
                        'email': new RegExp(search.search_text, 'i')
                    },
                        {
                            'fName': new RegExp(search.search_text, 'i')
                        },
                        {
                            'lName': new RegExp(search.search_text, 'i')
                        },
                        {
                            'userName': new RegExp(search.search_text, 'i')
                        }
                    ]
                }, {
                        "userId": {
                            $ne: userId
                        }
                    }, {
                        "isAdmin": false
                    }]
            })
                .select('userId fName lName userName btId email friends imageName isFollows currentLoginType loginTypes')
                .limit(search.limit)
                .skip(search.limit * search.page)
                .sort({
                    email: 'asc'
                })
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get users count
     * @param {object} search - search object 
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    listUsersCount: async function (search, userId) {
        try {
            return await UserModel.count({
                $and: [{
                    $or: [{
                        'email': new RegExp(search.search_text, 'i')
                    },
                        {
                            'fName': new RegExp(search.search_text, 'i')
                        },
                        {
                            'lName': new RegExp(search.search_text, 'i')
                        },
                        {
                            'userName': new RegExp(search.search_text, 'i')
                        }
                    ]
                }, {
                        "userId": {
                            $ne: userId
                        }
                    }, {
                        "isAdmin": false
                    }]
            }).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get users in FB friend list
     * @param {object} search - search object 
     * @param {integer} userId - user id
     * @param {Array} FbIds - Fb ids
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    listFBUsers: async function (search, userId, FbIds) {
        try {
            return await UserModel.find({
                $and: [{
                    $or: [{
                        'email': new RegExp(search.search_text, 'i')
                    },
                        {
                            'fName': new RegExp(search.search_text, 'i')
                        },
                        {
                            'lName': new RegExp(search.search_text, 'i')
                        },
                        {
                            'userName': new RegExp(search.search_text, 'i')
                        }
                    ]
                }, {
                        "userId": {
                            $ne: userId
                        }
                    }, {
                        'loginTypes.FB.fbId': {
                            $in: FbIds
                        }
                    }]
            })
                .select('userId fName lName userName btId email imageName currentLoginType loginTypes')
                .limit(search.limit)
                .skip(search.limit * search.page)
                .sort({
                    email: 'asc'
                })
                .exec();

        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get users in FB friends count
     * @param {object} search - search object 
     * @param {integer} userId - user id
     * @param {Array} FbIds - Fb ids
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    listFBUsersCount: async function (search, userId, FbIds) {
        try {
            return await UserModel.count({
                $and: [{
                    $or: [{
                        'email': new RegExp(search.search_text, 'i')
                    },
                        {
                            'fName': new RegExp(search.search_text, 'i')
                        },
                        {
                            'lName': new RegExp(search.search_text, 'i')
                        },
                        {
                            'userName': new RegExp(search.search_text, 'i')
                        }
                    ]
                }, {
                        "userId": {
                            $ne: userId
                        }
                    }, {
                        'loginTypes.FB.fbId': {
                            $in: FbIds
                        }
                    }]
            }).exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Check friend request already sent or not
     * @param {object} search - search object 
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    checkFriendrequest: async function (search, userId) {
        try {
            return await FriendrequestModel.findOne({
                $and: [{
                    'fromUserId': userId
                }, {
                        "toUserId": friendRequest.toUserId
                    }]
            }, 'userId');

        } catch (e) {
            throw e;
        }
    },

    /**
     *  Cehck friend request already sent or not
     * @param {object} search - search object 
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    checkFriendrequestBoth: async function (search, userId) {
        try {
            return await FriendrequestModel.findOne({
                $and: [{
                    $and: [{
                        'fromUserId': userId
                    }, {
                            "toUserId": search.toUserId
                        }],
                    $and: [{
                        'fromUserId': search.toUserId
                    }, {
                            "toUserId": userId
                        }]
                }]
            }, 'userId');

        } catch (e) {
            throw e;
        }
    },

    /**
     * Sent friend request
     * @param {object} friendRequestModel - friendRequest Model object 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    sendFriendrequest: async function (friendRequestModel) {
        try {
            return await friendRequestModel.save();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Set friends
     * @param {object} userdata - user object 
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    setFriendrequestFollowing: async function (userdata, userId) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userId
            }, {
                    $push: {
                        isFollowing: userdata
                    }
                }, {
                    safe: true,
                    upsert: true
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Set friends
     * @param {object} userdata - user object 
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    setFriendrequestFollows: async function (userdata, userId) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userdata
            }, {
                    $push: {
                        isFollows: userId
                    }
                }, {
                    safe: true,
                    upsert: true
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get user's Is Following from DB
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getIsFollowing: async function (userId) {
        try {
            var userId = userId ? userId : global.userId;
            return await UserModel.findOne({
                'userId': userId
            }, 'isFollowing isFollows');
        } catch (e) {
            throw e;
        }
    },



    /**
     * Cehck friend request already sent or not
     * @param {object} friendRequestResponse - friend request object 
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    checkFriendrequestStatus: async function (friendRequestResponse, userId) {
        try {
            return await FriendrequestModel.findOne({
                $and: [{
                    'toUserId': userId
                }, {
                        "fromUserId": friendRequestResponse.fromUserId
                    }]
            }, '_id requestStatus');

        } catch (e) {
            throw e;
        }
    },

    /**
     * Set friends
     * @param {object} userdata - user object 
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    setFriends: async function (userdata, userId) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userId
            }, {
                    $push: {
                        friends: userdata
                    }
                }, {
                    safe: true,
                    upsert: true
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Update friendrequest status
     * @param {integer} userId - user id
     * @param {object} friendRequestResponse - friend request object 
     * @param {integer} friendRequestResponse - response value
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    updateFriendrequestStatus: async function (userDataResponse, userId, friendRequestResponse) {
        try {
            return await FriendrequestModel.findOneAndUpdate({
                $and: [{
                    'toUserId': userId
                }, {
                        "fromUserId": friendRequestResponse.fromUserId
                    }]
            }, {
                    $set: userDataResponse
                }, {
                    new: false

                });

        } catch (e) {
            throw e;
        }
    },

    /**
     * Update friendrequest status
     * @param {integer} userId - user id
     * @param {object} friendRequestResponse - friend request object 
     * @param {integer} friendRequestResponse - response value
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    updateFriendrequestStatusBoth: async function (toUserId, userId) {
        try {
            return await FriendrequestModel.findOneAndUpdate({
                $and: [{
                    'toUserId': userId
                }, {
                        "fromUserId": toUserId
                    }, {
                        "requestStatus": 0
                    }]
            }, {
                    $set: {
                        "requestStatus": 1
                    }
                }, {
                    new: false

                });

        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get Friend Requests
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getFriendRequest: async function (userId) {
        try {
            return await FriendrequestModel.find({
                $and: [{
                    'toUserId': global.userId
                }, {
                        "requestStatus": 0
                    }]
            })
                .select('fromUserId fromUserName fromUserImg fName lName')
                .exec();

        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get received Friend Requests
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getSentFriendRequest: async function (userId) {
        try {
            return await FriendrequestModel.find({
                $and: [{
                    'toUserId': userId
                }]
            })
                .select('fromUserId toUserName toUserImg')
                .exec();

        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get Sent Friend Requests
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getSentFriendRequest1: async function (userId) {
        try {
            return await FriendrequestModel.find({
                $and: [{
                    'fromUserId': userId
                }]
            })
                .select('toUserId toUserName toUserImg')
                .exec();

        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get Friends Ids
     * @param {integer} userId - user id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getFriendsIds: async function (userId) {
        try {
            return await UserModel.findOne({
                'userId': userId
            }, 'friends');
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get Friends List
     * @param {Array} friendsID - friends list array 
     * @param {object} search - search object 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    listFriends: async function (search, friendsID) {
        try {
            return await UserModel.find({
                $and: [{
                    $or: [{
                        'email': new RegExp(search.search_text, 'i')
                    },
                        {
                            'fName': new RegExp(search.search_text, 'i')
                        },
                        {
                            'lName': new RegExp(search.search_text, 'i')
                        },
                        {
                            'userName': new RegExp(search.search_text, 'i')
                        }
                    ]
                }, {
                        'userId': {
                            $in: friendsID
                        }
                    }]
            })
                .select('userId fName lName btId userName email imageName currentLoginType loginTypes friends')
                .limit(search.limit)
                .skip(search.limit * search.page)
                .exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get Friends List count
     * @param {Array} friendsID - friends list array 
     * @param {object} search - search object 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    listFriendsCount: async function (search, friendsID) {
        try {
            return await UserModel.count({
                $and: [{
                    $or: [{
                        'email': new RegExp(search.search_text, 'i')
                    },
                        {
                            'fName': new RegExp(search.search_text, 'i')
                        },
                        {
                            'lName': new RegExp(search.search_text, 'i')
                        },
                        {
                            'userName': new RegExp(search.search_text, 'i')
                        }
                    ]
                }, {
                        'userId': {
                            $in: friendsID
                        }
                    }]
            }).exec();

        } catch (e) {
            throw e;
        }
    },

    /**
     * Cehck friend exists or not
     * @param {object} unfriend - friend object 
     * @param {integer} userId - user id 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    checkFriendStatus: async function (unfriend, userId) {
        try {
            return await UserModel.find({
                $and: [{
                    'userId': userId
                }, {
                        "friends": unfriend.friendId
                    }]
            }, '_id');

        } catch (e) {
            throw e;
        }
    },

    /**
     * Remove friend from friends collection
     * @param {object} unfriend - friend object 
     * @param {integer} userId - user id 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    unfriendRequest: async function (unfriend, userId) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userId
            }, {
                    '$pull': {
                        'friends': unfriend
                    },
                });
        } catch (e) {
            throw e;
        }
    },


    /**
     * Remove Is Following from user collection
     * @param {object} unfriend - friend object 
     * @param {integer} userId - user id 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    removeIsFollowing: async function (userId, unfriend) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userId
            }, {
                    '$pull': {
                        'isFollowing': unfriend
                    },
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Remove IsFollows from user collection
     * @param {object} unfriend - friend object 
     * @param {integer} userId - user id 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    removeIsFollows: async function (userId, unfriend) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': unfriend
            }, {
                    '$pull': {
                        'isFollows': userId
                    },
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Remove friend from friend request collection
     * @param {object} unfriend - friend object 
     * @param {integer} userId - user id 
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    removeFriend: async function (unfriend, userId) {
        try {
            return await FriendrequestModel.find({
                $and: [{
                    'fromUserId': userId
                }, {
                        "toUserId": unfriend.friendId
                    }]
            }).remove().exec();
        } catch (e) {
            throw e;
        }
    },

    /**
     * Update Profile Image
     * @param {object} userAuthDB - user object
     * @param {string} imageName - image name
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    updateprofileImage: async function (imageName, userAuthDB) {
        try {
            return await UserModel.findOneAndUpdate({
                'userId': userAuthDB.userId
            }, {
                    $set: {
                        'imageName': imageName
                    }
                }, {
                    new: false
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Update User Balance
     * @param {object} deductAmount - amount to be deducted from user balance
     * @param {integer} userId - user id
     * @returns {Number} Total count of records
     * @throws {object} e - Error
     */
    updateBalance: async function (deductAmount, appUserId = global.userId) {
        try {
            return await UserModel.update({
                'userId': appUserId
            }, {
                    $inc: {
                        "balance": -deductAmount
                    }
                }, {
                    new: true
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Add User Balance
     * @param {object} addAmount - amount added to user balance
     * @param {integer} userId - user id
     * @returns {Number} Total count of records
     * @throws {object} e - Error
     */
    addBalance: async function (addAmount, userId = global.userId) {
        try {
            return await UserModel.update({
                'userId': userId
            }, {
                    $inc: {
                        "balance": addAmount
                    }
                }, {
                    new: true
                });
        } catch (e) {
            throw e;
        }
    },

    /**
    * Update referral Money
    * @param {object} deductAmount - amount to be deducted from user balance   
    * @returns {Number} Total count of records
    * @throws {object} e - Error
    */
    updateReferralMoney: async function (deductAmount, appUserId = global.userId) {
        try {
            return await UserModel.update({
                'userId': appUserId
            }, {
                    $inc: {
                        "referralMoney": -deductAmount
                    }
                }, {
                    new: true
                });
        } catch (e) {
            throw e;
        }
    },

    /**
  * Add User Referral Money
  * @param {object} addAmount - amount added to user balance  
  * @returns {Number} Total count of records
  * @throws {object} e - Error
  */
    addReferralMoney: async function (addAmount, userId = global.userId) {
        try {
            return await UserModel.update({
                'userId': userId
            }, {
                    $inc: {
                        "referralMoney": addAmount
                    }
                }, {
                    new: true
                });
        } catch (e) {
            throw e;
        }
    },

    /**
* Update Transaction Status 
* @param {object} userId - user's id
* @param {string} transactionId - transactionId
* @returns {object} Result set object
* @throws {object} e - Error
*/
    updateTransactionStatus: async function (userId, transactionId, transactionData) {
        try {
            return await TransactionModel.findOneAndUpdate({
                "_id": transactionId, "userId": userId
            }, {
                    $set: transactionData
                }, {
                    new: false
                });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get users by the array of ids
     * @param {array} userId - user ids
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getAllParticipantsH2H: async function (userIds) {
        try {
            return await UserModel.find({
                "userId": {
                    $in: userIds
                }
            })
                .select('userId sportsRanking')
                .exec();
        } catch (e) {
            throw e;
        }
    },

};