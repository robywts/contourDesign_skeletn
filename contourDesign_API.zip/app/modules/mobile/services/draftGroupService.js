/**
 * DraftGroup Service
 * @exports User/Service
 */
var DraftGroupModel = require('../../../models/draftgroup');

module.exports = {

    /**
     *  Get draftgroup from DB
     * @param {object} week - Data required for getting draftgroups
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getDraftGroup: async function (request, date) {
        try {            
            var conestStatus;
            if (request.status && request.status != '') {
                if(request.status == 1) { conestStatus = "Completed"; } else if(request.status == 2){ conestStatus = "Live"; } else { conestStatus = "Upcoming"; }
				 
            }else {  conestStatus = ["Upcoming","Live","Completed"]; }  

            return await DraftGroupModel.find({
                "dgState": {
                    $in: conestStatus
                },					
				'startTimeUTC': {
						$gt: date
					}
            }, 'draftgroupId dgName gameList league sortOrder startTimeUTC dgState sportId ');
        } catch (e) {
            throw e;
        }
    },

    /**
     *  Get draftgroup from DB
     * @param {object} id - draftgroup id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getDraftGroupDetails: async function (draftgroupId) {
        try {
            return await DraftGroupModel.findOne({
                'draftgroupId': draftgroupId,
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get draftgroup's contest list from DB
     * @param {object} id - draftgroup id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getDraftGroupContest: async function (draftgroupId) {
        try {
            return await DraftGroupModel.findOne({
                'draftgroupId': draftgroupId,
            }, 'contestList');
        } catch (e) {
            throw e;
        }
    },

    /**
	 * Get draftgroup's contest list details from DB
	 * @param {object} array - contest ids
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
    getDraftgroupGames: async function (draftgroupId) {
        try {
            return await DraftGroupModel.find({
                'draftgroupId': draftgroupId
            }, 'gameList league');
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get draftgroup's players list from DB
     * @param {object} id - draftgroup id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getDraftGroupPlayers: async function (draftgroupId) {
        try {
            return await DraftGroupModel.findOne({
                'draftgroupId': draftgroupId,
            }, 'sportId gameList');
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get player details from DB
     * @param {object} array - contest ids
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getPlayerDataFromDraftgroup: async function (lineupData, playerIndex) {
        try {
            return await DraftGroupModel.aggregate([
                { "$match": { draftgroupId: lineupData.draftgroupId } },
                { "$unwind": "$gameList" },
                { "$match": { "gameList.eventId": lineupData.players[playerIndex].eventId } },
                { "$unwind": "$gameList.players" },
                { "$match": { "gameList.players.playerId": lineupData.players[playerIndex].playerId } },
                // Tidy up the output
                { "$project": { _id: 0, players: "$gameList.players", st: "$gameList.startTimeUTC" } }
            ])
        } catch (e) {
            throw e;
        }
    },

    /**
     * Add contest to draftgroup
     * @param {object} draftgroupId - draftgroup id
     * @param {object} draftgroupId - contest id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    addContest: async function (draftgroupId, contestId) {
        try {
            return await DraftGroupModel.findOneAndUpdate({ draftgroupId: draftgroupId }, { $push: { contestList: contestId } });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get min salary details w.r.t position in a draftgroup from DB
     * @param {object} draftgroupId - draftgroup id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getMinSalaryNBAMLBNHLDraftgroup: async function (dgId) {
        try {
            return await DraftGroupModel.aggregate(
                [
                    { "$match": { draftgroupId: parseInt(dgId) } },
                    { $unwind: "$gameList" },
                    { $unwind: "$gameList.players" },
                    { "$match": { "gameList.players.fanProjSalary": { "$gte": 1 } } },
                    {
                        $group:
                        {
                            _id: "$gameList.players.posGen",
                            min: { $min: "$gameList.players.fanProjSalary" }
                        }
                    }
                ]
            );
        } catch (e) {
            throw e;
        }
    },

    
    /**
     * Get min salary details w.r.t position in a draftgroup from DB
     * @param {object} draftgroupId - draftgroup id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getMinSalaryNFLGOLFDraftgroup: async function (dgId) {
        try {
            return await DraftGroupModel.aggregate(
                [
                    { "$match": { draftgroupId: parseInt(dgId) } },
                    { $unwind: "$gameList" },
                    { $unwind: "$gameList.players" },
                    { "$match": { "gameList.players.fanProjSalary": { "$gte": 1 } } },
                    {
                        $group:
                        {
                            _id: "$gameList.players.posAbbr",
                            min: { $min: "$gameList.players.fanProjSalary" },
                        }
                    }
                ]
            );
        } catch (e) {
            throw e;
        }
    },

};