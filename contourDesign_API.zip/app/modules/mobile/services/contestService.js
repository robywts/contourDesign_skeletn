/**
 * Contest Service
 * @exports Contest/Service
 */
var ContestModel = require('../../../models/contest');

module.exports = {
	/**
	 * Get all contests from DB
	 * @param {object} search - Data required for search
	 * @param {object} contest - contest object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getAll: async function (search, contest, date) {
		try {			

			if (contest.status && contest.status != '') {
				var conestStatus =contest.status;
            }else {var conestStatus = [1,2,3,4];}    
			var contestTypeIds = (!contest.contestTypeId) ? [1, 2] : contest.contestTypeId;
			var sportIds = (!contest.sportId) ? [1, 2, 3, 4, 5] : contest.sportId;
			return await ContestModel.find({
					'contestName': new RegExp(search.search_text, 'i'),
					'sportId': {
						$in: sportIds
					},
					'visibility': contest.visibility,
					'contestStatus': {
						$in: conestStatus
					},
					'contestTypeId': {
						$in: contestTypeIds
					},					
					'contestStartTime': {
						$gt: date
					},
				})
				//.select('_id contestId sName draftgroupId sportId contestName contestStartTime contestGroupId prizePool sort rewards isGuaranteed contestTypeId contestType maxEntriesPerUser maxLimit entryFees description visibility gameType gameTypeId isVideoAvailable attributes labels createdBy entrants contestStatus')
				//.limit(parseInt(search.limit))
				//.skip(search.limit * search.page)
				.sort({
					[search.sort_field]: search.sort
				})
				.exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get total count of contents
	 * @param {object} search - Data required for search
	 * @param {object} contestsDB - contest object
	 * @returns {Number} Total count of records
	 * @throws {object} e - Error
	 */
	getAllCount: async function (search, contestsDB) {
		try {
			var contestTypeIds = (!contestsDB.contestTypeId) ? [1, 2] : contestsDB.contestTypeId;
			var sportIds = (!contestsDB.sportId) ? [1, 2, 3, 4, 5] : contestsDB.sportId;
			return await ContestModel.count({
				'contestName': new RegExp(search.search_text, 'i'),
				'sportId': {
					$in: sportIds
				},
				'visibility': contestsDB.visibility,
				'contestStatus': contestsDB.contestStatus,
				'contestTypeId': {
					$in: contestTypeIds
				},
			}).exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get one record from DB
	 * @param {Number} id - Id of the record
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getOne: async function (id) {
		try {
			return await ContestModel.findOne({
				'contestId': id
			});
		} catch (e) {
			throw e;
		}
	},


	/**
	 * Add a contest to db
	 * @param {object} contestModel - Model object mapped to the data to be added
	 * @returns {object} Modal object
	 * @throws {object} e - Error
	 */
	add: async function (contestModel) {
		try {
			return await ContestModel.update({
				'contestId': contestModel.contestId
			}, contestModel, {
				new: true,
				upsert: true
			});
		} catch (e) {
			throw e;
		}
	},


	/**
	 * Update a contest to db
	 * @param {Number} id - Request object (id of the record)
	 * @param {object} contest - Object mapped to the data to be added
	 * @param {object} draftgroupId - draftgroup Id
	 * @returns {object} Response object
	 * @throws {object} e - Error
	 */
	update: async function (id, contest, draftgroupId) {
		try {
			return await ContestModel.update({
				contestId: id,
				draftgroupId: draftgroupId
			}, contest);
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Delete a contest
	 * @param {Number} id Request id of the record
	 * @returns {object} Delete Object
	 * @throws {object} e - Error
	 */
	delete: async function (id) {
		try {
			return await ContestModel.remove({
				contestId: id
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get draftgroup's contest list details from DB
	 * @param {object} array - contest ids
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getDraftGroupContestDetails: async function (contest) {
		try {
			return await ContestModel.find({
				'contestId': {
					$in: contest.contestList
				}
			}, 'contestId contestName entryFees contestTypeId contestType gameType gameTypeId');
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get user's contest list details from DB
	 * @param {object} search - Data required for search
	 * @param {object} request - Request object with request parameters
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getUserContest: async function (search, request) {
		try {
			return await ContestModel.find({
					$and: [{
						"contestTypeId": request.contestTypeId
					}, {
						"sportId": request.sportId
					}, {
						$or: [{
							"entrants.userId": global.userId
						}, {
							"createdBy": global.userId
						}]
					}]
				}).select('_id contestId sName draftgroupId sportId contestName contestStartTime contestGroupId prizePool sort rewards isGuaranteed contestTypeId contestType maxEntriesPerUser maxLimit entryFees description visibility gameType gameTypeId isVideoAvailable attributes labels createdBy entrants contestStatus')
				.sort({
					[search.sort_field]: search.sort
				})
				//.limit(parseInt(search.limit))
				//.skip(search.limit * search.page)
				.exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get user's contest list details from DB
	 * @param {object} request - Request object with request parameters
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getUserContestAll: async function (request) {
		try {
			return await ContestModel.count({
				$and: [{
					"contestTypeId": request.contestTypeId
				}, {
					"sportId": request.sportId
				}, {
					$or: [{
						"entrants.userId": global.userId
					}, {
						"createdBy": global.userId
					}]
				}]
			}).exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Add user to contest Schema
	 * @param {object} contestId - contest Id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	addEntrantsToContest: async function (contestId, appUserId = global.userId) {
		try {
			/*return await ContestModel.update({ 'contestId': contestId, 'entrants.userId': global.userId },
				{$push: {entrants:  {userId:global.userId, $inc: { totalentry: 1 }}} },
				{ upsert: true, safe: true },
				function (err, doc) {
				});*/

			return await ContestModel.findOne({
					'contestId': contestId,
					'entrants.userId': appUserId
				},
				async function (err, doc) {
					if (doc != null) {
						return await ContestModel.update({
							'contestId': contestId,
							'entrants.userId': appUserId
						}, {
							$inc: {
								'entrants.$.totalentry': 1
							}
						});
					} else {
						return await ContestModel.update({
							'contestId': contestId,
						}, {
							$push: {
								"entrants": {
									"userId": appUserId,
									"joinDate": new Date().toISOString(),
									"totalentry": 1
								}
							}
						});
					}
				});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get all Featured contests from DB
	 * @param {object} search - Data required for search
	 * @param {object} contest - contest object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getAllFeatured: async function (search, contest) {
		try {
			return await ContestModel.find({
					'contestName': new RegExp(search.search_text, 'i'),
					'visibility': contest.visibility,
					'contestStatus': {
						$in: [2, 3]
					},
					'labels': {
						$in: ['Featured']
					},
				})
				//.select('_id contestId contestName contestType contestTypeId gameType gameTypeId entryFees description visibility contestStatus entrants maxEntriesPerUser maxLimit')
				.limit(parseInt(search.limit))
				.skip(search.limit * search.page)
				.sort({
					[search.sort_field]: search.sort
				})
				.exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get total count of Featured contents
	 * @param {object} search - Data required for search
	 * @param {object} contestsDB - contest object
	 * @returns {Number} Total count of records
	 * @throws {object} e - Error
	 */
	getAllFeaturedCount: async function (search, contestsDB) {
		try {
			return await ContestModel.count({
				'contestName': new RegExp(search.search_text, 'i'),
				'visibility': contestsDB.visibility,
				'contestStatus': {
					$in: [2, 3]
				},
				'labels': {
					$in: ['Featured']
				},
			}).exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get user's all contest list details from DB
	 * @param {object} search - Data required for search
	 * @param {object} sportId - sport id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getAllUserContest: async function (search, sportId, date) {
		try {
           
			if (status && status != '') {
				var conestStatus =status;
            }else { var conestStatus = [1,2,3,4]; }         
   
			return await ContestModel.find({
					$and: [{
						"sportId": {
							$in: sportId
						}
					}, {
						$or: [{
							"entrants.userId": global.userId
						}, {
							"createdBy": global.userId
						}]
					},{
						"contestStatus": {
							$in: conestStatus
						}
					},{
						"contestStartTime": {
							$gt: date
						}
					}]
				})
				//.select('_id contestId sName draftgroupId sportId contestName contestStartTime contestGroupId prizePool sort rewards isGuaranteed contestTypeId contestType maxEntriesPerUser maxLimit entryFees description visibility gameType gameTypeId isVideoAvailable attributes labels createdBy //entrants')
				.sort({
					[search.sort_field]: search.sort
				})
				//.sort({ 'contestName': search.sort })
				//.limit(parseInt(search.limit))
				//.skip(search.limit * search.page)
				.exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get user's  all contest list details from DB
	 * @param {object} sportId - sport id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getAllMyUserContestAll: async function (sportId) {
		try {
			return await ContestModel.count({
				$and: [{
					"sportId": {
						$in: sportId
					}
				}, {
					$or: [{
						"entrants.userId": global.userId
					}, {
						"createdBy": global.userId
					}]
				}]
			}).exec();
		} catch (e) {
			throw e;
		}
	},


	/**
	 * Get user H2H contest list for Rival
	 * @param {object} contest - contest object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getUserAllH2HContest: async function (contest) {
		try {
			return await ContestModel.find({
				'sportId': contest.sportId,
				'visibility': contest.visibility,
				'contestTypeId': 2,
				'entrants.userId': global.userId,
				'contestStatus':1
			}).select('_id contestId createdBy entrants').exec();
		} catch (e) {
			throw e;
		}
	},

		/**
	 * Get user H2H contest list for Rival
	 * @param {object} contest - contest object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getUserAllMyH2HContest: async function () {
		try {
			return await ContestModel.find({				
				'visibility': 'Public',
				'contestTypeId': 2,
				'entrants.userId': global.userId,
				//'contestStatus':1
				'contestStatus':{$in : [1,2]}
			}).select('_id contestId createdBy entrants').exec();
		} catch (e) {
			throw e;
		}
	},


	/**
	 * Get contest created now by app user from DB
	 * @param {object} contestId - contest id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getContestCreated: async function (contestId) {
		try {
			return await ContestModel.find({
					contestId: contestId
				}).select('_id contestId sName draftgroupId sportId contestName contestStartTime contestGroupId prizePool sort rewards isGuaranteed contestTypeId contestType maxEntriesPerUser maxLimit entryFees description visibility gameType gameTypeId isVideoAvailable attributes labels createdBy entrants')
				.exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get user's  particular Contest from DB
	 * @param {object} contestId - contest id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getMyContestDetail: async function (contestId) {
		try {
			return await ContestModel.findOne({
				"createdBy": global.userId,
				"contestId": contestId
			}).exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Update Entrance Count
	 * @param {object} contestId - contest id  
	 * @returns {Number} Total count of records
	 * @throws {object} e - Error
	 */
	updateEntranceCount: async function (contestId) {
		try {
			return await ContestModel.update({
				'contestId': contestId,
				'entrants.userId': global.userId
			},{
				$inc: {
					"entrants.$.totalentry": -1
				}
			});
		} catch (e) {
			throw e;
		}
	},

		/**
	 * Remove a user Entrance
	 * @param {object} contestId - contest id  
	 * @returns {Number} Total count of records
	 * @throws {object} e - Error
	 */
	removeUserEntrance: async function (contestId) {
		try {
			return await ContestModel.findOneAndUpdate({
				'contestId': contestId,
				'entrants.userId': global.userId
			}, {
				'$pull': {
					'entrants':{ 'userId': global.userId }
				}
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get particular Contest from DB
	 * @param {object} contestId - contest id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getContestDetail: async function (contestId) {
		try {
			return await ContestModel.findOne({				
				"contestId": contestId
			}).exec();
		} catch (e) {
			throw e;
		}
	},

	 /**
     * Update contest ownership 
     * @param {object} userId - user's id
     * @param {string} contestId - contestId
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    updateContestOwnership: async function (userId, contestId) {
        try {
            return await ContestModel.findOneAndUpdate({
                "contestId": contestId
            }, {
                $set: {
                    'createdBy': userId
                }
            }, {
                new: false
            });
        } catch (e) {
            throw e;
        }
	},
	
	/**
	 * Get contests Fee
	 * @param {object} contestIds - contest ids
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getContestFee: async function (contestIds) {
		try {		
			return await ContestModel.find({				
					'contestId': {
						$in: contestIds
					}
				})
				.select('contestId entryFees entrants')			
				.exec();
		} catch (e) {
			throw e;
		}
	},
	
	/**
	 * Get all contest in a group
	 * @param {object} contestGroupId - contest GroupId	
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getGroupContests: async function (contestGroupId) {
		try {
			return await ContestModel.find({
				contestGroupId: contestGroupId
				}).select('contestId entrants')
				.exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get available auto contest
	 * @param {object} contestDetails - contest object	
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getAutoContestSimilar: async function (contestDetails) {
		try {
			return await ContestModel.findOne({
				contestName: contestDetails.contestName,
				draftgroupId:contestDetails.draftgroupId,
				contestTypeId:contestDetails.contestTypeId,
				gameTypeId:contestDetails.gameTypeId,
				entryFees:contestDetails.entryFees,
				autoId: { "$exists": true },
				$or:[
				{"entrants": { $exists: true, $not: {$size: contestDetails.maxLimit} }},
                {"entrants": { $exists: false}}
				]
				//$where: "this.entrants.length < 2",
				}).select('contestId entrants')
				.exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get logged in user's all contest list details from DB
	 * @param {object} search - Data required for search
	 * @param {object} sportId - sport id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getAllMyContest: async function () {
		try {
			return await ContestModel.find({
							"entrants.userId": global.userId
				}).select('contestId draftgroupId contestStatus gameTypeId')
				.exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get logged in user's all contest w.r.t to draftgroup list details from DB
	 * @param {object} search - Data required for search
	 * @param {object} sportId - sport id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getAllMyContestDraftgroup: async function (draftgroupId) {
		try {
			return await ContestModel.find({
							"entrants.userId": global.userId,
							"draftgroupId": draftgroupId
				}).select('contestId draftgroupId contestStatus')
				.exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Add referral lMoney To Entrants
	 * @param {object} contestId - contest Id
	 * @param {object} referralMoney - referralMoney
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	addreferralMoneyToEntrants: async function (contestId, referralMoney, userId = global.userId) {
		try {				
			   return await ContestModel.findOneAndUpdate({
							'contestId': contestId,
							'entrants.userId': userId
						}, {
							$set: {
								'entrants.$.referralMoney': referralMoney
							}
						}, {
							new: true
						});					
				
		} catch (e) {
			throw e;
		}
	},
	
	/**
	 * Add referral Money To Entrants
	 * @param {object} contestId - contest Id
	 * @param {object} referralMoney - referralMoney
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	addreferralMoneyToEntrants: async function (contestId, referralMoney) {
		try {				
			   return await ContestModel.findOneAndUpdate({
							'contestId': contestId,
							'entrants.userId': global.userId
						}, {
							$set: {
								'entrants.$.referralMoney': referralMoney
							}
						}, {
							new: true
						});					
				
		} catch (e) {
			throw e;
		}
	},

		/**
	 * Add TransactionId To Entrants
	 * @param {object} contestId - contest Id
	 * @param {object} transactionId - transaction Id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	addTransactionIdToEntrants: async function (contestId, transactionId, userId = global.userId) {
		try {				
			   return await ContestModel.findOneAndUpdate({
							'contestId': contestId,
							'entrants.userId': userId
						}, {
							$set: {
								'entrants.$.transactionId': transactionId
							}
						}, {
							new: true
						});					
				
		} catch (e) {
			throw e;
		}
	},
};