/**
 * Player Service
 * @exports Player/Service
 */
var PlayerNewsModel = require('../../../models/playernews');
var PlayerScoreModel = require('../../../models/playerScore');
var PlayerGamesModel = require('../../../models/playerGamesJson');

module.exports = {

    /**
     * Get player from DB
     * @param {object} id - player id
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getPlayerNewsDetails: async function (playerId) {
        try {
            return await PlayerNewsModel.find({
                'playerId': playerId,
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get player games from DB
     * @param {object} req - request
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getPlayerGamesDetails: async function (req) {
        try {
            return await PlayerGamesModel.findOne({
                'playerId': req.playerId,
                'sportsId': req.sportsId,
            });
        } catch (e) {
            throw e;
        }
    },

    /**
     * Get player scores from DB
     * @param {object} query - request object
     * @returns {object} Result set object
     * @throws {object} e - Error
     */
    getPlayerScores: async function (query) {
        try {
            if (query.final == 'true') {
                var eStatus = 'Final';
            } else if (query.final == 'false') {
                var eStatus = {
                    $ne: 'Final'
                }
            } else {
                var eStatus = '';
            }

            if (eStatus == '') { // both
                return await PlayerScoreModel.find({
                    'eventId': {
                        $in: query.idArr
                    }
                }).sort({
                    'updatedAt': 1
                });
            } else {
                return await PlayerScoreModel.find({
                    'eventId': {
                        $in: query.idArr
                    },
                    'eventStatus': eStatus
                }).sort({
                    'updatedAt': 1
                });
            }
        } catch (e) {
            throw e;
        }
    },

};