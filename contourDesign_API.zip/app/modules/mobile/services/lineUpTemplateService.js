/**
 * LineupTemplate Service
 * @exports LineupTemplate/Service
 */
var LineUpTemplateModel = require('../../../models/lineupTemplate');

module.exports = {

	/**
	 * Get lineup template
	 * @param {object} lineupTemplate - Data required for fetching lineup template
	 * @returns {Number} Result set object
	 * @throws {object} e - Error
	 */
	/*getLineUpTemplate: async function (lineupTemplate) {
		try {
			return await LineUpTemplateModel.findOne({
				'sportId': lineupTemplate.sportId,
			}, { 'gameTypes': { $elemMatch: { gameTypeId: lineupTemplate.gameTypeId } } }).select('sportId sName isAvailable sortOrder').exec();
		} catch (e) {
			throw e;
		}
	},*/

	/**
	 * Get lineup template
	 * @param {object} lineupTemplate - Data required for fetching lineup template
	 * @returns {Number} Result set object
	 * @throws {object} e - Error
	 */
	getLineUpTemplate: async function (lineupTemplate) {
		try {
			return await LineUpTemplateModel.find({}).select('sportId sName isAvailable sortOrder gameTypes').exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get All lineup template
	 * @returns {Number} Result set object
	 * @throws {object} e - Error
	 */
	getAllLineUpTemplate: async function () {
		try {
			return await LineUpTemplateModel.find({
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get Sport's lineup template
	 * @param {object} sportId - sport Id
	 * @returns {Number} Result set object
	 * @throws {object} e - Error
	 */
	getSportLineup: async function (sportId) {
		try {
			return await LineUpTemplateModel.findOne({
				'sportId': sportId, 'gameTypes.gameType': 'multiplier'
			}, { 'gameTypes.$': 1 });
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get Sport's lineup template
	 * @param {object} request - Data required for fetching lineup template
	 * @returns {Number} Result set object
	 * @throws {object} e - Error
	 */
	getGameType: async function (request) {
		try {
			return await LineUpTemplateModel.aggregate(
				{ "$match": { "sportId": request.sportId } },
				{ "$unwind": "$gameTypes" },
				{ "$group": { "_id": "$sName", gameTypes: { "$push": "$gameTypes.gameTypeId" } } })

		} catch (e) {
			throw e;
		}
	},


};