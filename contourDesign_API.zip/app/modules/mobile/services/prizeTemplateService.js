/**
 * PrizeTemplate Service
 * @exports PrizeTemplate/Service
 */
var PrizeTemplateModel = require('../../../models/prizeTemplate');

module.exports = {

	/**
	 * Get all prizetemplates
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
    getPrizeTemplate: async function () {
        try {
            return await PrizeTemplateModel.find({});
        } catch (e) {
            throw e;
        }
    },

    /**
	 * Get prize template details
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
    getPrizeTemplateDetail: async function (tempId) {
        try {
            return await PrizeTemplateModel.findOne({'prizeTmpId' : tempId});
        } catch (e) {
            throw e;
        }
    },

};