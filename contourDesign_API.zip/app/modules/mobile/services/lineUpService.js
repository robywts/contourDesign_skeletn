/**
 * Lineup Service
 * @exports Lineup/Service
 */
var LineUpModel = require('../../../models/lineup');

module.exports = {

	/**
	 * Add a contest lineup to db
	 * @param {object} LineUpModel - Model object mapped to the data to be added
	 * @returns {object} Modal object
	 * @throws {object} e - Error
	 */
	addLineup: async function (lineUpModel) {
		try {
			return await lineUpModel.save();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get lineups in a draftgroup from DB
	 * @param {Number} draftgroupId - draftgroup id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getDraftGroupLineups: async function (draftgroupId) {
		try {
			return await LineUpModel.find({
				'draftgroupId': draftgroupId,
				'userId': global.userId,
				"isReserved": {$ne: 1}
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get lineups in a contest from DB
	 * @param {Number} contestId - contest id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getContestLineups: async function (contestId, appUserId = global.userId) {
		try {
			return await LineUpModel.find({
				'contestId': contestId,
				'userId': appUserId,
				"isReserved": {$ne: 1}
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get lineups in a contest from DB
	 * @param {Number} contestId - contest id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getContestLineupsData: async function (contestId, appUserId = global.userId) {
		try {
			return await LineUpModel.find({
				'contestId': contestId,
				'userId': appUserId				
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Update a contest lineup to db
	 * @param {object} LineUpModel - Model object mapped to the data to be added
	 * @returns {object} Modal object
	 * @throws {object} e - Error
	 */
	updateLineup: async function (lineUpModel, lineupData, lineupID) {
		try {
			return await lineUpModel.findOneAndUpdate({
				lineupId: lineupID
			}, lineupData)

		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get contest standings details from DB
	 * @param {object} contestId - contest id
	 * @param {object} search - Data required for search
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getUserContestStandings: async function (contestId, search) {
		try {
			return await LineUpModel.find({
					"contestId": contestId
				}).select('userId userName userImgName position points lineupId winning avgRemTimePerc isReserved').sort({
					'position': search.sort
				}).limit(parseInt(search.limit))
				.skip(search.limit * search.page).exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get total count of contests by id
	 * @param {object} contestId - contest id
	 * @returns {Number} Total count of records
	 * @throws {object} e - Error
	 */
	getAllCountContUser: async function (contestId) {
		try {
			return await LineUpModel.count({
				"contestId": contestId,
				"isReserved": {$ne: 1}
			}).exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get lineUp by id
	 * @param {object} LineUpId - lineup id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getLineup: async function (LineUpId) {
		try {
			return await LineUpModel.find({
				"lineupId": LineUpId,
				'userId': global.userId,
				"isReserved": {$ne: 1}
			}).exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get lineUp by id
	 * @param {object} LineUpId - lineup id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getLineupData: async function (LineUpId) {
		try {
			return await LineUpModel.find({
				"lineupId": LineUpId/*,
				"isReserved": {$ne: 1}*/
			}).exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get user's all lineups from DB
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getAllLineups: async function (date) {
		try {
			return await LineUpModel.find({
				'userId': global.userId,
				'startTimeUTC': {
					$gt: date
				}/*,
				"isReserved": {$ne: 1}*/
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Delete a lineup
	 * @param {Number} id Request id of the record
	 * @returns {object} Delete Object
	 * @throws {object} e - Error
	 */
	delete: async function (id) {
		try {
			return await LineUpModel.remove({
				contestId: id,
				userId: global.userId
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Delete a lineup by lineupId
	 * @param {Number} id Request id of the record
	 * @returns {object} Delete Object
	 * @throws {object} e - Error
	 */
	deleteById: async function (id) {
		try {
			return await LineUpModel.remove({
				lineupId: id,
				userId: global.userId
			});
		} catch (e) {
			throw e;
		}
	},


	/**
	 * Add lineups to db
	 * @param {object} contestModel - Model object mapped to the data to be added
	 * @returns {object} Modal object
	 * @throws {object} e - Error
	 */
	addLineupMultiple: async function (lineUpModel) {
		try {
			return await LineUpModel.update({
				"lineupId": lineUpModel.lineupId
			}, lineUpModel, {
				new: true,
				upsert: true
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * update LineupW ith Contest
	 * @param {object} userAuthDB - contest object
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	updateLineupWithContest: async function (contestDB, draftgroupId, referralM = 0, usedTicketId = "N") {
		try {
			return await LineUpModel.findOneAndUpdate({
				'lineupId': contestDB.lineupId,
				'contestId': 0,
				'draftgroupId': draftgroupId
			}, {
				$set: {
					'contestId': contestDB.contestId,
					'referralMoney': referralM,
					'ticketId': usedTicketId
				}
			}, {
				new: true
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Add a reserved Lineup
	 * @param {Number} lineupId - lineupId
	 * @param {object} contestModel - Model object mapped to the data to be added
	 * @returns {object} Modal object
	 * @throws {object} e - Error
	 */
	addreservedLineup: async function (lineUpModel) {
		try { 
			return await LineUpModel.findOneAndUpdate({
				"lineupId": lineUpModel.lineupId
			}, lineUpModel, {
				upsert: true
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Update Lineup data 
	 * @param {object} lineupId - lineupId
	 * @param {string} lineupData - lineup Object 
	 * @throws {object} e - Error
	 */
	updateLineupData: async function (lineupId, lineupData) {
		try {
			return await LineUpModel.findOneAndUpdate({
				"lineupId": lineupId
			}, {
				$set: lineupData
			}, {
				new: false
			});
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Get all H2H opponents lineups
	 * @param {object} LineUpId - lineup id
	 * @returns {object} Result set object
	 * @throws {object} e - Error
	 */
	getAllOpponentsLineups: async function (opponents) {
		try {
			return await LineUpModel.find({
				'userId': {
					$in: opponents
				},
				"isReserved": {$ne: 1}
			}).exec();
		} catch (e) {
			throw e;
		}
	},

	/**
	 * Delete a reserved Lineup
	 * @param {Number} contestId - contestId
	 * @param {Number} userId - userId
	 * @returns {object} Modal object
	 * @throws {object} e - Error
	 */
	deleteReservedLineup: async function (contestId, userId) {
		try { 
			return await LineUpModel.remove({
				"contestId": contestId,
				"userId": userId,
				"isReserved": 1,
			});
		} catch (e) {
			throw e;
		}
	},
};