/**
 * Authentication in the Middleware
 * @exports General/Middleware
 */
var UserModel = require('../../models/user');
var ContestModel = require('../../models/contest');
var generalHelper = require('./helpers/generalHelper');
var _t = require('./translations/' + process.env.LANGUAGE + '/generalTrans.json');

module.exports = {
	/**
	 * Middleware Authentication (api auth and session auth)
	 * @param {Object} req - Request Object
	 * @param {Object} res - Response Object
	 * @param {Object} next - Next Object
	 */
	authentication: function (req, res, next) {
		try { //console.log(req.headers);
			if (process.env.RESTAPIKEY != req.headers['api-key']) { //checking for general api key
				generalHelper.handleError(req, res, 'API Auth Failed', _t.invalidApiKey, 1001);
			} else if (['/general/test', '/general/log', '/user/auth/login', '/user/auth/register', '/user/auth/fb', '/user/auth/forgot', '/user/auth/reset'].includes(req.url)) { //routes which don't need session auth
				next();
			} else if (!req.headers['session-key'] || req.headers['session-key'] == null) {
				generalHelper.handleError(req, res, 'Session Auth Failed', _t.invalidSessionKey, 1002);
			} else { //checking for session key of user
				// UserModel.findOne({
				// 	'sessions.sessionToken': req.headers['session-key'],
				// 	'userStatus': 1
				// }, '_id userId loginTypes.FB.fbToken', function (err, userDB) {
				UserModel.aggregate([{
					$match: {
						'sessions.sessionToken': req.headers['session-key'],
						'userStatus': 1
					}
				}, {
					"$unwind": "$sessions"
				}, {
					"$match": {
						"sessions.sessionToken": req.headers['session-key'],
					}
				}, {
					"$project": {
						"_id": "$_id",
						"userId": "$userId",
						"loginTypes.FB.fbToken": 1,
						"sessionToken": "$sessions.sessionToken",
						"geoSession": "$sessions.geoSession"
					}
				}], function (err, userDB) {
					try {
						if (err || !userDB[0]) { // if session key auth failed
							generalHelper.handleError(req, res, 'Session Auth Failed', _t.invalidSessionKey, 1002);
						} else { // successful authentication
							global.userId = userDB[0].userId;
							global.sessionToken = req.headers['session-key'];
							global.fbUserToken = (userDB[0].loginTypes) ? ((userDB[0].loginTypes.FB) ? userDB[0].loginTypes.FB.fbToken : '') : '';
							if (req.url == '/user/auth/geoToken') { // set global id only if it is geoToken api call
								if (!userDB[0].geoSession) {
									global.geoToken = {};
								} else {
									global.geoToken = userDB[0].geoSession;
								}
								next();
							} else if (req.method != 'GET' && ['/contests', '/contests/joinContest', '/contests/joinMultipleContest', '/users/depositMoney'].includes(req.url)) { // routes which are restricted from free users 
								if (!userDB[0].geoSession) {
									generalHelper.handleError(req, res, 'GeoToken Auth Failed', _t.invalidGeoToken, 1003);
								} else {
									var dbDt = new Date(userDB[0].geoSession.createdAt);
									dbDt.setDate(dbDt.getDate() + 1);
									var currDt = new Date();
									if (req.headers['geo-token'] != userDB[0].geoSession.geoToken) { // if geo token auth failed
										generalHelper.handleError(req, res, 'GeoToken Auth Failed', _t.invalidGeoToken, 1003);
									} else if (dbDt.getTime() < currDt.getTime()) { // token expired
										generalHelper.handleError(req, res, 'GeoToken Expired', _t.expiredGeoToken, 1004);
									} else if (userDB[0].geoSession.allowed == false) { // routes allowed is false
										if (req.url == '/contests') {
											if (req.body.entryFee <= 0) { // if free contest
												next();
											} else {
												generalHelper.handleError(req, res, 'User Geo Restricted', _t.restrictedGeoToken, 1005);
											}
										} else if (req.url == '/contests/joinContest' || req.url == '/contests/joinMultipleContest') {
											var contestIds = req.body.contestId;
											contestIds = (!Array.isArray(contestIds)) ? [contestIds] : contestIds
											ContestModel.count({
												'entryFees': {
													$gt: 0
												},
												contestId: {
													$in: contestIds
												}
											}, function (err, contestCnt) {
												try {
													if (err || contestCnt == null) { // Some issue has happened
														generalHelper.handleError(req, res, 'User Geo Restricted', _t.restrictedGeoToken, 1005);
													} else {
														// console.log(contestCnt);
														if (contestCnt <= 0) { // if free contest
															next();
														} else {
															generalHelper.handleError(req, res, 'User Geo Restricted', _t.restrictedGeoToken, 1005);
														}
													}
												} catch (e) {
													generalHelper.handleError(req, res, e.stack, _t.technicalError);
												}
											}).exec();
										} else { // other ws which don't require extra checking
											generalHelper.handleError(req, res, 'User Geo Restricted', _t.restrictedGeoToken, 1005);
										}
									} else { // ws not in restriction list
										// console.log(req);
										// console.log(userDB[0].geoSession.allowed);
										next();
									}
								}
							} else {
								next();
							}
						}
					} catch (e) {
						generalHelper.handleError(req, res, e.stack, _t.technicalError);
					}
				});
			}
		} catch (e) {
			generalHelper.handleError(req, res, e.stack, _t.technicalError);
		}
	}
};