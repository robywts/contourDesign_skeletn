/**
 * Scoring Rules Configuration
 * @exports General/ScoringRules
 */

/**
 * NFL Scoring Configuration
 */
var nflScore = {
  'passing': {
    'passing-yards': {
      'abr': 'PaYds',
      'pts': 0.04
    },
    'passing-300yds+':{
      'abr': '300YdPass+',
      'pts': 2
    },
    'interceptions':{
      'abr': 'Int',
      'pts': -1
    }
  },
  'rushing': {
    'rushing-yards': {
      'abr': 'RuYds',
      'pts': 0.1
    },
    'rushing-100yds+':{
      'abr': '100YdRush+',
      'pts': 2
    }
  },
  'receiving': {
    'receiving-yards': {
      'abr': 'RecYds',
      'pts': 0.1
    },
    'receptions': {
      'abr': 'Rec',
      'pts': 0.5
    },
    'receiving-100yds+':{
      'abr': '100YdRec+',
      'pts': 2
    }
  },
  'scoring': {
    'rushing-touchdowns': {
      'abr': 'RuTd',
      'pts': 6
    },
    'passing-touchdowns': {
      'abr': 'PaTd',
      'pts': 4
    },
    'receiving-touchdowns': {
      'abr': 'RecTd',
      'pts': 6
    },
    'kickoff-touchdowns': {
      'abr': 'KickOffTd',
      'pts': 6
    },
    'punt-return-touchdowns': {
      'abr': 'PuntRetTd',
      'pts': 6
    },
    'own-fumble-touchdowns': {
      'abr': 'FumbleTd',
      'pts': 6
    },
    'two-point-conversion': {
      'abr': 'TwoPointConv',
      'pts': 2
    },
    'two-point-pass-conversion': {
      'abr': 'TwoPointPassConv',
      'pts': 2
    },
    'extra-point-conversion': {
      'abr': 'ExtraPointConv',
      'pts': 1
    }
  },
  'fumbles':{
    'fumbles-lost': {
      'abr': 'Fmbl',
      'pts': -2
    }
  }
};

module.exports = {
  nflScore
};
