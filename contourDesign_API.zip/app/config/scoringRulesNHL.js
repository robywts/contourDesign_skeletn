/**
 * Scoring Rules Configuration
 * @exports General/ScoringRules
 */

/**
 * NHL Scoring Configuration
 */
var nhlScore = {
  'skaterStats': {
    'goals': {
      'abr': 'GOALS',
      'pts': 6
    },
    'assists':{
      'abr': 'ASST',
      'pts': 3
    },
    'shots-on-goal':{
      'abr': 'SOG',
      'pts': 0.25
    },
    'short-handed-goals':{
      'abr': 'SHG',
      'pts': 1
    },
    'short-handed-assists':{
      'abr': 'SHA',
      'pts': 1
    },
    'blocked-shots':{
      'abr': 'BLKSH',
      'pts': 1
    },
    'hits':{
      'abr': 'HITS',
      'pts': 1
    },
    'face-offs-won':{
      'abr': 'FOW',
      'pts': 0.2
    }
  },
  'goaltenderStats': {
    'win': {
      'abr': 'W',
      'pts': 0.1
    },
    'goals-against':{
      'abr': 'GA',
      'pts': -2
    },
    'saves':{
      'abr': 'SV',
      'pts': 0.4
    },
    'shutout':{
      'abr': 'SO',
      'pts': 4
    }
  }

};

module.exports = {
  nhlScore
};
