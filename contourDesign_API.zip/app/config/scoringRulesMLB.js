/**
 * Scoring Rules Configuration
 * @exports General/ScoringRules
 */

/**
 * Mlb Scoring Configuration
 */
var mlbScore = {
  'battingStats': {
    'singles': {
      'abr': 'BH',
      'pts': 2
    },
    'doubles': {
      'abr': 'DBL',
      'pts': 4
    },
    'triples': {
      'abr': 'TRPL',
      'pts': 6
    },
    'home-runs': {
      'abr': 'HR',
      'pts': 8
    },
    'runs-batted-in': {
      'abr': 'RBI',
      'pts': 3
    },
    'runs': {
      'abr': 'RUN',
      'pts': 2.5
    },
    'walks': {
      'abr': 'BB',
      'pts': 2
    },
    'stolen-bases': {
      'abr': 'SB',
      'pts': 4
    },
    'hit-by-pitch': {
      'abr': 'HBP',
      'pts': 2
    },
    'sacrifice-hits': {
      'abr': 'SH',
      'pts': 1
    },
    'sacrifice-flies': {
      'abr': 'SF',
      'pts': 1
    },
  },
  'pitchingStats': {
    'innings-pitched': {
      'abr': 'IP',
      'pts': 2
    },
    'strike-outs': {
      'abr': 'K',
      'pts': 2
    },
    'earned-runs': {
      'abr': 'ER',
      'pts': -2
    },
    'hits': {
      'abr': 'HA',
      'pts': -0.5
    },
    'wins': {
      'abr': 'W',
      'pts': 4
    },
    'walks': {
      'abr': 'BB',
      'pts': -0.5
    },
    'hit-batsmen': {
      'abr': 'HB',
      'pts': -0.5
    },
    'gidp': {
      'abr': 'GDP',
      'pts': 0.5
    }
  }
};

module.exports = {
  mlbScore
};