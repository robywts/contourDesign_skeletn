/**
 * Scoring Rules Configuration
 * @exports General/ScoringRules
 */

/**
 * NBA Scoring Configuration
 */
var nbaScore = {
    'points': {
      'abr': 'PTS',
      'pts': 0.5
    },
    'assists': {
      'abr': 'ASST',
      'pts': 0.8
    },
    'rebounds': {
      'abr': 'RB',
      'pts': 0.6
    },
    'steals': {
      'abr': 'STL',
      'pts': 1.5
    },
    'blocks': {
      'abr': 'BLK',
      'pts': 1.5
    },
    'turnovers': {
      'abr': 'TO',
      'pts': -0.5
    },
    '3pt-FG': {
      'abr': '3PTFG',
      'pts': 0.5
    },
    'double-double': {
      'abr': 'DBDB',
      'pts': 1.5
    },
    'triple-double': {
      'abr': 'TPLDB',
      'pts': 3
    },
};

module.exports = {
  nbaScore
};
