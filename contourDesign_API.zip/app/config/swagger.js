/**
 * Swagger Configuration
 * @exports General
 */

var swaggerJSDoc = require('swagger-jsdoc');

/**
 * Swagger Configuration for Webservices
 */
var swaggerSpecWS = swaggerJSDoc({
  swaggerDefinition: {
    info: {
      title: 'API Documentation',
      version: '1.0.0',
      description: 'Api Documentation',
    },
    host: process.env.HOST + ':' + process.env.HTTP_PORT,
    basePath: '/',
    schemes: ['http', 'https'],
    consumes: ['application/json'],
    produces: ['application/json'],
  },
  apis: ['./app/modules/mobile/swagger/*.js'],
});

/**
 * Swagger Configuration for Admin
 */
var swaggerSpecAdmin = swaggerJSDoc({
  swaggerDefinition: {
    info: {
      title: 'Admin API Documentation',
      version: '1.0.0',
      description: 'Admin Api Documentation',
    },
    host: process.env.HOST + ':' + process.env.HTTP_PORT,
    basePath: '/',
    schemes: ['http', 'https'],
    consumes: ['application/json'],
    produces: ['application/json'],
  },
  apis: ['./app/modules/admin/swagger/*.js'],
});

module.exports = { swaggerSpecWS, swaggerSpecAdmin };