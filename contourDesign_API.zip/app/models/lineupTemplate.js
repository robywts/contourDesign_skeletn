/**
 * LineUpTemplates Model
 * @exports Model/LineUpTemplate
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * LineUpTemplates Schema
 */
var LineUpTemplatesSchema = new Schema({
	sportId: { type: Number },
	sName: { type: String },
    sortOrder: { type: Number },
	isAvailable: { type: Boolean },
	gameTypes: [{
		lptemplateid: {
			type: Number,
			required: true
		},
		gameTypeId: { type: Number },
		gameType: { type: String },
		capLimit: { type: Number },
		template:
		[{
            id: { type: Number },
            posId: { type: Number },
            posAbbr: { type: String },
			posName: { type: String },
            playerId: { type: Number },
			playerName: { type: String },
		}]

	}],
},
	{
		timestamps: true
	}
);

module.exports = mongoose.model('lineuptemplates', LineUpTemplatesSchema);