/**
 * Clan Model
 * @exports Model/Clan
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

/**
 * Clan Schema
 */
var ClanSchema = new Schema({
	clanId: {
		type: Number,
		required: true
	},
	clanName : {
		type: String,
		required: true
	},
	createdById: {
		type: Number,
		required: true
	},
	createdByName : {
		type: String,
		required: true
	},
	createdByEmail : {
		type: String,
		required: true
	},
	rank: {
		type: Number,
		required: true		
	},
	totalPoints: {
		type: Number,
		required: true,
		default: 0		
	},
	clanStatus: {
		type: String,
		default: 1 // 1 - Active, 2 - Blocked
	},	
	createdAt: {
		type: Date,
		default: Date.now
	},
	updatedAt: {
		type: Date,
		default: Date.now
	}		
	
});

module.exports = mongoose.model('clans', ClanSchema);