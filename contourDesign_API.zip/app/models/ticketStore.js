/**
 * Ticket Store Model
 * @exports Model/TicketStore
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
// var SchemaTypes = mongoose.Schema.Types;

/**
 * Ticket Store Schema
 */
var TicketStoreSchema = new Schema({
	ticketId: {
		type: Number,
		required: true
	},	
	ticketAmount: {
		type: Number,
		required: true
	},
	totalRewards: {
		type: Number,
		required: true 
	}
}, {
	timestamps: true
});

module.exports = mongoose.model('ticketStores', TicketStoreSchema);