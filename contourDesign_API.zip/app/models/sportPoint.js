/**
 * User Model
 * @exports Model/User
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * Sports point Schema
 */
var PointsSchema = new Schema({
	pointId: {
		type: Number,
		required: true,
		index: true,
		unique: true
	},
	rank: {
		type: Number		
	},
	subRank: {
		type: Number		
	},
	points: {
		type: SchemaTypes.Double
	},
	iValue: {
		type: SchemaTypes.Double		
	},
	jValue: {
		type: SchemaTypes.Double
	},
	kValue: {
		type: Number
	},
	lValue: {
		type: Number
	},	
	createdAt: {
		type: Date,
		default: Date.now
	},
	updatedAt: {
		type: Date,
		default: Date.now
	},
});

module.exports = mongoose.model('sportPoints', PointsSchema);