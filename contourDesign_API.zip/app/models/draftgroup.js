/**
 * DraftGroups Model
 * @exports Model/DraftGroup
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * DraftGroups Schema
 */
var DraftGroupsSchema = new Schema({
	draftgroupId: {
		type: Number,
		required: true
	},
	dgName: {
		type: String,
		required: true
	},
	dgState: {
		type: String,
		required: true
	},

	week: { type: Number },
	eventTypeId: { type: Number },
	season: { type: Number },
	//	startTimeSuffix: { type: String },

	sportId: { type: Number },
    startTimeUTC: { type: Date },
    league: [{
		leagueId: { type: Number },
		name: { type: String },
		abbr: { type: String }
	}],
	//sName: { type: String },
    autoContest: {
			type: Number,
			default: 1,
			comment: '1- auto contest created/auto contest not needed, 0 - No auto contest created yet',
			enum: [0, 1]
		},
	contestList: [],
	sortOrder: { type: Number },
	gameList:
	[{
		eventId: { type: Number },
		startTimeUTC: {
			type:
			Date
		},
		gameStatus: { type: String },
		venueName: { type: String },
		weather: {
			conditionDesc:
			{ type: String }
		},
		startingLineupReady:
		{ type: String },

		players: [{

			fName: { type: String },

			lName: { type: String },

			playerId: { type: Number },

			uniform: { type: Number },

			posId: { type: Number },

			posAbbr: { type: String },

			posGen: { type: String },

			mValue: {
				type: SchemaTypes.Double,
				deafult: 0
			},


			capValue: {
				type: SchemaTypes.Double,
				deafult: 0
			},

			isInjured: { type: SchemaTypes.Double },

			canDraft: { type: String },

			isDisabled: { type: SchemaTypes.Double },


			competition: {

				compId: { type: Number },

				nameDisplay: [
					{

						htId: { type: Number },
						htName: { type: String },
						htAbbr: { type: String },
						htCity: { type: String },
						htScore: { type: SchemaTypes.Double },
						htRecord: {
							wins: { type: Number },
							losses: { type: Number },
						},
						value: { type: String },
						atId: { type: Number },
						atName: { type: String },
						atAbbr: { type: String },
						atCity: { type: String },
						atScore: { type: SchemaTypes.Double },
						atRecord: {
							wins: { type: Number },
							losses: { type: Number },
						}
					}],

			},


			draftAtt: [{
				title: { type: String },
				value: { type: String },
				sortValue: { type: SchemaTypes.Double }
			}, {
					title: { type: String },
					value: { type: String },
					sortValue: { type: String },
					quality: { type: String }
				}],

			playerAttributes: [],

			gameAttributes: [],
			teamId: { type: Number },
			teamAbbr: { type: String },
			fanProjSalary: { type: SchemaTypes.Double },
			fanProjScore: { type: SchemaTypes.Double },
			scoreInfo: [
				{
					title: { type: String },
					value: { type: SchemaTypes.Double }
				}
			],
			starting: { type: String },
			probable: { type: Boolean, default: false },
			info: {
				type: Array,
			}
		},
			{ draftAlerts: [] }
		]
	}]
},

	{
		timestamps: true
	}
);

module.exports = mongoose.model('draftgroups', DraftGroupsSchema);