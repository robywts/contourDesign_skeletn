/**
 * Contest Model
 * @exports Model/Contest
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * User Schema
 */
// var UserSchema = new Schema({
// 	_id: String,
// 	email: {
// 		type: String,
// 	}
// });

/**
 * Contest Schema
 */
var ContestSchema = new Schema({
	contestId: {
		type: Number,
		required: true,
		index: true,
		unique: true //check the counter
	},
	contestGroupId: { //discuss and update
		type: Number,
	},
	autoId: {
		type: Number,
	},
	contestName: {
		type: String,
		required: true
	},
	contestStartTime: { //is this right
		type: Date
	},
	visibility: {
		type: String,
		required: true,
		default: 'Public',
		enum: ['Public', 'Private']
	},
	isGuaranteed: {
		type: Boolean,
		default: false
	},
	isAdminRow: {
		type: Boolean,
		default: false
	},
	isVideoAvailable: {
		type: Boolean,
		default: false
	},
	summary: {
		type: String
	},
	sportId: {
		type: Number,
		default: 4,
		enum: [1, 2, 3, 4, 5] // 1 - NFL, 2 - MLB, 3 - NHL, 4 - NBA, 5 - GOLF
	},
	sName: {
		type: String
	},
	contestTypeId: {
		type: Number,
		required: true,
		enum: [1, 2] // 1 - Multiplayer, 2 - H2H
	},
	contestType: {
		type: String,
		required: true // (Multiplayer,H2H)
	},
	prizeTmpId: {
		type: Number,
		required: true
	},
	gameTypeId: {
		type: Number,
		required: true
	},
	gameType: {
		type: String,
		required: true
	},
	prizeMode: {
		type: String,
	},
	prizeTickets: {
		type: Number,
		default: 0
	},
	prizePool: {
		type: SchemaTypes.Double,
		default: 0
	},
	entryFees: {
		type: Number,
		required: true,
		default: 0
	},
	rakePerc: {
		type: Number,
		default: 0
	},
	minLimit: {
		type: Number,
		default: 0
	},
	maxLimit: {
		type: Number,
		default: 0
	},
	maxEntriesPerUser: {
		type: Number,
		default: 0
	},
	prizes: [{
		prizePosition: {
			type: String
		},
		amount: {
			type: SchemaTypes.Double,
			default: 0
		},
		fromRange: {
			type: String
		},
		toRange: {
			type: String
		}
	}],
	draftgroupId: {
		type: Number,
		required: true
	},
	contestStatus: {
		type: Number,
		required: true,
		default: 3,
		enum: [1, 2, 3, 4] // 1 - Completed, 2 - Live, 3 - Upcoming, 4- Cancelled
	},
	labels: [{
		type: String,
		enum: ['Featured', '50/50', 'Beginner', 'Intermediate', 'Onboarding']
	}],
	entrants: [{
		userId: {
			type: Number
		},
		totalentry: {
			type: Number
		},
		joinDate: {
			type: Date
		},
		referralMoney: {
			type: Number
		},
		transactionId: {
			type: String
		}
	}],
	createdBy: {
		type: Number,
		required: true
	},
	userName: {
		type: String,
		required: true
	},
	userEmail: {
		type: String,
		required: true
	},
	sort: {
		type: Number,
		default: 1
	},
	rewards: {
		type: Number,
		default: 0
	},
	refundIssued: {
		type: String
	},
	attributes: {
		sponsor: {
			sponsorName: {
				type: String
			},
			imgUrl: {
				type: String
			}
		}
	},
	rewardSettled: { type: Number, default: 0 }
}, {
		timestamps: true
	});

module.exports = mongoose.model('contests', ContestSchema);