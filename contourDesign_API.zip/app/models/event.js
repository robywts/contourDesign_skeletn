/**
 * Event Model
 * @exports Model/Event
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * Event Schema
 */
var EventSchema = new Schema({
	gameInfo: {
		type: JSON
	},
	sportId: {
		type: Number,
		required: true
	},
	league: JSON,
	season: {
		type: Number,
		required: true
	},
	week: {
		type: Number
	},
	eventTypeId: {
		type: Number
	},
	eventId: {
		type: Number,
		required: true,
		unique: true
	},
	eventStatusId: {
		type: String,
		required: true
	},
	isActive: {
		type: String
	},
	startTimeUTC: {
		type: Date
	},
	homeTeam: JSON,
	awayTeam: JSON,
	venueName: {
		type: String,
	},
	weather: {
		conditionDesc: { type: String }
	},
},
	{
		timestamps: true
	}
);

module.exports = mongoose.model('events', EventSchema);