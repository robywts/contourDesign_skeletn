/**
 * User Ticket Model
 * @exports Model/UserTicket
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
// var SchemaTypes = mongoose.Schema.Types;

/**
 * User Ticket Schema
 */
var UserTicketSchema = new Schema({
	userId: {
		type: Number,
		required: true
	},
	ticketId: {
		type: String,
		required: true
	},
	ticketAmount: {
		type: Number,
		required: true
	},
	ticketStatus: {
		type: String,
		required: true // N - New, U - Used
	}
}, {
	timestamps: true
});

module.exports = mongoose.model('userTickets', UserTicketSchema);