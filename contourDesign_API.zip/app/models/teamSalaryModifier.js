/**
 * TeamSalaryModifier Model
 * @exports Model/TeamSalaryModifier
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * TeamSalaryModifier Schema
 */
var TeamSalaryModifierSchema = new Schema({
	teamId: {
		type: Number,
		required: true
	},
	nickName: {
		type: String,
		required: true
	},
	country: {
		type: String,
		required: true,
	},
	season: {
		type: String,
		required: true,
	},
	sportId: {
		type: Number,
		required: true
	},
	gamePlayed: {
		type: Number,
		required: true
	},
	avgPoints: {},
	modifier: {}
},
	{
		timestamps: true
	}
);

module.exports = mongoose.model('teamSalaryModifier', TeamSalaryModifierSchema);