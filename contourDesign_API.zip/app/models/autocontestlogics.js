/**
 * AutoContestLogic Model
 * @exports Model/AutoContestLogic
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * Autocontests Schema
 */
var AutoContestLogicSchema = new Schema({
	sportId: {
		type: Number,
		required: true
	},

	contestTypeId: {
		type: Number,
		required: true
	},

	gameTypeId: {
		type: Number,
		required: true
	},

	gameType: {
		type: String,
		required: true
	},

	entryFees: {
		type: Array,
		required: true
	},

	maxLimit: {
		type: Number,
		required: true
	},

	maxEntriesPerUser: {
		type: Number,
		required: true
	},
	prizeTmpId: {
		type: Number,
		required: true
	},

},

);

module.exports = mongoose.model('autocontestlogics', AutoContestLogicSchema);