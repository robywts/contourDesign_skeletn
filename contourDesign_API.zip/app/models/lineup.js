/**
 * LineUps Model
 * @exports Model/LineUp
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * LineUps Schema
 */
var LineUpsSchema = new Schema({
	lineupId: { type: Number },

	contestId: { type: Number },
	userId: { type: Number },
	userName: { type: String },
	userImgName: { type: String },
	position: { type: Number },
	points: { type: SchemaTypes.Double },
	draftgroupId: {
		type: Number,
		required: true
	},
	dgName: {
		type: String
	},
	gameTypeId: {
		type: Number
	},
	startTimeUTC: { type: Date },
	sportId: { type: Number },


	sName: { type: String },

	players: [{

		eventId: { type: Number },

		eventST: { type: Date },

        tmpPosId: { type: Number },

        tmpPosAbbr: { type: String },

        tmpPosName: { type: String },

        tmpId: { type: Number },

		playerId: { type: Number },

		isInjured: {
			type: String,
		},

		fName: { type: String },

		lName: { type: String },
		playerName: { type: String },
        imgUrl: { type: String },
		mValue: {
			type: SchemaTypes.Double,
			deafult: 0
		},
		fanProjSalary: { type: SchemaTypes.Double },
		competition: {

			compId: { type: Number },

			nameDisplay: [
				{

					htId: { type: Number },
					htName: { type: String },
					htAbbr: { type: String },
					htScore: { type: SchemaTypes.Double },

					htPossess: { type: Number },

					htFieldPosition: { type: SchemaTypes.Double },

					value: { type: String },

					atId: { type: Number },
					atName: { type: String },
					atAbbr: { type: String },

					bold: { type: Number },

					atScore: { type: SchemaTypes.Double },

					atPossess: { type: Number },

					atFieldPosition: { type: SchemaTypes.Double },
				}],

			gameInfo: { type: String }

		},

		draftAtt: [{
			title: { type: String },
			value: { type: String },
			sortValue: { type: SchemaTypes.Double }
		}, {
				title: { type: String },
				value: { type: String },
				sortValue: { type: String },
				quality: { type: String }
			}],

		playerAttributes: [],

		gameAttributes: [],
		teamId: { type: Number },
		teamAbbr: { type: String },
		fanProjScore: { type: SchemaTypes.Double },
		multiplierScore: { type: SchemaTypes.Double },
		playerScore: { type: SchemaTypes.Double },
		starting: { type: String },
		probable: { 	type: Boolean,
			            default: false },
		remTimePerc: { type: SchemaTypes.Double },
		scoreInfo: [
			{
				title: { type: String },
				value: { type: SchemaTypes.Double }
			}
		],
		info: {
			type: Array,
		}
	}
	],
	winning: { type: SchemaTypes.Double },
	referralMoney: {
		type: Number,
		default: 0
	},
	ticketId: { type: String },
	standingChange: { type: Number },
	winningSettled: { type: Number },
	transactionId: { type: String, default: "N" },
	avgRemTimePerc: { type: SchemaTypes.Double },
	isReserved: {
		type: Number,
		default: 0
	},
	refundIssued: { type: String, default: "N" }
},
	{
		timestamps: true
	}
);

module.exports = mongoose.model('lineups', LineUpsSchema);