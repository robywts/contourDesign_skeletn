/**
 * Player Model
 * @exports Model/Player
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * Player Schema
 */
var PlayerSchema = new Schema({
	sportId: {
		type: Number,
		required: true
	},
	league: JSON,
	fName: {
		type: String,
		required: true
	},
	lName: {
		type: String,
	},
	playerId: {
		type: Number,
		required: true,
		unique: true
	},
	uniform: {
		type: Number,
	},
	team: JSON,
	positions: JSON,
	fanProjSalary: {
		type: SchemaTypes.Double,
		default: 0,
	},
	fanProjPoints: {
		type: SchemaTypes.Double,
		default: 0,
	},
	fanProjScore: {
		type: SchemaTypes.Double,
		default: 0,
	},
	playerImgName: {
		type: String,
		default: null,
	},
	isActive: {
		type: Number,
		required: false,
	},
	isSuspend: {
		type: Number,
		required: false,
	},
	isInjured: {
		type: String,
		required: false,
	},
	probables: {
		type: Array,
	},
	info: {
		type: Array,
	}
},
	{
		timestamps: true
	}
);

module.exports = mongoose.model('players', PlayerSchema);