/**
 * LockItem Model
 * @exports Model/LockItem
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

/**
 * LockItem Schema
 */
var LockItemSchema = new Schema({
	itemId: {
		type: Number,
		required: true,
		unique: true
	},
	clientId: {
		type: String,
		required: true
	},
	itemDateTime: {
		type: Date,
		default: Date.now
	}, 


});

module.exports = mongoose.model('lockItem', LockItemSchema);