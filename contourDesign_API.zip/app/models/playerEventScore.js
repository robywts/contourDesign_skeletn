/**
 * PlayerEventScore Model
 * @exports Model/PlayerEventScore
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * PlayerEventScore Schema
 */
var PlayerEventScoreSchema = new Schema({
	playerId: {
		type: Number,
		required: true
	},
	eventId: {
		type: Number,
		required: true
	},
	season: {
		type: String,
		required: true,
	},
	startTimeUTC: {
		type: Date
	},
	sportId: {
		type: Number,
		required: true
	},
	playerPosition: {
		type: String,
		required: true
	},
	playerScore: { type: SchemaTypes.Double }
},
	{
		timestamps: true
	}
);

module.exports = mongoose.model('playerEventScore', PlayerEventScoreSchema);