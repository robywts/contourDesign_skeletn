/**
 * Static Content Model
 * @exports Model/Static
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

/**
 * Static Schema
 */
var StaticSchema = new Schema({
	_id: String,
	name: {
		type: String
	},
	content : {
		type: String,
		required: true
	},	
	userId : {
		type: Number,
		required: true
	},
	userName : {
		type: String,
		required: true
	},
	userEmail : {
		type: String,
		required: true
	},
	createdAt: {
		type: Date,
		default: Date.now
	},
	updatedAt: {
		type: Date,
		default: Date.now
	}		
	
});

module.exports = mongoose.model('statics', StaticSchema);