/**
 * Notifications Model
 * @exports Model/Notification
 */

var mongoose = require('mongoose');
mongoose.set('debug', true);
var Schema = mongoose.Schema;

/**
 * User Schema
 */
var notificationsSchema = new Schema({

	userId: {
		type: Number,
		required: true
	},
	message: {
		type: String,
		required: true
	},
	isRead: {
		type: Number
	},
	notificationTypeId: {
		type: Number
	},
	createdAt: {
		type: Date,
		default: Date.now
	},
	updatedAt: {
		type: Date,
		default: Date.now
	}

});

module.exports = mongoose.model('notifications', notificationsSchema);