/**
 * Logger Model
 * @exports Model/Logger
 */
var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

/**
 * Logger Schema
 */
var LoggerSchema = new Schema({
	req: Object,
	res: Object,
	data: Array,
	type: String,
	updatedAt: {
		type: Date,
		default: Date.now
	}
});

module.exports = mongoose.model('Logger', LoggerSchema);