/**
 *  Transaction Model
 * @exports Model/Transaction
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;
require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * Transaction Schema
 */
var transactionSchema = new Schema({
    entryDate: {
        type: Date,
        required: true,
        default: Date.now
    },
    userId: {
        type: Number,
        required: true
    },
    tranStatus: {
        type: Number,
        required:true,
        default: 1,
		enum: [0, 1, 2] // 0 - Pending, 1 - Success, 2 - Failure
    },
    tranType: {
        type: String,
        required: true,
        default: 'D',
		enum: ['D', 'W', 'TM', 'RT', 'T', 'R', 'JC', 'WA', 'UC', 'CC'] // D - Deposit, W - Withdrawal, TM - Ticket to Money Conversion, RT - Reward to Ticket, T - Tickets, R - Reward, JC - Join Contest, WA - Winning Amount, CC - Cancelled Contest
    },
    amount: {
        type: SchemaTypes.Double,
        default: 0
    },
    updatedAt: {
        type: Date,
        default: Date.now
    },
    userName: {
        type: String,
        default: ''
    },
    userImg: {
        type: String,
        default: ''
    },
    fName: {
        type: String,
        default: ''
    },
    lName: {
        type: String,
        default: ''
    }
});

module.exports = mongoose.model('transaction', transactionSchema);