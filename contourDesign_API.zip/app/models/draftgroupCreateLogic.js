/**
 * DraftGroupCreateLogic Model
 * @exports Model/DraftGroup
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * DraftGroups Schema
 */
var DraftGroupCreateLogicSchema = new Schema({
	logicId: {
		type: Number,
		required: true
	},
	sportId: {
		type: Number,
		required: true
	},

	startTimeSuffix: {
		type: String,
		required: true
	},
	startTimeRange: {
		type: String,
		required: true
	},
	endTimeRange: {
		type: String,
		required: true
	},
	timezone: {
		type: String,
		required: true
	},
	minGameFordraftgroup: {
		type: String,
		required: true,
		Default: 2
	},
	totalTimeSlots: {
		type: Number
	},
	totalGamesPerTimeSlots:
	{
		type: Number
	},
	description: { type: String }
},

);

module.exports = mongoose.model('draftgroupcreatelogics', DraftGroupCreateLogicSchema);