/**
 * Player News Model
 * @exports Model/Player News
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;


/**
 * Player News Schema
 */
var PlayerNewsSchema = new Schema({
	sportId: { type: Number },
	league: {
		leagueId: { type: Number },
		abbr: { type: String }
	},
    season: { type: Number },

	playerId: { type: Number },
	fName: { type: String },
	lName: { type: String },
	playerNewsId: { type: Number },
	newsText: { type: String },
	adviceText: { type: String },
	team: {
		teamId: { type: Number },
		tAbbr: { type: String }
	},
	positions: [{
		posId: { type: Number },
		posAbbr: { type: String },
		posName: { type: String },
		sequence: { type: Number },
	}], 
originalDateLocal: { type: Date },
	timezone: { type: String },
	originalDateUtc: { type: Date },
},
	{
		timestamps: true
	}
);

module.exports = mongoose.model('playernews', PlayerNewsSchema);