/**
 * PlayerGames Model
 * @exports Model/PlayerGames
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * PlayerGames Schema
 */
var PlayerGamesSchema = new Schema({
	sportId: {
		type: Number,
		required: true
	},
	playerId: {
		type: Number,
		required: true
	},
	sportsId: {
		type: Number,
		required: true
	},
	gamesJson: Schema.Types.Mixed,
}, {
	timestamps: true
});

module.exports = mongoose.model('playerGames', PlayerGamesSchema);