/**
 * Withdrawal Model
 * @exports Model/Withdrawal
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

/**
 * Withdrawal Schema
 */
var WithdrawalSchema = new Schema({
	userId: {
		type: Number,
		required: true
	},
	userName : {
		type: String,
		required: true
	},
	userEmail : {
		type: String,
		required: true
	},
	amount: {
		type: Number,
		required: true		
	},
	paymentType: {
		type: String
	},
	requestStatus: {
		type: String,
		default: 'P' // P - Pending, C - Closed, R - Rejected, I - In progress
	},	
	createdAt: {
		type: Date,
		default: Date.now
	},
	updatedAt: {
		type: Date,
		default: Date.now
	}		
	
});

module.exports = mongoose.model('withdrawals', WithdrawalSchema);