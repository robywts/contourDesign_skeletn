/**
 *  Friend Requests Model
 * @exports Model/FriendRequest
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

/**
 * Friend Requests Schema
 */
var friendrequestSchema = new Schema({

    fromUserId: {
        type: String,
        required: true
    },
    toUserId: {
        type: String,
        default: ''
    },
    requestStatus: {
        type: Number,
        default: 0
    },
    sentAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    },
    toUserName: {
        type: String,
        default: ''
    },
    toUserImg: {
        type: String,
        default: ''
    },
    fromUserName: {
        type: String,
        default: ''
    },
    fromUserImg: {
        type: String,
        default: ''
    },
    fName: {
        type: String,
        default: ''
    },
    lName: {
        type: String,
        default: ''
    },

});

module.exports = mongoose.model('friendrequests', friendrequestSchema);