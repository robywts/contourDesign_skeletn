/**
 * User Model
 * @exports Model/User
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * Settings Schema
 */
var SettingsSchema = new Schema({
	daily: {
		type: Number,
		default: ''
	},
	weekly: {
		type: Number,
		default: ''
	},
	monthly: {
		type: Number,
		default: ''
	}
});



/**
 * User Schema
 */
var UserSchema = new Schema({
	userId: {
		type: Number,
		required: true,
		index: true,
		unique: true
	},
	userName: {
		type: String,
		//required: true,
		//unique: true
	},
	email: {
		type: String,
		required: true,
		index: true,
		unique: true
	},
	pwd: {
		type: String,
		//	required: true
	},
	btId: {
		type: String,
		//	required: true
	},
	fName: {
		type: String
	},
	lName: {
		type: String
	},
	imageName: {
		type: String
	},
	dob: {
		type: Date
	},
	isAdmin: {
		type: Boolean,
		default: false
	},
	resetCode: {
		type: String
	},
	sessions: [{
		sessionToken: {
			type: String
		},
		deviceToken: {
			default: '',
			type: String
		},
		deviceType: {
			type: Number,
			default: 1,
			comment: '1- IOS, 2 - Android, 0 - Admin',
			enum: [0, 1, 2]
		},
		createdAt: {
			type: Date,
			default: Date.now
		},
		geoSession: {
			geoToken: {
				type: String
			},
			allowed: {
				type: Boolean
			},
			state: {
				type: String
			},
			country: {
				type: String
			},
			lat: {
				type: String
			},
			lng: {
				type: String
			},
			createdAt: {
				type: Date
			}
		}
	}],
	referralMoney: {
		type: Number,
		default: 0
	},
	balance: {
		type: Number,
		default: 0
	},
	totalDeposited: {
		type: Number,
		default: 0
	},
	depositCnt: {
		type: Number,
		default: 0
	},
	balanceTickets: {
		type: Number,
		default: 0
	},
	totalTickets: {
		type: Number,
		default: 0
	},
	balanceRewards: {
		type: Number,
		default: 0
	},
	totalRewards: {
		type: Number,
		default: 0
	},
	userStatus: {
		type: Number,
		default: 1,
		enum: [1, 2, 3] // 1 - Active, 2 - InActive/Blocked, 3 - Deleted
	},
	// withdrawalStatus: {
	// 	type: String,
	// 	default: '' // P - Pending, C - Closed, R - Rejected, I - In progress
	// },
	createdAt: {
		type: Date,
		default: Date.now
	},
	updatedAt: {
		type: Date,
		default: Date.now
	},
	spendLimits: {
		daily: {
			type: Number,
			default: 0
		},
		weekly: {
			type: Number,
			default: 0
		},
		monthly: {
			type: Number,
			default: 0
		},
		maxEntryFee: {
			type: Number,
			default: 0
		}
	},
	depositLimits: {
		daily: {
			type: Number,
			default: 0
		},
		weekly: {
			type: Number,
			default: 0
		},
		monthly: {
			type: Number,
			default: 0
		}
	},
	friends: {
		type: Array,
	},
	isFollowing: {
		type: Array,
	},
	isFollows: {
		type: Array,
	},
	loginTypes: {
		FB: {
			fbToken: {
				type: String
			},
			fbId: {
				type: String
			}
		},
		TW: {
			twToken: {
				type: String
			},
			twId: {
				type: String
			}
		}
	},
	currentLoginType: {
		type: String
	},
	contestList: [{
		contestId: {
			type: Number
		},
		draftgroupId: {
			type: Number
		},
		lineups: {
			type: Array
		},
		sportId: {
			type: Number
		},
		sName: {
			type: String
		},
		contestStatus: {
			type: Number
		},
		position: {
			type: Number
		},
		points: {
			type: SchemaTypes.Double
		}
	}],
	permissions: {
		type: Array,
	},
	h2hCnt: {
		type: Number,
	},
	multiplayerCnt: {
		type: Number,
	},
	totalAmountWon: {
		type: Number,
	},
	avgAmountPerContest: {
		type: Number,
	},
	wins: {
		type: Number,
	},
	promoCode: {
		type: String,
	},
	referrer: {
		type: String,
	},	
	sportsRanking: [{
		sportId: {
			type: Number
		},
		rank: {			
			type: Number
		},	
		subRank: {			
			type: Number
		},
		points: {			
			type: SchemaTypes.Double
		},
		imageName: {
			type: String
		},	
		pointsForCurrentRank: {
			type: SchemaTypes.Double
		},
		pointsForCurrentSubRank: {
			type: SchemaTypes.Double
		},
		pointsForNextRank: {
			type: SchemaTypes.Double
		},
		pointsForNextSubRank: {
			type: SchemaTypes.Double
		},
		createdAt: {
			type: Date,
			default: Date.now
		},	
		updatedAt: {
			type: Date,
			default: Date.now
		}		
	}],
	rank: {		
		type: Number
	},			
	subRank: {			
		type: Number
	},
	rankName: {
		type: String
	},
	rankImageName: {
		type: String
	}
		

	// sMediaId: {
	// 	type: String
	// },

});

module.exports = mongoose.model('users', UserSchema);