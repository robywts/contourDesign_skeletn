/**
 * Rank Image Model
 * @exports Model/RankImage
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * Sports point Schema
 */
var RankImageSchema = new Schema({
	rankImageId: {
		type: Number,
		required: true,
		index: true,
		unique: true
	},
	rank: {
		type: Number		
	},	
	sportRankImage:{
        type: String,
    },	
    userRankImage:{
        type: String,
    },	
	createdAt: {
		type: Date,
		default: Date.now
	},
	updatedAt: {
		type: Date,
		default: Date.now
	},
});

module.exports = mongoose.model('rankImages', RankImageSchema);