/**
 * Team Model
 * @exports Model/Team
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

/**
 * Team Schema
 */
var TeamSchema = new Schema({
	teamId: {
		type: Number,
		required: true,
		unique: true
	},
	nickName: {
		type: String,
		required: true
	},
	country: {
		type: String,
		required: true,
	}
},
	{
		timestamps: true
	}
);

module.exports = mongoose.model('Teams', TeamSchema);