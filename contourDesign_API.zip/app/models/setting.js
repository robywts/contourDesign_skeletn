/**
 * Setting Model
 * @exports Model/Setting
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

/**
 * Setting Schema
 */
var SettingSchema = new Schema({
	settingId: {
		type: Number,
		required: true
	},
	rewardToDollar: {
		type: Number,
		required: true,
		default: 0
	}, // used to calculate the reward points for the user based on the total entry fee for the contest created by the user
	ticketToDollar: {
		type: Number,
		required: true,
		default: 0
	}, // used to calculate the dollar value based on the requested tickets requested to be converted to money
	rewardToTicket: {
		type: Number,
		required: true,
		default: 0
	}, // used to calculate the ticket value based on the requested rewards requested to be converted to money
	rewardToDollarDescri: {
		type: String,
		default: 'To calculate the reward points for the contest created by the user based on the total entry fee.'
	},
	ticketToDollarDescri: {
		type: String,
		default: 'To calculate the Ticket to Dollar conversion ratio.'
	},
	rewardToTicketDescri: {
		type: String,
		default: 'To calculate the Reward to Ticket conversion ratio.'
	},
	updatedById: {
		type: Number,
		required: true
	},
	updatedByName: {
		type: String,
		required: true
	},
	updatedByEmail: {
		type: String,
		required: true
	},
	updatedAt: {
		type: Date,
		default: Date.now
	}

});

module.exports = mongoose.model('settings', SettingSchema);