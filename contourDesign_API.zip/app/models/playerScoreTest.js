/**
 * PlayerScoreTest Model
 * @exports Model/PlayerScoreTest
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * PlayerScoreTest Schema
 */
var PlayerScoreTestSchema = new Schema({
	sportId: {
		type: Number,
		required: true
	},
	eventCode: {
		type: Number,
		required: true
	},
	eventId: {
		type: Number,
		required: true
	},
	eventStatus: {
		type: String,
		required: true
	},
	teamId: {
		type: Number,
		required: true
	},
	teamName: {
		type: String
	},
	teamAlias: {
		type: String
	},
	playerId: {
		type: Number,
		required: true
	},
	awayAbbr: {
		type: String
	},
	homeAbbr: {
		type: String
	},
	awayScore: {
		type: Number
	},
	homeScore: {
		type: Number
	},
	clock: {
		type: String
	},
	isAtBat: {
		type: String
	},
	liveGameInfo: {
		type: String
	},
	liveGameInfo2: {
		type: String
	},
	possTeam: {
		type: String
	},
	playerScore: {
		type: Number
	},
	multiPlayerScore: Schema.Types.Mixed,
	playerPositionId: {
		type: Number
	},
	playerPosition: {
		type: String
	},
	playerName: {
		type: String
	},
	eventDateTime: {
		type: String
	},
	fileName: {
		type: String
	},
	downloadUpdate: {
		type: String
	},
	playerStats: Schema.Types.Mixed,
}, {
	timestamps: true
});

module.exports = mongoose.model('playerScoresTest', PlayerScoreTestSchema);