/**
 * PrizeTemplate Model
 * @exports Model/PrizeTemplate
 */

var mongoose = require('mongoose');
mongoose.set('debug', false);
var Schema = mongoose.Schema;

require('mongoose-double')(mongoose);
var SchemaTypes = mongoose.Schema.Types;

/**
 * PrizeTemplate Schema
 */
var PrizeTemplateSchema = new Schema({
	prizeTmpId: {
		type: Number,
		required: true
	},
	parentPrizeTmpId: {
		type: Number,
		required: false
	},
	tmpName: {
		type: String,
		required: true
	},
	gameTypeId: {
		type: Number,
	},
	gameType: {
		type: String,
	},
	prizeMode: {
		type: String,
	},
	prizeTickets: {
		type: Number,
		default: 0
	},
	prizePool: {
		type: SchemaTypes.Double,
		default: 0
	},
	prizeCurrency: {
		type: String,
		default: 0
	},
	entryFee: {
		type: Number
	},
	rakePerc: {
		type: Number
	},
	minLimit: {
		type: Number,
		default: 0
	},
	maxLimit: {
		type: Number,
		default: 0
	},
	maxEntriesPerUser: {
		type: Number
	},
	prizes: [{
		prizePosition: {
			type: String
		},
		amount: {
			type: SchemaTypes.Double,
			default: 0
		},
		fromRange: {
			type: String
		},
		toRange: {
			type: String
		}
	}],
	status: {
		type: Number,
		default: 1,
		enum: [1, 2]
	},
	createdBy: {
		type: Number
	},
	createdAt: {
		type: Date,
		default: Date.now
	},
	updatedBy: {
		type: Number
	},
	updatedAt: {
		type: Date,
		default: Date.now
	}
});

module.exports = mongoose.model('prizetemplates', PrizeTemplateSchema);