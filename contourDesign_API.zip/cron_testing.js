require('dotenv').config();
require('./app/config/database'); //DB Connection
//NFL
var generalFunctionsCron = require('./app/modules/crons/generalFunctionsCron.js');
var playerScoreMLBCron = require('./app/modules/crons/playerMLBLiveScoreCron.js');
var playerGameStats = require('./app/modules/crons/playerGameStatsCron.js');
var mlbMValueUpdateCron = require('./app/modules/crons/mlbMValueUpdateCron');
var draftGroupCronMLB = require('./app/modules/crons/draftGroupCronMLB');
var generalSchemaUpdateCron = require('./app/modules/crons/generalSchemaUpdateCron');
// console.log(process.argv[2]);
switch (process.argv[2]) {
    case 'socket':
        {
            playerScoreMLBCron.mlbPlayerScoreSocket();
            break;
        }
    case 'download':
        {
            playerScoreMLBCron.mlbPlayerScoreDownload();
            break;
        }
    case 'push':
        {
            playerScoreMLBCron.mlbPlayerScorePush();
            break;
        }
    case 'playergames':
        {
            playerGameStats.playerGameByGameStats(process.argv[3], process.argv[4]); // allGames/annualStats, sportsId (1,2,3,4,5)
            break;
        }
    case 'test':
        {
            generalFunctionsCron.testSocketData();
            break;
        }
    case 'clearLogs':
        {
            generalFunctionsCron.clearLogs();
            break;
        }
    case 'zip':
        {
            playerScoreMLBCron.mlbZipCommand();
            break;
        }
    case 'mValueMLB':
        {
            mlbMValueUpdateCron.updateDraftMValue();
            break;
        }
    case 'DraftMLB':
        {
             draftGroupCronMLB.getDraftGroupDetails();
            break;
        }
    case 'DraftTimeCommon':
        {
             generalSchemaUpdateCron.draftGroupTime();
            break;
        }
}
// process.exit();