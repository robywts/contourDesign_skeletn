# Contour Design REST Api

A simple code documentation for the REST Api code developed in ExpressJs Framework

#### Run the command to Install:
```
npm install //make sure package-lock.json is removed before installing
```

#### Configure the Project:
```
.env
```

#### Start the App:
```
npm run start
npm run devstart //development mode
```

#### Swagger Sandbox Url
Compilation happens automatically
```
http://<domain>/api-docs

Mobile Web Services - http://<domain>/api-docs.json
Admin Web Services - http://<domain>/admin-api-docs.json
```

#### Change the above path in
```
./public/api-docs/index.html
```

#### JsDoc
Compile the document
```
npm run jsdoc
```
View the Documentation
```
./docs/index.html
```

#### Cron
Start the cron (Logs)
```
npm run startcron
npm run devstartcron //development mode
npm run starttelnetmlb //MLB socket connection
```

#### Server File Management
We use a process management tool ([pm2](http://pm2.keymetrics.io/)) to manage the Nodejs processes.
```
pm2 ls //To list the running process
pm2 start <config file> //pm2config.json
```

#### CronTab
We use CronTab in both the servers to restart the pm2 processes if it is stopped (File permission: 0764)
```
crontab -e

*/5 * * * * /home/ubuntu/cdapi/check_pm2_api.sh  >> /home/ubuntu/cdapi/app/modules/crons/logs/pm2_check.log 2>&1
*/5 * * * * /home/ubuntu/cdcron/check_pm2_cron.sh  >> /home/ubuntu/cdcron/app/modules/crons/logs/pm2_check.log 2>&1
```

### Main Links:
* [NodeJs](https://nodejs.org)
* [ExpressJs](https://expressjs.com/)
* [MongoDB](https://www.mongodb.com/)
* [Swagger](https://swagger.io/) - Api WebService Documentation
* [Mongoose](http://mongoosejs.com/) - Object Document Model - For MongoDB operations

### Developer Packages
* [JsDoc](http://usejsdoc.org) - Code Documentation
* [Nodemon](https://nodemon.io) - Automatic Restart of the Application

### Other NPM Packages:
* [Aws-Sdk](https://www.npmjs.com/package/aws-sdk) - For AWS related operation (S3 buck operations)
* [Bcrypt](https://www.npmjs.com/package/bcrypt) - For Password hashing
* [Body-parser](https://www.npmjs.com/package/body-parser) - A package to help the parsing of the request
* [Cron](https://www.npmjs.com/package/cron) - To handle the scheduled tasks
* [Dotenv](https://www.npmjs.com/package/dotenv) - To get the environment values from .env file
* [Fb](https://www.npmjs.com/package/fb) - To handle the Facebook related operations
* [Moment-Timezone](https://www.npmjs.com/package/moment-timezone) - To maintain a customized timezone (mainly used in cron)
* [Multer](https://www.npmjs.com/package/multer) - For File Upload
* [NodeMailer](https://nodemailer.com) - For Email Sending
* [Sharp](https://www.npmjs.com/package/sharp) - For Image Resizing
* [Telnet-Client](https://www.npmjs.com/package/telnet-client) - Telnet Client Package
* [Winston](https://www.npmjs.com/package/winston) - Logging (Mainly used in cron)
* [Xml2Js](https://www.npmjs.com/package/xml2js) - Converting the xml to js object (Mainly used for Telnet data)
* [Braintree](https://developers.braintreepayments.com/start/hello-server/node) - Braintree payment related package
* [Mongoose-double]() - To handle the double values in Mongoose
* [Pusher](https://npmjs.com/package/pusher) - To handle push notification using the Pusher service



