require('dotenv').config();
require('./app/config/database'); //DB Connection

var CronJob = require('cron').CronJob;

var playerScoreMLBCron = require('./app/modules/crons/playerMLBLiveScoreCron');

var winston = require('winston');
var logger = new(winston.Logger)({
  transports: [
    new(winston.transports.Console)(),
    new(winston.transports.File)({
      filename: './app/modules/crons/logs/cronError.log'
    })
  ]
});

const timeZone = 'America/Los_Angeles';

try {
  /**
   * MLB Socket data parsing Cron
   * 
   * @param {String} - Time interval (runs every 5 seconds)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('*/5 * * * * *', function () {
    try {
      playerScoreMLBCron.mlbPlayerScoreSocket();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * MLB data taken from the db and pushed through pusher
   * 
   * @param {String} - Time interval (runs every 1 seconds)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('*/5 * * * * *', function () {
    try {
      playerScoreMLBCron.mlbPlayerScorePush();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * MLB data to be downloaded from stats from xml file
   * 
   * @param {String} - Time interval (runs every 15 mins)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 */5 * * * *', function () {
    try {
      playerScoreMLBCron.mlbPlayerScoreDownload();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * MLB ziping the processed file and deleting it
   * 
   * @param {String} - Time interval (runs every day at 1:15 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 15 1 * * *', function () {
    try {
      playerScoreMLBCron.mlbZipCommand();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

} catch (ex) {
  logger.info(ex);
}