require('dotenv').config();
require('./app/config/database'); //DB Connection

var CronJob = require('cron').CronJob;
//NFL
var playerCron = require('./app/modules/crons/playerCron');
//var teamCron = require('./app/crons/teamCron');
var depthChartCron = require('./app/modules/crons/depthChartCron');
var playerFantasyCron = require('./app/modules/crons/playerFantasy');
var eventScheduleCron = require('./app/modules/crons/eventScheduleCron');
var draftGroupCron = require('./app/modules/crons/draftGroupCron');
//NBA
var eventNBAScheduleCron = require('./app/modules/crons/eventNBAScheduleCron');
var draftGroupCronNBA = require('./app/modules/crons/draftGroupCronNBA');
var nbaMValueUpdateCron = require('./app/modules/crons/nbaMValueUpdateCron');
//MLB
var eventMLBScheduleCron = require('./app/modules/crons/eventMLBScheduleCron');
var draftGroupCronMLB = require('./app/modules/crons/draftGroupCronMLB');
var mlbMValueUpdateCron = require('./app/modules/crons/mlbMValueUpdateCron');
var scoreCronMLB = require('./app/modules/crons/scoreCronMLB');
var salaryCapMLB = require('./app/modules/crons/salaryCapMLB');

//General
var generalSchemaUpdateCron = require('./app/modules/crons/generalSchemaUpdateCron');

var playerGames = require('./cron_server/cron_playerGames');
var rewardPointsMLB = require('./app/modules/crons/rewardPointsMLB');
//user tanking
var sportPointsCron = require('./app/modules/crons/sportPointsCron');
var sportRankingCron = require('./app/modules/crons/sportRankingCron');
var pointsCronMLB =    require('./app/modules/crons/pointsCronMLB');
//AvgFPP
var nflAvgFPPUpdateCron = require('./app/modules/crons/nflAvgFPPUpdateCron');
var nbaAvgFPPUpdateCron = require('./app/modules/crons/nbaAvgFPPUpdateCron');
var mlbAvgFPPUpdateCron = require('./app/modules/crons/mlbAvgFPPUpdateCron');

//var scoreCronMLB = require('./app/modules/crons/scoreCronMLB');

var winston = require('winston');
var logger = new (winston.Logger)({
  transports: [
    new (winston.transports.Console)(),
    new (winston.transports.File)({
      filename: './app/modules/crons/logs/cronError.log'
    })
  ]
});

const timeZone = 'America/Los_Angeles';

try {

  ///////////////////////////////////////////NFL////////////////////////////////////////////////
  /**
   * Player Cron to get basic details related to player - for players schema
   * 
   * @param {String} - Time interval (runs the cron daily at 1 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 0 1 * * *', function () {
    try {
      playerCron.getPlayerDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player Fantasy Cron to get average salary and points related to player - for players schema 
   * 
   * @param {String} - Time interval (runs the cron daily at 1:10 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 10 1 * * *', function () {
    try {
      playerFantasyCron.getPlayerFantasyDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  //team cron
  //new CronJob('0 0 0 * * *', function () {
  //  teamCronData = teamCron.getTeamDetails();
  //}, null, true, timeZone);

  /**
   * Depth Chart Cron to get player position details related to player - for players schema 
   * 
   * @param {String} - Time interval (runs the cron daily at 1:15 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 15 1 * * *', function () {
    try {
      depthChartCron.getDepthChartDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Event Cron to get scheduled NFL game details by week - for events schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:20 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 20 1 * * *', function () {
    try {
      eventScheduleCron.getEventScheduleDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to get event's weather - for events schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:30 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 30 1 * * *', function () {
    try {
      eventScheduleCron.getEventWeatherDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * NFL DraftGroup Cron to create draftgroup based on time slots - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron at 1:35 AM on Monday)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 35 1 * * 1', function () {
    try {
      draftGroupCron.getDraftGroupDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Player news Cron to save player news details - for playernews schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 4:30 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 30 4 * * *', function () {
    try {
      playerCron.getNewsDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Player Injury Cron to save player injury details - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:45 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 45 1 * * *', function () {
    try {
      playerCron.getInjuryDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  ///////////////////////////////////////////NBA////////////////////////////////////////////////

  /**
   * Event Cron to get scheduled NBA game details by day - for events schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 11:51 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 51 11 * * *', function () {
    try {
      eventNBAScheduleCron.getEventScheduleDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Player Cron to get basic details related to NBA player - for players schema
   * 
   * @param {String} - Time interval (runs the cron daily at 1:55 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 55 1 * * *', function () {
    try {
      eventNBAScheduleCron.getPlayerDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player Fantasy Cron to get average salary and points related to NBA player - for players schema 
   * 
   * @param {String} - Time interval (runs the cron daily at 2 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 0 2 * * *', function () {
    try {
      eventNBAScheduleCron.getPlayerFantasyDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player Injury Cron to save NBA player injury details - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 2:15 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 15 2 * * *', function () {
    try {
      eventNBAScheduleCron.getInjuryDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Depth Chart Cron to get player position details related to NBA player - for players schema 
   * 
   * @param {String} - Time interval (runs the cron daily at 2:20 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 20 2 * * *', function () {
    try {
      eventNBAScheduleCron.getDepthChartDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player news Cron to save NBA player news details - for playernews schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 2:25 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 25 2 * * *', function () {
    try {
      eventNBAScheduleCron.getNewsDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * NBA DraftGroup Cron to create draftgroup based on time slots - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 2:45 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 45 2 * * *', function () {
    try {
      draftGroupCronNBA.getDraftGroupDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);



  /**
   * Cron to update mValue value for players(NBA) - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 4:15 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 15 4 * * *', function () {
    try {
      nbaMValueUpdateCron.updateDraftMValue();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  ///////////////////////////////////////////MLB////////////////////////////////////////////////

  /**
   * Event Cron to get scheduled MLB game details by day - for events schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 12:52 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 52 0 * * *', function () {
    try {
      eventMLBScheduleCron.getEventScheduleDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player Cron to get basic details related to MLB player - for players schema
   * 
   * @param {String} - Time interval (runs the cron daily at 12:57 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 57 0 * * *', function () {
    try {
      eventMLBScheduleCron.getPlayerDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player Fantasy Cron to get average salary and points related to MLB player - for players schema 
   * 
   * @param {String} - Time interval (runs the cron daily at 1:02 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 2 1 * * *', function () {
    try {
     // eventMLBScheduleCron.getPlayerFantasyDetails();  //commented since salarycap MLB implemented
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player Injury Cron to save MLB player injury details - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:07 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 7 1 * * *', function () {
    try {
      eventMLBScheduleCron.getInjuryDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Depth Chart Cron to get player position details related to MLB player - for players schema 
   * 
   * @param {String} - Time interval (runs the cron daily at 1:12 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 12 1 * * *', function () {
    try {
      eventMLBScheduleCron.getDepthChartDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Player news Cron to save MLB player news details - for playernews schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:17 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 17 1 * * *', function () {
    try {
      eventMLBScheduleCron.getNewsDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * MLB DraftGroup Cron to create draftgroup based on time slots - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:22 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 22 1 * * *', function () {
    try {
      draftGroupCronMLB.getDraftGroupDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Cron to get MLB event's weather - for events schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:40 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 40 1 * * *', function () {
    try {
      eventMLBScheduleCron.getEventWeatherDetails();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to update mValue value for players(MLB) - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 1:50 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 50 1 * * *', function () {
    try {
      mlbMValueUpdateCron.updateDraftMValue();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to get all MLB Team for the season  
   * 
   * @param {String} - Time interval (runs daily at 11:30 PM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 30 23 * * *', function () {
    try {
      salaryCapMLB.getAllTeam();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to get all MLB Team's average points in the season  
   * 
   * @param {String} - Time interval (runs daily at 11:35 PM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 35 23 * * *', function () {
    try {
      salaryCapMLB.getTeamSeasonPoints();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to get all MLB Team's salary modifier for the season  
   * 
   * @param {String} - Time interval (runs once in a week at 11:40 PM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 40 23 * * 6', function () {
    try {
      salaryCapMLB.getTeamsModifier();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to get all MLB Player's score with respect to events  
   * 
   * @param {String} - Time interval (runs daily at 11:45 PM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 45 23 * * *', function () {
    try {
      salaryCapMLB.getPlayersScoreStats();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to calculate event's player salary  
   * 
   * @param {String} - Time interval (runs daily at 12:15 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 15 0 * * *', function () {
    try {
      salaryCapMLB.setPlayerSalary();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to unset events which are posponed - for events schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 12:55 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 55 0 * * *', function () {
    try {
      eventMLBScheduleCron.unsetPostponedEvents();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  ///////////////////////////////////////////General////////////////////////////////////////////

  /**
   * Cron to update gameStatus value for players - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 3 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 0 3 * * *', function () {
    try {
      generalSchemaUpdateCron.updateDraftPlayers();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to update mValue value for players(NFL,Golf) - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 4:55 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 55 4 * * *', function () {
    try {
      generalSchemaUpdateCron.updateDraftMValue();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to update draftgroup startTimeUTC - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 2 25 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 25 2 * * *', function () {
    try {
      generalSchemaUpdateCron.draftGroupTime();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);


  /**
   * Cron to update draftgroup startTimeUTC - for draftgroups schema  
   * 
   * @param {String} - Time interval (runs the cron daily at 4:05 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 5 4 * * *', function () {
    try {
      generalSchemaUpdateCron.updateDraftGroupStatus();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to delete player news which is older than a month 
   * 
   * @param {String} - Time interval (runs cron once in a day at 6 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 0 6 * * *', function () {
    try {
      generalSchemaUpdateCron.removePlayerNews();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to delete user lineups which is not used in any completed or live contest 
   * 
   * @param {String} - Time interval (runs cron every 13th minute of hour)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 13 * * * *', function () {
    try {
      generalSchemaUpdateCron.removeUnusedLineups();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to distribute the winning amount to users  
   * 
   * @param {String} - Time interval (runs cron daily at 5 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 0 5 * * *', function () {
    try {
      scoreCronMLB.winningDistribution();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

  /**
   * Cron to set new sport points  
   * 
   * @param {String} - Time interval (runs cron daily at 5 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
 /* new CronJob('* * * * * *', function () {    
    try {
      sportPointsCron.configureSportRankingPoints();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone); */


  /**
   * Cron to update user sport ranking  
   * 
   * @param {String} - Time interval (runs cron daily at 5 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
   new CronJob('0 10 7 * * *', function () {    
    try {
    sportRankingCron.setUserRanking();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone);

    /**
   * Cron to update user points MLB
   * 
   * @param {String} - Time interval (runs cron daily at 5 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 3 7 * * *', function () {    
    try {
      pointsCronMLB.updatePointsMLB();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone); 

      /**
   * Cron to update user points NFL  
   * 
   * @param {String} - Time interval (runs cron daily at 5 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 0 7 * * *', function () {    
    try {
      pointsCronMLB.updatePointsNFL();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone); 








   /**
   * Cron to update Avg FPP Value NFL  
   * 
   * @param {String} - Time interval (runs cron daily at 5 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 0 17 * * *', function () {    
    try {
      nflAvgFPPUpdateCron.updateDraftAvgFPPValue();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone); 

   /**
   * Cron to update Avg FPP Value NBA    
   * 
   * @param {String} - Time interval (runs cron daily at 5 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 5 17 * * *', function () {    
    try {
      nbaAvgFPPUpdateCron.updateDraftAvgFPPValue();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone); 

   /**
   * * Cron to update Avg FPP Value MLB  
   * 
   * @param {String} - Time interval (runs cron daily at 5 AM)
   * @param {Callback} - Task to execute
   * @param {String} - By default it is null (event to execute when the job stops)
   * @param {Boolean} - By default it is always true (starts the job right now - at specified time)
   * @param {String} timeZone - By default it is America/Los_Angeles'
   */
  new CronJob('0 10 17 * * *', function () {    
    try {
      mlbAvgFPPUpdateCron.updateDraftAvgFPPValue();
    } catch (ex) {
      logger.info(ex);
    }
  }, null, true, timeZone); 

} catch (ex) {
  logger.info(ex);
}