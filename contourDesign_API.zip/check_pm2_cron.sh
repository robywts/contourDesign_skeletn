#!/bin/bash
PATH=/home/ubuntu/bin:/home/ubuntu/.local/bin:/home/ubuntu/.nvm/versions/node/v9.2.0/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin
#pm2 describe 0 > /dev/null 
#RUNNING=$?  

#if [ "${RUNNING}" -ne 0 ]; then
#    pm2 start /home/ubuntu/cdapi/pm2config_api.json
#else
#    echo "Running"    
#    echo "${RUNNING}"
#fi;

outCron=$(cd /home/ubuntu/cdcron && pm2 describe CD-CRON)
outLiveScore=$(cd /home/ubuntu/cdcron && pm2 describe CD-LIVE-SCORE)
outMLB=$(cd /home/ubuntu/cdcron && pm2 describe CD-SOCKET-MLB)
outSTATS=$(cd /home/ubuntu/cdcron && pm2 describe CD-PLAYER-STATS)
outSECONDS=$(cd /home/ubuntu/cdcron && pm2 describe CD-CRON-SECONDS)
echo $(date +%d-%m-%Y" "%H:%M:%S" ")
if [[ $outCron != *"online"* || $outMLB != *"online"* || $outLiveScore != *"online"* || $outSTATS != *"online"* || $outSECONDS != *"online"*]]; then
  echo "$outCron"
  echo "$outLiveScore"
  echo "$outMLB"
  echo "$outSTATS"
  echo "$outSECONDS"
  (cd /home/ubuntu/cdcron && pm2 start pm2config_cron.json)
  echo "Restarted"
else
  out=$(cd /home/ubuntu/cdcron && pm2 ls)
  echo "$out"
fi