try {
	const exec = require("child_process").exec;
	var cmd = 'bash /home/ubuntu/.nvm/versions/node/v9.2.0/bin/pm2 show ' + process.argv[2];
	var cmdRestart = 'bash /home/ubuntu/.nvm/versions/node/v9.2.0/bin/pm2 restart ' + process.argv[2];

	exec(cmd, (error, stdout, stderr) => {
		try {
			if (error) {
				console.log(new Date() + ': Error Occured');
				console.log(error);
			} else {
				if (stdout.toLowerCase().indexOf('online') > -1) {
					console.log(new Date() + ': Online');
				} else {
					console.log(stdout);
					exec(cmdRestart, (er, sout, serr) => {
						console.log(new Date() + ':Restarted');
					});
				}
			}
		} catch (e) {
			console.log(new Date() + ': Error Caught');
			console.log(e);
		}
	});
} catch (e) {
	console.log(new Date() + ': Error Caught');
	console.log(e);
}